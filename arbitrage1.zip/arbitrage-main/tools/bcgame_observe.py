"""Изолированное наблюдение реального BC.Game без второй ноги и без ставок.

Запуск из корня: python -m tools.bcgame_observe --allow-live-observe --output NEW_DIR
По умолчанию 30 минут. Прокси — только ARB_BCGAME_PROXY_URL, как у адаптера;
нет аргумента с URL/секретом, смены IP, обхода отказов или изменения stale/polling.
Сырые generated/asked_at/updated_at сохраняются без исправлений наблюдателем.
"""

from __future__ import annotations

import argparse
import asyncio
from contextlib import contextmanager
import contextvars
from datetime import datetime, timezone
import gzip
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import sys
import time
from typing import Any

import httpx

from backend.adapters import bcgame as module
from backend.adapters.bcgame import BcGameAdapter, PROXY_ENV
from backend.config import load_settings
from backend.engine.arb import is_fresh
from backend.engine.scanner import BOOK_FIELDS, Scanner
from backend.storage.db import Database
from tools.bcgame_observation_report import analyze, packet_counts, write_summary

CURRENT = contextvars.ContextVar("bcgame_observation_request", default=None)
MERGING = contextvars.ContextVar("bcgame_observation_read", default=None)
PUBLIC_HEADERS = ("date", "age", "cache-control", "content-encoding", "last-modified", "etag", "cf-cache-status", "x-cache")


def mark() -> dict:
    """UTC — для сопоставления с источником, monotonic_ns — только для интервалов."""
    return {"utc": datetime.now(timezone.utc).isoformat(), "mono_ns": time.monotonic_ns()}


def json_default(value: Any) -> str:
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError("Unsupported diagnostic value")


def milliseconds(start: dict, end: dict) -> float:
    return (end["mono_ns"] - start["mono_ns"]) / 1e6


class Journal:
    """Новый каталог 0700, файлы 0600; приватные заголовки/URL/тексты ошибок не пишем."""

    def __init__(self, root: Path, capture_packets: bool = False):
        self.root = Path(root).absolute()
        self.root.mkdir(mode=0o700, parents=True, exist_ok=False)
        self.handle = os.fdopen(self.create_file("events.jsonl"), "w", encoding="utf-8")
        self.capture_packets = capture_packets
        self.sequence = 0
        self.quote_previous: dict[tuple, str] = {}

    def create_file(self, name: str) -> int:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
        return os.open(self.root / name, flags, 0o600)

    def emit(self, stage: str, *, at: dict | None = None, **values: Any) -> dict:
        row = {"stage": stage, **(at or mark()), **values}
        self.handle.write(json.dumps(row, default=json_default, ensure_ascii=False, allow_nan=False) + "\n")
        self.handle.flush()
        return row

    def capture(self, request_id: int, payload: dict) -> None:
        if not self.capture_packets:
            return
        started = mark()
        body = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
        with os.fdopen(self.create_file(f"packet-{request_id:06d}.json.gz"), "wb") as handle:
            handle.write(gzip.compress(body, compresslevel=1, mtime=0))
        self.emit("capture_write", started=started, request_id=request_id, duration_ms=milliseconds(started, mark()))

    def close(self) -> None:
        self.handle.close()


@contextmanager
def private_logging(journal: Journal):
    """Даже traceback сторонней библиотеки не должен раскрыть credentialed proxy URL."""
    class Handler(logging.Handler):
        def emit(self, record):
            journal.emit("log", logger=record.name, level=record.levelname,
                         error_type=record.exc_info[0].__name__ if record.exc_info else None)

    handler = Handler()
    saved = []
    for name in ("", "adapter.bcgame", "backend.engine.scanner", "httpx", "httpcore"):
        logger = logging.getLogger(name)
        saved.append((logger, logger.handlers[:], logger.propagate, logger.level))
        logger.handlers, logger.propagate = [handler], False
        logger.setLevel(logging.WARNING)
    try:
        yield
    finally:
        for logger, handlers, propagate, level in saved:
            logger.handlers, logger.propagate = handlers, propagate
            logger.setLevel(level)
        handler.close()


class Stream(httpx.AsyncByteStream):
    """Отметка конца чтения тела, отдельно от получения заголовков."""

    def __init__(self, wrapped, trace):
        self.wrapped, self.trace = wrapped, trace

    async def __aiter__(self):
        async for chunk in self.wrapped:
            yield chunk
        self.trace["body_received"] = mark()

    async def aclose(self):
        await self.wrapped.aclose()


class Semaphore:
    def __init__(self, wrapped):
        self.wrapped = wrapped

    async def __aenter__(self):
        trace = CURRENT.get()
        if trace is not None:
            trace["semaphore_wait_started"] = mark()
        await self.wrapped.__aenter__()
        if trace is not None:
            trace["semaphore_acquired"] = mark()
        return self

    async def __aexit__(self, *args):
        return await self.wrapped.__aexit__(*args)


def market_values(market) -> dict:
    values = {"market": market.key, "updated_at": market.updated_at,
              "asks": [market.outcome_a_ask, market.outcome_b_ask], "accepting_orders": market.accepting_orders}
    for key in ("bcgame_quote_times", "bcgame_quote_sources", "timestamp_kind", "actual_price_change_at"):
        if key in market.extra:
            values[key] = market.extra[key]
    return values


def winner(event: Any) -> dict:
    markets = event.get("markets") if isinstance(event, dict) else None
    variants = markets.get("186") if isinstance(markets, dict) else None
    selections = variants.get("") if isinstance(variants, dict) else None
    return selections if isinstance(selections, dict) else {}


@contextmanager
def observe_merges(adapter):
    """Обёртка только на время CLI; чужой адаптер и исходная merge-функция не меняются."""
    native = module.merge_payload

    def merge(old, patch):
        context = MERGING.get()
        if context is None or context["adapter"] is not adapter:
            return native(old, patch)
        started = mark()
        result = native(old, patch)
        ended = mark()
        changes = {k: [] for k in ("winner_initialized", "winner_changed_existing", "winner_unchanged", "winner_deleted")}
        for event_id in patch.get("events", {}):
            before, after = winner(old.get("events", {}).get(event_id)), winner(result["events"].get(event_id))
            for side in set(before) | set(after):
                if side not in before:
                    label = "winner_initialized"
                elif side not in after:
                    label = "winner_deleted"
                elif before[side] != after[side]:
                    label = "winner_changed_existing"
                else:
                    label = "winner_unchanged"
                changes[label].append(f"{event_id}:{side}")
        adapter.journal.emit("merged", at=ended, started=started, duration_ms=milliseconds(started, ended),
                             channel=context["channel"], request_id=context.get("request_id"),
                             version=patch.get("version"), event_patches=len(patch.get("events", {})), **changes)
        return result

    module.merge_payload = merge
    try:
        yield
    finally:
        module.merge_payload = native


class ObservationAdapter(BcGameAdapter):
    """Те же запросы/guards/данные, дополнительные отметки на границах обработки."""

    def __init__(self, *args, journal: Journal, **kwargs):
        super().__init__(*args, **kwargs)
        self.journal = journal
        self.phase = contextvars.ContextVar("bcgame_observation_phase", default="delta")
        self.sync_context = contextvars.ContextVar("bcgame_observation_sync", default=None)
        self._semaphore = Semaphore(self._semaphore)
        acquire = self._limit.acquire

        async def timed_acquire(*args, **kwargs):
            trace = CURRENT.get()
            if trace is not None:
                trace["rate_wait_started"] = mark()
            result = await acquire(*args, **kwargs)
            if trace is not None:
                trace["token_acquired"] = mark()
            return result

        self._limit.acquire = timed_acquire
        # Фиксируем единственную конфигурацию до сбоя; не перечитываем прокси при reopen.
        self._http_options = {"base_url": self.api_url, "timeout": self.http.timeout,
                              "follow_redirects": False, "trust_env": False,
                              "proxy": os.getenv(PROXY_ENV, "").strip() or None}
        self.generation = 0
        self.snapshots = self.deltas = self.failures = self.skipped_normalizations = 0
        self.installed = None
        self.fault = None
        self.fault_active = False
        self.normalization_finished: dict[str, dict] = {}
        self.book_installed: dict[str, tuple] = {}
        self._attach_http_hooks()

    def _attach_http_hooks(self):
        self.http.event_hooks["request"].append(self._request_started)
        self.http.event_hooks["response"].append(self._headers_received)
        client, generation = self.http, self.generation
        native_get = client.get

        async def get(*args, **kwargs):
            trace = CURRENT.get()
            started, was_closed = mark(), client.is_closed
            if trace is not None:
                trace["client_get_started"] = started
                trace["transport_generation"] = generation
            try:
                return await native_get(*args, **kwargs)
            except (RuntimeError, httpx.TransportError) as exc:
                # Контекст окна не доказывает причинность: HTTP-отказ/JSON сюда не попадают.
                if trace is not None and self.fault and client is self.fault["client"] and client.is_closed:
                    if was_closed and isinstance(exc, RuntimeError):
                        trace["fault_error_basis"] = "fault_closed_client"
                    elif (isinstance(exc, httpx.TransportError)
                          and started["mono_ns"] <= self.fault["injected"]["mono_ns"]
                          and "body_received" not in trace):
                        trace["fault_error_basis"] = "inflight_transport_closed_by_fault"
                raise

        client.get = get

    def _new_http(self):
        return httpx.AsyncClient(**self._http_options)

    async def _request_started(self, request):
        trace = CURRENT.get()
        if trace is not None:
            trace["http_started"] = mark()

    async def _headers_received(self, response):
        trace = CURRENT.get()
        if trace is None:
            return
        trace["headers_received"] = mark()
        trace["http_status"] = response.status_code
        trace["headers"] = {k: response.headers[k] for k in PUBLIC_HEADERS if k in response.headers}
        if response.is_stream_consumed:
            trace["body_received"] = mark()
        else:
            response.stream = Stream(response.stream, trace)
        native = response.json

        def parse(*args, **kwargs):
            trace["parse_started"] = mark()
            try:
                return native(*args, **kwargs)
            finally:
                trace["parse_finished"] = mark()
                trace["body_bytes"] = len(response.content)
                trace["body_sha256"] = hashlib.sha256(response.content).hexdigest()

        response.json = parse

    async def _get(self, channel, version):
        self.journal.sequence += 1
        trace = {"request_id": self.journal.sequence, "phase": self.phase.get(), "channel": channel,
                 "requested_version": version, "enqueued": mark(), "transport_generation": self.generation,
                 "fault_error_basis": None}
        context = MERGING.get()
        if context is not None and context["adapter"] is self:
            context["request_id"] = trace["request_id"]
        token = CURRENT.set(trace)
        try:
            data, asked = await super()._get(channel, version)
            trace["parent_returned"] = mark()
            trace["asked_at"] = asked.isoformat()
            trace["response"] = {k: data.get(k) for k in (
                "epoch", "version", "generated", "snapshot_complete", "top_events_versions", "rest_events_versions")}
            trace["has_index_marker"] = "top_events_versions" in data
            trace["counts"] = {k: len(data.get(k, {}) or {}) for k in ("sports", "categories", "tournaments", "events")}
            trace["packet_counts"] = packet_counts(data)
            touched, changed = [], []
            events = data.get("events")
            for event_id, event in events.items() if isinstance(events, dict) else ():
                for side, value in winner(event).items():
                    key = (channel, event_id, side)
                    fingerprint = json.dumps(value, sort_keys=True)
                    touched.append(f"{event_id}:{side}")
                    if self.journal.quote_previous.get(key) != fingerprint:
                        changed.append(f"{event_id}:{side}")
                    self.journal.quote_previous[key] = fingerprint
            # Сохраняем legacy-поля baseline; реальные изменения после merge записаны отдельно.
            trace["winner_touched"], trace["winner_changed"] = touched, changed
            self.journal.emit("http", **trace)
            sync = self.sync_context.get()
            if sync is not None:
                sync["requests"].append(trace)
            self.journal.capture(trace["request_id"], data)
            return data, asked
        except asyncio.CancelledError:
            self.journal.emit("http_cancelled", **trace)
            raise
        except Exception as exc:
            self.failures += 1
            injected = trace["fault_error_basis"] is not None
            self.journal.emit("http_error", **trace, error_type=type(exc).__name__,
                              error_status=getattr(exc, "status", None), injected=injected,
                              in_fault_window=self.fault_active,
                              fault_id=self.fault["id"] if self.fault and (injected or self.fault_active) else None)
            raise
        finally:
            CURRENT.reset(token)

    async def _snapshot(self, channel, *args, **kwargs):
        # previous=None может появиться в адаптере независимо от диагностического CLI.
        context = MERGING.get()
        merge_token = None
        if context is None or context["adapter"] is not self:
            merge_token = MERGING.set({"adapter": self, "channel": channel})
        elif context.get("previous") is not None:
            self.journal.emit("feed_reset", channel=channel, old_version=context["previous"].version,
                              old_epoch=context["previous"].epoch, reason="adapter_requested_resnapshot")
        token = self.phase.set("snapshot")
        started = mark()
        try:
            state = await super()._snapshot(channel, *args, **kwargs)
            self.snapshots += 1
            context = MERGING.get()
            context["snapshot"] = True
            self.journal.emit("snapshot_accepted", started=started, channel=channel, version=state.version,
                              epoch=state.epoch, generated_at=state.generated_at, asked_at=state.asked_at,
                              events=len(state.data["events"]))
            return state
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.journal.emit("snapshot_error", started=started, channel=channel, error_type=type(exc).__name__)
            raise
        finally:
            self.phase.reset(token)
            if merge_token is not None:
                MERGING.reset(merge_token)

    async def _read(self, channel, previous):
        context = {"adapter": self, "channel": channel, "previous": previous, "snapshot": False}
        token = MERGING.set(context)
        try:
            state = await super()._read(channel, previous)
            if previous is not None and not context["snapshot"]:
                self.deltas += 1
                self.journal.emit("delta_accepted", channel=channel, old_version=previous.version, version=state.version,
                                  epoch=state.epoch, generated_at=state.generated_at, asked_at=state.asked_at)
            sync = self.sync_context.get()
            if sync is not None:
                sync["read_finished"] = mark()
            return state
        finally:
            MERGING.reset(token)

    async def _sync(self):
        started = mark()
        context = {"requests": []}
        token = self.sync_context.set(context)
        try:
            await super()._sync()
            self.installed = mark()
            self.journal.emit("state_installed", at=self.installed, started=context.get("read_finished"),
                              sync_started=started, versions={k: v.version for k, v in self.feeds.items()},
                              request_ids=[t["request_id"] for t in context["requests"]],
                              boundary="last_read_return_to_sync_return")
            if self.fault and "reopened" in self.fault and not self.fault.get("recovered"):
                new_requests = [t for t in context["requests"] if t["transport_generation"] == self.generation
                                and t.get("http_started", {}).get("mono_ns", 0) >= self.fault["reopened"]["mono_ns"]]
                if new_requests:
                    self.fault["recovered"] = True
                    self.journal.emit("fault_recovered", fault_id=self.fault["id"], installed=self.installed,
                                      request_id=new_requests[-1]["request_id"], transport_generation=self.generation)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.journal.emit("sync_error", started=started, error_type=type(exc).__name__)
            raise
        finally:
            self.sync_context.reset(token)

    def _market(self, event_id, state, channel):
        started = mark()
        result = super()._market(event_id, state, channel)
        ended = mark()
        if result is None:
            self.skipped_normalizations += 1
        else:
            self.normalization_finished[result.key] = ended
            self.journal.emit("normalized", at=ended, started=started, version=state.version, epoch=state.epoch,
                              channel=channel, duration_ms=milliseconds(started, ended), **market_values(result))
        return result

    def _set_source_books(self, market, a, b, stamp):
        # Нормализация создаёт временный объект: это ещё не книга в модели Scanner.
        subscribed = self._subscribed.get(market.key) is market
        started = mark() if subscribed else None
        result = super()._set_source_books(market, a, b, stamp)
        if subscribed:
            ended = mark()
            self.book_installed[market.key] = (market, ended)
            self.journal.emit("engine_book_installed", at=ended, started=started,
                              normalized_finished=self.normalization_finished.get(market.key),
                              boundary="subscribed_source_book_setter_call", duration_ms=milliseconds(started, ended),
                              **market_values(market))
        return result

    def _invalidate(self, market):
        target = self._subscribed.get(market.key)
        previous = self.book_installed.get(market.key)
        started = mark()
        result = super()._invalidate(market)
        if self.book_installed.get(market.key) is previous:
            self.book_installed.pop(market.key, None)
        if target is not None:
            self.journal.emit("engine_book_invalidated", started=started, boundary="invalidate_call_envelope",
                              book_install_duration="not_measured", **market_values(target))
        return result

    def _publish(self, *args, **kwargs):
        started = mark()
        try:
            return super()._publish(*args, **kwargs)
        finally:
            ended = mark()
            self.journal.emit("publish_finished", at=ended, started=started, duration_ms=milliseconds(started, ended))

    def notify(self, market):
        started = mark()
        installed = self.book_installed.get(market.key)
        self.journal.emit("published", at=started, installed=self.installed,
                          book_installed=installed[1] if installed and installed[0] is market else None,
                          **market_values(market))
        super().notify(market)
        ended = mark()
        self.journal.emit("publish_callback_finished", at=ended, started=started, market=market.key,
                          duration_ms=milliseconds(started, ended))

    async def inject_fault(self, duration: float):
        """Закрываем именно HTTP-клиент; native backoff/guards и часы остаются прежними."""
        self.fault = {"id": 1, "injected": mark(), "client": self.http}
        self.fault_active = True
        self.journal.emit("fault_injected", at=self.fault["injected"], fault_id=1, duration_sec=duration,
                          method="close_http_client", transport_generation=self.generation)
        self.journal.emit("controlled_fault_window", duration_sec=duration, fault_id=1)
        try:
            await self.http.aclose()
            self.journal.emit("fault_transport_closed", fault_id=1)
            await asyncio.sleep(duration)
            self.http = self._new_http()
            self.generation += 1
            self._attach_http_hooks()
            self.fault_active = False
            self.fault["reopened"] = mark()
            self.journal.emit("fault_transport_reopened", at=self.fault["reopened"], fault_id=1,
                              transport_generation=self.generation, same_configuration=True)
        except asyncio.CancelledError:
            self.journal.emit("fault_cancelled", fault_id=1, transport_reopened="reopened" in self.fault)
            raise
        except Exception as exc:
            self.journal.emit("fault_error", fault_id=1, error_type=type(exc).__name__)
            raise


class ProbeScanner(Scanner):
    """Настоящий цикл Scanner и is_fresh, но только одна реальная площадка."""

    def __init__(self, settings, adapters, db, *, journal):
        if set(adapters) != {"bcgame"} or not isinstance(adapters["bcgame"], BcGameAdapter):
            raise ValueError("Observation requires only the real BC.Game adapter")
        super().__init__(settings, adapters, db)
        self.journal = journal
        self.checks = self.nonempty = 0

    def _on_price(self, market):
        self.journal.emit("engine_received", **market_values(market))
        return super()._on_price(market)

    def _merge(self, platform, fetched):
        current = self.markets.get(platform, {})
        before = {key: (market, market.model_dump(include=BOOK_FIELDS)) for key, market in current.items()}
        started = mark()
        result = super()._merge(platform, fetched)
        ended = mark()
        adapter = self.adapters[platform]
        for incoming in fetched:
            target = self.markets[platform][incoming.key]
            previous = before.get(incoming.key)
            if previous is None or previous[0] is not target or previous[1] != target.model_dump(include=BOOK_FIELDS):
                # Регистрация/merge имеют лишь общую границу вызова, не точный setter на рынок.
                adapter.book_installed.pop(target.key, None)
                self.journal.emit("engine_market_registered" if previous is None or previous[0] is not target
                                  else "engine_discovery_books_merged",
                                  at=ended, started=started, boundary="scanner_merge_call_envelope",
                                  normalized_finished=adapter.normalization_finished.get(target.key),
                                  book_install_duration="not_measured", **market_values(target))
        for key in set(before) - set(self.markets[platform]):
            adapter.book_installed.pop(key, None)
        return result

    def _report_paired(self, pairs, review):
        super()._report_paired(pairs, review)
        # Только диагностический быстрый приоритет реальных рынков, без фиктивных пар.
        self.adapters["bcgame"].set_paired(set(self.markets["bcgame"]))

    async def evaluate(self):
        if self.pairs:
            raise RuntimeError("Observation must not evaluate counterpart legs")
        checked = mark()
        now = datetime.fromisoformat(checked["utc"])
        self.journal.emit("engine_tick", at=checked, markets=len(self.markets["bcgame"]))
        for market in self.markets["bcgame"].values():
            nonempty = bool(market.asks_a and market.asks_b and market.accepting_orders)
            self.checks += 1
            self.nonempty += int(nonempty)
            self.journal.emit("engine_check", at=checked, **market_values(market),
                              age_sec=(now - market.updated_at).total_seconds() if market.updated_at else None,
                              fresh=is_fresh(market, now, self.settings.engine.stale_seconds), nonempty=nonempty)
        return await super().evaluate()


def validate_args(args) -> None:
    """Проверка также внутри run: прямой вызов не обходит явное согласие."""
    if not args.allow_live_observe:
        raise ValueError("Требуется --allow-live-observe для запросов реального публичного фида")
    for value in (args.duration, args.fault_duration):
        if not math.isfinite(value) or value <= 0:
            raise ValueError("Длительность должна быть положительным конечным числом секунд")
    if args.fault_at is not None and (
        not math.isfinite(args.fault_at) or args.fault_at < 0 or args.fault_at + args.fault_duration >= args.duration
    ):
        raise ValueError("Окно сбоя должно целиком помещаться в наблюдение с временем на восстановление")


async def run(args) -> dict:
    validate_args(args)
    journal = Journal(args.output, args.capture_packets)
    began = mark()
    adapter = scanner = db = fault_task = None
    outcome = "error"
    try:
        with private_logging(journal):
            try:
                settings = load_settings(args.config)
                adapter = ObservationAdapter("bcgame", settings.platforms["bcgame"], settings, journal=journal)
                os.close(journal.create_file("observer.db"))
                db = Database(journal.root / "observer.db")
                scanner = ProbeScanner(settings, {"bcgame": adapter}, db, journal=journal)
                journal.emit("run_started", format_version=2, implementation=args.label, duration_sec=args.duration,
                             poll_interval_sec=adapter.poll_sec, slow_poll_interval_sec=adapter.slow_poll_sec,
                             rate_limit_per_sec=adapter.cfg.opt("rate_limit_per_sec", 1),
                             request_timeout_sec=adapter.cfg.opt("request_timeout_sec", 5),
                             stale_seconds=settings.engine.stale_seconds, eval_interval_ms=settings.engine.eval_interval_ms,
                             discovery_refresh_sec=settings.discovery.refresh_seconds, include_live=adapter.include_live,
                             market_priority="all_observed_markets", diagnostic_fast_priority=True, only_one_venue=True,
                             enabled_in_application=adapter.cfg.enabled, quote_change_timestamp="not_supplied_by_source",
                             source_generated_semantics="unknown", individual_quote_change_time="unknown",
                             measurement_note="instrumented_boundaries_include_observer_overhead",
                             fault_attribution="closed_fault_client_only",
                             packet_capture_enabled=args.capture_packets, fault_at_sec=args.fault_at,
                             fault_duration_sec=args.fault_duration if args.fault_at is not None else None)
                with observe_merges(adapter):
                    try:
                        await db.connect()
                        await scanner.start()
                        if args.fault_at is not None:
                            async def fault_window():
                                await asyncio.sleep(max(0, args.fault_at - milliseconds(began, mark()) / 1000))
                                await adapter.inject_fault(args.fault_duration)
                            fault_task = asyncio.create_task(fault_window(), name="observation:transport-fault")
                        await asyncio.sleep(max(0, args.duration - milliseconds(began, mark()) / 1000))
                        outcome = "completed"
                    finally:
                        if fault_task is not None:
                            if not fault_task.done():
                                fault_task.cancel()
                            await asyncio.gather(fault_task, return_exceptions=True)
                        await scanner.stop()
            except asyncio.CancelledError:
                outcome = "interrupted"
                raise
            except Exception as exc:
                outcome = "error"
                journal.emit("run_error", error_type=type(exc).__name__)
            finally:
                if scanner is None and adapter is not None:
                    await adapter.stop()
                if db is not None:
                    try:
                        await db.close()
                    except Exception as exc:
                        outcome = "error"
                        journal.emit("shutdown_error", error_type=type(exc).__name__)
                journal.emit("run_finished", outcome=outcome, duration_sec=milliseconds(began, mark()) / 1000,
                             snapshots=adapter.snapshots if adapter else 0, deltas=adapter.deltas if adapter else 0,
                             errors=adapter.failures if adapter else 0, engine_checks=scanner.checks if scanner else 0,
                             nonempty_checks=scanner.nonempty if scanner else 0,
                             skipped_normalizations=adapter.skipped_normalizations if adapter else 0,
                             observed_markets=len(scanner.markets["bcgame"]) if scanner else 0)
    finally:
        journal.close()
        result = analyze(journal.root)
        write_summary(journal.root / "summary.json", result)
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--allow-live-observe", action="store_true", help="Явное согласие на чтение публичного фида")
    parser.add_argument("--output", required=True, type=Path, help="Новый приватный каталог (не существующий)")
    parser.add_argument("--duration", type=float, default=1800, help="Длительность в секундах, по умолчанию 1800")
    parser.add_argument("--label", default="observation", help="Метка реализации для сравнения baseline/after")
    parser.add_argument("--fault-at", type=float, help="Закрыть HTTP-клиент через N секунд от старта")
    parser.add_argument("--fault-duration", type=float, default=15, help="Через N секунд открыть тот же транспорт")
    parser.add_argument("--capture-packets", action="store_true", help="Сохранять только публичные JSON-payload в gzip")
    parser.add_argument("--config", type=Path, help="Обычный config.yaml проекта; не файл с credentials")
    args = parser.parse_args(argv)
    try:
        validate_args(args)
    except ValueError as exc:
        parser.error(str(exc))
    try:
        result = asyncio.run(run(args))
    except KeyboardInterrupt:
        print("Наблюдение прервано; сохранённые данные не считаются завершённым прогоном.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"Наблюдение не завершено ({type(exc).__name__}); приватные детали не выводятся.", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if result["validation"]["ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
