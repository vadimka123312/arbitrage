"""Офлайн-отчёт BC.Game: python -m tools.bcgame_observation_report DIRECTORY.

Читает также events.jsonl и packet-*.json.gz временного baseline-наблюдателя.
Возраст относится к часам модели, а generated — к сообщению, не доказанному
моменту изменения отдельной котировки. Отчёт не переопределяет is_fresh.
"""

from __future__ import annotations

import argparse
from collections import Counter, OrderedDict, defaultdict
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import gzip
import json
import math
import os
from pathlib import Path
import sys
from typing import Any, Iterable


def summary(values: Iterable[float | None]) -> dict:
    """Линейные перцентили, как в baseline; None/NaN/Infinity не являются данными."""
    ordered = sorted(float(v) for v in values if finite(v))
    if not ordered:
        return {"n": 0}

    def percentile(q: float) -> float:
        position = (len(ordered) - 1) * q
        low = int(position)
        return ordered[low] + (ordered[min(low + 1, len(ordered) - 1)] - ordered[low]) * (position - low)

    return {"n": len(ordered), "median": round(percentile(.5), 6), "p95": round(percentile(.95), 6),
            "max": round(ordered[-1], 6), "min": round(ordered[0], 6)}


def finite(value: Any) -> bool:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def dt(value: Any) -> datetime | None:
    """Не приписываем UTC строке, если источник не указал часовой пояс."""
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return stamp if stamp.tzinfo is not None else None
    except (AttributeError, TypeError, ValueError):
        return None


def source_time(value: Any) -> datetime | None:
    """В протоколе generated измеряется в миллисекундах Unix, не в секундах."""
    if isinstance(value, str):
        try:
            value = float(value)
        except ValueError:
            return None
    if not finite(value):
        return None
    try:
        return datetime.fromtimestamp(value / 1000, timezone.utc)
    except (ValueError, OverflowError, OSError):
        return None


def elapsed_ms(start: Any, end: Any) -> float | None:
    """Локальные интервалы считаем исключительно по monotonic_ns."""
    if not isinstance(start, dict) or not isinstance(end, dict):
        return None
    a, b = start.get("mono_ns"), end.get("mono_ns")
    return (b - a) / 1e6 if finite(a) and finite(b) and b >= a else None


def packet_counts(payload: dict) -> dict[str, int]:
    """Считаем маркеры удаления/блокировки, а не угадываем число удалённых книг."""
    counts = Counter(event_deletes=0, winner_deletes=0, winner_suspends=0, event_resets=0, null_deletes=0)

    def nulls(value: Any) -> int:
        if isinstance(value, dict):
            return sum(1 if v is None else nulls(v) for v in value.values())
        return 0

    counts["null_deletes"] = sum(nulls(payload.get(k)) for k in ("sports", "categories", "tournaments", "events"))
    events = payload.get("events")
    for event in events.values() if isinstance(events, dict) else ():
        if event is None:
            counts["event_deletes"] += 1
        if not isinstance(event, dict):
            continue
        counts["event_resets"] += bool(event.get("shouldResetEvent"))
        markets = event.get("markets")
        if not isinstance(markets, dict) or "186" not in markets:
            continue
        winner = markets["186"]
        if winner is None:
            counts["winner_deletes"] += 1
            continue
        if not isinstance(winner, dict) or "" not in winner:
            continue
        selections = winner[""]
        if selections is None:
            counts["winner_deletes"] += 1
        elif isinstance(selections, dict):
            for value in selections.values():
                counts["winner_deletes"] += value is None
                counts["winner_suspends"] += isinstance(value, dict) and value.get("b") in (1, "1")
    return dict(counts)


class _LifecycleUnavailable(Exception):
    """Недостаточно свидетельств для точного lifecycle-счётчика, не нулевой результат."""


def _merge_observed_event(old: dict, patch: dict) -> dict:
    """Только raw event/Winner: null, reset и сброс Winner при смене соперников."""
    def merge(before, changes):
        result = before.copy()
        for key, value in changes.items():
            if value is None:
                result.pop(key, None)
            elif isinstance(value, dict) and isinstance(result.get(key), dict):
                result[key] = merge(result[key], value)
            else:
                result[key] = value
        return result

    before = {} if patch.get("shouldResetEvent") else old
    old_desc = before.get("desc") or {}
    # Отсутствующий desc сохраняет привязку; явный null её удаляет, как native merge.
    new_desc = patch["desc"] if "desc" in patch else old_desc
    teams = old_desc.get("competitors") if isinstance(old_desc, dict) else None
    new_teams = new_desc.get("competitors", teams) if isinstance(new_desc, dict) else None
    if teams and teams != new_teams:
        markets = before.get("markets")
        before = {**before, "markets": {k: v for k, v in markets.items() if k != "186"} if isinstance(markets, dict) else {}}
    projected = {k: v for k, v in patch.items() if k in ("desc", "state")}
    if "markets" in patch:
        markets = patch["markets"]
        projected["markets"] = {"186": markets["186"]} if isinstance(markets, dict) and "186" in markets else (
            {} if isinstance(markets, dict) else markets)
    return merge(before, projected)


def _winner_unavailable(event: dict | None, channel: str) -> str | None:
    """Raw-доступность, не повтор полной нормализации, matching или математики."""
    if event is None:
        return "event_missing"
    state = event.get("state")
    status = state.get("status") if isinstance(state, dict) else None
    if isinstance(status, bool) or status not in ((0, 1) if channel == "live" else (0,)):
        return "event_inactive"
    markets = event.get("markets")
    variants = markets.get("186") if isinstance(markets, dict) else None
    selections = variants.get("") if isinstance(variants, dict) else None
    if not isinstance(selections, dict) or set(selections) != {"4", "5"}:
        return "winner_missing"
    if any(not isinstance(v, dict) for v in selections.values()):
        return "winner_missing"
    if any(v.get("b") in (1, "1") for v in selections.values()):
        return "winner_suspended"
    for value in selections.values():
        try:
            odds = float(value.get("k"))
        except (TypeError, ValueError, OverflowError):
            return "winner_quote_missing"
        if not math.isfinite(odds) or odds <= 1:
            return "winner_quote_missing"
    return None


def installed_lifecycle(root: Path, observed: set[str]) -> dict:
    """Ограниченный replay только установленных пакетов и нормализованных BC.Game IDs.

    В памяти остаются проекции наблюдаемых событий и последние 256 HTTP-ссылок;
    один распакованный payload ограничен 10 MB. Нет связи install→packet — нет
    доказанного нуля. Неполный snapshot/неустановленный delta не меняет raw-состояние.
    """
    observed = {key for key in observed if key.startswith("bcgame:")}
    ids = {key.split(":", 1)[1] for key in observed}
    pending: OrderedDict = OrderedDict()
    feeds, identities = {}, {}
    reasons, invalid, disappeared = set(), set(), set()
    by_reason: Counter = Counter()
    markers: Counter = Counter(packet_counts({}))
    checked = unknown = reused = installations = disappearances = 0

    def load(request):
        try:
            with gzip.open(root / f'packet-{request["request_id"]:06d}.json.gz', "rb") as handle:
                body = handle.read(10_000_001)
            if len(body) > 10_000_000:
                raise _LifecycleUnavailable("packet_size_limit")
            data = json.loads(body)
        except FileNotFoundError:
            raise _LifecycleUnavailable("packet_capture_missing") from None
        except (OSError, EOFError, ValueError, UnicodeError, RecursionError):
            raise _LifecycleUnavailable("packet_capture_unreadable") from None
        if not isinstance(data, dict) or any(
            isinstance(data.get(k), bool) or not str(data.get(k)).isdigit() or len(str(data.get(k))) > 24
            or str(data.get(k)) != str(request.get(k)) for k in ("epoch", "version")
        ):
            raise _LifecycleUnavailable("packet_identity_mismatch")
        return data

    def channel_state(channel, requests):
        roots = [i for i, request in enumerate(requests) if str(request["requested_version"]) == "0"]
        requests = requests[roots[-1]:] if roots else requests
        state = {} if roots else feeds.get(channel)
        identity = None if roots else identities.get(channel)
        local_markers: Counter = Counter()
        if state is None:
            raise _LifecycleUnavailable("no_installed_snapshot_base")
        if roots:
            index = load(requests[0])
            top, rest = index.get("top_events_versions"), index.get("rest_events_versions")
            if requests[0]["phase"] != "snapshot" or not isinstance(top, list) or not isinstance(rest, list):
                raise _LifecycleUnavailable("snapshot_index_missing")
            parts = list(dict.fromkeys(str(v) for v in top + rest))
            if (not parts or len(parts) > 64 or any(not p.isdigit() or p == "0" or len(p) > 24 for p in parts)
                    or [str(r["requested_version"]) for r in requests[1:]] != parts):
                raise _LifecycleUnavailable("snapshot_parts_incomplete")
            identity = (str(index.get("epoch")), str(index.get("version")))
            requests = requests[1:]
        for position, request in enumerate(requests):
            data = load(request)
            if request["phase"] != ("snapshot" if roots else "delta"):
                raise _LifecycleUnavailable("snapshot_index_missing")
            if str(data.get("epoch")) != identity[0] or "top_events_versions" in data or str(data.get("version")) == "0":
                raise _LifecycleUnavailable("reset_without_complete_snapshot")
            if not roots and str(request["requested_version"]) != identity[1]:
                raise _LifecycleUnavailable("delta_cursor_mismatch")
            if roots and position == len(requests) - 1 and data.get("snapshot_complete") is not True:
                raise _LifecycleUnavailable("snapshot_parts_incomplete")
            events = data.get("events", {})
            if not isinstance(events, dict):
                raise _LifecycleUnavailable("invalid_events_table")
            relevant = {key: value for key, value in events.items() if key in ids}
            state = state.copy()
            for key, value in relevant.items():
                if value is None:
                    state.pop(key, None)
                elif isinstance(value, dict):
                    state[key] = _merge_observed_event(state.get(key, {}), value)
                else:
                    raise _LifecycleUnavailable("invalid_event_entry")
            local_markers.update(packet_counts({"events": relevant}))
            identity = (str(data["epoch"]), str(data["version"]))
        return state, identity, local_markers

    with (root / "events.jsonl").open(encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            row = json.loads(line)
            if row["stage"] == "http":
                request_id = row.get("request_id")
                if isinstance(request_id, int) and not isinstance(request_id, bool) and request_id > 0:
                    pending[request_id] = {"request_id": request_id, "channel": row.get("channel"), "phase": row.get("phase"),
                                           "requested_version": row.get("requested_version"), **row.get("response", {})}
                    if len(pending) > 256:
                        pending.popitem(last=False)
            elif row["stage"] == "state_installed":
                versions = row.get("versions", {})
                try:
                    request_ids = row.get("request_ids")
                    if not isinstance(request_ids, list) or not request_ids:
                        raise _LifecycleUnavailable("installed_request_ids_missing")
                    if (len(request_ids) > 256 or any(not isinstance(r, int) or isinstance(r, bool) or r <= 0 for r in request_ids)
                            or len(set(request_ids)) != len(request_ids) or any(r not in pending for r in request_ids)):
                        raise _LifecycleUnavailable("installed_request_link_missing")
                    groups = defaultdict(list)
                    for request_id in request_ids:
                        request = pending[request_id]
                        if request["channel"] not in ("prematch", "live"):
                            raise _LifecycleUnavailable("installed_channels_unknown")
                        groups[request["channel"]].append(request)
                    if not isinstance(versions, dict) or not groups or set(groups) != set(versions) or not set(groups) <= {"prematch", "live"}:
                        raise _LifecycleUnavailable("installed_channels_unknown")
                    candidate, next_identities, next_markers = {}, {}, Counter()
                    for channel, requests in groups.items():
                        state, identity, local_markers = channel_state(channel, requests)
                        if identity[1] != str(versions[channel]):
                            raise _LifecycleUnavailable("installed_cursor_mismatch")
                        candidate[channel], next_identities[channel] = state, identity
                        next_markers.update(local_markers)
                    for channel, state in candidate.items():
                        gone = set(feeds.get(channel) or {}) - set(state)
                        disappeared.update(gone)
                        disappearances += len(gone)
                    feeds, identities = candidate, next_identities
                    markers.update(next_markers)
                    installations += 1
                except _LifecycleUnavailable as exc:
                    reasons.add(str(exc))
                    feeds, identities = {}, {}
                pending.clear()
            elif row["stage"] == "engine_check" and row.get("market") in observed:
                if not feeds:
                    unknown += 1
                    continue
                checked += 1
                event_id = row["market"].split(":", 1)[1]
                channel = next((c for c in ("live", "prematch") if event_id in feeds.get(c, {})), "prematch")
                reason = _winner_unavailable(feeds.get(channel, {}).get(event_id), channel)
                if reason and row.get("nonempty") is True and row.get("fresh") is True:
                    invalid.add(row["market"])
                    reused += 1
                    by_reason[reason] += 1
    if not installations:
        reasons.add("no_linked_installed_state")
    if not checked:
        reasons.add("no_checkable_engine_samples")
    if unknown:
        reasons.add("engine_samples_without_installed_state")
    measured = not reasons
    return {"status": "measured" if measured else "not_measured", "not_measured_reasons": sorted(reasons),
            "invalid_reused_markets": len(invalid) if measured else None,
            "invalid_reused_samples": reused if measured else None,
            "invalid_reused_market_keys": sorted(invalid) if measured else None,
            "invalid_reused_samples_by_reason": dict(by_reason) if measured else None,
            "observed_installed_packet_markers": dict(markers) if measured else None,
            "observed_event_disappearances": disappearances if measured else None,
            "observed_disappeared_markets": len(disappeared) if measured else None,
            "linked_installations": installations, "checked_samples": checked, "not_measured_samples": unknown,
            "verified_invalid_reused_markets": len(invalid) if checked else None,
            "verified_invalid_reused_samples": reused if checked else None,
            "cross_reset_quote_chronology": "not_measured",
            "clock_safety": "not_assessed_by_raw_availability_even_when_reuse_is_zero",
            "scope": "normalized_bcgame_ids_against_installed_raw_event_state_and_winner_186_only"}


def write_summary(path: Path, result: dict) -> None:
    """Новый файл 0600; существующий отчёт/пакет/БД никогда не перезаписываем."""
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def analyze(root: Path) -> dict:
    """Основные счётчики JSONL и отдельный bounded replay установленных публичных пакетов."""
    root = Path(root)
    stages: Counter = Counter()
    samples: Counter = Counter(total=0, nonempty=0, empty=0, fresh_nonempty=0, stale_nonempty=0,
                               unknown_timestamp=0, unknown_timestamp_nonempty=0,
                               unknown_freshness_nonempty=0, blocked=0, negative_age=0)
    counts: Counter = Counter(observed_price_changes=0, unchanged_publications=0, unchanged_price_clock_updates=0,
                              empty_or_suspended_publications=0, injected_http_errors=0, fault_window_http_errors=0,
                              source_time_reversals=0,
                              event_deletes=0, winner_deletes=0, winner_suspends=0, event_resets=0, null_deletes=0,
                              winner_initialized=0, winner_changed_existing=0, winner_unchanged=0, winner_deleted=0)
    durations: dict[str, list] = defaultdict(list)
    ages: list[float] = []
    market_ages: dict[str, list] = defaultdict(list)
    normalized: set[str] = set()
    received: dict[str, dict] = {}
    checked_receipts: dict[str, int] = {}
    published: dict[str, dict] = {}
    last_marks: dict[tuple, dict] = {}
    last_source: dict[tuple, datetime] = {}
    last_books: dict[str, tuple] = {}
    last_stamps: dict[str, Any] = {}
    cursors: Counter = Counter()
    returned_cursors: Counter = Counter()
    payloads: Counter = Counter()
    faults: dict[int, dict] = {}
    zero_market_ticks = 0
    fault_attribution_unknown = fault_window_unknown = False
    first = last = started = finished = None

    def interval(label: str, key: tuple, row: dict) -> None:
        previous = last_marks.get((label, *key))
        value = elapsed_ms(previous, row)
        if value is not None:
            durations[label].append(value / 1000)
        last_marks[(label, *key)] = row

    with (root / "events.jsonl").open(encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            row = json.loads(line)
            stage = row["stage"]
            first = first or row
            last = row
            stages[stage] += 1
            key = row.get("market", "")
            if stage == "run_started":
                started = row
            elif stage == "run_finished":
                finished = row
            elif stage in ("http", "http_error"):
                for label, a, b in (
                    ("queue_ms", "enqueued", "token_acquired"),
                    ("semaphore_ms", "enqueued", "semaphore_acquired"),
                    ("rate_ms", "semaphore_acquired", "token_acquired"),
                    ("http_ms", "token_acquired", "body_received"),
                    ("headers_ms", "http_started", "headers_received"),
                    ("body_ms", "headers_received", "body_received"),
                    ("parse_ms", "parse_started", "parse_finished"),
                    ("request_total_ms", "enqueued", "parent_returned"),
                ):
                    if label == "semaphore_ms":
                        a = "semaphore_wait_started" if "semaphore_wait_started" in row else a
                    elif label == "rate_ms":
                        a = "rate_wait_started" if "rate_wait_started" in row else a
                    value = elapsed_ms(row.get(a), row.get(b))
                    if value is not None:
                        durations[label].append(value)
                if stage == "http_error":
                    if row.get("injected") and "fault_error_basis" not in row:
                        fault_attribution_unknown = True
                    else:
                        counts["injected_http_errors"] += bool(row.get("injected"))
                    counts["fault_window_http_errors"] += row.get("in_fault_window") is True
                    fault_window_unknown |= "in_fault_window" not in row
                    counts["http_status_" + str(row.get("error_status"))] += 1
                    continue
                channel, phase = row.get("channel", "prematch"), row.get("phase", "delta")
                response = row.get("response", {})
                cursors[(channel, str(row.get("requested_version")))] += 1
                if phase == "delta":
                    counts["delta_requests"] += 1
                    counts["index_markers_in_delta"] += bool(row.get("has_index_marker"))
                    returned_cursors[(channel, str(response.get("epoch")), str(response.get("version")))] += 1
                digest = row.get("body_sha256")
                if digest:
                    payloads[digest] += 1
                interval("http_response_interval_sec", (channel, phase), row)
                generated = source_time(response.get("generated"))
                body = dt(row.get("body_received", {}).get("utc"))
                asked = dt(row.get("asked_at"))
                if generated and body:
                    age = (body - generated).total_seconds()
                    durations["source_age_at_body_sec"].append(age)
                    durations[phase + "_source_age_at_body_sec"].append(age)
                if generated and asked:
                    difference = (generated - asked).total_seconds()
                    durations["source_minus_request_start_sec"].append(difference)
                    durations["request_start_clamp_would_lose_sec"].append(max(0, difference))
                    durations[phase + "_request_start_clamp_would_lose_sec"].append(max(0, difference))
                if generated:
                    previous = last_source.get((channel, phase))
                    if previous:
                        difference = (generated - previous).total_seconds()
                        durations["source_generated_interval_sec"].append(difference)
                        counts["source_time_reversals"] += difference < 0
                    last_source[(channel, phase)] = generated
                date = row.get("headers", {}).get("date")
                if body and date:
                    try:
                        server_date = parsedate_to_datetime(date)
                        if server_date.tzinfo:
                            durations["http_date_clock_difference_sec"].append((body - server_date).total_seconds())
                    except (TypeError, ValueError, OverflowError):
                        pass
                metrics = row.get("packet_counts")
                request_id = row.get("request_id")
                if metrics is None and isinstance(request_id, int) and request_id > 0:
                    path = root / f"packet-{request_id:06d}.json.gz"
                    if path.is_file():
                        with gzip.open(path, "rt", encoding="utf-8") as packet:
                            metrics = packet_counts(json.load(packet))
                for name, value in (metrics or {}).items():
                    if finite(value):
                        counts[name] += value
            elif stage in ("merged", "normalized", "capture_write", "publish_finished", "publish_callback_finished"):
                durations[stage + "_ms"].append(row.get("duration_ms"))
                if stage == "normalized":
                    normalized.add(key)
                if stage == "merged":
                    for name in ("winner_initialized", "winner_changed_existing", "winner_unchanged", "winner_deleted"):
                        counts[name] += len(row.get(name, []))
            elif stage == "snapshot_accepted":
                durations["snapshot_total_ms"].append(elapsed_ms(row.get("started"), row))
            elif stage == "state_installed":
                durations["feed_state_install_ms"].append(elapsed_ms(row.get("started"), row))
                durations["sync_total_ms"].append(elapsed_ms(row.get("sync_started"), row))
                interval("feed_state_install_interval_sec", (), row)
            elif stage == "engine_book_installed":
                durations["engine_book_install_duration_ms"].append(row.get("duration_ms"))
                durations["normalize_to_engine_book_install_ms"].append(elapsed_ms(row.get("normalized_finished"), row))
            elif stage in ("engine_market_registered", "engine_discovery_books_merged"):
                durations["discovery_merge_envelope_ms"].append(elapsed_ms(row.get("started"), row))
                durations["normalize_to_engine_registration_ms"].append(elapsed_ms(row.get("normalized_finished"), row))
            elif stage == "published":
                published[key] = row
                interval("publication_interval_sec", (key,), row)
                durations["feed_state_to_publish_ms"].append(elapsed_ms(row.get("installed"), row))
                durations["engine_book_install_to_publish_ms"].append(elapsed_ms(row.get("book_installed"), row))
                asks = row.get("asks")
                book = tuple(asks) if isinstance(asks, list) and len(asks) == 2 and all(finite(v) for v in asks) else None
                previous = last_books.get(key)
                if book is not None and row.get("accepting_orders", True):
                    if previous is not None and book != previous:
                        counts["observed_price_changes"] += 1
                        interval("observed_price_change_interval_sec", (key,), row)
                    elif previous == book:
                        counts["unchanged_publications"] += 1
                    if previous == book and last_stamps.get(key) != row.get("updated_at"):
                        counts["unchanged_price_clock_updates"] += 1
                    last_books[key] = book
                else:
                    counts["empty_or_suspended_publications"] += 1
                previous_stamp, stamp = dt(last_stamps.get(key)), dt(row.get("updated_at"))
                if previous_stamp and stamp and previous_stamp != stamp:
                    durations["model_timestamp_interval_sec"].append((stamp - previous_stamp).total_seconds())
                last_stamps[key] = row.get("updated_at")
            elif stage == "engine_received":
                received[key] = row
                durations["publish_callback_ms"].append(elapsed_ms(published.get(key), row))
            elif stage == "engine_tick":
                zero_market_ticks += row.get("markets") == 0
            elif stage == "engine_check":
                samples["total"] += 1
                unknown = dt(row.get("updated_at")) is None
                samples["unknown_timestamp"] += unknown
                samples["blocked"] += unknown or not row.get("nonempty") or row.get("fresh") is not True
                receipt = received.get(key)
                if receipt and checked_receipts.get(key) != receipt.get("mono_ns"):
                    durations["first_engine_check_ms"].append(elapsed_ms(receipt, row))
                    checked_receipts[key] = receipt.get("mono_ns")
                if not row.get("nonempty"):
                    samples["empty"] += 1
                    continue
                samples["nonempty"] += 1
                label = "unknown_timestamp_nonempty" if unknown else (
                    "fresh_nonempty" if row.get("fresh") is True else (
                        "stale_nonempty" if row.get("fresh") is False else "unknown_freshness_nonempty"))
                samples[label] += 1
                age = row.get("age_sec")
                if not unknown and finite(age):
                    ages.append(age)
                    market_ages[key].append(age)
                    samples["negative_age"] += age < 0
                now = dt(row.get("utc"))
                provenance = row.get("bcgame_quote_times")
                if now and isinstance(provenance, dict):
                    for side in ("4", "5"):
                        stamp = dt(provenance.get(side))
                        if stamp:
                            durations["quote_provenance_age_sec"].append((now - stamp).total_seconds())
            elif stage in ("fault_injected", "fault_transport_closed", "fault_transport_reopened", "fault_recovered", "fault_cancelled"):
                fault = faults.setdefault(row.get("fault_id", 1), {})
                fault[stage] = row

    nonempty = samples["nonempty"]
    fault_summary = {"scheduled": bool(started and started.get("fault_at_sec") is not None),
                     "injected": stages["fault_injected"], "transport_closed": stages["fault_transport_closed"],
                     "transport_reopened": stages["fault_transport_reopened"],
                     "recovered": stages["fault_recovered"], "cancelled": stages["fault_cancelled"],
                     "errors": stages["fault_error"]}
    for fault in faults.values():
        for label, a, b in (("fault_close_ms", "fault_injected", "fault_transport_closed"),
                            ("fault_transport_closed_ms", "fault_transport_closed", "fault_transport_reopened"),
                            ("fault_recovery_ms", "fault_injected", "fault_recovered"),
                            ("fault_reopen_to_feed_ms", "fault_transport_reopened", "fault_recovered")):
            durations[label].append(elapsed_ms(fault.get(a), fault.get(b)))
    reasons = []
    if not finished or finished.get("outcome", "completed") != "completed":
        reasons.append("run_not_completed")
    if not stages["snapshot_accepted"]:
        reasons.append("no_accepted_snapshot")
    if not normalized:
        reasons.append("no_normalized_markets")
    if not nonempty:
        reasons.append("no_nonempty_engine_samples")
    if not ages:
        reasons.append("no_valid_model_age_samples")
    if fault_summary["scheduled"] and not (
        fault_summary["injected"] == fault_summary["transport_closed"] == fault_summary["transport_reopened"] == fault_summary["recovered"] == 1
        and not fault_summary["cancelled"] and not fault_summary["errors"]
    ):
        reasons.append("controlled_fault_not_recovered")
    counts["repeated_requested_cursors"] = sum(v - 1 for v in cursors.values())
    counts["repeated_returned_delta_cursors"] = sum(v - 1 for v in returned_cursors.values())
    counts["duplicate_payloads"] = sum(v - 1 for v in payloads.values())
    counts["http_errors"] = stages["http_error"]
    counts["snapshot_errors"] = stages["snapshot_error"]
    counts["sync_errors"] = stages["sync_error"]
    counts["run_errors"] = stages["run_error"]
    counts["feed_resets"] = stages["feed_reset"]
    counts["http_successes"] = stages["http"]
    counts["accepted_snapshots"] = stages["snapshot_accepted"]
    counts["accepted_deltas"] = stages["delta_accepted"]
    counts["payload_digest_samples"] = sum(payloads.values())
    if fault_attribution_unknown:
        counts["injected_http_errors"] = None
    if fault_window_unknown:
        counts["fault_window_http_errors"] = None
    return {
        "format_version": 2,
        "from_utc": first.get("utc") if first else None,
        "until_utc": last.get("utc") if last else None,
        "duration_sec": (elapsed_ms(first, last) / 1000) if elapsed_ms(first, last) is not None else None,
        "implementation": started.get("implementation") if started else None,
        "stages": dict(stages), "counts": dict(counts), "engine_samples": dict(samples),
        "age_at_engine_sec": summary(ages),
        "age_by_market_sec": {k: summary(v) for k, v in sorted(market_ages.items())},
        "fresh_share": samples["fresh_nonempty"] / nonempty if nonempty else None,
        "stale_share": samples["stale_nonempty"] / nonempty if nonempty else None,
        "unknown_share": (samples["unknown_timestamp_nonempty"] + samples["unknown_freshness_nonempty"]) / nonempty
        if nonempty else None,
        "blocked_share": samples["blocked"] / samples["total"] if samples["total"] else None,
        "engine_tick_coverage": {"status": "measured" if stages["engine_tick"] else "not_measured",
                                 "ticks": stages["engine_tick"] or None,
                                 "zero_market_ticks": zero_market_ticks if stages["engine_tick"] else None,
                                 "with_markets_share": 1 - zero_market_ticks / stages["engine_tick"]
                                 if stages["engine_tick"] else None,
                                 "fresh_share_denominator": "nonempty_engine_samples_only"},
        "fresh_share_all_engine_samples": samples["fresh_nonempty"] / samples["total"] if samples["total"] else None,
        "stale_seconds": started.get("stale_seconds") if started else None,
        "durations": {k: summary(v) for k, v in sorted(durations.items())},
        "measurement_boundaries": {
            "feed_state_install_ms": "last_read_return_to_sync_return_envelope_not_engine_book",
            "engine_book_timings": {key: "measured" if any(finite(v) for v in durations.get(key, [])) else "not_measured"
                                    for key in ("engine_book_install_duration_ms", "normalize_to_engine_book_install_ms",
                                                "engine_book_install_to_publish_ms")},
            "engine_book_install_duration_ms": "subscribed_object_source_book_setter_call_only",
            "discovery_book_install_duration": "not_measured_scanner_merge_envelope_only",
            "invalidation_book_install_duration": "not_measured_invalidate_call_envelope_only",
        },
        "unique_normalized_markets": len(normalized),
        "delta_requests": counts["delta_requests"], "index_markers_in_delta": counts["index_markers_in_delta"],
        "repeated_requested_cursors": counts["repeated_requested_cursors"],
        "faults": fault_summary,
        "lifecycle": installed_lifecycle(root, normalized),
        "validation": {"ok": not reasons, "reasons": reasons,
                       "meaning": "nonempty_diagnostic_capture_not_a_freshness_or_arbitrage_verdict"},
        "timestamp_semantics": {"source_generated_unit": "unix_milliseconds", "source_generated_meaning": "unknown",
                                "individual_quote_change_time": "unknown", "local_intervals": "monotonic_ns",
                                "age_at_engine": "adapter_model_updated_at", "fresh": "recorded_is_fresh_result",
                                "clamp_loss": "counterfactual_not_applied_to_quotes",
                                "quote_changes": "observed_public_asks_not_source_change_timestamps"},
        "observation_scope": {"only_one_venue": started.get("only_one_venue") if started else None,
                              "market_priority": started.get("market_priority") if started else None,
                              "packet_markers": "entire_public_feed_not_only_normalized_markets",
                              "readiness": "not_assessed"},
        "run_finished": finished,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path, help="Новый приватный JSON-файл; без флага только stdout")
    args = parser.parse_args(argv)
    try:
        result = analyze(args.directory)
        if args.output:
            write_summary(args.output, result)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"Не удалось прочитать наблюдение ({type(exc).__name__}); детали не выводятся.", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if result["validation"]["ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
