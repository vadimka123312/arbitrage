# Аудит freshness telemetry и last-good cache

Дата: 2026-10-20. База: `origin/main` `0a98a220769f72736d98ec16aac5318682774d2a`.

Ветка: `vorflux/freshness-cache-telemetry`.

## Итог

Временные ошибки HTTP 500, 403, 429 и timeout уже сохраняли последний корректный кэш всех четырёх адаптеров.
Найденные дефекты относились к ответам HTTP 200:

- malformed discovery payload мог выглядеть как пустой список;
- partial book payload мог частично изменить внутренний кэш;
- элемент без структуры стакана мог стать пустым свежим стаканом;
- достижение pagination cap могло опубликовать неполный список;
- malformed Kalshi series payload мог заменить last-good metadata;
- API не показывал основание timestamp и отдельно не сообщал время изменения коэффициента.

Исправление не меняет `stale_seconds`, matching, fee logic, execution и формулу арбитража. Новые источники не добавлены.

## Почему в отчётах разные количества тестов

Актуальный `origin/main` собирал и выполнял:

```text
479 Python tests
27 Node tests
```

Другие числа имеют четыре причины:

1. Это результаты более ранних commit. Число тестов росло вместе с Stake, paper и BC.Game.
2. Часть записей относится к профильным наборам, а не к полной регрессии.
3. В handoff есть результаты незакоммиченных промежуточных состояний.
4. `181 passed` относится к отдельному репозиторию surebet3.

Не вошедшая в main ветка `origin/vorflux/fix-bcgame-status-metrics` собирает 481 Python и 30 Node tests. Она не была базой этой работы.

После текущих 23 новых parametrized cases актуальное число этой ветки:

```text
502 Python tests
27 Node tests
```

CI не проверяет фиксированное число. CI выполняет `python -m pytest -q` и `node --test tests/js/*.test.mjs`.

## Полный путь timestamp

### Общий путь

1. Адаптер получает полный response или WebSocket message.
2. Адаптер разбирает payload и вызывает `NormalizedMarket.set_books(..., ts)`.
3. `set_books()` записывает asks, bids, sizes и `updated_at`.
4. `Scanner._merge()` сохраняет более новый book при rediscovery.
5. После `subscribe_prices()` адаптеры изменяют scanner market objects на месте.
6. `evaluate_pair()` вызывает `is_fresh(market, now, stale_seconds)`.
7. Текущий `stale_seconds` равен 10 секундам.
8. Paper checks отдельно вызывают `fetch_book()` и повторяют stale check.

### Polymarket

- REST: `updated_at` равен локальному времени получения полного `/books` batch.
- WebSocket: `updated_at` равен времени book/price frame.
- PONG подтверждает живое последовательное соединение и обновляет receive confirmation для snapshotted tokens.
- Exchange timestamp сохраняется отдельно для диагностики и ordering.
- Рынок использует более старое время двух outcome books.

### Kalshi

- REST: `updated_at` равен локальному времени получения полного orderbook batch.
- WebSocket: `updated_at` равен времени snapshot/delta.
- Keepalive подтверждает живое последовательное соединение для snapshotted tickers.
- Orderbook API не предоставляет надёжный timestamp изменения цены.
- Рынок использует более старое время двух books.

### Stake

- `updated_at` равен времени отправки запроса `/fixtures/{slug}`.
- Timestamp назначается только после успешного разбора полного fixture response.
- Повторный полный response подтверждает текущее состояние, даже если odds не изменились.
- Provider timestamp изменения конкретного коэффициента не используется.

### BC.Game

- `updated_at` равен времени завершённой coherent feed synchronization.
- `generated` хранится как source-message telemetry.
- Per-outcome evidence не обновляется при неизменившемся коэффициенте.
- Источник не предоставляет достоверное время фактического изменения коэффициента.

## Семантика freshness

`updated_at` означает время подтверждения согласованного состояния, а не время фактического изменения цены.

Это различие важно:

- неизменившаяся цена не становится устаревшей только потому, что её значение не изменилось;
- локальный timestamp не выдаётся за provider price-change timestamp;
- `actual_price_change_at` остаётся `null`, если источник его не предоставляет;
- source timestamp выводится отдельно, если он доступен;
- engine продолжает использовать прежний `updated_at` и прежний порог.

API market view теперь содержит:

```text
timestamp_kind
source_book_timestamp
actual_price_change_at
```

Эти поля диагностические. Они не участвуют в расчёте арбитража.

## Найденные дефекты и исправления

### 1. Polymarket malformed discovery

Было: non-list body завершал pagination как обычный конец списка. Scanner мог удалить last-good markets.

Стало: malformed body вызывает `ValueError`. Discovery loop сохраняет существующие markets.

### 2. Kalshi malformed discovery

Было: body без `events` превращался в пустой список.

Стало: body обязан содержать `events` list. Иначе discovery считается failed и last-good markets сохраняются.

### 3. Truncated pagination

Было: Polymarket, Kalshi или Stake могли достичь настроенного page cap и вернуть неполный список.

Стало: незавершённая pagination вызывает ошибку. Неполный список не передаётся в `Scanner._merge()`.

### 4. Partial orderbook responses

Было: Polymarket и Kalshi применяли элементы ответа по мере разбора. Позднее обнаруженный missing token мог оставить half-snapshot во внутреннем кэше.

Стало:

- весь poll сначала проверяется во временном `pending` state;
- каждый запрошенный token/ticker должен присутствовать;
- только после полной проверки state публикуется атомарно;
- при partial payload last-good cache и market `updated_at` не меняются.

WebSocket book с более новым source timestamp продолжает иметь приоритет над REST.

### 5. Missing book object

Было: item без `asks`/`bids` или `orderbook` мог стать пустым свежим book.

Стало: missing book structure считается incomplete payload.

Явно переданный пустой book остаётся допустимым authoritative state. Это важно для закрытого или временно пустого стакана.

### 6. Kalshi series metadata

Было: malformed HTTP 200 мог заменить last-good series metadata пустым dict и установить часовой cache timer.

Стало: malformed metadata не заменяет last-good value и не запускает успешный cache timer.

### 7. Stake malformed fixture

Было: fixture без `groups` мог выглядеть как рынок, который больше не предлагается.

Стало: `groups` обязан быть list. Malformed response не заменяет last-good odds.

## Проверенные failure cases

Новые offline tests проверяют Polymarket и Kalshi для:

- HTTP 500;
- HTTP 403;
- HTTP 429;
- timeout;
- пустого response list;
- partial response;
- item без book structure;
- malformed body.

Для каждого случая проверяется:

- last-good books не меняются;
- per-book timestamps не меняются;
- market `updated_at` не меняется;
- platform `last_update` не выдаёт failure за успешное обновление.

Отдельные tests проверяют:

- malformed discovery;
- pagination truncation;
- Kalshi last-good series metadata;
- Stake malformed fixture;
- timestamp provenance в API view.

## Что намеренно не изменено

### Heartbeat confirmation

Polymarket PONG и Kalshi WebSocket keepalive продолжают подтверждать состояние после принятого snapshot.
Изменение этой семантики меняет arb availability и требует отдельного решения.

Риск остаётся: malformed stream event может быть пропущен, а heartbeat продолжит подтверждать connection liveness.
Для изменения нужен отдельный resync protocol и tests sequence-gap behavior.

### BC.Game source age

BC.Game `generated` остаётся diagnostic timestamp. Старый `generated` не блокирует coherent response.
Добавление age gate изменит arb behavior и требует отдельного продуктового решения.

### Stake empty fixture list

Валидный пустой fixture list остаётся authoritative. Требование двух пустых ответов подряд было бы новым фильтром.

### Explicitly empty order book

Полный response с обоими запрошенными пустыми books очищает asks. Это корректное состояние «котировок нет».

### Unchanged odds

Полный coherent response с неизменившимися odds подтверждает текущее состояние. Он не утверждает, что цена изменилась.

## Изменённые файлы

- `backend/adapters/polymarket.py`
- `backend/adapters/kalshi.py`
- `backend/adapters/stake.py`
- `backend/engine/scanner.py`
- `tests/test_freshness_cache.py`
- `tests/test_net_and_freshness.py`
- `CLAUDE.md`
- `docs/handoff/*`

## Результаты проверки

```text
Focused freshness and adapter suite: 109 passed
Full Python suite: 502 passed, 1 warning in 24.54s
Node suite: 27 passed, 0 failed in 85.38ms
python -m compileall -q backend tests: success
git diff --check: success
```

Warning: Starlette сообщает deprecated использование `httpx` в `fastapi.testclient`. Это существующее предупреждение.

Живая сеть не использовалась. Все failure cases проверены через `httpx.MockTransport`.

## Риски регрессии

1. Недокументированный partial response теперь вызывает retry/backoff вместо частичного обновления.
2. Слишком маленький `max_pages` теперь явно ломает discovery вместо тихого усечения.
3. Malformed Stake fixture теперь сохраняет старую котировку до обычного stale timeout вместо немедленного удаления.
4. Atomic multi-batch commit обязан не перезаписывать более новый WebSocket state. Это покрыто отдельными гонками
   для Polymarket PONG и Kalshi disconnect.
4. Новые API-поля могут быть проигнорированы старым frontend. Текущий frontend совместим с добавочными полями.
5. Explicit empty complete books всё ещё очищают asks, поэтому источник должен отличать empty от malformed.

## Quality review

Первый review нашёл две multi-batch гонки и дал risk 5/10, Block. Обе гонки исправлены:

- Polymarket сохраняет более позднее PONG confirmation при равном source timestamp.
- Kalshi сохраняет WS book при обновлении во время REST pass, даже если WebSocket отключился до commit.

Повторный review не нашёл actionable defects. Итог: risk 3/10, Low, Safe to ship.

## Критерии принятия PR

PR можно принять, если выполнены все условия:

1. `python -m pytest -q` даёт 502 passed.
2. `node --test tests/js/*.test.mjs` даёт 27 pass.
3. CI проходит на Python 3.12 и Node 20.
4. HTTP 500/403/429/timeout не меняют last-good cache и `updated_at`.
5. Malformed и partial HTTP 200 не публикуют half-snapshot.
6. Полный response с обоими пустыми books остаётся допустимым и удаляет asks.
7. Полный unchanged response продолжает подтверждать coherent state.
8. `stale_seconds`, matching, fees, execution и arb formulas не меняются.
9. Новые telemetry fields не участвуют в `is_fresh()` или `evaluate_pair()`.
10. Diff не содержит secrets, generated data или посторонних файлов.
