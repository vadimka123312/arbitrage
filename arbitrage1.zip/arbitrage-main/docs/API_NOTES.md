# API notes (verified 2026-10-15; Stake 2026-10-16; BC.Game 2026-10-19)

Verified with live requests from the dev machine and the current docs
(`https://docs.polymarket.com/llms.txt`, `https://docs.kalshi.com/llms.txt`).
APIs change; re-check these notes when something breaks.

## Polymarket

| Purpose | Endpoint | Auth | Limit (Cloudflare, per IP) |
| --- | --- | --- | --- |
| Sports list, tag and series ids | `GET https://gamma-api.polymarket.com/sports` | no | 4000 req / 10 s (general) |
| Events + nested markets | `GET https://gamma-api.polymarket.com/events?series_id=<id>&closed=false&end_date_min=<iso>&limit=100&offset=<n>` | no | 500 req / 10 s |
| One order book | `GET https://clob.polymarket.com/book?token_id=<id>` | no | 1500 req / 10 s |
| Many order books | `POST https://clob.polymarket.com/books` body `[{"token_id": "..."}]` | no | 500 req / 10 s |
| Live books | `wss://ws-subscriptions-clob.polymarket.com/ws/market` | no | — |

Esports filter:

- Tag `64` = "Esports". Every game also has its own series id (from `/sports`):
  `cs2=10310`, `dota2=10309`, `lol=10311`, `val=10369`, `ow=10430`, `r6siege=10432`,
  `mlbb=10426`, `codmw=10427`, `rl=10433`, `hok=10434`, `sc2=10435`, `pubg=10431`.
- The scanner queries per game with `series_id` (configured in `backend/config.yaml`).

Event and market fields that the adapter uses:

- Event: `slug` (→ `https://polymarket.com/event/<slug>`), `title`
  (`"Counter-Strike: NIP vs Liquid (BO3) - Stake Pulse Beat III Playoffs"`), `startTime`, `live`,
  `ended`, `score` (`"0-0|0-0|Bo3"`), `eventMetadata` (league, tournament), `teams`.
- Market: `sportsMarketType` — `moneyline` = match winner; `child_moneyline` = map winner;
  `totals`, `map_handicap`, `round_handicap_game_N` and others are ignored.
  `outcomes` (JSON string, team names), `clobTokenIds` (JSON string) or `positionIds`
  (use when `version == "v2"`), `description` (resolution rules), `orderMinSize`,
  `orderPriceMinTickSize`, `bestBid`/`bestAsk` (first outcome), `feesEnabled`, `feeSchedule`.
- Fees: sports markets charge a **taker** fee `fee = C × rate × p × (1 − p)`; `feeSchedule` example
  `{"exponent": 1, "rate": 0.05, "takerOnly": true, "rebateRate": 0.15}` (`sports_fees_v3`);
  some markets still have `rate 0.03` (`sports_fees_v2`). Fees are rounded to 5 decimals. Makers pay 0.
- Books of the two outcome tokens are mirrored (ask of A = 1 − bid of B).
- WebSocket: subscribe with `{"assets_ids": [...], "type": "market"}`; events `book` (snapshot),
  `price_change` (`price_changes[]` with `asset_id, price, size, side, best_bid, best_ask`),
  `last_trade_price`, `tick_size_change`. Send the text `PING` every 10 s (server answers `PONG`).
  Add/remove assets with `{"assets_ids": [...], "operation": "subscribe" | "unsubscribe"}`.
- Market flags that affect arbitrage: `clearBookOnStart: true` (book is cleared at match start),
  `secondsDelay: 1` (in-play taker orders are delayed).

## Kalshi

Base URL: `https://external-api.kalshi.com/trade-api/v2` (recommended);
`https://api.elections.kalshi.com/trade-api/v2` is still supported.

| Purpose | Endpoint | Auth |
| --- | --- | --- |
| Series list (category, tags, fees) | `GET /series?category=Sports` | no |
| One series | `GET /series/<series_ticker>` | no |
| Events with markets | `GET /events?series_ticker=<t>&status=open&with_nested_markets=true&limit=200&cursor=<c>` | no |
| One order book | `GET /markets/<ticker>/orderbook` | no |
| Many order books (≤100) | `GET /markets/orderbooks?tickers=<a>&tickers=<b>...` | no |
| WebSocket | `wss://external-api-ws.kalshi.com/trade-api/ws/v2` | **yes** (API key + RSA-PSS signature) |

Esports filter: series with tag `Esports` in category `Sports`. Match-winner series:
`KXCS2GAME`, `KXDOTA2GAME`, `KXLOLGAME`, `KXVALORANTGAME`, `KXOWGAME`, `KXR6GAME`, `KXMLBBGAME`,
`KXCODGAME`, `KXRLGAME`. Map winners (`KXCS2MAP`, `KXLOLMAP`, ...), totals and spreads are ignored.

Data model:

- One match = one event (`event_ticker`, e.g. `KXCS2GAME-26OCT160400TLNIP`, title `"Liquid vs. NIP"`)
  with two binary markets, one per team (`yes_sub_title` = team name).
- Prices are fixed-point dollar strings (`yes_ask_dollars: "0.5700"`); integer-cent fields were removed.
  Sizes are `*_fp` strings (fractional contracts allowed, 0.01 granularity).
- Order book response: `{"orderbook_fp": {"yes_dollars": [["0.4200", "13.00"], ...], "no_dollars": [...]}}`
  — bids only, ascending; best bid is the last element. Ask YES = 1 − best NO bid; ask NO = 1 − best YES bid.
- "Team A wins" can be bought as YES on A's market or NO on B's market (the scanner takes the cheaper).
- Best-of format is not published. Start time is in the ticker (`26OCT160400` = 2026-10-16 04:00
  America/New_York) and in `rules_primary` ("originally scheduled for Oct 16, 2026 at 4:00 AM EDT").
- Rules: `rules_primary` + `rules_secondary`. Typical esports clauses: postponed > 48 h, cancelled
  or forfeited before play → "fair market price"; forfeit after start → official result.
- Fees (`fee_type: quadratic`, `fee_multiplier: 1` for esports series):
  taker fee = `roundup_to_cent(0.07 × M × C × P × (1 − P))`.
- Rate limits: token buckets; Basic tier read budget 200 tokens/s with default cost 10 tokens
  (≈ 20 req/s). A 429 has no `Retry-After` header.
- Web URL: `https://kalshi.com/markets/<series_lower>/<series-title-slug>/<event_ticker_lower>`,
  e.g. `https://kalshi.com/markets/kxcs2game/counterstrike-2-game/kxcs2game-26oct160400tlnip`.
  kalshi.com pages return 429 to non-browser clients, so the URL pattern was confirmed from
  search-engine results, not with curl.

## Stake (integrated in session 5 — checked 2026-10-16 08:25 and 16:19–16:45 UTC)

Official **STAKE Sports Data API**: docs `https://docs-odds-data.stake.com/` (OpenAPI 3.1 spec
`https://docs-odds-data.stake.com/dist.yaml/dist.yaml`), server `https://odds-data.stake.com`, contact
`developers@easygo.io`. REST only (no WebSocket in the spec): odds must be polled. Adapter: `backend/adapters/stake.py`.

| Purpose | Endpoint | Notes |
| --- | --- | --- |
| Sports | `GET /sports` | 46 sports on 2026-10-16 (47 at 08:25) |
| Fixtures of a game (discovery) | `GET /sport/<sport slug>/fixture?limit=50&offset=<n>` | default limit 10; `limit` > 50 → 400 `numberLessEqual`; exact `startTime`, `tournament`, `category`, `competitors` |
| Schedule | `GET /schedule/sport/<slug>` | same fixtures in date buckets, but `date` = start rounded **down to the hour**, no tournament → not used |
| Tournaments / categories (web links) | `GET /sport/<slug>/tournament`, `GET /sport/<slug>/category` | paged like fixtures; `id`, `slug`, `categoryId` |
| Odds of one fixture | `GET /fixtures/<fixture slug>` (`/odds/<slug>` returns the same) | `{"fixture", "groups", "swishMarkets"}`; unknown slug or a UUID → **500** `{"message":"error"}` |

- Auth: the spec declares an `X-API-KEY` header for all paths, but every call above answered 200 **without a key**
  from the Vorflux sandbox (US) on 2026-10-16. The adapter sends `ARB_STAKE_API_KEY` from `.env` when it is set.
- Rate limits: none published, no rate-limit headers. A test of 160 fixture requests at 8 req/s (4 at a time) gave
  160 × 200, latency p50 0.14 s, p95 0.80 s, max 2.3 s. Cloudflare in front (`cf-cache-status: DYNAMIC`); gzip works
  (a CS2 fixture: 85 KB → 18 KB; average over 64 fixtures 13 KB, LoL up to 42 KB).
- Esports (provider `oddin`, enabled): `counter-strike`, `dota-2`, `league-of-legends`, `valorant`, `overwatch`,
  `rainbow-six`, `mobile-legends`, `counter-strike-2-duels`, `dota-2-duels` and others. `counter-strike-sr` and
  `starcraft` (`betradar`) are disabled; no Call of Duty or Rocket League.
- Fixture fields: `slug` (`883116-cloud9-m80`), `name` (`"Cloud9 - M80"`), `status` (`inactive|active|live|ended`),
  `startTime` (ms; the fixture list and the odds response agree), `preMatchEnabled`, `inPlayEnabled`, `enabled`,
  `blacklisted`, `tournamentId`; in the list also `tournament`, `category`, `competitors` (short names that can
  differ from the outcome names: "Aurora" vs "Aurora Gaming").
- Odds response: `groups[].markets` is a **list of market lists** (the spec says a flat list of markets). The same
  market is listed in several groups (`main`, `winner`, `threeway`) → deduplicate by `id`. Market: `name`,
  `specifiers`, `status` (`active|deactivated|cancelled|suspended|rollback|settled`), `updatedAt` (ms), `outcomes`
  `{name, odds (decimal; 0 when inactive), active, voidFactor}`.
- Match winner: `name == "Match Winner - Twoway"`, `specifiers == "variant=way:two|way=two"`, outcome names = team
  names (what you bet on). Present on all 64 fixtures of the six games. Not used: `Map N Winner - Twoway`
  (`map=N`), `Match Winner / Map N Winner` (combos), `Match Winner - Threeway` (BO2 draws).
- Best-of: specifier `best_of=N` of the market "Correct Score" (45 of 64 fixtures; none for Overwatch).
- Web link: `https://stake.com/sports/<sport slug>/<category slug>/<tournament slug>/<fixture slug>`, e.g.
  `https://stake.com/sports/counter-strike/international-3/esl-pro-league-season-23-online-stage-t4/597846-m80-team-liquid`
  (pattern from web-archive URLs; `stake.com` answers 403 to the sandbox, so links were not opened).
- No maximum stake in the API (limits are per account and hidden). Minimum stake: not in the API or the rules; public
  reviews say about $0.10.
- Sample (08:25 UTC): Fnatic - Heroic — Fnatic @2.50, Heroic @1.48 → Σ 1/odds = 1.076 (≈ 7.6 % bookmaker margin).
  Same moment: Polymarket Fnatic 0.34 / Heroic 0.67, Kalshi Fnatic 0.35 / Heroic 0.66 → no arb.
- Sportsbook rules (`https://stake.com/policies/sportsbook`, read from the web-archive copy of 2026-10-11): esports —
  postponed for more than 24 h before the start → all bets void; interrupted and not resumed within 24 h → undecided
  bets void; walkover declared by the organizer → void; a team retires during the match → the match market is void;
  "Push Rule (2-way Markets)": a draw in a winner market → void; obviously wrong prices ("deviation of more than 100 %
  in the pay-out compared to the market average") may be voided. Summary used by the scanner: `STAKE_RULES` in
  `backend/matching/rules.py`.
- The website `https://stake.com/` and its internal `/_api/graphql` answer 403 from the sandbox; the odds API does not.

## BC.Game (2026-10-19, недокументированный гостевой BETBY-фид)

Продолжение исследования timestamps: `docs/BCGAME_FRESHNESS.md`. `generated` находится на уровне сообщения,
а индивидуальный last-modified цены отсутствует. Адаптер сохраняет source-время исходов для диагностики.
Успешный согласованный snapshot или delta подтверждает всё текущее состояние после полного разбора ответа.
Ошибка доступа, неполный snapshot и отклонённая версия не обновляют книги.

Проверено на публичной странице без входа и ставок. Пользователь отдельно разрешил фиксированные SOCKS5-прокси.
Прямой запрос renderer из sandbox возвращает `Access is forbidden from your location`.
20.10.2026 прямой запрос feed index также получил CloudFront HTTP 503, `bb-rsn: bc`, `{"error":"access blocked"}`.
Адаптер распознаёт этот ответ отдельно, показывает точную причину и прекращает запросы до перезапуска.
Три из четырёх разрешённых прокси получили настоящий JavaScript. Подмена заголовков и решение challenge не использованы.
Учётные данные не входят в репозиторий. REA 6.7.0 статически разобрал renderer и публичные scripts BC.Game.

Источники протокола:
- https://bc.game/sports — публичный клиент, включая `Com-B1p9wKAo.js` и `get_device_info-rpvMbrTP.js`.
- https://bcgame.sptsportscdn.com/bt-renderer.min.js — перенаправление на https://start9.sptpub.com/bt-renderer.min.js.
- Гостевой `POST https://bc.game/api/platform-sports/v14/home/sport/provider/support/` возвращает
  `sportProviders[].betByBrand.brandFlag`; наблюдённый BETBY brand ID — `2103509236163162112`.
  Обычный Chrome получил HTTP 200; curl к BC.Game получил Cloudflare 403. Challenge не решался.

База API: `https://api-k-c7818b61-623.sptpub.com`. Обычные GET без ключа, cookies и Authorization вернули HTTP 200:
- `/api/v2/auth/brand/2103509236163162112/settings?lang=en` — гостевые настройки.
- `/api/v3/descriptions/markets/en` — 2 117 описаний рынков.
- `/api/v1/descriptions/statuses/en` — 230 описаний статусов.
- `/api/v4/prematch/brand/2103509236163162112/en/0` — индекс snapshot.

Индекс содержит `epoch`, `version`, `top_events_versions`, `rest_events_versions`, `generated` (Unix milliseconds).
Нужно сразу загрузить все версии из двух списков. Части содержат `sports`, `categories`, `tournaments`, `events`.
Последняя часть содержит `snapshot_complete: true` и версию для следующего delta-запроса.
Ответы сжаты gzip. Просроченная версия возвращает `version: 0`; изменение epoch также требует нового snapshot.
В delta `null` удаляет запись/рынок/исход, а `shouldResetEvent` заменяет событие целиком.
Частичный snapshot нельзя публиковать или считать пустой здоровой площадкой.

События имеют строковые ID. `desc` содержит `type`, `sport`, `category`, `tournament`, `slug`, `scheduled`
(Unix seconds), `competitors[0/1].name`. Связанные справочники дают название турнира и URL-slug.
В записанных pre-match матчах `state.status: 0`. `markets["186"][""]` — Winner, исходы `4`/`5` относятся к
первому/второму competitor, независимо от порядка ключей JSON. `k` — decimal odds; `b: 1` блокирует исход.
Рынок `1` с пустым specifier — 1x2, поэтому такой матч пропускается. Явный чётный best-of также исключается.
Надёжного best-of в полученных матчах нет; количество предложенных рынков карт не доказывает формат.

Наблюдённые виды спорта: `109 counter-strike`, `111 dota-2`, `110 league-of-legends`, `194 valorant`,
`121 overwatch-2`, `125 rainbow-six`, `201 mobile-legends`. CoD и Rocket League не найдены.
Ссылка по коду клиента: `https://bc.game/sports/{sport.slug}/{category.slug}/{tournament.slug}/{event.slug}-{eventId}`.
Минимум и реальный максимум ставки не опубликованы. Лимит запросов не найден; адаптер начинает с 1 запроса/с.
API не документирован и может измениться. Гостевой доступ не заменяет разрешение на использование данных.

Полученный snapshot 13:14 UTC содержит 2 098 событий всех видов спорта и 49 esports матчей семи игр.
`tests/fixtures/bcgame_prematch_esports.json` — явно сокращённая запись: один матч на игру и связанные справочники.
В 13:29 UTC адаптер нашёл 14 рынков в окне 72 часа: CS2 10, Dota 2 2, MLBB 2.
В 13:33 UTC пять последовательных обновлений имели возраст источника 4,872–8,088 секунды при пороге stale 10 секунд.
Это короткая проверка доставки, а не гарантия свежести букмекера или принятия ставки.

Повторная проверка 14:09:01–14:09:27 UTC, горизонт 72 часа, только автоматические сопоставления:

| Игра | BC.Game | С Polymarket | С Kalshi | Со Stake |
| --- | ---: | ---: | ---: | ---: |
| CS2 | 8 | 8 | 7 | 8 |
| Dota 2 | 3 | 3 | 3 | 3 |
| LoL | 0 | 0 | 0 | 0 |
| Valorant | 0 | 0 | 0 | 0 |
| Overwatch | 0 | 0 | 0 | 0 |
| R6 | 0 | 0 | 0 | 0 |
| MLBB | 2 | 2 | 2 | 0 |
| CoD | 0 | 0 | 0 | 0 |
| Rocket League | 0 | 0 | 0 | 0 |
| Всего | 13 | 13 | 12 | 11 |

Пулы источников: Polymarket 64, Kalshi 92, Stake 15, BC.Game 13. Запросы завершились без ошибок.
Одна CS2-пара Kalshi осталась в review: Team Nemesis — Nuclear TigeRES, расхождение старта 170 минут.
MLBB не включён в существующую конфигурацию Stake. Нулевые строки других игр означают отсутствие рынков в этом окне.
Для MLBB добавлен только алиас ONIC Philippines ↔ ONIC PH: соперник TNC Pro Team и время совпали на трёх площадках.
Сравнение с прежними 14 рынками изменилось из-за начала двух CS2 матчей и входа Team Liquid — 1win в окно 72 часа.

Повторные callbacks старой временной модели получили возраст источника 11,986 / 13,246 / 12,943 с.
Это хуже раннего прогона 4,872–8,088 с. Глобальный порог stale 10 с не изменён.
Текущий адаптер использует время завершения успешной атомарной синхронизации состояния, а source timestamp
сохраняет отдельно для диагностики. Ошибка или неполное состояние не обновляют время книг.

Официальные правила: https://bc.game/help/terms-sports. curl получил 403, браузерная попытка чтения завершилась
тайм-аутом. Правила отмены, переноса, форфейта и ничьей не подтверждены; профиль намеренно пустой.
Чужие пересказы со сроками 24/48/72 часа не используются. `include_live: true` проверен только синтетически.
