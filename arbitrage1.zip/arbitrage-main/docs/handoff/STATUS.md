# STATUS

## Сессия 12: freshness telemetry и last-good cache

Обновлено 2026-10-20 15:50 UTC. Ветка `vorflux/freshness-cache-telemetry` от `origin/main` `0a98a22`.

Минимальная реализация готова. Malformed/partial HTTP 200 для Polymarket и Kalshi больше не публикуют half-snapshot.
Malformed discovery и незавершённая pagination не удаляют last-good markets. Stake сохраняет odds при fixture без `groups`.
Kalshi сохраняет last-good series metadata. API показывает timestamp provenance отдельно от неизвестного price-change time.

Пороги, matching, fees, execution и arb formulas не изменены. Focused suite: 109 passed. Полная регрессия:
502 Python passed, 27 Node pass, compileall и diff check successful. Живая сеть не использовалась.

Полный технический отчёт: `docs/FRESHNESS_TELEMETRY_AUDIT.md`. Implementation и review fixes опубликованы.
Повторный review: risk 3/10, Safe to ship, блокеров нет. CI прошёл для implementation `7f0e543` и
финального report state `9d546d3`. PR 14 готов к review владельца; merge не выполнялся.

## Сессия 10: proxy BC.Game

Поддержка `ARB_BCGAME_PROXY_URL` уже была реализована. Добавлена прямая регрессия, которая подтверждает передачу
HTTP proxy в единый клиент и использование того же клиента для index, каждой части snapshot, delta и reset.
Другие площадки не менялись. Полная регрессия: 479 Python passed и 27 Node pass.

## Сессия 9: подключение BC.Game продолжается

Обновлено 2026-10-20 11:30 UTC. Ветка `vorflux/add-bcgame-adapter`, WIP.

Подтверждено: текущий sandbox устанавливает TCP/TLS-соединение с BETBY, но CloudFront возвращает HTTP 503 с
`bb-rsn: bc` за 34,8 мс. Ошибка возникает до JSON-контракта snapshot; это не `ReadTimeout` и не ошибка нормализации.
Прокси, CloakBrowser, вход и обход региональных ограничений не использовались.

До изменений ветка уже содержала адаптер, регистрацию, matching, mock и UI. Реальный запуск исключал BC.Game через
`enabled: false`, а отдельный evidence clock не соответствовал общему REST-подходу Stake.
Живой успешный сбор в этой сессии пока не подтверждён.

Реализация обновлена: `enabled: true`; coherent snapshot/delta подтверждает состояние временем завершения ответа;
source evidence остаётся диагностическим. Timeout 15 с и два request-level повтора покрывают historical long-poll
4,2–4,9 с и transient network/5xx. Полная регрессия: 470 Python passed; 27 Node pass.
Живой успешный сбор по-прежнему не подтверждён из-за CloudFront 503 `bb-rsn: bc`.

Review-правки готовы: source evidence полностью диагностический и не блокирует coherent state; clock skew до 5 с
допускается; geo-block получает точное сообщение и latch. Snapshot/delta остаются подтверждением всего согласованного
состояния после полного разбора ответа по общему REST-контракту задачи. Полная регрессия: 473 Python passed; 27 Node pass.

Follow-up review: risk 3/10, verdict Safe to ship, блокеров нет. `bb-rsn` latch принимает только код `bc` или
явное тело `access blocked`. Финальная локальная регрессия: 475 Python passed; 27 Node pass.

Независимый Test Report: PASSED. Mock UI и API подтвердили четвёртую площадку и пары BC.Game; disabled config
не затронул другие площадки. Живая проверка честно завершилась CloudFront geo-block с 0 рынков и 0 вилок.
Успешный живой сбор из текущего sandbox не подтверждён.

Последнее обновление: 2026-10-19 14:35 UTC (сессия 7).

## Сессия 8: завершено расследование и 30 минут наблюдения — NOT READY

Обновлено 2026-10-19 17:41 UTC. Продолжается https://github.com/lndrosa/arbitrage/pull/9 на той же ветке.
Искусственное старение от request-start clamp и ложное омоложение общего канала исправлены.
Пер-исходные source evidence, барьеры недоступности, manifest boundary и effective BO прошли review.
Срок stale 10 с, polling/rate, математика, matching, предыдущие адаптеры и default config не изменены.

Финальный живой прогон опубликованного 6a99003: 16:50:10.929–17:20:10.906 UTC, monotonic 1800,034 с.
1 snapshot, 361 delta, 368 успешных HTTP, 15 нормализованных рынков. 28 изменений k в 8 исходах 4 рынков.
45 705 engine checks, 45 312 непустых: fresh 312 (0,689%), stale 42 411 (93,598%), unknown 2 589 (5,714%).
Evidence age по 42 723 датированным samples: median 750,998 / p95 1683,281 / max 1801,058 с.
HTTP-клиент закрыт на 15,026 с и восстановил состояние через 24,625 с; 2 ошибки вызваны инъекцией, native HTTP ошибок 0.
3 наблюдаемых события исчезли, outcome b=1 среди наблюдаемых 0; raw invalid reuse 0/45 705.
Это не подтверждение всех reset-веток: реальный epoch/reset не встретился; temporal safety отдельно покрыта тестами.

Индивидуальный business timestamp отсутствует. Source generated — время сообщения, не доказанное время изменения цены.
Некоторые корректные unchanged prices могут оставаться актуальными, но строгую свежесть доказать нельзя.
Metadata latch после переноса старта удерживал новый исход до согласованного rematch до 35,385 с; защита не обойдена.
Итоговый operational verdict — NOT READY. BC.Game остаётся выключенным; ставки и auto-merge не выполнялись.

После live: Python 468 passed (21,41 с), Node 27 pass; compileall exit 0; отдельно настроенного typecheck нет.
Core review 3/10, measurement review 2/10 закрыли известные must-fix. Это кодовые оценки, не live-допуск.
Полный технический отчёт: docs/BCGAME_FRESHNESS.md. Mock preview не используется как доказательство живой работы.
Полный task diff и итоговые артефакты проверены на proxy credentials; совпадений нет. Временная `.env` удалена.

## Сессия 7: BC.Game реализован, выключен по умолчанию

Открытый PR: https://github.com/lndrosa/arbitrage/pull/9 (`isDraft: false`). Ветка `vorflux/add-bcgame-adapter` основана на актуальном
`main` `f97523b`. Адаптер читает гостевой BETBY REST без ключа, входа, ставок, подмены заголовков и решения challenge.
Пользователь отдельно разрешил фиксированные прокси. Учётные данные и HAR удалены после проверок; в git их нет.

Реализованы атомарный snapshot/delta, два исхода Winner 186, один ask-уровень, нулевая комиссия, лимит частоты,
параллелизм, тайм-ауты, backoff, Retry-After, остановка после 401/403 и отдельное paper-чтение.
Изменённые метаданные блокируют книгу до повторного сопоставления. Paper фиксирует вход до первого await.
По отдельному запросу пользователя Stake отклоняет NaN/Infinity и переполнение размера. Поиск, математика и БД не менялись.

Живой сбор 14:09 UTC, окно 72 ч: BC.Game 13 (CS2 8, Dota 2 3, MLBB 2). Авто-пары: PM 13, Kalshi 12, Stake 11.
Одна пара Kalshi требует ручной проверки из-за разницы старта 170 минут. Добавлен подтверждённый MLBB-алиас ONIC PH.
Таблица всех игр и причины изменения чисел находятся в `docs/API_NOTES.md`.

Существенные ограничения: официальные правила расчёта и скрытый BO2 неизвестны. Поздний возраст источника
11,986–13,246 с превышает порог 10 с; движок исключает старые книги. Порог не изменён, BC.Game выключен по умолчанию.
Ранний прогон 4,872–8,088 с не является гарантией стабильной свежести. Реальные ставки и live-режим не проверены.

Проверки: 349 Python и 27 Node тестов прошли, одно предупреждение Starlette. Проверены реальные публичные ответы,
непрерывный REST-опрос, отдельная книга, четыре mock-площадки и все шесть пар.
Браузер подтвердил цвета, фильтр CS2/поиск Natus, ссылки и статистику; console пустой. Preview содержит только mock:
https://ot1tcsweh0w8.preview.us1.vorflux.com. Сервер использует отдельную временную БД и точный allow-list hostname.

Review: исходные два дефекта и paper-гонка исправлены. Последняя точечная проверка закрыла все известные must-fix.
Риск снизился 5 → 4 → 3/10 после этих исправлений; финальный verdict — Ship with mitigations, Low.
Меры: сохранить `enabled: false` и порог свежести 10 с. Агент не менял draft/ready и не выполнял merge.
Поздняя проверка GitHub исправила прежнее предположение о draft: фактически PR открыт, auto-merge выключен.
Описание обновлено через GitHub CLI с сохранением внешних секций: platform `pr edit` не получил datasource-доступ.
Оценка 3/10 записана в описание, но platform `pr report-risk` вернул `not_tracked`; его индекс не обновился.

### Out-of-Scope Feedback

- Fix requested: пользователь включил проверку конечности Stake в текущую задачу. Исправлено; десять новых тестов прошли.
  Реальные ответы Stake с NaN/Infinity не наблюдались.

## Session 6: honest arb statistics — done, waiting for the user's review and merge (PR 6 → 7 → 8)

Task: honest statistics of arbs from the real history `arb_copy.db` (kept in `main` as it is, by the user's
decision; analysed only through copies in `/tmp`). Arb search logic is unchanged (a regression test compares the arbs
found with capture on and off). Three stacked PRs, all target `main`, merge in order:

1. `vorflux/stats-capture` (from `main` `f8325dc`) — https://github.com/lndrosa/arbitrage/pull/6. Data capture:
   config `capture:`, `engine/capture.py` (phase, minutes to start, book snapshots at confirmation and at the peak,
   profit at 10–250 $ with walk_book under a budget, optimal size, liquidity flags), migration of 18 columns with
   ADD COLUMN, `GET /api/history/{id}`. Review risk 3/10; its size-jump findings fixed. 235 pytest + 18 Node.
2. `vorflux/paper-checks` (from PR 1) — https://github.com/lndrosa/arbitrage/pull/7. REST re-read of both books at
   +5/+15/+60 s after confirmation (`engine/paper.py`, `fetch_book` in the adapters, table `paper_checks`), legs by
   team name, late / slow / timeout / changed teams = no data. Review risk 4/10; its findings fixed. 253 pytest +
   18 Node.
3. `vorflux/honest-stats` (from PR 2) — https://github.com/lndrosa/arbitrage/pull/8. The honest report
   (`backend/honest_stats.py`, `stats.py`), `report.py` flags, API, the «Статистика» tab: by phase, at confirmation,
   percentiles, without top-N, distinct per 24 h, per-arb cap, bankroll with locked money (one pool; phases show their
   share), paper survival, tournaments, flags, «данных нет» for old rows. Review risk 4/10; its findings fixed.
   267 pytest + 20 Node.

Checked: tests, the mock mode, a copy of `arb_copy.db` (the user's numbers come out of the report) and the browser
(mock mode on a copy of the history). Not checked live: the new REST requests of the paper checks against the real
venues and the capture on real books.

## Session 5: Stake as the third venue — done, waiting for the user's merge

Branch `vorflux/stake-adapter` from `main` `0f2d40c`, PR https://github.com/lndrosa/arbitrage/pull/5 (open, not a
draft, CI green). Adapter, config, rules profile, aliases, polling hook, header and report match counters, mock
bookmaker, recorded fixtures, tests (212 pytest + 18 Node pass), README, API notes. Live checks: four runs of the full
scanner (16:51–18:12 UTC), Stake quotes never older than 10 s on the fixed code, 4 distinct Polymarket ↔ Stake arbs
(no Kalshi ↔ Stake). Review rounds 1 (3/10, 5/10) and 2 (4/10) and 8 Macroscope comments: all fixed. No model change
(no second PR). Next: the user merges and runs the scanner for several days (NEXT_STEPS, session 5).

## Overall

Feature-complete scanner; the GitHub block of session 3 is resolved. The history was restored from the git bundle into
`lndrosa/arbitrage` (private), and `vorflux/esports-arb-scanner-v3` is merged into `main` (merge commit `cd055b3`,
"Merge pull request #1"). On top of it the user added `CLAUDE.md`, the CI workflow `.github/workflows/ci.yml` and a
README clone URL (`5e55fb3`, main HEAD at the start of session 4).

On `5e55fb3`: `python -m pytest -q` → 144 passed, `node --test tests/js/*.test.mjs` → 11 passed.

Session 4 works from `main` in separate branches, one PR per change (the user merges):

1. `vorflux/session4-checks` — handoff after the restore, README clone URL `https://github.com/lndrosa/arbitrage.git`,
   end-to-end check of `04cbe85` (passed), second review of `d8942e9` and `04cbe85` (risk 2/10) with fixes for all its
   findings and for one gap found by the check (re-checked live). PR: https://github.com/lndrosa/arbitrage/pull/2;
   second review round: risk 2/10, its findings fixed.
2. `vorflux/history-stats-report` — report from the SQLite history (arbs per day in Europe/Moscow, profit $, lifetime,
   game, pairs of venues, top matches) with scanner uptime per minute: `python report.py`, `GET /api/stats`.
   PR: https://github.com/lndrosa/arbitrage/pull/3. Review: risk 3/10, "ship with mitigations"; all its findings
   fixed (own read-only connection per request, one-pass build in a worker thread, rate per 24 h like with like);
   second round: risk 3/10, its mitigations done (one build at a time, `-o` cannot overwrite the history).
3. `vorflux/stats-tab` — the "Статистика" tab on top of `GET /api/stats`. PR: https://github.com/lndrosa/arbitrage/pull/4.
   Browser-checked at 1440/1366/1280/900 px. Review: risk 2/10, "safe to ship"; its findings fixed and re-checked
   in the browser; second round (with #3): no repeated requests from the tab.
   Each in its own PR, branched from the previous one (the handoff files change in every PR).

## Components

| Component | Status |
| --- | --- |
| API research notes | Done (`docs/API_NOTES.md`, incl. Stake and BC.Game notes) |
| Backend core (models, config, net, logging) | Done |
| Engine (fees, arb, tracker, scanner) | Done, unit-tested; per-order minimum checked per instrument |
| Matching (normalizer, matcher, rules) | Done, unit-tested; live: 98–99 auto pairs, 2 review |
| Storage (SQLite) | Done, covered by API tests; uptime table and read-only mode for the report (session 4) |
| API server (FastAPI + WS) | Done, covered by API tests |
| Mock adapter | Done |
| Polymarket adapter | Done, live-verified (WS + REST resync) |
| Stake adapter | Done (session 5), live-verified: odds API without a key, 4 runs, pairs with both exchanges |
| Kalshi adapter | Done, live-verified (REST polling); optional WS not tested (needs API keys) |
| Frontend | Done; 18 Node tests on `vorflux/stats-tab` (11 on `main`) |
| Tests | 151 pytest + 12 Node on `vorflux/session4-checks`, 172 + 12 on `vorflux/history-stats-report`, 172 + 18 on `vorflux/stats-tab`; CI runs both on every PR |
| README | Done (Russian) |
| Windows launcher | `run-windows.bat`, not tested on Windows |
| Discovery log line (`04cbe85`) | Unit-tested; end-to-end check passed (session 4): one WARNING line, no traceback |
| Statistics report | Done (`backend/stats.py`, `report.py`, `GET /api/stats`, table `scanner_uptime`) |
| Statistics tab | Done (`frontend/js/views/stats.js`, `frontend/js/stats-format.js`), browser-checked |
