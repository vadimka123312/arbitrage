# HISTORY

## 2026-10-20 — начало freshness telemetry audit

- Создана ветка `vorflux/freshness-cache-telemetry` от чистого `origin/main` `0a98a22`.
- Подтверждён baseline 479 Python / 27 Node; CI и compileall проверены.
- Прослежен общий путь `NormalizedMarket.updated_at` → scanner merge → `is_fresh(..., stale_seconds)`.
- Начата проверка last-good cache для HTTP errors, malformed, empty и partial responses всех адаптеров.
- Продуктовые пороги и arbitrage path пока не изменены.

Chronological log of work on the Esports Arb Scanner. Newest entries at the bottom.

## 2026-10-20 — аудит UI-метрик BC.Game

- Актуальный `origin/main` после merge PR #9: `0a98a22`. Рабочая ветка создана от него:
  `vorflux/fix-bcgame-status-metrics`; `main` не изменялся.
- `latency_ms` измерял только последний отдельный `await http.get`: long-poll плюс загрузку одного response body.
  Rate limiter, ожидание semaphore, retry backoff, JSON/merge/normalization и полный multipart snapshot не входят.
- `last_update` означает завершение последней успешной coherent sync. Это не время изменения коэффициента BETBY.
- При ошибке старое или ошибочное `latency_ms` оставалось в status. `last_update` намеренно оставался временем
  последней успешной sync, но UI называл его общим словом «Обновлено».
- Исправлено только для отображения BC.Game: «Последний HTTP-ответ» и «Последняя успешная синхронизация».
  Tooltip явно сообщает, что BETBY не даёт возраст коэффициента. При ошибке latency очищается.
- Целевые проверки: 2 Python passed; 9 Node pass. Полная регрессия: 481 Python passed; 29 Node pass.
- Review: risk 2/10, Safe to ship, блокеров нет. Тест snapshot усилен разными длительностями 1 111 / 2 222 /
  4 157 мс и подтверждает именно последний response. Tooltip пары BC.Game больше не говорит «Котировки свежие»:
  он сообщает о недавней sync и неизвестном времени изменения коэффициента.
- Финальная регрессия: 481 Python passed; 30 Node pass. Browser подтвердил header, Settings и pair tooltip.

## 2026-10-20 — проверка локального proxy для BC.Game

- Подтверждено: адаптер читает `ARB_BCGAME_PROXY_URL` один раз при создании и передаёт значение в единый
  `httpx.AsyncClient(proxy=..., trust_env=False)`. Все index и multipart snapshot-запросы идут через этот клиент.
- Локальный адрес пользователя не добавлен в код. `.env.example` содержит отдельные HTTP и SOCKS placeholders.
- Добавлен параметризованный тест с proxy и без proxy. Он проверяет client options и пути index, всех snapshot-частей,
  обычного delta и delta reset с повторным snapshot: `0`, `101`, `102`, `501`, затем reset `0`, `101`, `102`.
- Целевые proxy/timeout/recovery тесты: 8 passed, 58 deselected. Полная регрессия: 479 Python passed, 27 Node pass.
  Diff не содержит локальный адрес пользователя, proxy credentials
  или посторонние файлы; изменён только безопасный placeholder `.env.example`.

## 2026-10-20 — полноценное подключение BC.Game

- 11:25 UTC — Работа продолжена в существующей ветке `vorflux/add-bcgame-adapter` на `ac273f5`; рабочее дерево чистое.
- 11:30 UTC — Прямой разрешённый запрос без прокси, входа и обхода ограничений к
  `GET https://api-k-c7818b61-623.sptpub.com/api/v4/prematch/brand/2103509236163162112/en/0`
  завершился за 34,8 мс ответом CloudFront HTTP 503, JSON `{"error": ...}` и заголовком `bb-rsn: bc`.
  DNS, TCP и TLS завершились успешно; текущий отказ происходит на уровне CDN до разбора BETBY snapshot.
- Изучена текущая реализация ветки. BC.Game уже зарегистрирован в общем loader, scanner loop, matching, mock и UI,
  но `platforms.bcgame.enabled: false` исключает его из реального запуска. Дополнительный per-outcome evidence clock
  использует `generated` сообщения вместо общего для REST-адаптеров времени запроса и поэтому оставляет книги старше
  глобального `engine.stale_seconds`, даже когда синхронизация состояния успешно завершилась.
- Следующий шаг: применить к BC.Game общий REST-контракт свежести проекта, включить площадку и сохранить честную
  обработку сетевых и контрактных ошибок без фиктивных рынков.
- 11:42 UTC — BC.Game включён в committed config. Успешный атомарный snapshot/delta теперь подтверждает всё
  согласованное состояние временем завершения ответа; source timestamps сохранены в metadata для диагностики.
- Timeout увеличен с 5 до 15 с после установления причины: разрешённый historical long-poll занимал 4,2–4,9 с.
  Добавлены два request-level повтора для transport errors и HTTP 408/425/5xx. Ошибки 429 продолжают соблюдать
  `Retry-After`; ошибки и неполные snapshots не обновляют книги.
- Статус parser errors теперь содержит безопасную точную причину вместо одного `feed unavailable (ValueError)`.
- Целевые BC.Game-тесты: 192 passed in 6,94 s. Полная регрессия ещё не выполнена.
- 11:46 UTC — Полная регрессия завершена: 470 Python passed и 27 Node pass. UI API metadata теперь ожидает
  все четыре включённые площадки; отдельный тест подтверждает отключение только BC.Game через config.
- 11:54 UTC — После review диагностический per-outcome clock перестал блокировать coherent snapshot/delta при
  регрессии source timestamp. Допуск clock skew 5 с предотвращает отказ при небольшом расхождении часов.
- CloudFront 503 с `bb-rsn` и `{"error":"access blocked"}` теперь даёт точную ошибку и latch до перезапуска,
  без трёх request retries и бесконечного polling. Обычные transient 503 продолжают повторяться.
- Добавлены прямые тесты 503 → retry → success, exhausted 503 без потери feed, geo-block latch и clock skew.
  Все BC.Game-тесты: 196 passed in 7,73 s.
- 11:57 UTC — Полная регрессия review checkpoint: 473 Python passed и 27 Node pass; secret scan чистый.
- 12:01 UTC — Follow-up review снизил риск с 5/10 до 3/10 и не нашёл блокеров. Geo-block latch сужен до
  `bb-rsn: bc` или тела `access blocked`; другой `bb-rsn` остаётся transient 503 и повторяется.
- Добавлены boundary-тест clock skew +6 с и non-blocking `bb-rsn: maintenance`. Итог: 475 Python passed, 27 Node pass.
- Независимый testing agent подтвердил актуальный `e7d02c4`: 475 Python passed, 27 Node pass, 6 целевых retry/skew
  тестов passed. Mock API показал 16/16/16/17 рынков и 88 пар; UI показал BC.Game на 1280 и 1100 px.
- Disabled-config процесс оставил только Polymarket, Kalshi и Stake. Прямой live-процесс без proxy получил точную
  ошибку CloudFront `bb-rsn: bc`, 0 рынков, 0 пар и 0 вилок. Фиктивные данные и ложный Live не появились.

## 2026-10-15

- 18:14 UTC — Task received: build "Esports Arb Scanner" (Polymarket vs Kalshi esports arbitrage scanner) from scratch.
- 18:15–18:30 — API research with live requests and current docs (docs.polymarket.com, docs.kalshi.com). Key findings are in `docs/API_NOTES.md`:
  - Polymarket sports markets now charge a taker fee (`feeSchedule.rate` = 0.05 for `sports_fees_v3`).
  - Kalshi removed integer-cent price fields; prices are dollar strings (`*_dollars`), sizes are `*_fp`.
  - Kalshi WebSocket needs API-key auth even for public channels → REST polling by default.
- 18:25 — Bootstrap commit pushed to `main` (only `.gitignore` + stub `README.md`) so a PR base exists. Work branch: `vorflux/esports-arb-scanner`.
- 18:25–18:41 — Backend core implemented: `models.py`, `config.py` + `config.yaml`, `logging_setup.py`,
  `net.py` (token bucket + retries with exponential backoff), `engine/fees.py`, `engine/arb.py`,
  `engine/tracker.py`, `engine/scanner.py`, `matching/normalizer.py` + `aliases.yaml`, `matching/matcher.py`,
  `matching/rules.py`, `storage/db.py`, `adapters/base.py`, `adapters/mock.py`, `api/server.py`, `run.py`.
- 18:41 — First mock-mode smoke run: backend starts, 16+16 mock markets, 13 auto pairs, 2 review pairs.
- 18:42 — Checkpoint commit `0da8fcc` (WIP): real Polymarket/Kalshi adapters, frontend and tests are not written yet.
- 18:43 — Frontend delegated to a build subagent (vanilla HTML/CSS/JS against `/ws` + REST); it only touches `frontend/`.
- 18:43–18:48 — Real adapters: `adapters/common.py`, `adapters/polymarket.py` (Gamma discovery, CLOB WS books with PING,
  REST `/books` resync), `adapters/kalshi.py` (events discovery, batched `/markets/orderbooks` polling, YES/NO merge,
  optional authenticated WS with keepalive).
- 18:48 — First live run against real APIs: 113 Polymarket + 126 Kalshi markets, 99 auto pairs, 2 review pairs,
  both platforms healthy, 1 real (tiny, 0.14 %) arb confirmed. Checkpoint commit `8e23c10` at 18:49.
- 18:49–18:54 — Unit tests (93) with fixtures captured from the live APIs; README (Russian), Makefile, `.env.example`,
  `pytest.ini`.
- 18:54 — Checkpoint commit `428ad23` (WIP). Frontend: subagent has written `frontend/index.html` only so far (in progress).
- Note: timestamps above were corrected at 18:57 from the git commit times (earlier entries were written with estimated times).
- 18:55–18:57 — Freshness fixes: Kalshi poll and Polymarket REST resync refresh `updated_at` only for markets whose books
  came back in that response; Kalshi NO-side merge only for mutually exclusive events; Polymarket PING every 5 s;
  per-pair isolation of evaluation errors; finished adapter tasks pruned. +6 tests (retry/backoff, freshness, merge).
- 19:12 — WIP checkpoint of the frontend files written so far by the subagent (`frontend/index.html`, `styles.css`,
  `app.js`, `js/*`). The subagent is still working; these files are not reviewed or verified yet.
- 19:28 — Second WIP checkpoint of frontend files (subagent still iterating: app.js, index.html, store.js, ui.js,
  history.js, styles.css changed). Not verified by the main agent yet.
- 19:31 — Frontend subagent finished: 5 tabs, live WS updates with REST fallback, highlight, timers, sound and
  browser notifications, review/confirm/block, settings form, CSV export; checked in a browser at 1440 px and 900 px
  (screenshots in `/code/.generated_artifacts/images/ui_*.png`, not committed).
- 19:32 — Backend fixes recommended by the frontend work: atomic settings update (validate all keys first, plus
  review ≤ auto threshold), `Cache-Control: no-cache` for the static UI, fresh `server_time` in cached snapshots.
  +2 API tests. README: UI section.
- 19:33 — Corrected the 19:40/19:42/19:43 timestamps above to the real `date -u` times (19:31/19:32). Commit `71e7d5f`.
- 19:37 — Draft PR opened: https://github.com/rayan23-bot/1/pull/1. Real-mode preview server started on 0.0.0.0:8000
  (public URL verified in a browser: both platforms healthy, 212 markets, 87 pairs, 2 small live arbs, WS "Live").
  Quality phase started: simplify pass, three reviews (engine maths, adapters/server, frontend), end-to-end testing.
- 19:45 — Testing subagent: 33-case plan written, mock (:8080) and real (:8081) instances set up; told to wait for
  review fixes. Added `tests/test_persistence.py` (history filters + CSV, overrides/settings across restart,
  shutdown flush of active arbs) to close gaps from the testing audit. 104 tests pass.
- 19:57 — Reviews received (engine maths 4/10, adapters/server 5/10, frontend 4/10; all "ship with mitigations").
  Main issue found by two reviewers: discovery/subscription re-stamped cached books with `utcnow()`, so stale books
  could look fresh. Simplify patch applied (18 files, +109/−198, behaviour unchanged); 104 tests pass.
- 20:04 — Review fixes, part 1 (backend): books stamped with their real receive time (Polymarket `TokenBook.received_at`,
  Kalshi `book_ts`, per-batch times), PONG/keepalive refresh only for books snapshotted on that connection, Polymarket
  WS library pings + PONG timeout + backoff reset on first data + generation counter + per-event error isolation,
  Kalshi `/exchange/status` gating (paused trading → not actionable), Kalshi WS seq-gap resync and REST fallback,
  cache pruning; matcher: unknown start time or gap > 90 min → review only, identical names beyond the tolerance
  (≤ 48 h) → review; pair warnings for start-time gaps and BO2 draws; rules parser wording; fee_multiplier 0;
  per-instrument fees/fixed costs and same-price aggregation; history write isolation; `counts.matches`,
  `quotes.*.actionable`. 114 tests pass. Frontend fixes running in the frontend subagent.
- 20:05 — Review fixes, part 2 (backend): Host allow-list (TrustedHostMiddleware) + Origin check for writes and `/ws`
  (DNS-rebinding/CSRF protection; `server.allowed_hosts`, env `ARB_ALLOWED_HOSTS`), env renamed to `ARB_HOST`/`ARB_PORT`
  with a warning for non-loopback binds, Retry-After capped, CSV formula escaping, separate mock log file,
  `fastapi>=0.115`, `websockets>=14`. 117 tests pass.

## 2026-10-15 — session 2

- 21:08 UTC — New session. Read docs/handoff. Repository is now `ravistiedemann79/1`; PR #1 is the same:
  https://github.com/ravistiedemann79/1/pull/1 (open, not draft). Prior session transcripts are not available, so the
  uncommitted frontend review fixes from session 1 are lost and must be redone.
- 21:11 — Fresh venv (installed `python3.12-venv` in the sandbox), `pytest -q` → 117 passed on `b1fbf7c`.
- 21:13 — README clone URL updated to `ravistiedemann79/1`. Checkpoint commit.
- 21:14 — Real-mode server on 0.0.0.0:8000 (`ARB_ALLOWED_HOSTS='*.vorflux.com'`, `--db /tmp/arb_real.db`) and mock
  server on :8001. Preview URL set to `localhost:8000`; public URL https://iz082a8cbrgd.preview.us1.vorflux.com → 200.
- 21:16 — Browser check at 1440 px reproduced the UI issues: arbs table 1412 px wide in a 1390 px wrapper (⚠ column
  clipped), pairs table clipped at the "Действия" column; header "матчей" showed the market count (207) instead of
  `counts.matches` (124).
- 21:17–21:23 — Frontend review fixes (WIP, not browser-verified yet):
  - liveness: server WebSocket heartbeat every 2 s when nothing changed (`HEARTBEAT_SECONDS`); client watchdog drops a
    socket silent for 6 s, a socket counts as open only after its first message, REST polling covers gaps;
    staleness is time-based (no confirmed data for 6 s → banner, dimmed tables, frozen timers); stuck scanner
    (`last_eval_at` older than 5 s) → amber "Расчёт остановлен" indicator and banner;
  - overflow: compact cell padding, wrapping numeric headers, smaller tournament/instrument caps and column minimums,
    edge shadows on horizontally scrollable tables (`watchScrollEdges`);
  - header uses `counts.matches`; pairs/review views mark `quotes.*.actionable === false` as "неактуально".
- 21:23 — `pytest -q` → 118 passed (new test: heartbeat when the state does not change). WIP checkpoint commit.
- 21:24 — Servers restarted with the heartbeat code. Browser check (agent-browser 0.37.1, real mode): tables fit at
  1440/1366 px; at 1280 px the pairs table scrolls by 59 px and at 900 px both tables scroll, with the right-edge
  shadow; header shows 123 matches. Liveness: SIGSTOP of the mock server → "Нет связи с сервером" + banner after
  ≤ 9 s, recovery to "Live" 1 s after SIGCONT; a server whose scanner stops evaluating (`/tmp/arbtest/stall_server.py`,
  port 8002) → amber "Расчёт остановлен" + banner, frozen candidate countdown.
- 21:27 — Stall banner text made generic (mock mode logs to `logs/scanner_mock.log`); README UI section documents
  liveness, the "неактуально" label and table scrolling. Checkpoint commit.
- 21:30 — PR #1 update failed: `vflux pr edit` → "No GitHub datasource has access"; `gh` → PR #1 is 404 (API and web),
  while `refs/pull/1/head` still follows the branch and `pr create` answers "A pull request already exists". The PR
  is hidden (probably its author account is flagged); it cannot be edited or replaced.
- 21:33 — New branch `vorflux/esports-arb-scanner-v2` at `51202fd` (pushed); new PR
  https://github.com/ravistiedemann79/1/pull/2 (open) with the updated description. The old branch stays as is.
- 21:34–21:50 — Quality phase started (user notified with the PR #2 link). Simplify agent: suggestions only (to apply
  after reviews). Backend review round 2: 4/10, "ship with mitigations"; frontend review: 4/10, "ship with mitigations".
- 21:50–21:57 — Backend review fixes: Kalshi WS is the only writer for books it snapshotted (`_ws_owned`; polling skips
  them, also for responses already in flight; polling continues for the rest instead of stopping at 90 % coverage);
  `/exchange/status` check counts failures (no retry storm before every poll), 1 retry, non-object JSON ignored;
  WS backoff resets only after 30 s of stable stream; sequence gaps checked for snapshots too; Polymarket PONG timeout
  starts after the handshake; IPv6 `[::1]` Host accepted; matcher holds the markets of a strong pair that failed only
  the time rules, so a weaker candidate cannot auto-pair them; `broadcast_interval_ms` capped at 200–2000;
  clearer warning for non-loopback binds; `HttpClient.get_json(retries=...)`. +6 tests → 124 passed. Checkpoint commit.
- 21:58–22:01 — Frontend review fixes (WIP, browser re-check pending): `isStale()` true at once when the socket is
  closed and REST fails; scanner stall measured as `server_time − last_eval_at` from STATE/heartbeat (server clock
  only, no false "stalled" during silence); indicator order offline → stalled → live → polling; amber banner for the
  stall; tab title shows "Нет связи"/"Расчёт остановлен"; badges refresh on filter changes; ticking text aria-hidden;
  new-arb alerts fire once per occurrence when it is confirmed AND passes the filters (also later), not again after a
  threshold change, not for arbs revealed by changing filters; "Сумма цен" shows average prices in walk_book mode;
  ⚠ column moved next to "Profit %" (arbs and pairs); "неактуально" pairs sort last; accent-tinted scroll edges;
  history "Показать ещё" pages by cursor (`before_first_seen`/`before_id`) and shows how many newer rows need
  "Обновить". Simplify suggestions applied (connection timers/abandon, watchScrollEdges, constants, heartbeat code).
  +1 test (cursor paging) → 125 passed. WIP checkpoint commit.
- 22:06 — Timestamps 21:35/21:36 and 22:12 above were estimates; corrected from the commit times (`575910d` 21:33,
  `3726794` 22:01). Later entries use `date -u`.
- 22:02–22:06 — Browser re-check of the round-2 fixes passed (details in VERIFICATION). Alert rule refined: an arb is
  announced when its own data turns alert-worthy, so filter changes and intermediate values while typing neither
  fire nor mute alerts; logic moved to `frontend/js/detector.js`. New Node tests `tests/js/frontend.test.mjs`
  (9: detector + liveness), `make test-js`. History cursor paging checked in the browser (100 → 200 → 235, button hides).
- 22:08–22:58 — Testing subagent executing (own instances on 8080/8081/8002, restarted on `f3bd0a3`). `pr report-risk`
  (score 4) → `not_tracked`: the platform has no datasource for this repository, so the score is not stored.
- 22:56–23:01 — Fixes for two bugs seen in the testing subagent's evidence: (bug 3) the settings error
  "matching.review_threshold must not exceed matching.auto_threshold" was shown in English → translated, field
  highlighted; (bug 2) after a long freeze "Live" came back only after the WebSocket backoff (up to 15 s) → a REST poll
  that succeeds after an outage reconnects the socket at once (only after an outage, no reconnect storm when a
  proxy blocks WebSockets). Checkpoint commit.
- 23:12–23:15 — Testing subagent's re-run results (`/code/.generated_artifacts/rerun_results.jsonl`, on `f3bd0a3`):
  all checks pass except T4c (1 of 4 freeze/resume cycles showed a false amber "Расчёт остановлен" for 0.9 s right
  after SIGCONT: the resumed server answers once with its pre-freeze evaluation time) and T5 (Live 8 s late after
  a 43 s freeze = bug 2, fixed in `81eb74a`). Fixes: the stall signal must persist 1.5 s (`STALL_CONFIRM_MS`); the
  "was down" check for the reconnect runs when the REST answer arrives; "неактуально" on its own line in the pairs
  table (from the subagent's patch). Node tests: 10. Checkpoint commit.

## 2026-10-16 — session 3

- 00:04 UTC — New session. Read docs/handoff. The repository is now `amantairthe/1` (same repository, created
  2026-10-15 17:17 UTC, renamed again). The earlier owner accounts `rayan23-bot` and `ravistiedemann79` return 404
  on the GitHub API, and PR #1 and PR #2 both return 404 now (API and web), although `refs/pull/1/head` (`51202fd`)
  and `refs/pull/2/head` (`3d07067`) still exist. Prior session transcripts and the testing subagent's artifacts are
  not available on the new machine.
- 00:06 — Fresh venv (installed `python3.12-venv` again), `pytest -q` → 125 passed. `node --test` failed once on the
  first (cold) run: `assert.ok(Math.abs(dataNow() - store.lastDataAt) < 50)` in the liveness test depends on wall-clock
  timing (the server-clock offset sample of a just-created STATE). The next 31 runs passed. To fix in this session.
- 00:10 — README clone URL updated to `amantairthe/1`. Checkpoint commit (handoff + README).
- 00:11 — `pr create` for head `vorflux/esports-arb-scanner-v2` → 422 "A pull request already exists for
  amantairthe:vorflux/esports-arb-scanner-v2" (hidden PR #2). New branch `vorflux/esports-arb-scanner-v3` at `57a9a55`
  (pushed) and new PR https://github.com/amantairthe/1/pull/3 (open, author `amantairthe`, visible on the API).
  The `-v2` branch stays at `57a9a55`; all new work goes to `-v3`.
- 00:13–00:17 — Fix (known issue, low): every order must reach the per-order minimum, not only the leg total.
  `execute_best_level` / `execute_walk_book` now run through `_with_min_orders`: when an instrument's order (Kalshi
  YES «A» or NO «B»; Polymarket has one instrument per outcome) is below `min_order_size`, that instrument is dropped
  and the leg is priced again (each retry removes an instrument, so it ends). The old leg-total checks moved into
  this wrapper. +5 tests → 130 passed. Node liveness assertion made exact (`dataNow() === lastDataAt + clockOffset`,
  `serverNow() − dataNow() ≥ 7000`) instead of a 50 ms wall-clock tolerance.
- 00:15 — The user sent a 49-minute log of `python run.py` on Windows (Python 3.13, branch `-v2` ZIP download,
  local time UTC+3): `Activate.ps1` was blocked by the PowerShell execution policy (fixed by the user with
  `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`); real mode works (Polymarket 99–105 markets, Kalshi
  110–118), 6 "ARB confirmed" lines (same OW Falcons vs SEIJI arb 4 times), warnings with empty error text
  (`network error on /books ()`), Polymarket `ws N error: no close frame received or sent` at 02:49:11 (together with a
  Kalshi network error → local network drop) and 03:13:48, no log line for the reconnect or for an arb that ends.
- 00:18–00:23 — Changes from the user's Windows log:
  - `backend/net.py`: `describe_error()` (message, or the exception type when the message is empty) for
    network-error warnings and `HttpError` texts; after a retried *network* error a request that succeeds logs
    `<client>: GET /path succeeded after N retries` (429/5xx retries do not, they are routine — a 45 s real run in the
    sandbox showed ~8 Kalshi 429 retries per discovery cycle).
  - Polymarket WebSocket: `ws N reconnected after X s` (INFO) after a lost connection; error texts via
    `describe_error`. Kalshi: `orderbook polling recovered after X s` after failed polls; error texts via `describe_error`.
  - Scanner: `ARB ended: <match> | lasted N s, max P% $V | <reason>` for confirmed arbs, reason = `stale data (<platform>)`,
    `trading paused (<platform>)`, `market gone (<platform>)`, `pair no longer matched` or `prices, depth or filters changed`.
  - README: Windows steps without activation (`.venv\Scripts\python.exe ...`), the execution-policy workaround, a
    table of log lines; why one arb can be confirmed several times. New `run-windows.bat` (double-click launcher:
    creates `.venv`, installs requirements, runs `run.py %*`; CRLF bytes kept by `.gitattributes` `*.bat -text`;
    not named `start.bat` because `start` is a cmd built-in). Not tested on Windows (no Windows or Wine here).
  - +6 tests → 135 passed.
- 00:24 — Quality phase started (user notified with the PR #3 link). Review subagent (`review-session3`, scope
  `3d07067..e35e749`, risk assessment requested) and testing subagent (`testing-e2e-s3`: plan + setup first, waits
  for the go-ahead) dispatched.
- 00:25 — Real-mode preview server on 0.0.0.0:8000 (`ARB_ALLOWED_HOSTS='*.vorflux.com'`, `--db /tmp/arb3/preview_real.db`),
  preview URL `localhost:8000`, public URL https://aq7g72fga4r8.preview.us1.vorflux.com (browser check passed).
- 00:39 — Review (`review-session3`): risk 3/10, low, "ship with mitigations". Medium finding: `_with_min_orders`
  dropped small instruments from both legs at once, so a Kalshi leftover below 1 contract also made the Polymarket
  order (min 5 shares) "small" and emptied that leg → no arb (tests hid it with a Polymarket minimum of 0).
  Low findings: rebalancing instead of dropping (understates volume only), `run-windows.bat` error handling, logging
  wording/gaps, README contradictions, test gaps.
- 00:40–00:43 — Review fixes: instruments of a split leg are dropped first (a whole leg only when nothing else is
  small); `describe_error` = `Type: message` (HttpError text as is); Polymarket `ws N connected after` (first
  connection after failures) vs `reconnected after`, `ws N closed (code C), reconnecting`, `REST book refresh recovered
  after X s`; Kalshi recovery line only after a real poll; `ARB ended` shows the legs, only for arbs that had an
  `ARB confirmed` line (`_announced` set), and is logged on shutdown (`scanner stopped`); `run-windows.bat`: `pushd`,
  `run.py` presence check (ZIP not extracted), `where py`, Python ≥ 3.11 and pip checks of `.venv` (broken `.venv` →
  "delete the .venv folder"), message before the first install, exit code kept; README: `py -3 -m venv`, activation
  text without contradiction, Kalshi/Polymarket recovery lines, note that durations start when the failure is noticed.
  Not done (low, conservative): rebalancing split orders instead of dropping a part. +5 tests → 140 passed.
- 00:44 — Review fixes committed (`48c4ab0`, pushed to `-v3` and `-v2`); preview server restarted on it.
- 01:00 — Testing subagent had not returned its plan after 34 min (still active); sent it the go-ahead to execute on
  `48c4ab0` with a summary of the changes.
- 01:02 — `pr edit` for PR #3 → "No GitHub datasource has access to repository: amantairthe/1" (`pr create` works
  with the user token, editing does not); `pr report-risk --score 3` → `not_tracked`. The intended PR description is
  saved in `docs/handoff/PR_BODY.md` (paste it into PR #3, or apply it with `pr edit` once the GitHub integration
  has access to the repository).
- 01:13 — Testing subagent (`testing-e2e-s3`): OVERALL PASSED, 25/25 cases (re-run on `48c4ab0`), incl. iptables
  outages of its own real-mode instance (`stale data (Kalshi)` / `(Polymarket)`, reconnect and recovery lines),
  SIGSTOP/SIGCONT liveness, `scanner stopped` on SIGINT, split-book fixture (`/tmp/e2e-s3/fixture/splitfix.py`)
  reproducing the min-order bug on `e35e749` and its fix on `48c4ab0`. Minor issues found: (1) split instrument text
  cut off in the arbs table (`.leg-instr` nowrap + ellipsis); (2) pairs table highlighted the raw top-of-book Kalshi
  price that the engine skips (tiny leftover) while "Лучшая сумма" used the executed price; (3) recovery durations
  measured from when the failure was noticed (after ~74 s of HTTP retries) understated the outage 5×; (4) `ws: no
  PONG` line without the connection number; (5) no unit test for `REST book refresh recovered`.
- 01:14–01:17 — Fixes for all five: each part of a split instrument on its own line (wraps, nothing cut off);
  quotes carry `left_price`/`right_price`/`left_instrument`/`right_instrument` (what the engine buys) and the pairs
  grid and review cards show those (`quoteCells()` in `frontend/js/views/common.js`, raw top of book only when a
  direction has no quote); durations are the data gap — `ws N reconnected, no data for X s` (since the last frame),
  `ws N connected after X s of failed attempts`, `orderbook polling recovered, no data for X s` and `REST book refresh
  recovered, no data for X s` (since the last successful poll); `ws N: no PONG …`; README table updated. +3 pytest
  (REST recovery, PONG line, executed quote prices) and +1 Node test (quote cells) → 143 pytest, 11 Node.
- 01:17–01:19 — Browser check of the UI fixes with the tester's split fixture on :8090 (`PYTHONPATH=/tmp/e2e-s3/fixture
  … --config /tmp/e2e-s3/split.yaml`): arbs table shows `YES «Bravo» ×3` / `+ NO «Alpha» ×4` on two lines, nothing cut
  off, table fits at 1440 px; pairs tab highlights Kalshi 0,42 (NO «India») for India vs Juliett and NO «Charlie» ×4
  for Charlie vs Delta, consistent with "Лучшая сумма". Testing subagent asked to re-verify the 5 fixes on `d8942e9`.
  Preview server restarted on `d8942e9` (quotes carry the new fields).
- 01:28 — Testing subagent re-check on `d8942e9`: PASSED 5/5 (split instrument on two lines, table 1390/1390 at 1440
  and 1301/1301 at 1366; quote cells incl. review cards; 110.1 s full outage of its own instance → `orderbook polling
  recovered, no data for 110.5 s`, `ws 0 reconnected, no data for 110.8 s`, `ws 1 … 113.8 s`, `REST book refresh
  recovered, no data for 113.6 s`; `ws 1: no PONG for 15 s, reconnecting`; pytest 143, Node 11). New finding (older
  code): a discovery that runs out of retries logged `ERROR … discovery failed` with a ~60-line traceback. Fixed: an
  `HttpError` there gives one line `WARNING <platform>: discovery failed: <error> (retry in N s)`; other exceptions
  keep the traceback. README log table: discovery line. +1 test → 144 passed.
- 01:29 — **Blocker: the GitHub account `amantairthe` is suspended.** `git push` → 403 "remote: Your account is
  suspended"; `https://github.com/amantairthe/1`, PR #3 and `/users/amantairthe` → 404; `git ls-remote` → 403. This is
  the third owner account of this repository to be suspended (`rayan23-bot`, `ravistiedemann79`, `amantairthe`).
  The last published commit is `8c8ac78` (on `-v2` and `-v3`, now unreachable); `04cbe85` (discovery-log fix) and this
  entry exist only locally. A git bundle with the full history and a ZIP of the working tree were saved as
  downloadable artifacts in the session (`/code/.generated_artifacts/esports-arb-scanner-full-history.bundle`,
  `/code/.generated_artifacts/esports-arb-scanner-<sha>.zip`).
- 01:30 — Saved and verified: `esports-arb-scanner-full-history.bundle` (branches `main`, `vorflux/esports-arb-scanner`,
  `-v2`, `-v3`; a clone of it passes 144 pytest + 11 Node tests) and a source ZIP (`run-windows.bat` keeps CRLF).
  Test Report published (report 1110, PASSED, coverage 25/25). Preview server on :8000 restarted on `e0c0d78`.
  `docs/handoff/PR_BODY.md` updated with the final Testing section for the next PR.
- 07:41 — The user asked where the session stopped. Re-check: still suspended (`git ls-remote` → 403;
  `/users/amantairthe`, `/repos/amantairthe/1`, PR #3 → 404; no Vorflux datasource). Found a fault in the saved
  bundle: it had no `HEAD`, so a plain `git clone <bundle>` gave an empty working tree ("remote HEAD refers to
  nonexistent ref, unable to checkout"). The new bundle includes `HEAD` (a plain clone checks out `-v3`). Restore
  route tested: `git clone --mirror <bundle>` + `git push --mirror` into an empty bare repository → all 4 branches.
- 07:44 — NEXT_STEPS rewritten: where session 3 stopped, resume steps, open items. Local commit only (push blocked);
  new bundle and source ZIP saved as session artifacts.
- 08:21 — The user asked for an opinion on next steps and how to add Stake and BC.Game. Research: Stake has an
  official STAKE Sports Data API (`https://odds-data.stake.com`); it answered without a key from the sandbox and lists
  CS2, Dota 2, LoL, Valorant, Overwatch and R6 with a `Match Winner - Twoway` market in decimal odds. BC.Game runs on
  BETBY (industry news), no official API; odds-api.io lists both books. Live sample: Stake Fnatic 2.50 / Heroic 1.48
  (≈ 7.6 % margin) vs Polymarket 0.34 / 0.67 and Kalshi 0.35 / 0.66 → no arb.
- 08:28 — Facts added to `docs/API_NOTES.md` (Stake, BC.Game sections); recommendation and the Stake adapter design added
  to `docs/handoff/NEXT_STEPS.md` ("Roadmap after the restore"). Local commit only (push blocked); bundle and source
  ZIP rebuilt.

## 2026-10-16 — session 4

- 13:02 UTC — New session. Read `CLAUDE.md` and docs/handoff. The repository is `lndrosa/arbitrage` (private, the
  user's own account). The history was restored from the bundle, and `vorflux/esports-arb-scanner-v3` was merged into
  `main` through PR #1 (`cd055b3`). Then the user added `CLAUDE.md`, `.github/workflows/ci.yml` (pytest + Node tests on
  push to `main` and on PRs) and a README clone URL (`5e55fb3`). `gh pr list --state all` shows no PRs;
  `/repos/lndrosa/arbitrage/pulls/1` → 404.
- 13:05 — Fresh venv (installed `python3.12-venv` again). On `5e55fb3`: `pytest -q` → 144 passed, `node --test` → 11 pass.
- 13:10 — Branch `vorflux/session4-checks` from `main`. End-to-end check of `04cbe85` started in the background (own
  real-mode instance on :8041 under a separate user `arbcheck`; its outbound traffic is cut with iptables, loopback stays
  open: phase 1 = DROP for 240 s after a good start, phase 2 = start while REJECT is active). Review subagent
  (`review-d8942e9-04cbe85`) dispatched for `48c4ab0..04cbe85` without docs, with a risk assessment.
- 13:13 — Handoff rewritten for session 4 (STATUS, NEXT_STEPS: plan of three stacked PRs, open items). `PR_BODY.md`
  removed: it was the text for the PR that is now merged.
- 13:13 — User decisions: the repository is `lndrosa/arbitrage` (the user's account) and the README clone URL must be
  `https://github.com/lndrosa/arbitrage.git`; names of the earlier owner accounts must not appear in the README,
  instructions or new documents (older HISTORY entries and existing commits stay as they are); the "per day" report
  uses the time zone Europe/Moscow; the rest of the plan is approved. README clone URL changed.
- 13:15–13:27 — End-to-end check of `04cbe85`. The first attempt cut only IPv4, so Polymarket (IPv6 here) stayed
  online; repeated with `ip6tables` as well. Result: every discovery that ran out of retries logged one line
  `WARNING … <platform>: discovery failed: <error> (retry in N s)` (4 lines in a 240 s black-hole outage, 5 lines while
  starting offline), no traceback and no ERROR line in the whole log. Details in VERIFICATION.
- 13:24 — Review (`review-d8942e9-04cbe85`): risk 2/10, low, "safe to ship"; no high or medium findings. Low: (1) the
  WebSocket data-gap clock restarted at every handshake, so connections that open and deliver nothing hide a growing
  gap; (2) in WebSocket mode `REST book refresh recovered, no data for X s` reports the time since the last REST
  success, which is not a data gap (the WebSocket may have delivered data); (3) no test checked the logged durations.
  Nits: (4) `connected after X s of failed attempts` counted from the first failure, not from the start of the first
  attempt (up to 15 s too short); (5) a rejected discovery request (4xx) looked like a temporary outage; (6) a
  misplaced doc comment in `common.js`; (7) `_ping_loop(conn_id=0)` default; (8) `' + '` inside a team name split the
  instrument text, and `legCell` had no test.
- 13:25–13:30 — Fixes for all eight review findings plus the gap from the check:
  - `polymarket.py`: new `WsLink` per WebSocket loop (last frame, start of the first failed attempt, connected); a
    connection without frames does not reset the gap; `connected after` counts from the start of the first attempt;
    `_ensure_ws` hands the link of a loop that is down to the loop that replaces it, so the recovery after a new
    subscription is still logged with the whole gap (a link that is up starts afresh: no line for a routine
    re-subscription); in WebSocket mode the REST line is `REST book refresh recovered, last success X s ago`;
    `_ping_loop` needs `conn_id`.
  - `scanner.py`: a discovery request rejected with 4xx (except 408, 425, 429) is logged at ERROR level, still one line
    without a traceback.
  - `common.js`: `quoteCells` moved below `alignedRight`; a split order is cut only at `' + '` before the next `YES «` /
    `NO «` part.
  - README log table: the REST line in WebSocket mode, the ERROR discovery line, the `no data for` wording.
  - Tests: fake clock (`time` attribute of the adapter module patched) with exact durations for the WebSocket, REST
    (both modes) and Kalshi recovery lines; handover test; rejected-request test; Node test for `legCell`.
    148 pytest + 12 Node tests pass.
- 13:31–13:38 — Re-check of the fixes on a live instance (same outage, phase 1 only): the market set changed after the
  outage again, and this time the log has `ws 0 reconnected, no data for 245.0 s` (the outage was 240 s) and the new
  `REST book refresh recovered, last success 251.1 s ago`; no traceback, no ERROR line.
- 13:19–13:44 — Statistics report (roadmap step 2) on `vorflux/history-stats-report` (branched from
  `vorflux/session4-checks`, which is merged into it):
  - `backend/stats.py`: the report for the last N days. Days are calendar days in `stats.timezone` (Europe/Moscow by
    the user's decision; day bounds from `zoneinfo`, so zones with summer time also work). Units: an arb = one
    confirmed appearance (= one `ARB confirmed` line); distinct arbs, matches, candidates (vanished before the
    threshold); profit $ = sum of the maximum profit of each appearance after fees (upper estimate) and without
    repeats = the best appearance of each arb per day; medians of profit %, volume and lifetime; shares of arbs that
    lived 30 s / 60 s; tables per day, per lifetime bucket, per game, per pair of venues, top matches.
  - Scanner uptime: table `scanner_uptime` (one row per Unix minute; `healthy` = every platform healthy at every
    check, a check every 30 s). The first row marks when tracking started: older days have unknown hours (`—`), not
    0. "Per 24 h with fresh data" counts only arbs found after tracking started.
  - `report.py` (text, or `--json`; `--days`, `--db`, `--mock`, `--config`, `--tz`, `--top`): opens SQLite read-only
    (works while the scanner writes; never creates a missing file), clear messages for a missing or unreadable file.
    `GET /api/stats?days=1..366&top=1..50` for the dashboard. Config `stats.timezone` (validated at load).
  - README section "Статистика по истории". 160 pytest (+12 in `tests/test_stats.py`) and 12 Node tests pass.
  - One test failed on the first run because my own expected order was wrong: games and matches are sorted by profit
    and then by the number of arbs, so CS2 (3 arbs, $1.00) comes before Dota 2 (1 arb, $1.00). The rule stayed; the
    expectation was corrected.
- 13:45 — PR https://github.com/lndrosa/arbitrage/pull/2 (`vorflux/session4-checks`) and
  https://github.com/lndrosa/arbitrage/pull/3 (`vorflux/history-stats-report`) opened, both into `main`, both open
  (not draft). `pr create` reported `assignee_error: No GitHub datasource has access to repository: lndrosa/arbitrage`
  (the PRs were created with the user token; assigning failed).
- 13:46–13:55 — "Статистика" tab on `vorflux/stats-tab` (branched from `vorflux/history-stats-report`):
  - `frontend/js/views/stats.js`: period Сегодня / 7 / 30 / 90 days (saved in the browser), Обновить, JSON download;
    six KPI cards with "?" hints; the uptime note; tables per day (new days first, bars for arbs and profit), lifetime
    buckets, per game, per pair of venues, top 10 matches; empty state; loads `/api/stats` when the tab opens (no
    redraw every second).
  - `frontend/js/stats-format.js`: formatting without DOM (hours, minutes, days, shares, bars, KPI texts, uptime note),
    5 Node tests in `tests/js/stats.test.mjs`.
  - Browser check (seeded 7-day history on the preview) found and fixed: game badges showed raw ids when the report
    came before META (the view now redraws on META); bars covered the numbers (now a track left of the number); the
    new tables had no scroll-edge shadow (`watchScrollEdges` now returns its observer, the view re-watches after each
    render); at 900 px the sixth tab did not fit (below 1100 px the pairs tab is called «Пары» and tabs are narrower).
  - README: the tab in the UI section and in "Статистика по истории". 160 pytest + 17 Node tests pass.
- 13:57–14:09 — Quality pass over the three PRs: a simplify subagent and three review subagents (one per PR). Review of
  PR #2 (`review-pr2-fixes`): risk 2/10, "safe to ship", no high or medium findings. Low: (1) `WsLink.connected` stayed
  True up to ~20 s after the data stopped (PONG timeout, closing handshake), so a re-subscription in that window could
  still lose the recovery line; (2) no test ran the real loop through a re-subscription. Nits: the flag was set before
  an await and the line logged after it; the test helper could spin forever when a script ended with a failure;
  `last success` was printed when REST had never succeeded; CLAUDE.md test counts.
- 14:10–14:14 — Fixes on PR #2 (worktree `/tmp/wt-a`, because the preview runs from the main working tree):
  `connected` becomes True only right after the recovery line (no await in between) and False as soon as data stops
  (inner `finally` before the closing handshake, and in `_ping_loop` before closing a connection without PONG);
  comment that the handover is matched by connection number; REST in WebSocket mode without any earlier success logs
  `REST book refresh recovered, first success X s after start`; the test helper stops when its script runs out; new
  test `test_polymarket_ws_real_loops_hand_an_outage_over_on_resubscription` (real `_ensure_ws` and `_ws_loop` tasks,
  fake clock: a routine re-subscription logs nothing, an outage replaced by a new subscription logs exactly
  `ws 0 reconnected, no data for 100.0 s`). 151 pytest + 12 Node tests pass. Not done (nit): the start of an attempt
  that is still in flight when its loop is replaced is not handed over (at most 15 s too short, logs only).
- 14:17 — Review of PR #3 (`review-pr3-stats`): risk 3/10, "ship with mitigations". Medium: `GET /api/stats` read
  through the scanner's own connection (one shared lock) and built the report on the event loop: on a large history
  (their test: 240k confirmed rows) scanning paused for seconds. Low: the per-24h rate counted arbs from all minutes but
  divided by the minutes with fresh data only (the same as the Macroscope comment) and extrapolated from 60 minutes;
  the CLI showed the threshold from `config.yaml` instead of the one saved in the UI; `report.py --json > file` garbles
  Cyrillic in PowerShell 5.1; the read-only URI failed for network drives (`resolve()` → UNC host); test gaps. Nits:
  the uptime note, `--db <folder>`, the "file not found" hint, README details, bugs in the uptime check logged as
  write failures. Simplify (`simplify-stats`): behaviour-preserving patches for #3 and #4 (checked on 400 random
  histories and in headless Chrome).
- 14:18–14:30 — PR #3 fixes (worktree `/tmp/wt-b`; `vorflux/session4-checks` merged in first, append-only handoff
  conflicts resolved by keeping both sides):
  - simplify patch applied as its own commit;
  - the report is built in one pass over a database cursor (`_Group` aggregates, `array('d')` for the medians, no row
    copies) inside one worker-thread call `Database.read()`, which runs all queries in one fresh read snapshot (ends a
    transaction left open, rolls back afterwards); the queries are module-level functions in `db.py`;
  - `/api/stats` opens a read-only connection of its own per request (falls back to the scanner's connection only if
    that fails);
  - per 24 h = arbs whose minute has fresh data (`LEFT JOIN scanner_uptime` on the minute of `first_seen`, column
    `minute_healthy`) / minutes with fresh data × 1440, shown from 24 h of such minutes on;
  - day of a row found by comparing its UTC isoformat string with the day bounds (bisect), venue keys cached;
  - CLI: saved UI settings applied (threshold), `2,5 с` formatting, `-o/--output` (UTF-8 file), `is_file()`, clearer
    hint (`python run.py --mock` for `--mock`), UTF-8 for stderr too;
  - read-only open: `absolute()` URI, UNC fallback with `PRAGMA query_only = ON`;
  - uptime loop: database errors are a warning once per streak, other exceptions keep the traceback;
  - uptime note in the text report: partial hours from the start of tracking, or days with arbs but no uptime rows;
  - README: `-o`, the threshold, the rate definition and caveat, candidates ≥ 1 s, lifetime includes the threshold;
  - tests: rate with `minute_healthy`, 24 h minimum, missing values, unknown hours after tracking started, the minute
    health from SQL and exact day bounds with microseconds, read-only cannot write and sees a running writer, uptime
    write failures never stop the scanner, CLI `-o` / saved threshold / folder / unwritable output, `/api/stats` does
    not use the scanner's connection. 168 pytest pass.
  - Three test failures on the way, each explained (none fixed by changing what the test expects without a reason):
    (1) the rate test, because the rate definition changed on purpose; (2) `test_missing_values…`: my own test
    expected the team of the older row although the newest row of the pair defines it; (3) the read-only test: a
    failed write left an implicit transaction open on the read-only connection, which pinned an old snapshot (this led
    to the fresh-snapshot `read()`). Later the same test failed again only because a mutation check and its restore
    had the same file size within one second, so Python kept the stale `.pyc`; clearing `__pycache__` fixed it.
- 14:31 — Replies to the Macroscope comment on #3 and #4 (`gh api …/comments/<id>/replies`; `vflux pr reply` and
  `pr edit` fail with "No GitHub datasource has access to repository: lndrosa/arbitrage", `pr report-risk` →
  `not_tracked`). PR #2 description updated through the REST API (only the Vorflux block).
- 14:32–14:36 — PR #4 (main working tree, `vorflux/stats-tab`): `vorflux/history-stats-report` merged in (README and
  append-only handoff conflicts resolved), simplify patch for the tab applied as its own commit (it also fixed review
  finding 2: scroll listeners are re-attached only when the content really changed). Fixes for the review of #4
  (`review-pr4-tab`: risk 2/10, "safe to ship"): the per-24h word agrees with the rounded number («5 вилок», not «5
  вилки»); the summary line uses `setHTML` in every state (it could stay blank after a failed period switch); no toast
  when the error card already says it; the old period's numbers are dimmed (`aria-busy`) while another period loads;
  formatted counts; gap above the loading/error card; no stale-data dimming on this tab; hints with `role="button"`
  and an `aria-label`; arrow keys ignore modifier keys; `stats-<N>d.json` download name; `title` on KPI values;
  `DEFAULT_DAYS` reused in `store.js`; the HTML builders are exported and covered by an escaping test. Adapted to #3:
  "нужно хотя бы 24 ч со свежими данными", the rate and lifetime hints, the uptime note rules of the console report.
  168 pytest + 18 Node tests pass; browser re-check passed (VERIFICATION 14:34–14:36).
- 14:38–14:58 — Second review round of #3 and #4 (`review-round2-stats`): risk 3/10, "ship with mitigations". The
  rewrite gives the same output as the old code on 4,500 random cases (10 time zones, day edges, NULLs, non-UTC strings)
  except the intended rate change; the snapshot handling cannot roll back committed scanner data. Medium: parallel
  `/api/stats` requests (a held arrow key, refreshes, retries) all ran at once on the default thread pool, which the
  scanner's database writes also use: on a 240k-row history 6 parallel requests stalled the scanner's next write for
  21 s. Low: `report.py -o <history file>` would overwrite the history. Nits: one flag for both kinds of uptime errors;
  "UTC only" for `minute_healthy`; wrappers used only by tests; "Сегодня" can never show a rate; test gaps.
- 14:58–15:00 — Fixes on #3 (`/tmp/wt-b`): `StatsBuilds` in `server.py` — one build at a time (lock) and one shared task
  per (days, top), shielded so a request that goes away does not cancel it for the others; `report.py -o` refuses the
  history file and its `-wal`/`-shm`; the uptime loop remembers the kind of failure ("db"/"bug") and logs again when it
  changes; comments for the UTC-only join and the test-only wrappers. Tests: build queue (one build for identical
  requests, never two at once, a cancelled waiter does not cancel the build), the API fallback to the scanner's
  connection, the UNC fallback (simulated: reads work, writes fail), `-o` on the history file. 172 pytest pass.
- 15:01–15:02 — #4 (main working tree): #3 merged in again (append-only handoff conflicts: both sides kept). Round-2
  fixes in the tab: a held arrow key (`e.repeat`) does not switch the period again and again, and while a request for
  a period is running, the same period is not requested again (5 quick clicks on «Обновить» → 1 request); «Сегодня»
  says "для оценки выберите 7 дней или больше" instead of "нужно хотя бы 24 ч" (one day can hardly collect 24 h of
  fresh data). Preview restarted on the final code. 172 pytest + 18 Node tests pass.

## 2026-10-16 — session 5 (Stake adapter)

- 16:17 UTC — Task: connect Stake as the third venue (design: NEXT_STEPS item 6). Branch `vorflux/stake-adapter` from
  `main` = `0f2d40c`. Baseline on `main`: 172 pytest + 18 Node tests pass (the sandbox has no `python3-venv`: the venv
  was made with `--without-pip` + get-pip).
- 16:19–16:40 — Live research of the STAKE Sports Data API (no key): `/sports`, schedules, fixture lists, fixture odds
  for all 64 fixtures of the six games, tournaments, categories, a 160-request rate test (8 req/s, all 200). Findings
  that differ from the design or the spec (details in `docs/API_NOTES.md`, numbers in VERIFICATION):
  - `/schedule/sport/<slug>` rounds the start time down to the hour and has no tournament → discovery uses
    `/sport/<slug>/fixture?limit=50&offset=<n>` (same fixtures, exact `startTime`, tournament; limit ≤ 50);
  - `groups[].markets` is a list of market lists (the spec says a flat list); the two-way market is listed in
    `main`, `winner` and `threeway` → flattened and deduplicated;
  - an unknown fixture answers HTTP 500 `{"message":"error"}`, not 404;
  - no batch odds endpoint: one request per fixture; the scanner passes all markets to `subscribe_prices` and does
    not say which are paired, so "poll only paired fixtures" needs a small hook (`MarketAdapter.set_paired`, called
    by `Scanner.rematch`);
  - the header counter "Матчи" (`markets − pairs`) undercounts a match paired on three venues → counted as connected
    groups of pairs.
  - Stake rules from the web-archive copy (2026-10-11) of `stake.com/policies/sportsbook` (the site answers 403 to the
    sandbox): postponed > 24 h, cancelled, walkover, retirement during the match and a draw of a two-way market → void.
- 16:20–16:44 — Written (WIP, not committed before 16:45): `backend/adapters/stake.py`, config sections `platforms.stake`
  and `fees.stake`, `STAKE_RULES`/`STAKE_PROFILE` in `rules.py`, four aliases (cs2 Betclic, BET-M 33; r6 CAG Osaka,
  Kingzone/KINGZERO), the `set_paired` hook, the match counter, a bookmaker profile for `--mock`, `ARB_STAKE_API_KEY`
  in `.env.example`, recorded fixtures (R6 Cloud9 vs M80 on Stake, Polymarket and Kalshi, 16:43 UTC).
  `test_meta_and_state` expected exactly {polymarket, kalshi}; it now expects stake too (config has three platforms).
- 16:45 — WIP commit `8a3498e` pushed (172 pytest + 18 Node pass on it). Interim message to the user with the
  differences between the design and the code/API (hook, counter, discovery endpoint, no model change for a minimum).
- 16:46–16:50 — Tests on the recorded responses: `tests/test_stake.py` (18: odds → price/size, nested markets, the
  two-way market filter, discovery with the recorded R6 lists, the API key header, the discovery window, live /
  suspended / closed fixtures, BO2 skipped, fast and slow polling, one log line per failing fixture, the poll-loop
  outage and recovery lines, zero fee, an arb with a Stake leg, three venues through `Scanner.rematch`, a broken hint,
  the match counter, the mock bookmaker), `test_rules.py` (+1: Stake profile vs the real Polymarket and Kalshi texts),
  `test_stats.py` (+2: pairs with Stake in "пары площадок", also from a database through `collect`).
  A test found log spam: odds requests used `retries=1`, so `backend.net` logged "HTTP 500 … retry" on every pass for
  a broken fixture → odds requests now use `retries=0` (the next pass retries anyway). My own expectation that the
  second discovery asks for no fixture at all was wrong: fixtures without an answer are asked again each discovery.
- 16:51 — Live run of the full scanner started (`/tmp/stake/live/run_live.py`: `backend.run.main` with request
  counters per HTTP client, port 8031, history in `/tmp/stake/live/live_run.db`). 16:53 — quote-delay measurement
  started (`/tmp/stake/live/delay.py`, 10 min: 3 live + 3 pre-match fixtures every 2 s, `updatedAt` vs receive time).
- 16:52–16:56 — README: Stake section (how it works, the key, assumptions, bookmaker risks), log lines, the
  "Данные, ч" caveat with three venues, the data-source table, Stake in the arb maths; `docs/API_NOTES.md`: the Stake
  section rewritten as verified. Log lines of the Stake adapter lost the redundant "stake:" prefix (the logger name is
  `adapter.stake`).
- 16:58 — PR opened: https://github.com/lndrosa/arbitrage/pull/5 (not a draft). Message to the user: post-processing
  starts. Subagents: `simplify-stake` (worktree `/tmp/wt-simplify`, patch only), `review-stake-adapter`,
  `review-stake-integration` (read-only, with risk assessments).
- 16:59–17:06 — UI check: `--mock` instance on port 8041 (`--host 0.0.0.0`, `ARB_ALLOWED_HOSTS='*'` in the shell only,
  history in `/tmp/stake/mock_ui.db`), preview `https://aw5xy4wcey3n.preview.us1.vorflux.com/`; the live instance
  (port 8031) opened locally. README: measured quote delay of the Stake API.
- 17:12 — `simplify-stake` patch applied as its own commit `53bf5a5` (no behaviour change; 193 + 18 pass).
- 17:14 — `review-stake-integration`: risk 3/10, "ship with mitigations": engine, matcher, fees, tracker untouched; the
  hook and the counter cannot change pairs or arbs; aliases and rules are data only. Findings: the report's "матчей"
  counted venue pairs (one match on three venues = 3); README lacked how to switch Stake off (uptime now needs all
  three venues); stale `CLAUDE.md`/`STATUS.md`; nits (redundant alias variants, the rules comment, the Stake mock
  listed MLBB, `set_paired` not in "Как добавить новую площадку", traffic per day).
- 17:15 — `review-stake-adapter`: risk 5/10, "ship with mitigations". Two real bugs, both reproduced by the reviewer:
  (1) a pass applied its answers only at its end, so a quote was already as old as the pass (12 s worst age with
  50 paired fixtures, 25 s with one hung request); (2) when Stake lists the outcomes the other way round,
  `Scanner._merge` keeps the book (equal time) but takes the new team order → a fake 40.6 % arb on the recorded data
  (the simplify patch had removed the re-apply in `subscribe_prices` as dead code; it was the guard). Also: no backoff
  and no 429 handling, partial failures looked healthy, one failing game list stopped the whole discovery, BO2 only
  from "Correct Score", a custom key header would follow a cross-host redirect, test gaps, a flaky time comparison.
- 17:15–17:29 — Fixes: every answer is applied at once; the unpaired fixtures only get the requests left in a pass
  (80 % of rate × interval, the longest waiting first); answers stamped with the request time; 4 s request timeout;
  backoff 10 → 60 s when half or more of a pass fails or on 429, such a pass is "down"; a warning when a pass takes
  longer than `stale_seconds − 3`; a failing game list keeps its last list (all failing → discovery fails); a draw is
  also seen from a match-level three-way market; outcome lists are validated; `subscribe_prices` re-applies the cached
  odds again (with a test through `Scanner._merge`); one line for a full outage; `HttpClient(follow_redirects=False)`
  for Stake (new optional argument, default unchanged); the report counts distinct matches (`count_matches`, pairs
  that share a market are one match); the mock Stake lists only its configured games; aliases without the redundant
  variants; README (switching Stake off, traffic, timings, 403 can be Cloudflare, `set_paired` for new venues, log
  lines), `CLAUDE.md` (205 passed, Stake in the venue and adapter lists).
- 16:51–17:29 — First live run (code `8a3498e`…`3859a9f`) stopped with SIGTERM; the shutdown wrote the 3 active arbs.
- 17:30 — Second live run started on `7500580` (port 8032, `/tmp/stake/live2/`), with a sampler of the Stake quote
  ages from `/api/state` every 2 s. Review round 2 (`review-stake-round2`, scope `3859a9f..7500580`).
- 17:46 — Round 2: risk 4/10, "ship with mitigations"; fixes 1, 2, 4, 5, 6 of round 1 verified (incl. the merge test
  failing against the old logic). New: (1) a total outage of the odds endpoint during discovery was silent and Stake
  looked healthy with 0 markets (regression of the "one line for a full outage" change); (2) the "half or more failed"
  rule flipped small passes (one timeout or a removed fixture) to "down", and the first backoff step (10 s) equalled
  `stale_seconds`; also one 429 paused polling; (3) an empty pass counted as a recovery; (4) errors while applying an
  answer counted as failed requests; (5) an unfollowed redirect was read as a normal (possibly empty) answer;
  (6) no tests pinned the request-time stamp and the 429 flag.
- 17:47–17:50 — Fixes: discovery raises when not one odds request answered and there are neither markets nor recent
  odds (the scanner then logs `discovery failed … -> 403` and Stake is not healthy), otherwise one warning per streak;
  "down" needs two passes in a row with more failures than answers, backoff only while down or after two passes in a
  row with a 429; an empty pass changes no state; apply errors are logged with their traceback once per fixture and
  are not request failures; `HttpClient` raises `… redirect to <host> not followed` for a 3xx when it does not follow
  redirects (the game then keeps its last list); the loop's sleep is injectable for tests. Tests: 208 passed.
- 17:51 — Third live run started on the final code (`3520618`, port 8033, `/tmp/stake/live3/`) with the sampler.
  Two screenshots kept as evidence (live active arbs with Stake legs; the mock "По парам площадок" card). The PR
  description was replaced through the REST API (`vflux pr edit` and `gh pr edit` fail: no datasource / missing
  `read:org`); `pr report-risk` → `not_tracked`. Out-of-scope finding surfaced: Polymarket and Kalshi discovery stops
  for all games when one game request fails (Pending).
- 17:52–17:56 — The Macroscope bot left 7 inline comments on the PR commits; 3 were already fixed by the review rounds
  (BO2 seen while polling, answers applied only at the end of a pass, an idle pass as recovery). Fixed now: a fixture
  with unusable team names is asked again after `slow_poll_interval_sec`; a list answer without the list is a failure
  (the game keeps its last list) instead of an empty list; an older answer never replaces a newer one (discovery and
  polling can overlap); an empty pass while not failing marks Stake connected (no markets at all was "unhealthy" since
  the round-2 change). 4 tests; 212 passed.
- 18:07 — Third live run stopped. `request_timeout_sec` default 4 → 3 s (one straggler made a 7.9 s pass); README
  numbers updated. Macroscope threads answered (7 replies, REST API).
- 18:08–18:12 — Short live run of the final code (`54bfad9`, port 8034, `/tmp/stake/live4/`); then one more
  Macroscope comment (18:00): when Stake replaces one team of a fixture (A–B → C–B), the old market would still price
  B. Fixed: an answer is priced only when it has the same two teams as the market (any order); otherwise the market
  has no levels and takes no orders until discovery builds it anew. The test of renamed outcomes now expects both
  sides empty (my own test from this session, not one of the original 172). 212 passed.

## 2026-10-18 — session 6 (honest arb statistics, three stacked PRs)

- 19:34 UTC — Task from the user: make the arb statistics honest without changing how arbs are found. Input: the
  real history `arb_copy.db` (16.10–18.10, server in Germany), committed to `main` in `f8325dc` ("Add files via
  upload"; `*.db` is in `.gitignore`, the file came through the GitHub upload). The user's rules for it: do not change
  or rename it, analyse copies outside the repository (`/tmp/arbdb/`), do not add it to new commits. Baseline on
  `main` `f8325dc`: 212 pytest + 18 Node pass (venv again with `--without-pip` + get-pip: no `python3-venv`).
- 19:35–19:45 — Read CLAUDE.md, NEXT_STEPS, STATUS, `stats.py`, `report.py`, `storage/db.py`, `engine/arb.py`,
  `engine/tracker.py`, the adapters and the «Статистика» tab. Checked the user's numbers on a copy (all match; details
  and the small differences in VERIFICATION). Interim message: the file is tracked by git, the numbers, the
  differences.
- 19:47–19:49 — Three questions to the user, answers: keep `arb_copy.db` as it is; PR 2 re-reads the books with its
  own REST requests to both venues and compares them with the scanner's books; PR 3 bankroll = one capital pool with
  money locked until settlement (`settle_hours` after the later of start and confirmation).
- Plan (stacked like session 4, every PR targets `main`): PR 1 `vorflux/stats-capture` (data: phase,
  minutes_to_start, book snapshots at confirmation and at the peak, profit at fixed stakes with walk_book, optimal
  size, liquidity flags, migration with ADD COLUMN); PR 2 `vorflux/paper-checks` from PR 1 (REST re-read at +5/+15/+60
  s); PR 3 `vorflux/honest-stats` from PR 2 (report, API, tab).
- 19:50–19:59 — PR 1 WIP: `capture:` config section, `arb.py` `direction_inputs` / `cap_levels` / `execute_budget`
  (walk_book under a budget), `engine/capture.py`, `ClosedArb.capture`, `MarketAdapter.instrument_ids` (Kalshi:
  label → ticker and side), migration in `storage/db.py` (17 columns, ALTER TABLE ADD COLUMN), `GET
  /api/history/{id}` with the snapshots, a coverage line in the report. Existing 212 tests pass; new tests not
  written yet.
- 20:00 — WIP commit `703ea82` pushed (212 pytest pass on it, no new tests yet).
- 20:00–20:06 — `tests/test_capture.py` (17 tests: `cap_levels`, `execute_budget` with fees, Kalshi rounding and
  minimum orders, the Stake limit, the stake table and the optimal size, phase, snapshots at confirmation and peak
  through the tracker, a confirmation in the same tick as the peak, unconfirmed rows, size-jump / stale / large-volume
  flags and their thresholds, capture switched off, Kalshi instrument ids on the recorded books, the scanner writing
  the data and surviving a capture failure, the migration of a first-version table, the migration of a copy of
  `arb_copy.db` (skipped when the file is absent), `GET /api/history/{id}`). Two of my own test expectations were
  wrong and fixed in the tests (the 250 $ stake fitted into the book of the scenario; the re-appearance after the
  failure needed the book to come back). The stale-data threshold default went from 5 to 7 s: with a healthy link a
  Polymarket book is refreshed by the PONG every 5 s and Stake is polled every 5 s, so 5 s would flag normal data.
  README section «Данные для честной статистики», `CLAUDE.md` gets the expected test counts (the line was removed by
  the user's rewrite in `298915d`).
- 20:08 — PR 1 opened: https://github.com/lndrosa/arbitrage/pull/6 (`vflux pr create` failed twice with "Comment
  media preparation failed"; created with `gh pr create`). Message to the user with the `report.py` output.
- 20:09 — PR 2 branch `vorflux/paper-checks` from PR 1 (`4de2bb1`).
- 20:09–20:21 — PR 2: `paper:` config (`delays_sec` 5/15/60, `max_concurrency` 4, `max_pending` 600);
  `MarketAdapter.fetch_book` (a copy of the market with books from a new REST request, no retries, the adapter's
  cache and the scanner's market untouched) for Polymarket (`POST /books`, with the exchange timestamps), Kalshi
  (`/markets/orderbooks`), Stake (`/fixtures/<slug>`) and the mock; `HttpClient.post_json(retries=…)`;
  `engine/paper.py` (`PaperChecker`: a time-ordered queue, checks with the engine's rules on the REST books and on
  the scanner's books, `books_match`, stake table and optimal size, statuses ok / error / unsupported); table
  `paper_checks` (CREATE TABLE IF NOT EXISTS, index on arb_id + first_seen); the scanner schedules the checks on
  confirmation; `GET /api/history/{id}` lists the checks of that appearance; one summary line in the report.
  `tests/test_paper.py` (12). One of my test expectations was wrong (one observation is below
  `history_min_lifetime_sec`, so it was not stored) and was fixed in the test.
- 20:23 — PR 2 opened: https://github.com/lndrosa/arbitrage/pull/7 (`vflux pr create` worked this time). Message to
  the user with the `report.py` output. PR 3 branch `vorflux/honest-stats` from PR 2 (`e870b0d`).
- 20:24–20:40 — PR 3 backend WIP: `stats:` settings (`exclude_top_n` 10, `bankroll_usd` 1000,
  `max_stake_per_arb_usd` 100, `settle_hours` 3); `backend/honest_stats.py` (records with the phase derived from the
  stored start time for old rows, percentiles, the profit curve from the stake table, profit at a stake — exact or the
  user's estimate min(profit, stake × pct / 100) for rows without data, capped profit, the bankroll simulation with
  locked money, outliers, paper aggregation, flags); `build_report` rebuilt on these records (phases, outliers,
  tournaments, flags in the top matches, distinct per 24 h, `profit_trimmed_usd` / `confirm_profit_usd` /
  `median_profit_usd` in every group); new text report; `report.py --bankroll / --max-stake / --exclude-top`. The
  summary query of PR 2 (`query_paper_summary`) is replaced by `query_stats_paper`. Changed test expectations (the
  text no longer headlines the sum of maxima; per 24 h shows distinct arbs instead of profit; the PR 2 tests read
  the paper block of the new report). 241 pytest pass; frontend and new tests not done yet.
- 20:40 — WIP commit `2bbd3c0` pushed earlier (backend of PR 3, 241 pytest). Then: frontend of the «Статистика»
  tab — new headline tiles (values at confirmation, without top-N, profit per arb, bankroll, left at +5 s, lifetime,
  per 24 h with distinct arbs; the run time moved to the line above), tables by phase, the largest arbs, by
  tournament, paper checks (all and by phase), flags in the top matches, «данных нет» and «(K из N)» for partly known
  values at confirmation; `tests/test_honest_stats.py` (9, incl. the user's checked numbers on a copy of
  `arb_copy.db`), 2 more Node tests; README (the report table and its parameters).
- 20:36–20:40 — Browser check of the tab: `run.py --mock` on a copy of `arb_copy.db` (`/tmp/arbdb/ui.db`, port 8061,
  `ARB_ALLOWED_HOSTS='*'` in the shell only), preview `https://xnrp4bippyea.preview.us1.vorflux.com/`; screenshots at
  1440 and 1280 px (old rows «данных нет» / «нет снимков», mock rows with data and paper checks).
- 20:44–21:04 — Quality pass of the stack: simplify (all three PRs) and three reviews (one per PR) with risk
  assessments. PR 2 review: risk 4/10, "ship with mitigations". Must-fix reproduced by the reviewer: a check priced
  the scanner's current markets with the pair's `swapped` flag from the moment of confirmation, so a Stake team
  reorder within 60 s gave a fake surviving arb (46.95 % against a real 4.1 %). Fixed in PR 2 (`vorflux/paper-checks`):
  each leg buys the team by its name from the moment of confirmation (`outcome_of`, `priced_pair`); a changed team is
  `error` "teams changed" (Stake `fetch_book` also raises on another opponent); checks that start more than
  `paper.max_late_sec` (5 s) late are `late` without a request; `actual_delay_sec` is stored; an answer older than
  `engine.stale_seconds` is `error` "slow answer", not "arb gone"; every check is limited by `paper.check_timeout_sec`
  (30 s); venue failures and DB write failures are logged once per streak; an appearance is scheduled once (a
  re-confirmation after a runtime threshold change adds nothing); the stake table only for an arb that is left; the
  queue loop survives an unexpected error; the reason text does not repeat the venue. 6 new tests.
- 20:44–21:10 — Quality pass (simplify + one review per PR, with risk assessments). PR 1 review: risk 3/10, "ship
  with mitigations"; `execute_budget` checked by the reviewer against a brute force on 300 random books (never worse
  than 1 cent), migration safe, arb search unchanged. Must-fix reproduced: `size_jump` compared sizes at different
  prices (a bought-out best level `0.50×10 → 0.51×3000` was flagged ×300). Fixed in PR 1 (`vorflux/stats-capture`):
  a jump counts only at the same or a better price and without a data gap longer than `engine.stale_seconds`; an
  appearance keeps its jumps (up to 20) and the flag uses only jumps up to its confirmation or peak (with `count`);
  each arb is observed in its own guarded step (one failing arb no longer stops capture for the others, one log line
  per arb); the budget bisection stops at 0.001 % (about 30 steps instead of 50) and reuses the full walk for all
  stakes (stake table + optimal size 3.8 → 2.0 ms per moment); `filled` = the whole profitable volume is below the
  stake; new column `peak_profit_usd` (18 columns now); `capture_version` documented (1 = written by this version,
  data at confirmation only for confirmed arbs with capture on); the report line names all reasons for missing data;
  `best_level` of capture renamed `top_of_book` (it was easy to confuse with the engine's `_best_level`). 6 new
  tests (bought-out level / data gap / late jump, brute force on split Kalshi legs, one failing arb, reappearance,
  capture on = capture off for the arbs found, data written on `scanner.stop()`).
- 21:12–21:19 — PR 3 review: risk 4/10, "ship with mitigations"; the user's numbers come out of the report exactly.
  Must-fix: (1) the «Банкролл» column per phase ran a separate full bankroll per phase (59.76 $ + 90.82 $ against a
  total of 74.43 $) → one shared simulation, phases show their share (`simulate_bankroll(..., group_of=phase)`,
  column «Банкролл (доля)»; real data: 51.83 $ + 22.60 $ = 74.43 $); (2) the console by-day / game / venue /
  tournament tables printed partly known values at confirmation without «(у K из N)» and «—» instead of «данных
  нет» → one `_confirm_text` for all. Should-fix done: timestamps without a time zone are UTC (one such row crashed
  the report); a captured row without a profitable stake gives 0, not the estimate by the maxima; paper delays = the
  configured ones plus those found in the history; the bankroll line counts the "no profitable volume" skips and
  states max(start, confirmation) + settle hours; `derived_phase_arbs` only for rows written before this version;
  paper stake curves parsed once at join time; `by_tournament` capped at 50 in JSON with `tournaments_total`;
  `--bankroll nan` rejected. Nits: labels use the number of arbs actually excluded («Сумма макс. $» when none),
  «без данных у N» instead of «ошибки у N», paper disabled is said so, the confirm and paper tiles are grey when
  there is no data, «Прибыль на вилку, медиана» (max over life), games and venues full width (the venue table no
  longer scrolls), dead code removed (`ArbRecord.label`, the uptime hint, `_Group.profits`, duplicate CSS rules),
  unknown flag keys dropped in the console like in the tab. 5 new Python tests, Node tests extended.
- 21:25 — Simplify patch for PR 1 applied (no behaviour change, checked by the simplify agent with byte-identical
  outputs on a copy of `arb_copy.db`): `dataclasses.replace` for the same-moment confirm snapshot, one-caller helper
  `_r` removed, `migrate` returns nothing, one `table_columns` (ordered) instead of two PRAGMA helpers, the insert
  reads every capture column by name. 235 pytest + 18 Node pass.
- 21:26 — Simplified PR 1 merged into PR 2 (conflicts only in the handoff logs; entry times corrected to the commit
  times) and the simplify patch for PR 2 applied (no behaviour change): `capture.to_json` / `capture.book_levels`
  shared by snapshots and paper checks, the Polymarket copy reads the exchange time from its book, one JSON-column
  parser for history rows and paper checks. 253 pytest + 18 Node pass.
- 21:28 — Simplified PR 2 merged into PR 3 (conflicts only in the handoff logs; times corrected to the commit times)
  and the simplify patch for PR 3 applied (no behaviour change): `share_at_least`, `_Group` without the duplicate
  lifetimes array, `settings` from `asdict`, one phase label table, simpler console helpers, one `flagsCell` in the
  tab. `report.py` on a fresh copy of `arb_copy.db`: identical output before and after. 267 pytest + 20 Node pass.
  STATUS and NEXT_STEPS: final state of session 6.

## 2026-10-19 — session 7 (BC.Game)

- 11:50–12:06 UTC — Read the repository instructions, handoff, adapter interfaces, Stake example, network helper,
  mock adapter, matching rules and platform configuration on current `main` `f97523b`. Created branch
  `vorflux/add-bcgame-adapter`.
- Public research found no documented BC.Game sportsbook API. Odds-API.io publicly lists BC.Game, but needs a paid key
  for events and odds. The user then authorized REA-based browser observation.
- Installed REA 6.7.0 under `/home/ubuntu/.local` because the system npm prefix is not writable. A standard Chrome page
  opened `https://bc.game/sports` without login, header changes or a Cloudflare bypass. REA passively observed the page
  and retained its public scripts.
- REA confirmed that BC.Game embeds BETBY: the page loads
  `https://bcgame.sptsportscdn.com/bt-renderer.min.js`, uses a configured `betby_brand_id`, and initializes
  `BTRenderer`. The public renderer returned only `Access is forbidden from your location` for the sandbox IP.
- Stopped the reverse-engineering work at that point. The task forbids bypassing country or IP blocks. No adapter,
  configuration, rules or tests were added; direct BC.Game data shapes and settlement rules remain unknown.
- Documentation checkpoint: 267 Python tests and 20 Node tests pass. The first Python command failed because the host
  had neither pytest nor `python3-venv`; an isolated dependency directory under `/tmp` was used for the successful run.
- 12:58–13:04 UTC — Пользователь повторно разрешил проверить четыре SOCKS5-прокси. Учётные данные оставлены только
  во временном каталоге с правами 0700; значения не включены в репозиторий и вывод проверок.
  Через прокси 1, 2 и 4 публичный renderer BETBY вернул JavaScript (51 479 байт), а прямой запрос и прокси 3 —
  `Access is forbidden from your location` (3 678 байт). Разрешены только обычные публичные запросы; заголовки не подменены.
- REA 6.7.0 статически разобрал доступный renderer. Публичные scripts содержат адрес API, но brand ID получается
  из отдельной конфигурации BC.Game. Запрос этой конфигурации и запросы правил через прокси 1 вернули Cloudflare 403.
  Challenge не решён и не обойдён; доступ к JavaScript пока не подтверждает доступ к коэффициентам.
- Контрольная точка перед браузерной проверкой: Python — 267 passed (16.27 с, одно предупреждение), Node — 20 passed.
  Изменены только четыре файла handoff; учётных данных и посторонних файлов в diff нет.
- 13:13 UTC — Обычный Chrome через прокси 1 получил страницу BC.Game и ответ гостевой конфигурации с HTTP 200.
  Вход, подмена заголовков и решение challenge не использованы. Brand ID `2103509236163162112` взят из поля
  `sportProviders[].betByBrand.brandFlag`, а не из перебора. Нативный SOCKS5 в Chrome сначала дал
  `ERR_SOCKS_CONNECTION_FAILED`; локальный туннель на loopback добавил SOCKS5-аутентификацию без изменения HTTP.
- Публичные GET к BETBY: настройки бренда, 2 117 описаний рынков, 230 описаний статусов и индекс pre-match фида
  вернули HTTP 200 без ключа. Части snapshot имеют короткий срок жизни и сжатие gzip; полная проверка ещё идёт.
  Повторные тесты перед контрольной точкой: 267 Python passed (16.20 с, одно предупреждение), 20 Node passed.
- 13:14–13:29 UTC — Получен согласованный snapshot из шести gzip-частей: 2 098 событий всех видов спорта,
  49 esports матчей с рынком 186 (Winner, исходы 4/5). Записана сокращённая fixture семи игр без cookies и секретов.
  Реализован WIP `BcGameAdapter`: snapshot/delta, два исхода, исключение BO2/1x2/live по умолчанию, один ask-уровень,
  нулевая комиссия, REST-лимиты, тайм-ауты, backoff, Retry-After и остановка после 401/403.
- Добавлены выключенная конфигурация BC.Game, SOCKS-зависимость и пустой пример переменной прокси. В mock добавлены
  BC.Game, все шесть пар четырёх площадок, API/report/frontend тесты; поиск и математика не изменены.
  Правила расчёта пока оставлены неизвестными. Специализированные тесты протокола ещё не готовы.
- 13:29 UTC — Живая проверка нового адаптера: 14 рынков в окне 72 часа (CS2 10, Dota 2 2, MLBB 2), повторное чтение
  фида и независимое REST-чтение книги прошли. Возраст источника после полного цикла достиг около 18 секунд;
  непрерывная свежесть ещё не доказана. Контрольные тесты: 284 Python passed (16.98 с), 27 Node passed.
- 13:33–13:38 UTC — Непрерывный запуск адаптера с подпиской и `set_paired` дал пять обновлений одного матча:
  возраст источника 7,595 / 5,222 / 8,088 / 6,799 / 4,872 с. Предыдущие 18 с относились к отдельному скрипту без
  фонового опроса во время независимого REST-чтения. Котировки не освежаются по времени получения старого ответа.
- Добавлены 46 тестов протокола и безопасности. Первый запуск: 39 passed, 2 failed — NaN/Infinity проходили через
  общий helper Stake. BC.Game теперь проверяет конечность коэффициента и размера; Stake не изменён, находка
  опубликована как Pending вне текущего объёма. Итог: 330 Python passed (18.18 с, одно предупреждение), 27 Node passed.
- README и API_NOTES описывают гостевой протокол, запуск, допущения лимита ставки, неизвестные правила и ограничения
  живой проверки. REA не добавлен как зависимость сканера. Сопоставление с тремя живыми площадками ещё идёт.
- 13:41 UTC — Пользователь выбрал Fix для находки Stake NaN/Infinity. Исправление теперь входит в текущую задачу:
  общий `odds_level` отклоняет нечисловые/бесконечные коэффициенты, лимиты и переполнение размера. Добавлены 10
  тестов Stake; отдельная проверка BC.Game удалена как дублирующая. Формулы движка и корректных ставок не меняются.
- Контрольная точка после запрошенного исправления Stake: 340 Python passed (18.25 с, одно предупреждение),
  27 Node passed. CLI больше не перечисляет только две площадки; сведения о доступных площадках остаются в конфигурации.
- 13:46–14:05 UTC — PR-черновик https://github.com/lndrosa/arbitrage/pull/9 создан. Первая попытка создания не прошла
  из-за сбоя подготовки media; повтор с компактным Markdown прошёл. Начата проверка качества.
  Simplify предложил убрать два лишних deepcopy и вернуть прежние проверки форматирования в отдельный тест; применено.
- Первый review дал Block, 5/10: старые пары переживали изменение формата/старта, а ожидающий токен запрос обходил
  новую блокировку 403/429. Пять регрессий сначала упали, затем прошли после исправления. При изменении метаданных
  книга блокируется до rematch с актуальными данными; paper-чтение также отклоняет несовместимую книгу.
- Живое сопоставление 13:38:37–13:39:02 UTC: BC.Game 14 рынков; авто-пары с PM 13, Kalshi 12, Stake 12; ошибок нет.
  Проверка двух MLBB review-пар доказала ONIC Philippines = ONIC PH: одинаковые TNC Pro Team и время старта.
  Добавлен только game-scoped алиас; CS2 и ONIC Indonesia не объединяются.
- Публичный mock preview: https://ot1tcsweh0w8.preview.us1.vorflux.com, четыре зелёных индикатора, синтетическая
  Stake ↔ BC.Game вилка и обе ссылки видны в браузере. Первая запись отклонена: ожидалась неверная подпись статистики.
- Контрольная точка исправлений review: 347 Python passed (18.34 с, одно предупреждение), 27 Node passed.
  Поиск, математика и схема БД не изменены; секреты и посторонние файлы проверены перед публикацией.
- 14:09 UTC — Финальный живой сбор после алиаса: BC.Game 13 (CS2 8, Dota 2 3, MLBB 2), авто PM 13 / Kalshi 12 /
  Stake 11, одна review-пара Kalshi со сдвигом 170 мин. Два CS2 матча начались; Dota 2 Team Liquid — 1win вошёл
  в окно 72 ч. Возраст трёх callbacks 11,986 / 13,246 / 12,943 с; порог движка 10 с не менялся и исключает эти книги.
- Браузер успешно прошёл фильтр CS2 и поиск Natus, проверил обе ссылки и таблицу статистики всех шести пар.
  Console пустой. Снимки прочитаны; все данные preview синтетические. Успешная запись слишком короткая (0,6 с)
  для чтения, поэтому не выдаётся как пользовательская демонстрация; вместо неё сохранены читаемые снимки.
- 14:11–14:13 UTC — Повторный review подтвердил два исходных исправления, риск 5 → 4, но нашёл paper-гонку:
  discovery мог изменить входной market во время REST-ожидания. Два новых теста сначала упали; независимая копия
  входа до первого await устранила гонку метаданных и ориентации. Полный прогон: 349 Python passed (18.52 с),
  27 Node passed. Итоговая точечная проверка исправления ещё нужна.
- Повтор перед публикацией, включая отказ `evaluate_pair` на старом источнике: 349 Python passed (18.74 с,
  одно предупреждение), 27 Node passed. Контрольная точка paper-исправления готова к публикации.
- 14:24 UTC — Итоговая точечная проверка закрыла paper-гонку и все предыдущие must-fix. Риск 4 → 3/10,
  Low, Ship with mitigations: оставить BC.Game выключенным и не ослаблять порог свежести.
  Ранее полная проверка дала 5/10; снижение объясняется исправлением трёх воспроизведённых дефектов.
- Полный diff проверен на все предоставленные proxy credentials/адреса; совпадений нет. Временные input, настройки
  браузера и HAR удалены (всего пять файлов), собственные туннель и
  исследовательский Chrome остановлены. Mock preview сохранён на отдельной временной БД.
- Финальная контрольная точка 14:27 UTC: 349 Python passed (18.36 с, одно предупреждение), 27 Node passed.
  Исходные три must-fix закрыты; никаких новых production-изменений после проверенного paper-fix нет.
- Проверка GitHub исправила прежнее предположение о черновике: PR фактически `OPEN`, `isDraft: false`, auto-merge отсутствует.
  Ранее агент опирался на запрошенный `--draft`, а не на проверенное состояние. Draft/ready и merge агент не менял.
- Platform `pr edit` вернул ошибку datasource-доступа. GitHub CLI заменил только точный авторский блок; внешние секции
  и состояние PR сохранены. Оценка review 3/10 включена в описание. Platform `pr report-risk` вернул `not_tracked`,
  поэтому сохранение оценки в платформенном индексе не подтверждено; инфраструктурные ошибки зарегистрированы.

- Последняя контрольная точка 2026-10-19 14:35 UTC: 349 passed, 1 warning in 18.57s; Node 27 pass. Исправлен только handoff статуса PR; код не менялся.

## 2026-10-19 — сессия 8: свежесть BC.Game

- 2026-10-19 15:13 UTC — Пользователь запросил измерение всего пути данных, минимальный доказанный fix и длительный shadow-тест.
  Рабочая ветка и PR 9 сохранены. Main повторно проверен: `f97523b`; defaults, stale и математика не изменены.
- Статическое исследование: глобальный timestamp канала переносится на неизменившиеся рынки. В записанных
  исходах нет индивидуального времени; `generated` нельзя объявлять временем изменения каждого коэффициента.
  Правильность финального response cursor подтверждена публичным клиентом и offline replay.
- Изолированный временный наблюдатель сначала не стартовал из-за неподключённой собственной БД. Подключение исправлено.
  Повтор 18 с: 1 snapshot, 4 delta, 10 непустых рынков, 210 engine-проверок, 0 HTTP-ошибок.
  Это smoke, не достаточное доказательство причины или живой готовности.

- 2026-10-19 15:54 UTC — База 300,325 с завершена: 76 HTTP, 2 snapshot, 61 delta, 10 рынков, 5 580 непустых проверок.
  Медиана HTTP 4,245 с; min(source generated, request send) искусственно добавлял 3,931448 с в медиане.
  В 10 наблюдаемых рынках не было изменений цен, но 620 раз продвинулись общие отметки.
- Реализованы per-outcome clocks с source generated, без query-time clamp; unchanged/snapshot/reconnect не омолаживают цену.
  Добавлены 36 регрессий и диагностический инструмент с 32 собственными офлайн-тестами. Полный прогон 417/27 зелёный.
- Точный replay 76 ответов/5 580 проверок: 93,011% прежней apparent freshness → 0% честной source-evidence freshness.
  Исправление не выдаётся как увеличение реальной свежести. Кандидатный live smoke 60 с: 1 050 samples, 0% свежих,
  один закрытый/переоткрытый HTTP-клиент и одно подтверждённое восстановление состояния.
- Предыдущая проверка credentials ошибочно запустила Python без project PYTHONPATH и не импортировала dotenv.
  Она перезапущена сразу после публикации; совпадений credentials в commit нет. Последующие команды используют set -e.
- Первый post-fix live 15:57:01–16:10:24 UTC остановлен по review, 803,249 с; validation false, outcome interrupted.
  Контролируемый сбой в нём ещё не произошёл. В качестве завершённого длительного теста эта попытка не используется.
- Review выявил лазейки удаления/паузы и разные источники BO. Добавлены watermark недоступности, полный manifest boundary
  вместо min старых частей и единый effective BO; дополнительно закрыты third/1x2 и metadata-only изменения игры.
  Старый опубликованный 91e1137 на новых lifecycle-тестах дал 14 failed / 2 passed; исправления проходят эти 16 случаев.
- После уточнения разновозрастных частей core-проверка закрыла оставшиеся P1; риск 5 → 3/10, но не live-готовность.
  Наблюдатель также исправил desc:null projection, fault attribution и границы установки книги. Следующий запуск — 30 минут.

- Контрольная точка 2026-10-19 16:49 UTC: Python 468 passed, 1 warning in 21.53 s; Node 27 pass. Core review 3/10 и measurement review 2/10 закрыли известные must-fix. Новый полный 30-минутный прогон ещё не завершён.

- 2026-10-19 17:41 UTC — Финальный прогон 6a99003 завершён: 16:50:10.929–17:20:10.906 UTC, 1800,034 с, 1 snapshot/361 delta,
  15 нормализованных рынков, 28 изменений k в 4 рынках. 45 705 checks, из них 45 312 непустых.
  Fresh/stale/unknown: 0,689% / 93,598% / 5,714%; age median/p95/max 750,998 / 1683,281 / 1801,058 с.
- Controlled close 17:00:10.872, reopen 17:00:25.898, state recovered 17:00:35.497 UTC. Две инъецированные ошибки,
  native HTTP ошибок 0. Из 15 наблюдавшихся ID исчезли 3; raw invalid reuse 0, active unchanged-contract clock advances 0.
- Корреляция первого source origin выявила дополнительное защитное ожидание rematch 35,385 с после переноса старта.
  Это не скрыто как микросекундный последний setter. Сам guard сохранён; будущая архитектурная работа вынесена в NEXT_STEPS.
- После live: 468 Python passed, одно предупреждение Starlette, 21.41 s; Node 27 pass; compileall 0.
  Конечный operational verdict NOT READY: исправление кода не создаёт отсутствующих source-доказательств актуальности.
- Полный task diff и два итоговых артефакта проверены на предоставленные credentials и proxy address; совпадений нет.
  Временная .env удалена после завершения всех реальных запросов. Production engine/scanner/matching/config и прежние адаптеры
  в этой итерации не изменены; bcgame.enabled=false, stale=10 подтверждены загрузкой YAML.

## 2026-10-20 — freshness telemetry implementation

- Malformed и truncated discovery Polymarket/Kalshi/Stake теперь завершаются ошибкой без удаления last-good markets.
- Polymarket и Kalshi валидируют полный book batch и публикуют его атомарно. Partial HTTP 200 не меняет кэш.
- Kalshi сохраняет last-good series metadata; Stake отклоняет fixture без `groups` list.
- Market API получил диагностические `timestamp_kind`, `source_book_timestamp`, `actual_price_change_at`.
- `updated_at` и `stale_seconds` не изменены; новые поля не участвуют в arb calculation.
- Добавлен `docs/FRESHNESS_TELEMETRY_AUDIT.md` и 21 regression case.
- Focused suite: 109 passed. Full: 502 Python passed; 27 Node pass; compileall и diff check успешны.
- Review нашёл две multi-batch гонки: откат Polymarket PONG confirmation и overwrite Kalshi WS state.
- Исправления сохраняют более новый WS state независимо от текущего ownership; добавлены две regression tests.
- Simplify убрал повторный parse Polymarket books. После исправлений: 109 focused, 502 Python, 27 Node.
- Follow-up review: risk снижен с 5/10 до 3/10; verdict изменён с Block на Safe to ship.
- CI implementation/review-fix commit `7f0e543` прошёл. PR: https://github.com/lndrosa/arbitrage/pull/14.
- Финальный report state `9d546d3` прошёл GitHub CI: test pass за 56 s; Macroscope skipped.
