# VERIFICATION

## 2026-10-20 — freshness telemetry baseline

- `origin/main` и локальная база: `0a98a220769f72736d98ec16aac5318682774d2a`; дерево было чистым.
- `python -m pytest --collect-only -q` → 479 tests collected.
- `PYTHONPATH=/tmp/arbitrage-test-deps python -m pytest -q` → 479 passed, 1 warning in 24,09 s.
- `node --test tests/js/*.test.mjs` → 27 pass, 0 fail in 94,43 ms.
- `python -m compileall -q backend tests` → success.
- `.github/workflows/ci.yml` запускает эти же Python- и Node-команды на Python 3.12 и Node 20.
- Не вошедшая в main ветка `origin/vorflux/fix-bcgame-status-metrics` изменяет ожидаемый count на 481/30;
  она не является текущим baseline и не включена в эту ветку.

Exact results of checks. Newest at the bottom.

## 2026-10-20 — аудит UI-метрик BC.Game

- Tree рабочей ветки до изменений совпадал с `origin/main 0a98a22`, merge commit PR #9.
- Кодовый путь latency: `backend/adapters/bcgame.py` `_get()` → `PlatformStatus.latency_ms` →
  `Scanner._platform_view()` → `/api/state` → `frontend/js/views/header.js` и `settings.js`.
- Кодовый путь sync time: `FeedState.confirmed_at` → `_sync().status.last_update` → тот же API/UI path.
- Регрессия latency: три snapshot HTTP-ответа по 4 157 мс оставляют `status.latency_ms == 4157.0`, а не 12 471 мс.
- Регрессия ошибки: `_failure(ReadTimeout)` очищает latency, сохраняет last successful sync и ставит disconnected/error.
- UI unit: BC.Game использует точные labels и note; Stake сохраняет прежние общие labels.
- Целевые результаты: 2 Python passed, 66 deselected; 9 Node pass.
- Полная регрессия: `.venv/bin/python -m pytest -q` → 481 passed, 1 warning in 23,83 s;
  `node --test tests/js/*.test.mjs` → 29 pass, 0 fail in 78,59 ms.
- `git diff --check` и secret/foreign-file scan → успешно.
- Review: 2/10 Low, Safe to ship, существенных findings нет. Неблокирующее замечание к test semantics исправлено.
- Усиленная latency regression: snapshot responses 1 111 / 2 222 / 4 157 мс → status latency 4 157 мс.
- Финальная регрессия: `.venv/bin/python -m pytest -q` → 481 passed, 1 warning in 24,03 s;
  `node --test tests/js/*.test.mjs` → 30 pass, 0 fail in 80,68 ms.
- agent-browser 0.37.1: header popup содержит точные labels/note; Settings показывает `HTTP-ответ` и
  `синхронизировано`; BC.Game pair tooltip сообщает неизвестное время изменения коэффициента.

## 2026-10-20 — proxy BC.Game

- Код: `os.getenv("ARB_BCGAME_PROXY_URL", "").strip() or None` передаётся как `proxy` в
  `httpx.AsyncClient`; `trust_env=False` исключает неявные системные proxy.
- `_snapshot()` и `_read()` запрашивают index, manifest parts, delta и reset через `_get()`, который использует
  единственный `self.http`. Тест с proxy и без proxy подтвердил пути `0/101/102/501` и повторный `0/101/102` после reset.
- Целевые proxy/timeout/recovery тесты: 8 passed, 58 deselected in 0,27 s.
- Полная регрессия: `.venv/bin/python -m pytest -q` → 479 passed, 1 warning in 24,19 s;
  `node --test tests/js/*.test.mjs` → 27 pass, 0 fail in 93,89 ms.
- `git diff --check` → успешно. Добавленный diff не содержит локальный адрес пользователя, proxy credentials или secret files.
- Git: `.env` не отслеживается и игнорируется; `.env.example` отслеживается как безопасный шаблон.

## 2026-10-20 — BC.Game WIP

- Ветка: `vorflux/add-bcgame-adapter`, `HEAD ac273f5`, синхронизирована с origin перед началом изменений.
- Прямой запрос к BETBY index без прокси:
  `curl --connect-timeout 10 --max-time 25 https://api-k-c7818b61-623.sptpub.com/api/v4/prematch/brand/2103509236163162112/en/0`.
- Результат: HTTP 503; connect 0,017859 с; TLS 0,032645 с; first byte 0,034734 с; total 0,034795 с; 30 байт.
  Ответ дал CloudFront, заголовок `bb-rsn: bc`, тело — JSON object только с ключом `error`.
- Вывод: текущая живая ошибка — отказ CDN по местоположению до snapshot parser. Успешный сбор не подтверждён.
- Базовая регрессия до изменений реализации: `.venv/bin/python -m pytest -q` → 468 passed, 1 warning in 22,61 s;
  `node --test tests/js/*.test.mjs` → 27 pass, 0 fail.
- Проверка добавленного handoff diff на `.env`, ключи, HAR, proxy URL, Authorization и API key → совпадений нет.
- После реализации: `.venv/bin/python -m pytest -q tests/test_bcgame.py tests/test_bcgame_freshness.py
  tests/test_bcgame_availability.py tests/test_bcgame_integration.py tests/test_bcgame_observer.py` → 192 passed in 6,94 s.
- Проверены: реальный записанный BETBY contract, normalization, participant aliases, coherent updates, исчезновение
  и блокировка рынков, `ReadTimeout`, parser error detail, request retries, `Retry-After`, выключенная конфигурация,
  matching всех шести пар четырёх площадок и UI metadata. Полная регрессия ожидается.
- Полная регрессия после реализации: `.venv/bin/python -m pytest -q` → 470 passed, 1 warning in 24,20 s.
- Frontend regression: `node --test tests/js/*.test.mjs` → 27 pass, 0 fail in 72,05 ms.
- Единственное предупреждение Python: upstream `StarletteDeprecationWarning` из `fastapi/testclient.py` про `httpx2`.
- Review follow-up: полный BC.Game-набор после geo-block/skew/diagnostic clock правок → 196 passed in 7,73 s.
- Новые прямые проверки: transient 503 восстановился на третьем запросе; exhausted 503 сохранил предыдущий feed;
  CloudFront `access blocked` выполнил один запрос и установил latch; source clock +3 с принят и ограничен текущим временем.
- Полная регрессия после review: `.venv/bin/python -m pytest -q` → 473 passed, 1 warning in 23,75 s;
  `node --test tests/js/*.test.mjs` → 27 pass, 0 fail in 85,42 ms.
- `git diff --check` и повторная проверка changed files/added lines на секреты → успешно.
- Follow-up review: риск 3/10, `Safe to ship`, блокеров нет.
- После сужения geo latch: `.venv/bin/python -m pytest -q` → 475 passed, 1 warning in 23,87 s;
  `node --test tests/js/*.test.mjs` → 27 pass, 0 fail in 75,38 ms.
- Независимый testing agent на `e7d02c4`: 475 Python passed in 24,23 s; 27 Node pass in 72,45 ms;
  6 целевых retry/geo-block/skew tests passed in 0,25 s.
- Controlled contract harness: snapshot, delta, removal, timeout atomicity, retryable/exhausted 503, malformed JSON
  и incomplete snapshot прошли. Mock API: 16/16/16/17 рынков и 88 пар с BC.Game.
- Browser UI: 1280 и 1100 px без наложений; BC.Game присутствует в котировках и ссылках.
- Live без `HTTP_PROXY`, `HTTPS_PROXY`, `ALL_PROXY`, `ARB_BCGAME_PROXY_URL`: точная ошибка
  `BC.Game: access blocked by CloudFront (bb-rsn: bc)`, unhealthy, 0 рынков, 0 пар, 0 вилок.
- Test Report опубликован со статусом PASSED. Ограничение: успешный live feed из sandbox не подтверждён.

## 2026-10-15

- Live API reachability from the dev sandbox (curl):
  - `GET https://gamma-api.polymarket.com/sports` → 200
  - `GET https://clob.polymarket.com/time` → 200
  - `GET https://api.elections.kalshi.com/trade-api/v2/exchange/status` → 200
  - `GET https://kalshi.com/` → 429 (Cloudflare bot protection; web pages cannot be fetched with curl)
- `GET /markets/orderbooks?tickers=...` (Kalshi, 10 tickers, no auth) → 200 in 45 ms.
- `POST https://clob.polymarket.com/books` (2 tokens) → 200; token books are mirrored (ask A = 1 − bid B).
- No code tests yet.
- 18:41 — `python run.py --mock --no-browser --port 8011` (25 s run):
  - `GET /api/health` → `{"ok":true,"mock_mode":true,...}`
  - `GET /api/state` → counts `markets 32 (16+16), pairs 13, review 2, active_arbs 0`.
  - Matching check: "Spirit Academy vs MOUZ NXT" and "Team Spirit vs MOUZ" were paired correctly (no academy mix-up);
    swapped team order (Kalshi "FaZe Clan / NAVI" vs Polymarket "Natus Vincere / FaZe") detected (`swapped=True`).
  - Review bucket: "ONIC PH" vs "ONIC" (team score 85) and a 270-minute start-time difference.
  - No arbs appeared in 9 s; mock dislocation size raised from 0.045–0.09 to 0.06–0.12 so net-of-fee arbs occur.
- 18:47 — Adapter-only live check (script): Polymarket `fetch_markets` 113 markets in 2.3 s
  (cs2 53, dota2 20, mlbb 15, ow 11, r6 8, lol 3, valorant 3); Kalshi 126 markets in 1.0 s. Matcher: 99 auto pairs,
  2 review pairs (LoL FURIA–MVK and C9–KC: Polymarket and Kalshi start times differ by 300 min).
- 18:48 — `python run.py --no-browser --port 8013 --db /tmp/real_test.db` (real APIs, 30 s): both platforms
  `healthy: true` (Polymarket mode ws, Kalshi mode rest, latency 6 ms), 99/99 pairs fresh on both sides,
  1 confirmed arb: OW "Falcons vs SEIJI ESPORTS" buy SEIJI @0.07 (Polymarket) + YES Falcons @0.92 (Kalshi),
  net +0.136 % on $24.09 after fees. No errors in the log.
- 18:53 — `.venv/bin/python -m pytest -q` → `93 passed, 1 warning in 1.05s`
  (warning: Starlette TestClient deprecation of httpx, harmless).
- 18:56 — `.venv/bin/python -m pytest -q` → `99 passed, 1 warning in 1.06s`.
- 18:55 — Live re-run after the freshness fixes (`--port 8014`, 25 s): 112 + 126 markets, 98 pairs, 98/98 fresh,
  both platforms healthy, the same OW arb confirmed (+0.14 %, $24.09), 2 LoL review pairs. No errors in the log.
- 19:32 — `.venv/bin/python -m pytest -q` → `101 passed, 1 warning in 1.18s`.
- 19:31 — Frontend subagent report: no JS console errors in mock mode; checked 1440 px and 900 px; WS reconnect and
  REST fallback tested by stopping/starting the backend; CSV download tested in the browser.
- 19:29 — `node --check` on all frontend JS files: no syntax errors; all assets served with 200 by FastAPI.
- 19:37 — Public preview `https://lybdrliu9ksq.preview.us1.vorflux.com/` → HTTP 200 (18875 bytes); `/api/health` → 200;
  browser screenshot (real mode): Polymarket WS 92 ms, Kalshi REST 5 ms, 212 markets, 87 pairs, 2 confirmed arbs
  (Dota 2 OG vs Team Synapse +0.64 % on $14.90; OW Falcons vs SEIJI ESPORTS +0.14 % on $24.09), indicator "Live".
  Issue seen: the ⚠ column is partly cut off at 1440 px.
- 19:45 — `.venv/bin/python -m pytest -q` → `104 passed, 1 warning in 1.34s`.
- 20:04 — `.venv/bin/python -m pytest -q` → `114 passed, 1 warning in 1.76s` (after review fixes part 1).
- 20:05 — `.venv/bin/python -m pytest -q` → `117 passed, 1 warning in 1.83s` (after review fixes part 2).

## 2026-10-15 — session 2

- 21:11 — `.venv/bin/python -m pytest -q` on `b1fbf7c` → `117 passed, 1 warning in 2.02s`.
- 21:13 — Real mode (`run.py --host 0.0.0.0 --port 8000`, 20 s after start): `/api/state` counts
  `markets 207 (98 Polymarket + 109 Kalshi), matches 124, pairs 83, review 4, active_arbs 2`; Polymarket ws healthy
  (89 ms), Kalshi rest healthy (4.9 ms); confirmed arbs: OW Falcons vs SEIJI ESPORTS +0.136 %, Dota 2 Xipto Esports vs
  Ivory +0.032 %. No errors in the log.
- 21:14 — Public preview `https://iz082a8cbrgd.preview.us1.vorflux.com/` → `status=200 bytes=18956`; `/api/health` → 200.
- 21:16 — agent-browser 0.37.1, 1440×900, real mode: arbs table `scrollWidth 1412 > clientWidth 1390` (⚠ clipped);
  pairs table clipped at "Действия" (screenshot read back).
- 21:23 — `.venv/bin/python -m pytest -q` → `118 passed, 1 warning in 2.28s`; `node --check` on all frontend JS → OK.
- 21:24 — Real mode, table fit (`scrollWidth/clientWidth` of `.table-wrap`): 1440 px arbs `1390/1390`, pairs
  `1375/1375`; 1366 px arbs `1316/1316`, pairs `1301/1301`; 1280 px arbs `1246/1246`, pairs `1290/1231` + `more-right`;
  900 px arbs `1198/866` + `more-right`, pairs `1290/851` + `more-right`. Header stat `123` (= `counts.matches`).
  No console errors.
- 21:25 — Mock server SIGSTOP at 21:25:45: T+3 s `live:Live`; T+9 s `offline:Нет связи с сервером`, `data-stale`,
  banner "Нет связи с сервером … последнее обновление 9 с назад"; SIGCONT at 21:25:57 → `live:Live` after 1 s.
- 21:26 — Stall server (scanner stops after 30 evaluations): `stalled:Расчёт остановлен|обновлено 21 с назад`, banner
  "Сканер не пересчитывает вилки … последний расчёт был 21 с назад", candidate countdown frozen at "через 3 с".
- 21:27 — `.venv/bin/python -m pytest -q` → `118 passed`; `node --check` on all frontend JS → OK.
- 21:58 — `.venv/bin/python -m pytest -q` → `124 passed, 1 warning in 2.44s` (after backend review fixes).
- 22:01 — `.venv/bin/python -m pytest -q` → `125 passed, 1 warning in 2.50s`; `node --check` on all frontend JS → OK.
- 22:03 — Browser re-check (servers restarted on the new code): table fit unchanged with ⚠ next to "Profit %"
  (1440 px arbs `1390/1390`, pairs `1375/1375`; 1366 px `1316/1316`, `1301/1301`); own mock on :8095 — SIGSTOP:
  `live` until t+0.5 s sample, `offline` at t+6.58 s, never `stalled`; SIGCONT → `live` after 1.5 s; SIGKILL →
  `offline` after 0.5 s; tab title "Нет связи · …"; stall server :8002 → `stalled|stalled|Расчёт остановлен · …`
  (amber banner). 900 px: ⚠ column visible, accent edge on the right. No console errors.
- 22:05 — `node --test tests/js/*.test.mjs` → `tests 9, pass 9, fail 0`. Mock :8001 history: "Показать ещё" 100 → 200 →
  235 of 235, then the button hides; `/api/history` total 235.
- 22:59 — Own mock :8096 frozen 25 s (SIGSTOP) → `offline`; after SIGCONT → `live` after 0.5 s.
- 23:00 — Settings form on :8001, review threshold 90 > auto 85 → banner "Сервер отклонил изменения в поле «Порог ручной
  проверки»: значение не может быть больше, чем «Порог автосопоставления»." + field error; server value unchanged (60).
- 23:01 — `.venv/bin/python -m pytest -q` → `125 passed`; `node --test tests/js/*.test.mjs` → 9 pass.
- 23:15 — Own mock :8097: 4 cycles of 9 s SIGSTOP + SIGCONT → `live` 0.2 s after SIGCONT each time, `stalled` never
  seen (samples every 0.2 s); 40 s freeze → `live` after 0.2 s; stall server :8098 → `stalled` detected. No console
  errors. `node --test tests/js/*.test.mjs` → 10 pass; `pytest -q` → 125 passed.

## 2026-10-16 — session 3

- 00:06 — `git ls-remote origin`: `main` `7a7803f`, `vorflux/esports-arb-scanner` `51202fd`,
  `vorflux/esports-arb-scanner-v2` `3d07067`, `refs/pull/1/head` `51202fd`, `refs/pull/2/head` `3d07067`.
  `GET https://api.github.com/repos/amantairthe/1/pulls/2` → 404, `/pulls/1` → 404, `https://github.com/amantairthe/1/pull/2`
  → 404; `GET https://api.github.com/users/ravistiedemann79` → 404, `/users/rayan23-bot` → 404, `/users/amantairthe` → 200.
- 00:07 — `.venv/bin/python -m pytest -q` on `3d07067` → `125 passed, 1 warning in 2.64s`.
- 00:07 — `node --test tests/js/*.test.mjs` (first run) → 1 failure: `ERR_ASSERTION actual: false expected: true
  operator: '=='` (the only `assert.ok` in the file: `Math.abs(dataNow() - store.lastDataAt) < 50`); 31 later runs →
  `tests 10, pass 10, fail 0`.
- 00:12 — `GET https://api.github.com/repos/amantairthe/1/pulls/3` → `state open, draft false`, head
  `vorflux/esports-arb-scanner-v3`, user `amantairthe`.
- 00:16 — `.venv/bin/python -m pytest -q` → `130 passed, 1 warning in 2.16s` (per-order minimum fix + 5 tests).
- 00:17 — `node --test tests/js/*.test.mjs` × 15 runs → `tests 10, pass 10, fail 0` each time.
- 00:21 — Real mode smoke run (`run.py --no-browser --port 8031 --db /tmp/arb3/real.db`, 45 s): Polymarket 105 markets,
  Kalshi 118; Kalshi `/events` answered HTTP 429 several times per discovery (retried, then OK); 1 confirmed arb
  (OW Falcons vs SEIJI ESPORTS, 5.04 %, $8.68). No errors.
- 00:22 — `.venv/bin/python -m pytest -q` → `135 passed, 1 warning in 2.57s`.
- 00:23 — `file run-windows.bat` → `DOS batch file, ASCII text, with CRLF line terminators`.
- 00:26 — Public preview `https://aq7g72fga4r8.preview.us1.vorflux.com/` → `status=200 bytes=19046`; `/api/health` → 200.
  Browser (agent-browser, 1440×900): Polymarket WS 95 ms, Kalshi REST 6 ms, 130 matches, 93 pairs, 1 arb (OW Falcons vs
  SEIJI ESPORTS: Polymarket SEIJI @0.07 + Kalshi YES «Falcons» @0.87, +5.04 %, 9.12 contracts, $8.68, profit $0.44,
  ⚠ 4 rule differences: cancel / forfeit before start 50/50 vs fair price, postponement 14 d vs 48 h), indicator "Live",
  no console errors.
- 00:42 — New min-order tests fail without the fix (`git stash` of `backend/engine/arb.py` → 2 failed) and pass with it.
- 00:43 — `.venv/bin/python -m pytest -q` → `140 passed, 1 warning in 3.36s`; `node --test tests/js/*.test.mjs` →
  `tests 10, pass 10, fail 0`; `py_compile` of all backend files OK; `file run-windows.bat` → CRLF, ASCII only.
- 01:13 — Testing subagent report (`testing-e2e-s3`, on `48c4ab0`): pytest 140 passed, Node 10/10 (×10 repeats); mock
  UI tabs, filters, sorting, links, ⚠ popover, threshold slider, history paging (100 → 192 of 192), CSV (67 rows = API
  total, BOM), review confirm/block/undo, settings save + Russian validation error; real mode healthy (104–105 + 118
  markets, 92–93 pairs); SIGSTOP 20 s / 15 s → offline after 5.9 s / 6.2 s, never "Расчёт остановлен" (265 samples),
  Live 0.18 s / 0.52 s after SIGCONT; iptables outages: Kalshi 90 s → `ARB ended … | stale data (Kalshi)`, `orderbook
  polling recovered after 18.3 s` (data gap ≈ 91 s); Polymarket 80 s → `stale data (Polymarket)`, `ws 0 error:
  ConnectionClosedError: …`, `ws 0 reconnected after 58.7 s`; SIGINT → `scanner stopped` lines; split-book fixture:
  `YES «Bravo» ×3 + NO «Alpha» ×4` = 7 contracts, 0.5 leftovers skipped; `run-windows.bat` CRLF kept in ZIP and in a
  clone with `autocrlf=true`.
- 01:17 — `.venv/bin/python -m pytest -q` → `143 passed, 1 warning in 4.41s`; `node --test tests/js/*.test.mjs` →
  `tests 11, pass 11, fail 0`; `node --check` on all frontend JS → OK.
- 01:18 — Split fixture :8090, agent-browser 1440×900: 5 confirmed arbs (Charlie/Delta NO «Charlie» 4 contracts,
  Kilo/Lima YES «Lima» 50, Alpha/Bravo `YES «Bravo» ×3 + NO «Alpha» ×4` 7, Echo/Foxtrot YES «Foxtrot» 3, India/Juliett
  NO «India» 10; Golf/Hotel none); `.leg-instr` scrollWidth = clientWidth (141) for all, arbs `.table-wrap` 1390/1390;
  pairs tab best cells: India/Juliett `0,50` + `0,42 [инструмент: NO «India» · в расчёте: 10 контр.]`, Charlie/Delta
  `0,50 [инструмент: NO «Charlie» · в расчёте: 4 контр.]`; no console errors. Screenshots:
  `/code/.generated_artifacts/images/fix_split_arbs.png`, `fix_split_pairs.png` (not committed).
- 01:19 — Preview restarted on `d8942e9`: public URL → 200; Polymarket ws + Kalshi rest healthy; quote keys include
  `left_price`, `right_price`, `left_instrument`, `right_instrument`.
- 01:28 — Testing subagent re-check (`d8942e9`): 5/5 passed (details in HISTORY 01:28). Screenshots
  `/code/.generated_artifacts/images/v3_split_arbs_1440.png`, `v3_split_arbs_1366.png`, `v3_pairs_quotes.png`,
  `v3_review_cards.png` (not committed).
- 01:28 — `.venv/bin/python -m pytest -q` → `144 passed, 1 warning in 4.52s`; `node --test tests/js/*.test.mjs` → 11 pass.
- 01:29 — `git push` → `remote: Your account is suspended` (403); `https://api.github.com/repos/amantairthe/1`,
  `/pulls/3`, `/users/amantairthe` → 404; `vflux repo list-datasources` → no repositories.
- 01:30 — `git bundle verify` → "The bundle records a complete history"; clone of the bundle (branch `-v3`) →
  `pytest -q` 144 passed, `node --test` 11 pass; ZIP → `run-windows.bat: DOS batch file, ASCII text, with CRLF line terminators`.
- 01:31 — Preview on `e0c0d78`: public URL → 200; Polymarket 104 + Kalshi 118 markets healthy, 93 pairs.
- 07:41 — `git ls-remote origin` → `remote: Your account is suspended` (403); `https://api.github.com/users/amantairthe`,
  `/repos/amantairthe/1`, `https://github.com/amantairthe/1/pull/3` → 404; `vflux repo list-datasources` → no repositories.
- 07:42 — Old bundle: `git clone <bundle>` → "warning: remote HEAD refers to nonexistent ref, unable to checkout",
  0 files. Bundle with `HEAD`: plain clone → 11 entries, branch `vorflux/esports-arb-scanner-v3`; `git clone --mirror`
  + `git push --mirror` into an empty bare repository → `main` `7a7803f`, `vorflux/esports-arb-scanner` `51202fd`,
  `-v2` and `-v3` at the head commit.
- 08:24 — `GET https://docs-odds-data.stake.com/dist.yaml/dist.yaml` → 200 (OpenAPI 3.1 "STAKE Sports Data API",
  server `https://odds-data.stake.com`, security `X-API-KEY`). Without a key: `GET /sports` → 200 (47 sports);
  `GET /sport/counter-strike/fixture` → 200 (10 fixtures); `GET /schedule/sport/counter-strike` → 200 (18 dates, 28
  matches); `GET /fixtures/882405-fnatic-heroic` → 200 (91 KB; `winner` group: `Match Winner - Twoway`, Fnatic 2.5,
  Heroic 1.48). `https://stake.com/` and `/_api/graphql` → 403; `https://bc.game/` → 200;
  `https://odds-api.io/sportsbooks` contains `>Stake<` and `>BC.Game<`.
- 08:26 — Preview scanner (:8000): pair fnatic/Heroic — Polymarket 0.34 / 0.67, Kalshi Heroic 0.66 / fnatic 0.35.

## 2026-10-16 — session 4

- 13:04 — `git ls-remote origin` (`https://github.com/lndrosa/arbitrage.git`): `main` `5e55fb3`, `vorflux/esports-arb-scanner`
  `51202fd`, `-v2` and `-v3` `f8db1b6`, `refs/pull/1/head` `f8db1b6`. `gh api repos/lndrosa/arbitrage` → private,
  created `2026-10-16T08:34:28Z`, `delete_branch_on_merge: false`. `gh pr list --state all` → `[]`;
  `gh api repos/lndrosa/arbitrage/pulls/1` → 404.
- 13:06 — On `5e55fb3`: `.venv/bin/python -m pytest -q` → `144 passed, 1 warning in 4.67s`;
  `node --test tests/js/*.test.mjs` → `tests 11, pass 11, fail 0` (Node v24.21.0).
- 13:15–13:17 — First outage run (own real-mode instance on :8041 under user `arbcheck`, outbound traffic cut with
  `iptables -I OUTPUT -m owner --uid-owner arbcheck ! -o lo -j DROP`): only Kalshi went offline. Polymarket kept
  working (`polymarket: 91 markets` at 13:16:04 and 13:17:06, `/api/state` → polymarket healthy) because
  `gamma-api.polymarket.com` resolves to IPv6 (`2606:4700:440d::6812:22cd`) and the sandbox has an IPv6 route; Kalshi
  (`77.114.19.64`) is IPv4 only. Kalshi line: `WARNING backend.engine.scanner: kalshi: discovery failed: kalshi: GET
  /events failed: ConnectTimeout (retry in 2 s)`. Run stopped; the same rule added with `ip6tables` for the next run.
- 13:18–13:27 — End-to-end check of `04cbe85` (`/tmp/arbcheck/run_check.sh`, IPv4 + IPv6 rules):
  - phase 1: start online (13:18:12, Polymarket 91 + Kalshi 98 markets), DROP 13:18:25–13:22:25 (240 s). Discovery
    lines: `WARNING backend.engine.scanner: polymarket: discovery failed: polymarket-gamma: GET /events failed:
    ConnectTimeout (retry in 2 s)` (13:20:26), the same at 13:21:42 (`retry in 3 s`); `kalshi: discovery failed: kalshi:
    GET /events failed: ConnectTimeout (retry in 2 s)` (13:20:45, 13:22:19). `/api/state` at 13:20:25 and 13:22:25: both
    platforms `healthy: false` (`ws: TimeoutError: timed out during opening handshake`, `poll: kalshi: GET
    /markets/orderbooks failed: ConnectTimeout`). After the restore: `orderbook polling recovered, no data for 241.2 s`,
    `polymarket-gamma: GET /events succeeded after 3 retries`, `REST book refresh recovered, no data for 252.7 s`; at
    13:24:25 both healthy (92 + 97 markets).
  - phase 2: start while REJECT is active (13:24:29), traffic back at 13:25:30: 5 lines `… discovery failed: … GET
    /events failed: ConnectError: All connection attempts failed (retry in 1 s / 3 s / 6 s)`; at 13:27:00 both healthy
    (91 + 98 markets).
  - Whole log (`scanner.log` + console of both phases): `Traceback` 0, `ERROR` lines 0, WARNING lines 126.
  - Gap found: after the restore there was no `ws 0 reconnected` line at all. Discovery at 13:22:28 found 92 markets
    instead of 91, so `_ensure_ws` replaced the failing WebSocket loop with a new one, whose first connection logs
    nothing. Fixed in this branch (see HISTORY 13:28).
- 13:26 — Review fixes, without the fixes in the source (`git stash` of `polymarket.py`, `scanner.py`, `common.js`):
  pytest → 3 failed (`test_polymarket_rest_refresh_recovery_line[True-…]`,
  `test_polymarket_ws_data_gap_counts_from_the_last_frame`: `'ws 0 connected after 15.0 s of failed attempts' != '…
  30.0 s …'`, `test_discovery_rejected_request_logs_an_error_without_traceback`), Node → 1 failed (split-order test).
  With the fixes: all pass.
- 13:29 — Handover check: with `handover = {}` in `_ensure_ws`, `test_polymarket_ws_outage_survives_a_new_subscription`
  fails; with the fix it passes.
- 13:30 — `.venv/bin/python -m pytest -q` → `148 passed, 1 warning in 5.56s`; `node --test tests/js/*.test.mjs` →
  `tests 12, pass 12, fail 0`.
- 13:31–13:38 — Re-check on `fce9746` (`/tmp/arbcheck/run_recheck.sh`: phase 1 only, IPv4 + IPv6 DROP 13:31:43–13:35:43,
  240 s): Polymarket 90 → 91 markets after the outage, so the WebSocket was re-subscribed again. Lines after the
  restore: `orderbook polling recovered, no data for 241.2 s` (13:35:43), `REST book refresh recovered, last success
  251.1 s ago` (13:35:44), `ws 0 reconnected, no data for 245.0 s` (13:35:48, right after `polymarket: 91 markets`).
  4 discovery lines, all `WARNING … discovery failed: … ConnectTimeout (retry in N s)`; `Traceback` 0, `ERROR` 0,
  WARNING lines 80. After the run: `iptables -S OUTPUT` and `ip6tables -S OUTPUT` → `-P OUTPUT ACCEPT` only.
- 13:33 — `pytest -q tests/test_stats.py` → 1 failed: `test_totals_groups_and_repeated_appearances`, by_game order
  `[('CS2', 3, 1.0), ('Dota 2', 1, 1.0)]` vs the expected `[('Dota 2', 1, 1.0), ('CS2', 3, 1.0)]`. The sort rule is
  profit, then the number of arbs; the expectation (and the same mistake for top matches) was wrong and was fixed →
  12 passed.
- 13:34 — `pytest -q` → `160 passed, 1 warning in 6.06s`; `node --test` → 12 pass.
- 13:35–13:36 — Mock run (`run.py --mock --port 8051 --db /tmp/stats_demo/mock.db`, 100 s): `/api/stats?days=2` →
  1 arb at 13:35; `report.py --mock --db /tmp/stats_demo/mock.db --days 3` after the run: 3 arbs, 1 candidate,
  profit $40.91, best $24.21 (5.29 %), all tables printed.
- 13:40 — `report.py --db <copy of the live-check DB>` (written by `fce9746`, no `scanner_uptime` table) → exit 0,
  "Работа сканера: нет данных", hours `—`.
- 13:40–13:44 — Real-mode run on this branch (`run.py --port 8052 --db /tmp/stats_demo/real_b.db`, 200 s): Polymarket 92
  + Kalshi 100 markets, no confirmed arb in that time. `report.py --json` while the scanner was running (read-only
  access in parallel) → `run_minutes 4, data_minutes 3` (the first minute is before both platforms were healthy),
  `uptime_since 2026-10-16T13:40:00+00:00`; after the stop: 3 candidates. `Traceback` / `ERROR` in the log: 0.
- 13:47 — Seeded history (`/tmp/stats_demo/seed.py`: 29 rows over 7 days, uptime from the third day) →
  `report.py --db /tmp/stats_demo/seed.db --days 7`: 24 arbs (13 distinct, 7 matches), 5 candidates, profit $24.11,
  without repeats $23.81, run 95 h 51 min / fresh data 93 h 02 min, per 24 h 3.9 arbs; days 10.10 and 11.10 `—`
  (before the first uptime row), 12.10 20.0 h (tracking from 03:00 Moscow time).
- 13:48 — Preview: mock server `run.py --mock --host 0.0.0.0 --port 8000 --db /tmp/stats_demo/seed.db`
  (`ARB_ALLOWED_HOSTS='*.vorflux.com'`), preview URL `localhost:8000`, public `https://kicp6bwohjg9.preview.us1.vorflux.com`
  → `status=200 bytes=20436`; `/api/stats?days=7` over the public host → 200.
- 13:49–13:55 — agent-browser 0.37.1 (installed: the machine had 0.21.2), public URL `#stats`:
  - 1440×900: tab selected, summary "7 дней: 10.10 – 16.10 · дни по часовому поясу Europe/Moscow · порог
    подтверждения 5 с", 6 KPI cards, uptime note "Время работы записывается с 12.10.2026 03:00 …"; table wraps
    1375/1375, 756/756, 605/605, 1375/1375 (nothing cut off). Screenshots read back.
  - First run: game badges `cs2`, `valorant`, … (report before META) and bars under the numbers → fixed; re-check:
    badges `Dota 2`, `CS2`, `Valorant`, `OW`, `LoL`.
  - "?" on «Прибыль» → popover with the explanation; «Сегодня» → 1 day row, JSON link `/api/stats?days=1`, saved
    `{"days": 1}`; «30 дней» → "30 дней: 17.09 – 16.10", 30 rows.
  - 1366: wraps 1301/1301, 715/715, 572/572, 1301/1301; 1280: 1231/1231, 676/676, 541/541, 1231/1231; 900: KPI grid 3
    columns, top-matches table 964/851 with the scroll-edge class `more-right` (after the fix).
  - Tab bar: 900 px `925/853` with six tabs → fixed (`853/853`, pairs tab «Пары 13»); 1101 px `1054/1054` with the long
    label; 1440 px `1377/1377`. Pairs table 1375/1375 and arbs table 1390/1390 at 1440 px unchanged. ArrowRight from
    «История» → «Статистика» (`#stats`).
  - Empty history (fresh mock DB on :8053, opened at once): "Подтверждённых вилок за этот период нет", KPIs `0`,
    `0,00 $`, `—`, «Работа сканера 1 мин, со свежими данными 0 мин», only the day table below.
  - No JavaScript errors (`agent-browser errors` empty in every run).
- 13:55 — `pytest -q` → 160 passed; `node --test tests/js/*.test.mjs` → `tests 17, pass 17, fail 0`; `node --check`
  on all frontend JS → OK.
- 14:15 — PR #2 fixes (`/tmp/wt-a`): `pytest -q` → `151 passed, 1 warning in 8.17s`; `node --test` → 12 pass. With the
  previous `polymarket.py` (`e624c93`) the new REST case `[True-False-…first success 105.0 s after start]` fails; with
  `link.connected, link.failed_since = True, None` replaced by `link.failed_since = None` the real-loop test fails
  (`assert adapter._ws_links[0].connected is True`); with the fix all 30 tests of the file pass.
- 14:15 — CI of the three PRs (`gh pr checks`): job `test` passed on #2, #3 and #4; "Macroscope - Correctness Check"
  passed on #2. Macroscope comment on #3 (also on #4): `per_24h` counts arbs from all minutes but divides by the minutes
  with fresh data only (fixed in PR #3, see HISTORY).
- 14:21 — `/tmp/wt-b` after merging `vorflux/session4-checks`: `pytest -q` → `163 passed`; simplify patch
  (`/tmp/simplify/pr3.patch`) applied → `163 passed`.
- 14:24 — SQLite check: `strftime('%s', '2026-10-16T13:40:59.999999+00:00')` → `1792158060` (rounds into the next
  minute), so the join uses `substr(first_seen, 1, 19)` (UTC time without the fraction).
- 14:25 — Python sqlite3 (3.12.3, SQLite 3.45.1): a failed `INSERT` on a `mode=ro` connection leaves
  `in_transaction == True`, and later `SELECT`s see the old snapshot until `rollback()`; a cursor that is not read to the
  end also pins the snapshot.
- 14:26 — Mutation checks: without the snapshot handling in `read()` (`stats_arbs` via `_run`) the read-only test
  fails (`assert 1 == 2`); with it, it passes.
- 14:27–14:29 — Benchmark (`/tmp/stats_demo/bench.py`, 240k confirmed rows over 30 days + 43,200 uptime minutes,
  `collect()` through a read-only connection, a 10 ms ticker on the event loop): 500 pairs, 366 days → 2.74 s, max
  event-loop lag 46 ms, peak RSS 69 MB; 7 days (53,921 rows) → 0.54 s, lag 8 ms, 46 MB. Worst case with ~240k distinct
  pairs → 4.93 s, lag 233 ms, 593 MB (memory goes into per-pair groups). Before the one-pass rewrite (240k distinct
  pairs): 5.47 s, 641 MB; the query alone: 0.74 s.
- 14:29 — `pytest -q` (after clearing a stale `__pycache__`, see HISTORY) → `168 passed, 1 warning in 8.47s`.
- 14:30 — Mock server on this branch (:8062, copy of the seeded 7-day DB): `/api/stats?days=1|7|90` → 200 in 3–4 ms;
  7 days: 24 arbs, run 5752 min, fresh data 5582 min, per 24 h 3.35 arbs / $3.65 (before: 3.9, which counted arbs from
  minutes without fresh data); `report.py --days 7 -o /tmp/stats_demo/out.txt` → "Отчёт сохранён", text with the new
  notes. `Traceback` / `ERROR` in the server log: 0.
- 14:33 — `vorflux/stats-tab` after merging #3 and the simplify patch: `pytest -q` → 168 passed; `node --test` → 17
  pass. After the #4 review fixes: 2 Node tests failed first because their expected texts were the old ones on purpose
  ("нужен хотя бы 1 ч" → "нужно хотя бы 24 ч", new uptime-note wording); updated, plus new cases (4.97 → «5 вилок»,
  0.96 → «1 вилка», 20.98 → «21 вилка», 4.94 → «4,9 вилки»; «12 345», «уникальных 4 321 · матчей 1 200»; partial
  hours and unknown-day notes; escaping of team names, `event_title` in `title="…"`, venue and game labels) → 18 pass.
- 14:34–14:36 — Preview restarted on the merged code (public URL → 200, `/api/stats?days=7` → 200, `rate_min_data_hours`
  24). agent-browser 0.37.1, 1440×900: KPIs «146», «1 704,10 $ / без повторов 700,37 $», «34,3 вилки»; note
  "Время работы записывается с 12.10.2026 03:00: до этого часы неизвестны («—») или неполные."; hint labels
  "Пояснение: Вилок" …; KPI `title` "96 ч 35 мин"; JSON link `/api/stats?days=7`, download `stats-7d.json`; tables
  1375/1375, 756/756, 605/605, 1375/1375. With `fetch` to `/api/stats` failing: «30 дней» → error card, 0 toasts;
  back to «7 дней» → the 7-day numbers stay, the summary line stays, 1 toast «Не удалось обновить статистику: Сервер
  недоступен». Three refreshes with unchanged numbers → 0 new scroll listeners. 900 px: tabs 853/853; days table
  875/851 and top matches 956/851, both with the edge shadow. Empty history (:8053): "Подтверждённых вилок за этот
  период нет", rate «нужно хотя бы 24 ч со свежими данными». No JavaScript errors. Screenshots:
  `/code/.generated_artifacts/images/stats_tab_1440.png`, `stats_tab_1440_tables.png`, `stats_tab_900.png`,
  `stats_tab_empty.png` (not committed).
- 14:36 — `pytest -q` → 168 passed; `node --test tests/js/*.test.mjs` → `tests 18, pass 18, fail 0`; `node --check` on
  all frontend JS → OK.
- 15:00 — `/tmp/wt-b`: `pytest -q tests/test_stats.py` → 21 passed. Mutation check: without the lock in
  `StatsBuilds._run` the queue test fails (`running["max"]` 3 instead of 1); restored (and `__pycache__` cleared) →
  `pytest -q` → `172 passed, 1 warning in 8.89s`.
- 15:02 — `vorflux/stats-tab` with #3 merged: `pytest -q` → 172 passed; `node --test tests/js/*.test.mjs` → 18 pass;
  `node --check` on all frontend JS → OK. Preview restarted (public URL → 200). agent-browser 0.37.1: 5 clicks on
  «Обновить» in one go → 1 request to `/api/stats`; «Сегодня» → KPI «На 24 ч … | — | для оценки выберите 7 дней или
  больше»; «7 дней» → «52,8 вилки | прибыль 689,46 $» (the mock run keeps adding arbs to the seeded copy). No JavaScript
  errors.

## 2026-10-16 — session 5 (Stake adapter)

- 16:18 — Baseline on `main` `0f2d40c`: `.venv/bin/python -m pytest -q` → `172 passed, 1 warning`;
  `node --test tests/js/*.test.mjs` → `tests 18, pass 18`.
- 16:19 — Stake API without a key (from the Vorflux sandbox, US): `GET https://odds-data.stake.com/sports` → 200
  (46 sports; esports by `oddin` enabled: counter-strike, dota-2, league-of-legends, valorant, overwatch, rainbow-six,
  mobile-legends and others). `GET /schedule/sport/<slug>` → 200 for all six games: 29 + 5 + 4 + 7 + 6 + 13 = 64
  fixtures (60 active, 4 live). `GET /fixtures/<slug>` → 200 for all 64; each has `Match Winner - Twoway`
  (`variant=way:two|way=two`); `best_of` from "Correct Score" in 45 of 64 (none for Overwatch).
- 16:25 — `/sport/counter-strike/fixture?limit=50` → the same 29 fixtures as the schedule, with exact start times
  (schedule `date` = start rounded down to the hour, e.g. 10:45 → 10:00) and tournament names; `limit=51` → 400
  `numberLessEqual`; `/fixtures/<uuid>` and an unknown slug → 500 `{"message":"error"}`; gzip: 85 KB → 18 KB.
- 16:32 — Rate test: 160 × `GET /fixtures/<slug>` at 8 req/s, 4 at a time → 160 × 200, latency p50 0.14 s, p95 0.80 s,
  max 2.3 s. No rate-limit headers.
- 16:35 — Web links: `https://stake.com/sports/<sport>/<category slug>/<tournament slug>/<fixture slug>` (pattern from
  archived stake.com URLs; stake.com itself → 403 from the sandbox, the link was not opened).
- 16:39 — Live matching (real adapters, `Matcher` unchanged): Polymarket 82, Kalshi 99, Stake 40 markets (cs2 13,
  dota2 4, lol 3, valorant 1, overwatch 6, r6 13). Before the aliases: Polymarket ↔ Stake 28 auto + 2 review,
  Kalshi ↔ Stake 20 auto + 2 review; after four aliases: 30 auto + 0 review and 22 auto + 0 review; 9 Stake fixtures
  (R6 South America, one Dota 2) are on no other venue.
- 16:42 — `python run.py --mock` (3 platforms): 16 + 16 + 17 markets, 43 pairs (PM↔Stake 16, Kalshi↔Stake 14,
  PM↔Kalshi 13), header "Матчи" 19 (old formula: 49 − 43 = 6), all platforms healthy, confirmed mock arb
  Polymarket + Stake «G2 Esports» коэф. 1,37 (68.5 contracts = 50 × 1.37).
- 16:44 — `pytest -q` → 171 passed, 1 failed: `test_meta_and_state` (expected platforms {polymarket, kalshi}; the
  config now has stake too) → expectation updated.
- 16:50 — `pytest -q` → `193 passed, 1 warning` (172 + 21 new: 18 `test_stake.py`, 1 `test_rules.py`, 2
  `test_stats.py`); `node --test tests/js/*.test.mjs` → 18 pass.
- 16:51–16:55 — Live run, first minutes: Polymarket 81, Kalshi 96, Stake 40 markets; 112 pairs (Polymarket ↔ Kalshi 60,
  Polymarket ↔ Stake 30, Kalshi ↔ Stake 22), 0 review; all 112 pairs fresh on both sides; all three platforms
  healthy; header "Матчи" 126. Stake requests: 1719 in 270 s (6.4 req/s; 31 Stake markets are in pairs). No arb yet;
  closest Stake pair Polymarket ↔ Stake Team Tidebound / Team Resilience, sum of asks 0.9962, cost with fees 1.0087.
- 16:53–17:03 — Quote delay of the Stake API (`/tmp/stake/live/delay.py`, 3 live + 3 pre-match fixtures, each about
  every 2–3 s): 72 market updates (63 live, 9 pre-match). Receive time − market `updatedAt`: live min 0.8 s, median
  5.2 s, p90 9.4 s, max 12.1 s; pre-match min 4.0 s, median 6.1 s, max 10.0 s. Server `Date` − local clock −1…0 s
  (1 s resolution), so the clocks agree. The sampling adds up to 2–3 s; the API itself lags about 3–10 s.
- 17:00 — Public preview of the `--mock` instance: `GET https://aw5xy4wcey3n.preview.us1.vorflux.com/` → 200 (20517
  bytes), `/api/meta` lists Polymarket (mock), Kalshi (mock), Stake (mock).
- 17:04–17:06 — Browser (agent-browser 0.37.1, 1440 × 900): header with three platform chips (all green), 19 матчей,
  43 пар; «Статистика» → «По парам площадок»: «Polymarket (mock) ↔ Kalshi (mock)» 8, «Kalshi (mock) ↔ Stake (mock)» 6,
  «Polymarket (mock) ↔ Stake (mock)» 2; «Матчи с наибольшей прибылью» also names «Kalshi (mock) ↔ Stake (mock)». No
  frontend change was needed. Live instance (localhost:8031): one-row header at 1440 px (Polymarket WS, Kalshi REST,
  Stake REST), two rows at 1280 px (the existing responsive layout); «Сопоставленные пары» shows Polymarket ↔ Stake
  pairs with a «Stake ↗» link (e.g. Team Tidebound vs Team Resilience: sum 0,996, −0,86 % after fees, ⚠ 6, 100 %).
  With the mock names («… (mock)») the header wraps already at 1440 px when the page has a scrollbar.
- 16:51–17:29 — Live run of the full scanner (first version of the adapter), 38 min: Stake 13972 requests in 2250 s
  (6.2 req/s), all three platforms healthy at every look; `report.py --db /tmp/stake/live/live_run.db --days 1`:
  14 confirmed arbs (7 distinct, 7 matches), 23 candidates; data minutes 37 of 38. By venue pair:
  Polymarket ↔ Kalshi 10 arbs, 2.68 $; **Polymarket ↔ Stake 4 arbs (3 distinct), 0.66 $ upper estimate, max 2.37 %**;
  Kalshi ↔ Stake none. The Stake arbs: Dota 2 Xtreme Gaming vs Yakult Brothers — Xtreme Gaming on Polymarket @0.740 +
  Yakult's Brothers on Stake @0.227 (коэф. 4,4), 2.37 %, volume 17.08 $, profit 0.40 $, 2 min 15 s; Dota 2 Team
  Tidebound vs Team Resilience — Team Tidebound on Polymarket @0.510 + Team Resilience on Stake @0.476 (коэф. 2,1),
  0.13 %, volume up to 104.86 $, 2 appearances, 0.19 $ in total, 2 min 49 s in total; Overwatch Twisted Minds vs Team
  Risk — Twisted Minds on Polymarket @0.890 + Team Risk on Stake @0.100 (коэф. 10), 0.51 %, 12.93 $, 0.07 $, 4 min
  (13 contracts: the Polymarket book was the limit). All pre-match (start 17.10 08:00–17:00 UTC).
- 17:29 — After the review fixes: `pytest -q` → `205 passed` (+12 since 193: 11 more in `test_stake.py`, now 29, and
  `test_count_matches_joins_pairs_that_share_a_market` in `test_stats.py`); `node --test` → 18 pass.
- 17:30–17:50 — Second live run (`7500580`), sampler every 2 s (564 samples): Stake markets in pairs 49–58 pair sides
  per sample; the oldest Stake quote in a pair per sample: median 5.3 s, p90 6.0 s, p99 7.0 s, max 8.3 s; 0 samples with
  a Stake quote older than 10 s; Stake healthy in all samples. Stake requests 7385 in 1140 s (6.5 req/s). Confirmed
  Stake arbs: the two from the first run again (Team Tidebound vs Team Resilience 0.13 %, Twisted Minds vs Team Risk
  0.51 %, both active the whole time) and Overwatch 99DIVINE vs MURASH GAMING (BO7) — MURASH GAMING on Polymarket
  @0.480 + 99DIVINE on Stake @0.476 (коэф. 2,1), 3.23 %, 4.84 $.
- 17:50 — After the round-2 fixes: `pytest -q` → `208 passed` (+3: request-time stamp and 429 flag, a total odds outage
  at discovery, a redirect keeps the last list); `node --test` → 18 pass.
- 17:56 — After the Macroscope fixes: `pytest -q` → `212 passed` (+4: unusable names re-checked, malformed list answer,
  older answer ignored, no markets is healthy); `node --test` → 18 pass.
- 17:51–18:07 — Third live run (`3520618`), sampler 446 samples: 55–58 Stake pair sides per sample; the oldest Stake
  quote in a pair: median 5.3 s, p90 6.1 s, p99 8.0 s, max 9.4 s; 0 samples older than 10 s, Stake always healthy;
  Stake requests 6749 in 930 s (7.3 req/s, 45 Stake markets, ~36 in pairs). One `odds polling pass took 7.9 s for
  36 fixtures` warning (a slow answer at the end of a pass) → default `request_timeout_sec` lowered from 4 to 3 s.
  `report.py`: 6 arbs; Polymarket ↔ Stake 4 (4 distinct) 6.48 $, max 3.23 %; Polymarket ↔ Kalshi 2, 0.78 $. Xtreme
  Gaming vs Yakult Brothers came back with 214.92 $ volume (the Stake level of 50 × 4.4 = 220 contracts was the limit):
  2.37 %, 5.08 $; 99DIVINE vs MURASH GAMING up to 103.81 $ (3.23 %, 1.19 $).
- 18:08–18:12 — Live run of the final code `54bfad9` (4 min, 119 samples): Stake 43 markets, Polymarket ↔ Stake 30 and
  Kalshi ↔ Stake 23 pairs, 7.0 req/s; the oldest Stake quote in a pair: median 5.3 s, p90 6.0 s, max 7.6 s, never older
  than 10 s; Stake unhealthy only in the first 2 samples (before its first poll pass, 18:08:15–17), then healthy; the 3
  long-lived Stake arbs confirmed again; no warnings. CI `test` and the Macroscope check green on `54bfad9`.
- 18:13 — After the same-teams fix: `pytest -q` → `212 passed`; `node --test` → 18 pass.

## 2026-10-18 — session 6 (honest arb statistics)

- 19:36 — Baseline on `main` `f8325dc`: `.venv/bin/python -m pytest -q` → `212 passed, 1 warning`;
  `node --test tests/js/*.test.mjs` → `tests 18, pass 18`.
- 19:37 — `arb_copy.db` (SHA-256 `4fe5e960b789ea8286054b61abaf389c6baa78abb03063de5ccb5696f237c458`, WAL mode) read
  only through copies in `/tmp/arbdb/`: `arb_history` 796 rows (374 confirmed), `scanner_uptime` 2801 minutes
  (2791 healthy, first 16.10 21:59 MSK), `settings` 1 row (`engine.confirm_seconds` = 5), `pair_overrides` empty.
- 19:40 — The user's numbers, recomputed with Python on the copy (all match):
  confirmed 374; distinct pair_key + direction 134; Σ max_profit_usd 1250.72; phase by `first_seen < start_time`:
  before the start 220 (876.49 $, median lifetime 93.46 s, median volume 27.735 $), after the start 154 (374.23 $,
  median lifetime 13.378 s); max_volume_usd ≥ 1000: 15 rows, 952.84 $ = 76.18 %, all Polymarket ↔ Kalshi; capped at
  100 $ per appearance (min(profit, 100 × pct / 100)): 256.373 $; medians of all: volume 33.40 $, profit 0.80 %;
  CCT South America Series 7 Group Stage: 35 rows, 850.94 $ (68.0 %); RED Canids Academy vs realgotis22 (id 51):
  before the start, 465.8 s, 15456.43 $, 635.87 $.
- 19:42 — Differences and caveats found: (1) the first two appearances of RED Canids vs realgotis22 are 147.89 $ /
  6.82 $ (id 48) and 13.99 $ / 0.15 $ (id 49); (2) "three of the four largest pre-start arbs are CCT" holds by
  volume (4th: MVK Esports vs FURIA Esports, Worlds Play-In, 463.57 $); by profit all four are CCT; (3) "other
  tournaments peak in the hundreds of dollars" holds only before the start: after the start Thunderpick World
  Championship Playoffs 13480.83 $ (FURIA vs Aurora Gaming, 29 s), Worlds Play-In 4361.84 $, VCT Champions Playoffs
  3541.69 $, Demacia Cup 1200.51 $; of the 15 large rows 3 are before the start (all CCT), 12 after; (4) the median
  max_profit_usd is 0.21 $ (0.3 $ is the product of the medians); (5) the tracker keeps the maxima of profit %,
  volume and profit $ independently: in 87 of 374 rows they come from different moments (with profit / volume
  instead of max %, the 100 $ cap gives 233.91 $); (6) `leg1_ask`/`leg2_ask` are the last prices of an appearance,
  not the peak prices.
- 19:55 — Migration check on a copy (`/tmp/arbdb/mig.db`): `Database.connect()` added 17 columns (29 → 46), all 796
  old rows unchanged (compared column by column), `PRAGMA integrity_check` → ok, new fields NULL /
  `capture_version` 0, `list_history`, `get_history_item(51)` and CSV work. `report.py` on the migrated and on an
  unmigrated copy: same output as `main` plus one line "у 0 из 374 вилок … данных нет". `arb_copy.db` hash unchanged.
- 19:58 — `python run.py --mock` for 45 s (`/tmp/arbdb/mock1.db`): 2 confirmed rows, both with phase, snapshots
  (2.8 KB each), stake table, optimal size, flags `{}`; no traceback. Peak triple consistent (7.27 $ = 262.08 $ ×
  2.775 %), while max % and max volume came from other moments.
- 20:03 — `stake_table` + `optimal` for one moment with 10 levels per leg (Polymarket fees, Kalshi rounding, split
  instruments): 3.8 ms (computed once per confirmed appearance, when it closes).
- 20:06 — `pytest -q` → `229 passed, 1 warning` (212 + 17 in `tests/test_capture.py`); `node --test` → 18 pass.
  `report.py --db /tmp/arbdb/pr1.db --days 7` (fresh copy of `arb_copy.db`): exit 0, same numbers as `main` plus
  the line «у 0 из 374 вилок … данных нет»; `arb_copy.db` hash unchanged.
- 20:19–20:21 — `python run.py --mock` 75 s (`/tmp/arbdb/mock2.db`): 6 confirmed arbs, 12 paper checks (6 at +5 s,
  6 at +15 s), all `ok`, `books_match` 1 in all (the mock "request" reads the same world), 2 of 6 arbs left at +5 s
  and at +15 s; latency ~11 ms (the mock sleeps 10 ms); the +60 s checks were pending at shutdown → one line
  "paper checks: 6 pending checks dropped on shutdown"; no traceback. The report line: «+5 с — осталась 2 из 6;
  +15 с — осталась 2 из 6».
- 20:22 — `pytest -q` → `241 passed` (229 + 12 in `tests/test_paper.py`); `node --test` → 18 pass.
  `report.py --db /tmp/arbdb/pr2.db --days 7` (fresh copy of `arb_copy.db`): exit 0, PR 1 output plus «Бумажная
  проверка …: данных нет». The REST requests of `fetch_book` were checked only on recorded / constructed responses
  (Kalshi orderbooks fixture, Stake Cloud9–M80 fixture, a constructed Polymarket `/books` answer), not live.
- 20:35 — `report.py --db /tmp/arbdb/pr3.db --days 7` (fresh copy of `arb_copy.db`) with the PR 3 report: the user's
  numbers come out of the report itself: 374 arbs, 134 distinct, sum of maxima 1250.72 $; before the start 220 arbs
  (876.49 $, median lifetime 1 min 34 s, median volume 27.73 $), after the start 154 (374.23 $, median lifetime
  13 s); 15 arbs with volume ≥ 1000 $ (flag «большой объём»); 100 $ per arb: 256.37 $ (estimate by the maxima, all
  rows lack data at confirmation). New: without top-10 298.40 $ (the top 10 gave 952.32 $ = 76 %), median profit per
  arb 0.21 $ (p90 3.30 $), bankroll 1000 $ / 100 $ per arb / settle 3 h: 74.43 $ (131 of 374 arbs taken, 241
  skipped for locked money) — an estimate by the maxima; distinct arbs per 24 h of fresh data 70.2; CCT South America
  Series 7 Group Stage 850.94 $ (68 % of the sum of maxima, 30.27 $ without the top 10).
- 20:36–20:40 — Browser (agent-browser 0.37.1) on the public preview of the mock instance with the copied history
  (`curl` → 200, 20517 bytes; `/api/stats` over the public host → 380 arbs, 6 with data at confirmation, paper
  checks at +5 s: 6 checked, 2 left): all 9 cards render (phases, largest arbs, days, lifetime, games, venues,
  tournaments, paper checks, top matches with flags); at 1280 px the phase table scrolls sideways like the other wide
  tables; no console errors.
- 20:40 — `pytest -q` → `250 passed` (241 + 9 in `tests/test_honest_stats.py`); `node --test` → 20 pass (18 + 2).
- 21:04 — PR 2 after the review fixes (worktree `/tmp/wt-pr2`): `pytest -q` → `247 passed` (241 + 6: reordered
  teams priced by name and a changed team, late and slow checks, concurrency limit + timeout + one log line for DB
  failures, one log line per failing venue, Kalshi `fetch_book` without retries on 503, Stake changed teams);
  `node --test` → 18 pass.
- 21:10 — PR 1 after the review fixes (worktree `/tmp/wt-pr1`): `pytest -q` → `235 passed` (229 + 6); `node --test`
  → 18 pass; stake table + optimal size for one moment (10 levels per leg, split Kalshi leg) 2.0 ms (was 3.8 ms);
  correction to the 20:03 entry: the table is computed once per moment, so up to twice per confirmed appearance
  (confirmation and peak, once when they are the same moment). Snapshot size measured by the reviewer: about
  4.1 KB, about 8.9 KB per confirmed row (README now says 3–5 KB). `report.py` on a fresh copy of `arb_copy.db`:
  same output, the coverage line now names all reasons for missing data.
- 21:11 — PR 1 fixes merged into PR 2 (`git merge vorflux/stats-capture`; conflicts only in the report line, the
  handoff logs and CLAUDE.md; `paper.py` follows the rename `best_level` → `top_of_book`): `pytest -q` → `253 passed`
  (235 of PR 1 + 18 in `tests/test_paper.py`); `node --test` → 18 pass.
- 21:12 — PR 2 (with the PR 1 fixes) merged into PR 3 (`git merge vorflux/paper-checks`; conflicts only in the text
  report, which PR 3 rewrote, the handoff logs and CLAUDE.md): `pytest -q` → `262 passed`; `node --test` → 20 pass.
- 21:19 — PR 3 after the review fixes: `pytest -q` → `267 passed` (262 + 5 in `tests/test_honest_stats.py`);
  `node --test` → 20 pass. `report.py --db /tmp/arbdb/pr3b.db --days 7` (fresh copy of `arb_copy.db`; the period is
  now 13.10–19.10 because it is past midnight in Moscow): same checked numbers; «Банкролл (доля)» до старта 51,83 $ +
  после старта 22,60 $ = итог 74,43 $; bankroll line «взято 131 из 374, пропущено 241 (все деньги заняты) и 2 (нет
  выгодного объёма)».
- 21:20–21:21 — Browser on the restarted demo (mock mode on a fresh copy of the history, public preview
  `https://xnrp4bippyea.preview.us1.vorflux.com/`): the phase table shows «Банкролл (доля)» 51,83 $ + 22,95 $ =
  total 74,78 $ (the mock adds 6 captured arbs); partly known values at confirmation as «15,62 $ (4 из 224)»; the
  venue table no longer scrolls sideways at 1440 px; no console errors.
- 21:28 — After the simplify patches on all three branches: PR 1 235 pytest + 18 Node, PR 2 253 + 18, PR 3 267 + 20
  (all pass). `report.py --db /tmp/arbdb/pr3c.db --days 7`: byte-identical to the output before the patch (except the
  database path); `arb_copy.db` SHA-256 still `4fe5e960…c458`.

## 2026-10-19 — session 7 (BC.Game)

- Repository baseline: `main` and `origin/main` were both `f97523b`; the working tree was clean before the task.
- REA install: `rea --version` → `6.7.0`. The system-wide install failed with `EACCES` for
  `/usr/lib/node_modules`; the user-prefix install under `/home/ubuntu/.local` succeeded.
- Public Chrome page, no login: `https://bc.game/sports` loaded with title
  `Sports Betting - Football, Cricket & Esports Odds | BC Game`.
- REA target evidence: Chrome 155, exact origin `https://bc.game`, 160 first-party scripts retained. Public scripts
  identify the provider as BETBY and load `https://bcgame.sptsportscdn.com/bt-renderer.min.js`.
- The retained renderer source contains only the fallback message `Access is forbidden from your location`; no event,
  market or odds endpoint was exposed to this location. No country/IP restriction was bypassed.
- No live BC.Game odds, match counts, rate limits or settlement rules were verified.
- `node --test tests/js/*.test.mjs` → 20 passed.
- System `python -m pytest -q` first failed because pytest was absent. Creating `.venv` then failed because ensurepip /
  `python3-venv` was absent. With dependencies and `pytest-asyncio` isolated under `/tmp/arbitrage-pydeps`,
  `PYTHONPATH=/tmp/arbitrage-pydeps python -m pytest -q` → 267 passed, 1 warning in 16.48 s.
- 13:04 UTC — `origin/main` повторно проверен: `f97523b`. Рабочая ветка перед проверками чистая.
- Пять одиночных проверок renderer (прямой запрос и четыре прокси), затем обычный переход по публичному HTTP 302
  на `https://start9.sptpub.com/bt-renderer.min.js`: прямой запрос и прокси 3 дали HTTP 200 с геоблокировкой
  (3 678 байт); прокси 1, 2 и 4 дали HTTP 200 с JavaScript (51 479 байт). Повторов и подмены заголовков не было.
- Через прокси 1: `GET /help/terms-service`, `GET /help/terms-sports`, `GET /robots.txt` и публичный
  `POST /api/platform-sports/v14/home/sport/provider/support/` на `bc.game` вернули HTTP 403 с Cloudflare challenge.
  Запросы не повторены; challenge не решён. POST взят из публичного клиента и только читает конфигурацию провайдеров.
- `rea analyze-javascript-application` успешно разобрал публичный renderer без исполнения кода сайта.
  Данные матчей, рынков, коэффициентов, лимитов и расчёта ставок пока не получены.
- Перед контрольным коммитом: `PYTHONPATH=/tmp/arbitrage-pydeps python -m pytest -q` → 267 passed,
  1 warning in 16.27 s; `node --test tests/js/*.test.mjs` → 20 pass, 0 fail.
- Следующая контрольная точка, 13:13 UTC: те же команды → 267 passed, 1 warning in 16.20 s; 20 pass, 0 fail.
- Нативный Chrome с аутентифицированным SOCKS5 дал `net::ERR_SOCKS_CONNECTION_FAILED`. Через локальный SOCKS5-туннель
  обычный Chrome получил `https://bc.game/sports` (HTTP 200) и публичную конфигурацию провайдеров (HTTP 200, `code: 0`).
  Закрыты только собственные именованные браузерные сессии. HAR остался временным и не опубликован: он не очищен.
- Из гостевого ответа получен brand ID `2103509236163162112`. Без cookies и ключей обычные GET к BETBY вернули:
  `/api/v2/auth/brand/2103509236163162112/settings?lang=en` — HTTP 200;
  `/api/v3/descriptions/markets/en` — HTTP 200, 2 117 записей;
  `/api/v1/descriptions/statuses/en` — HTTP 200, 230 записей;
  `/api/v4/prematch/brand/2103509236163162112/en/0` — HTTP 200, индекс шести частей snapshot.
- Первая отложенная загрузка частей получила `version: 0` без событий: версии устарели. При немедленной загрузке
  первая часть вернула gzip, который исходный исследовательский скрипт ошибочно прочёл как UTF-8.
  Это ошибки исследовательского чтения, не доказательство отсутствия матчей. Декодирование исправлено во временном
  скрипте; результаты полной загрузки ожидаются. Частота ограничена примерно одним запросом в секунду.
- После исправления gzip получены все шесть частей, последняя содержит `snapshot_complete: true`.
  Объединено 2 098 событий, 53 вида спорта, 231 категория и 454 турнира. Реальные match/Winner рынки:
  CS2 22, Dota 2 7, LoL 9, Valorant 4, Overwatch 3, R6 2, MLBB 2; это полный фид без окна 72 часа.
- WIP-проверка в 13:29 UTC через один фиксированный разрешённый прокси: `BcGameAdapter.fetch_markets()` → 14 рынков
  в окне 72 часа (CS2 10, Dota 2 2, MLBB 2). `poll_once()` и `fetch_book()` ответили без ключа и входа.
  Это не подтверждение непрерывной свежести: время источника в итоговом результате было примерно на 18 секунд старше
  времени завершения скрипта. Требуется отдельная проверка delta/cursor; BC.Game остаётся выключенным.
- Новый код компилируется. Перед WIP-коммитом: `PYTHONPATH=/tmp/arbitrage-pydeps python -m pytest -q` →
  284 passed, 1 warning in 16.98 s; `node --test tests/js/*.test.mjs` → 27 pass, 0 fail.
  Новые 17 Python и 7 Node тестов проверяют только mock/интеграцию; протокол адаптера ещё не покрыт.
- 13:33 UTC — Живая подписка, один фиксированный прокси, пять различных времён источника одного рынка:
  возраст на callback 7,595 / 5,222 / 8,088 / 6,799 / 4,872 с. `connected: true`, ошибка отсутствует.
  В этом прогоне включён фоновый polling; предыдущий отдельный скрипт его не запускал.
- Первый специализированный прогон: 39 passed, 2 failed (NaN/Infinity в коэффициентах).
  Добавлена отдельная проверка конечности в BC.Game, без изменения helper Stake или математики движка.
- Финальные команды перед контрольной точкой 13:38 UTC: `PYTHONPATH=/tmp/arbitrage-pydeps python -m pytest -q` →
  330 passed, 1 warning in 18.18 s; `node --test tests/js/*.test.mjs` → 27 pass, 0 fail.
  Новые 46 тестов BC.Game покрывают snapshot/delta/reset/epoch, частичный ответ, BO2/1x2, порядок команд,
  удаление рынков, stale timestamps, 401/403, 429/Retry-After, тайм-ауты, параллелизм, отсутствие утечки секрета,
  независимое чтение книги и синтетический live. Реальные live-матчи не проверены.
- После разрешённого пользователем исправления Stake, 13:42 UTC:
  `PYTHONPATH=/tmp/arbitrage-pydeps python -m pytest -q` → 340 passed, 1 warning in 18.25 s;
  `node --test tests/js/*.test.mjs` → 27 pass, 0 fail. Десять новых случаев Stake проверяют NaN, ±Infinity,
  строковые NaN/Infinity, нечисловой лимит ставки и переполнение размера. Нормальные примеры 1/odds и max_stake×odds
  проходят прежние тесты без изменения ожидаемых результатов.
- Первая проверка PR: два must-fix. Локальная проверка новых регрессий сначала не собралась из-за пропущенного
  параметра теста `change`; тест исправлен. Повтор: 5 failed, 46 deselected — подтверждены оба дефекта и paper-вариант.
  После исправлений `tests/test_bcgame.py` → 51 passed in 1.47 s. Добавлены ещё два теста доказанного MLBB-алиаса.
- Публичный preview отвечает HTTP 200; `/api/meta` содержит четыре `(mock)` площадки, `mock_mode: true`.
  В браузере прочитан screenshot 1440×900: четыре зелёных индикатора, цены, синтетическая Stake ↔ BC.Game вилка и ссылки.
  Console пустой. Первая запись фильтров дошла до статистики, но ожидание `При подтверждении` завершилось timeout:
  интерфейс использует другую подпись. Запись не опубликована. API статистики вернул все шесть пар, включая Stake ↔ BC.Game.
- Контрольные команды после обоих review-fix и MLBB-алиаса:
  `PYTHONPATH=/tmp/arbitrage-pydeps python -m pytest -q` → 347 passed, 1 warning in 18.34 s;
  `node --test tests/js/*.test.mjs` → 27 pass, 0 fail. Проверка секретов и diff выполняется перед commit/push.
- Окончательный живой сбор 14:09:01–14:09:27 UTC: пулы PM 64 / Kalshi 92 / Stake 15 / BC.Game 13; ошибок запросов нет.
  BC.Game по играм и авто-пары (PM / Kalshi / Stake): CS2 8 (8 / 7 / 8), Dota 2 3 (3 / 3 / 3), MLBB 2 (2 / 2 / 0).
  Остальные игры — 0 в окне 72 ч. Одна review-пара Kalshi, разница старта 170 мин. Полная таблица в API_NOTES.
- Возраст поздних callbacks 11,986 / 13,246 / 12,943 с. Эти котировки старше порога 10 с; тест `evaluate_pair`
  на старой книге возвращает пустой список. Ранний возраст 4,872–8,088 с не является гарантией последующей доставки.
- Публичный mock: фильтр CS2 и поиск Natus оставили шесть пар; href BC.Game — `https://bc.game/sports/mock/bcgame-000`.
  Вкладка статистики показывает все шесть пар, в том числе Stake ↔ BC.Game. Console: 0 байт; screenshots прочитаны.
  Запись 1280×720, 15 fps содержит весь быстрый сценарий за 0,6 с; для чтения выбраны screenshots, видео не публикуется.
- Paper race: до исправления 2 failed, 53 deselected. После копии исходного market до первого await:
  `PYTHONPATH=/tmp/arbitrage-pydeps python -m pytest -q` → 349 passed, 1 warning in 18.52 s;
  `node --test tests/js/*.test.mjs` → 27 pass, 0 fail. Финальная точечная проверка review ещё ожидается.
- 14:20 UTC, повтор перед публикацией: 349 passed, 1 warning in 18.74 s; Node 27 pass, 0 fail.
  В этот прогон входит явный отказ движка рассчитывать вилку по старой BC.Game-книге.
- Итоговый review, 14:24 UTC: блокирующие замечания закрыты, риск 3/10 Low, Ship with mitigations.
  Review статический; тесты и живые запросы выполнял основной агент, а не reviewer.
- Полный branch diff не содержит предоставленных proxy credentials и адресов. Отсутствуют tracked `.env`, HAR и
  browser state. Временный input удалён; собственные proxy tunnel и исследовательский Chrome остановлены.
- Финальный прогон перед handoff-коммитом, 14:27 UTC: `PYTHONPATH=/tmp/arbitrage-pydeps python -m pytest -q` →
  349 passed, 1 warning in 18.36 s; `node --test tests/js/*.test.mjs` → 27 pass, 0 fail.
- `gh pr view`: `state: OPEN`, `isDraft: false`, `autoMergeRequest: null`. Прежнее сообщение о draft исправлено;
  агент не выполнял изменение draft/ready или merge.
- CLI fallback заменил один точный авторский блок PR. SHA-256 внешнего содержимого до/после совпал; чужие
  комментарии/секции не перезаписаны. Platform `pr edit` не получил datasource-доступ.
- Platform `pr report-risk --score 3` → `not_tracked`, `index_updated: false`, `review_updated: false`.
  Оценка есть в описании PR, но не сохранена в платформенном индексе. Ошибка не замалчивается как успешная публикация.

- После исправления статуса PR, 2026-10-19 14:35 UTC: 349 passed, 1 warning in 18.57s; Node 27 pass, 0 fail.

## 2026-10-19 — сессия 8, измерения

- 2026-10-19 15:13 UTC — PR OPEN, isDraft false, autoMergeRequest null; рабочая ветка до начала чистая.
- Гостевой индекс через ранее разрешённый фиксированный прокси: HTTP 200; безопасные Date/cache headers сохранены.
- Наблюдатель использует настоящие Scanner callback/eval-loop и функцию is_fresh, но не строит фиктивные пары.
  Все engine samples относятся к реальным BC.Game-книгам; прибыльные вилки в этом одно-площадочном режиме не измеряются.
- Первый smoke не стартовал: database is not connected. После явного connect: 18 с, 1 snapshot, 4 delta,
  10 непустых рынков, 210 непустых engine samples, 0 HTTP-ошибок. Причина старения ещё не установлена.

- Базовая живая выборка 15:14:33.711–15:19:34.037 UTC: 2 snapshot, 61 delta, 76 HTTP, ошибок 0,
  10 непустых рынков, 5 580 samples; apparent fresh 93,011%, возраст median 7,260 / p95 12,916 / max 70,558 с.
- По тем же 76 payload и 5 580 UTC-проверкам offline replay нового учёта: fresh 0%, evidence age
  median 209,078 / p95 342,169 / max 356,720 с. Не является новым live-тестом или измерением actual price last-modified.
- Новый live smoke 15:47:38.890–15:48:38.852 UTC: 1 snapshot, 12 delta, 1 050 непустых checks, fresh 0%;
  закрытие/переоткрытие клиента/восстановление по одному. Одна инъецированная ошибка и отмена запроса при завершении.
- Перед длительным запуском: Python 417 passed, 1 warning in 21.16 s; Node 27 pass, 0 fail.
  91 тест основного BC.Game и новой свежести + 32 теста observer проходят без сети и текущего расписания.
- Прерванная попытка 91e1137: 803,249 с, outcome interrupted, validation false (run_not_completed, controlled_fault_not_recovered).
- Новые lifecycle-регрессии на архиве опубликованного 91e1137: 14 failed / 2 passed. На исправленном коде 16 passed.
  Дополнительные mixed-age/third/threeway/game cases довели профильный набор до 111 passed in 3.25 s.
- Инструмент наблюдения после review: 63 offline-теста прошли; network/credentials builder не использовал.
  Book setter timing измеряется только для subscribed объекта; discovery и invalidate остаются помеченными envelope/not_measured.

- Контрольная точка 2026-10-19 16:49 UTC: Python 468 passed, 1 warning in 21.53 s; Node 27 pass. Core review 3/10 и measurement review 2/10 закрыли известные must-fix. Новый полный 30-минутный прогон ещё не завершён.

- Финальный live 6a99003 completed: monotonic 1800,034 с; UTC 16:50:10.929–17:20:10.906.
  Сэмплы 45 705/45 312 total/nonempty, unknown 2 589; age statistics n=42 723. Fresh 312/45 312=0,689%.
  Snapshot/delta 1/361, HTTP success 368, injected errors 2, native errors 0, close/reopen/recovered по одному.
- 4 event delete-маркера относятся к 3 исчезнувшим наблюдаемым ID; b1 среди них 0. Global feed markers отдельно в отчёте.
  Raw lifecycle проверил все 45 705 samples: invalid reuse 0. Epoch/reset в финальной live-выборке не встретился.
- Последняя source/evidence корреляция: 64 source-origin исхода доставлены, median первой нормализации→callback 7,116 мс,
  max 35 384,720 мс (безопасный metadata latch). Бизнес-время изменения цены неизвестно.
- Финальные команды: Python 468 passed, 1 warning in 21.41 s; Node 27 pass, 0 fail; compileall exit 0.
  Тайпчекер не настроен. Цена может оставаться верной без изменения, но data freshness<=10 с не доказана.
- Независимая проверка активного unchanged-contract clock: 0 ложных продвижений. Пять сырых переходов счётчика
  объяснены empty/unknown/quarantine/rebinding, а не признаны пятью обновлениями старой цены.
- Task diff от 1ff0b77: engine/scanner/math/matcher, прошлые три адаптера и config.yaml не менялись.
  YAML подтверждает bcgame.enabled=false и stale_seconds=10. Секреты не найдены; защищённая временная .env удалена.

## 2026-10-20 — freshness telemetry implementation checkpoint

- Focused: `python -m pytest -q tests/test_freshness_cache.py tests/test_net_and_freshness.py tests/test_adapters.py tests/test_stake.py` → 109 passed in 8,43 s.
- Collection: `python -m pytest --collect-only -q` → 502 tests collected.
- Full: `python -m pytest -q` → 502 passed, 1 existing Starlette warning in 24,88 s.
- Node: `node --test tests/js/*.test.mjs` → 27 pass, 0 fail in 85,15 ms.
- `python -m compileall -q backend tests` → success.
- `git diff --check` → success.
- Проверки используют recorded fixtures и `httpx.MockTransport`; живая сеть не проверялась.
- HTTP 500/403/429/timeout, malformed, empty и partial cases сохраняют last-good cache по новым регрессиям.
- Review fixes: multi-batch Polymarket PONG и Kalshi WS-disconnect regression tests → 109 focused passed.
- После review fixes: 502 tests collected; 502 passed, 1 warning in 24,54 s; Node 27 pass in 85,38 ms.
- Compileall и `git diff --check` после review fixes → success.
- Follow-up review `e39f28d..7f0e543`: actionable defects не найдены; risk 3/10, Safe to ship.
- GitHub CI run https://github.com/lndrosa/arbitrage/actions/runs/39453409618 → test pass in 50 s; Macroscope skipped.
- Final report CI https://github.com/lndrosa/arbitrage/actions/runs/39453772768 → test pass in 56 s; Macroscope skipped.
