# NEXT STEPS

## Сессия 12

1. Передать владельцу PR 14 для review. Не выполнять merge.
2. Не менять heartbeat semantics или BC.Game source-age policy в этом PR.
3. При принятии проверить критерии из `docs/FRESHNESS_TELEMETRY_AUDIT.md`.

## Сессия 10

1. Опубликовать checkpoint.
2. Обновить существующий Test Report с тем же заголовком.
3. Подтвердить пользователю фактический путь proxy через все snapshot parts.

## Сессия 9: текущий следующий шаг

1. Обновить PR итоговыми результатами и списком изменённых файлов.
2. Не менять draft-state и не выполнять merge.
3. Для успешной живой проверки запустить `python run.py` из разрешённой юрисдикции без обхода ограничений.

## Сессия 8: исследование завершено, включение BC.Game не разрешено

Итог: NOT READY. Код и измерительные ошибки исправлены, 468 Python + 27 Node пройдены.
Финальное наблюдение длилось 1800,034 с; 45 312 непустых samples, только 0,689% проходят cutoff 10 с.
Actual business last-modified источник не сообщает. Уменьшение polling не устраняет эту неопределённость.

Дальнейшие задачи владельца, не автоматические действия агента:
1. Проверить PR 9 и отчёт docs/BCGAME_FRESHNESS.md. Не включать BC.Game и не менять общий stale.
2. Получить разрешённый источник с индивидуальными метками или подтверждённой семантикой актуальности состояния.
3. Отдельно спроектировать безопасную реакцию на metadata changes: периодический rematch может задержать книгу на десятки секунд.
4. Подтвердить официальные правила отмены/переноса/форфейта/ничьей и реальные лимиты ставки.
5. Только после этих доказательств повторить controlled shadow qualification; никакого допуска к реальным ставкам сейчас нет.

Прерванные 803,249 с первого post-fix запуска не засчитаны как завершённый длительный тест.
В финальном тесте HTTP-клиент действительно закрыт/переоткрыт с той же конфигурацией, затем установлено новое состояние.
Raw lifecycle-ноль не равен доказательству temporal reset safety; соответствующие ветки подтверждены offline-регрессиями.

## Сессия 7 (2026-10-19): BC.Game реализован, включение требует отдельных проверок

Открытый PR: https://github.com/lndrosa/arbitrage/pull/9, `isDraft: false`, auto-merge выключен.
Реализация, тесты, simplify и review завершены. Все известные must-fix исправлены.
Последний риск — 3/10, Ship with mitigations. Агент не менял draft/ready после тестов.

Следующие шаги владельца:
1. Проверить PR и выполнить merge вручную, если код подходит. Не включать BC.Game автоматически.
2. Получить актуальные официальные правила отмены, переноса, форфейта и ничьей: https://bc.game/help/terms-sports.
3. Проверить стабильность разрешённого источника при текущем пороге 10 с. Поздние данные были старше этого порога.
4. Подтвердить реальные ограничения ставки вместо допущения `max_stake_usd: 50`.
5. Только после этих проверок изменить `platforms.bcgame.enabled`. Не ослаблять порог ради зелёного индикатора.

Пользователь разрешил четыре фиксированных SOCKS5-прокси в этой сессии. Учётные данные не сохранены в репозитории;
временный input и HAR удалены, туннель остановлен. Для повторной живой проверки нужен новый разрешённый доступ.
Запрещены вход, ставки, подмена заголовков, решение challenge и автоматическая смена прокси.

Живое сопоставление 14:09 UTC: BC.Game 13, авто PM 13 / Kalshi 12 / Stake 11; одна review-пара Kalshi.
Таблица всех игр: `docs/API_NOTES.md`. Поздний возраст источника 11,986–13,246 с; движок отбрасывает старые книги.
Preview только с синтетическими данными: https://ot1tcsweh0w8.preview.us1.vorflux.com.
Никаких реальных ставок или production-ключей preview не использует.

Инфраструктурное ограничение: platform `pr edit` не видит GitHub datasource. Описание обновлено CLI без потери чужих секций.
Platform `pr report-risk` вернул `not_tracked`; оценка есть в PR, но не в платформенном индексе.

## Session 6 (2026-10-18, 19:34–21:30 UTC): honest statistics — done

Decisions of the user (19:49): keep `arb_copy.db` in `main` as it is (do not change, rename or re-add it; work on
copies in `/tmp`); PR 2 re-reads both books with its own REST requests and compares them with the scanner's books;
PR 3 bankroll = one capital pool, money locked until settlement (`settle_hours` after the later of start and
confirmation). Days stay in Europe/Moscow. Arb search logic must not change.

PRs (stacked, merge in this order): https://github.com/lndrosa/arbitrage/pull/6 →
https://github.com/lndrosa/arbitrage/pull/7 → https://github.com/lndrosa/arbitrage/pull/8. Quality pass done
(simplify, one review per PR with risk 3/10, 4/10, 4/10; all must-fix and should-fix findings fixed and merged
forward).

After the merge (user):
1. Update the code and run the scanner as before. The first start migrates `data/arb_history.db` (18 columns in
   `arb_history`, new table `paper_checks`); old rows stay as they are and show «данных нет».
2. Paper checks add about 6 requests per confirmed arb (about 1100 per day at the 16–18.10 rate). To switch them off:
   `paper.enabled: false`.
3. After 3–7 days: `python report.py --days 7` (or the «Статистика» tab) and send the output. Look at «При
   подтверждении», «Без топ-10», «Банкролл», the paper checks by phase and the flags of the largest arbs (CCT South
   America Series 7). The snapshots of a suspicious arb: `GET /api/history/<id>` (Kalshi tickers per level).
4. If `size_jump` or `stale_data` flags look noisy, tune `capture.size_jump_ratio`, `size_jump_min_usd`,
   `stale_age_sec` in `config.yaml`.

Open items:
- Not verified live: the paper-check REST requests against the real venues (only recorded / constructed answers and
  the mock mode), capture on real books.
- Out of scope, unchanged: `include_live: false` works only for Stake; there is still no pre-start filter for
  Polymarket ↔ Kalshi in the search (the user asked not to change the search; the report now separates the phases).

## Session 5 (2026-10-16, 16:17–18:13 UTC): Stake adapter — done

PR https://github.com/lndrosa/arbitrage/pull/5 (branch `vorflux/stake-adapter`). No model change, so no second PR:
Stake's minimum bet (about $0.10 by public reviews) is below the Polymarket 5-share and Kalshi 1-contract minimums.

After the merge (user):
1. Update the code (`git pull`), start the scanner as before (`run-windows.bat` or `python run.py`). Stake is on by
   default (`platforms.stake.enabled: true`); no key is needed. Keep `include_live: false` and `max_stake_usd: 50`
   (or your real limit).
2. Check in the first minutes: the Stake chip in the header is green; «Сопоставленные пары» has Polymarket ↔ Stake and
   Kalshi ↔ Stake pairs; the log has `stake: N markets` every minute and no `discovery failed`.
3. Run 3–7 days without sleep mode (Stake adds about 6–7 requests per second, about 7 GB of traffic per day).
4. Then `python report.py --days 7` (Windows: `.venv\Scripts\python.exe report.py --days 7 -o report.txt`) or the
   «Статистика» tab → «По парам площадок»; send the output. "Данные, ч" now need all three venues to be fresh.
5. If the log often shows `odds polling pass took … s`, raise `rate_limit_per_sec` or drop games; if Stake answers
   401/403, see README «Stake (букмекер)» (key in `.env` or `enabled: false`).

Open items for later sessions:
- Out-of-scope finding (Pending): Polymarket and Kalshi discovery stops for all games when one game request fails
  (Stake already keeps the last list per game).
- Not verified live: links to stake.com (403 from the sandbox), real bets and limits, `include_live: true`, the key
  path and real 401/403/429 answers, 10 req/s.
- Roadmap items 3–5 and 7–9 below stay as they were (Telegram alerts, bet calculator, one row per match across venues,
  BC.Game, risks in the UI).

## Session 4 (2026-10-16, started 13:02 UTC)

The project is restored and merged: `main` = `5e55fb3` (merge of PR #1 `cd055b3` + the user's `CLAUDE.md`, CI workflow
and README clone URL). 144 pytest + 11 Node tests pass on it. The restore steps of session 3 are done.

Plan: one PR per change. Every PR updates `docs/handoff`, so the branches are stacked (each starts from the previous
one) and all PRs target `main`. Merge them in order; until the previous PR is merged, a PR also shows its commits.

1. `vorflux/session4-checks` — handoff after the restore; README clone URL `https://github.com/lndrosa/arbitrage.git`;
   end-to-end check of `04cbe85` (passed); second review of `d8942e9` and `04cbe85` (risk 2/10) with fixes for all
   its findings and for the missing WebSocket recovery line found by the check. **Done:**
   https://github.com/lndrosa/arbitrage/pull/2
2. `vorflux/history-stats-report` — roadmap step 2: a report from the SQLite history (arbs per day, profit $,
   lifetime, game, pair) as a command and an API endpoint. Days are counted in Europe/Moscow (user's decision).
   **Done:** https://github.com/lndrosa/arbitrage/pull/3 (review: risk 3/10, all its findings fixed).
3. `vorflux/stats-tab` — a "Статистика" tab in the dashboard on top of that endpoint. **Done:**
   https://github.com/lndrosa/arbitrage/pull/4
4. Quality pass over the three PRs (simplify, one review per PR, a second round for #3 and #4, the Macroscope bot):
   **done**, all findings fixed; risks 2/10 (#2), 3/10 (#3 and #4 after the second round, "ship with mitigations" →
   mitigations done).

After the merge (user):
- run the scanner 3–7 days with the new version (it writes its uptime from the first start), then send the output of
  `python report.py --days 7` (or look at the "Статистика" tab) — the input for the decision about new venues;
- update the expected test counts in `CLAUDE.md` (144/11 now; after all three PRs: 172 pytest, 18 Node).

Not now (user's decision): new venues (Stake, BC.Game) — only after the statistics show value.

## Open items

a. The user runs `run-windows.bat` on Windows (it was never run on Windows) and sends the console output.
b. Done (session 4): end-to-end check of `04cbe85`, second review of `d8942e9` and `04cbe85`, fixes (PR 1).
c. Known, not fixed (low, by design): a split Kalshi order part below the minimum is dropped, not rebalanced
   (volume can be understated, never overstated).
d. Not possible without keys: Kalshi WebSocket live test (needs Kalshi API keys).

## Roadmap after the restore (recommendation of session 3, 2026-10-16)

Data point: the user's 49-minute real run had 6 "ARB confirmed" lines; the best profit was about $0.36
(4.07 % of $8.76). Polymarket ↔ Kalshi esports arbs are rare and limited by thin books. So measure first, then add
venues.

1. Restore, open the PR, merge after the user approves. **Done**: restored into `lndrosa/arbitrage`, PR #1 merged (`cd055b3`).
2. Measure 3–7 days: run 24/7, then a report from the SQLite history (arbs per day, profit $, lifetime, game,
   pair). Optionally a "Статистика" tab. Decide on the next venues with these numbers. **The report exists**
   (session 4): after the merge, run the scanner 3–7 days with the new version (it writes its uptime from the first
   start), then `python report.py --days 7` and send the output.
3. Telegram alerts for confirmed arbs above a threshold (token in `.env`), and a 24/7 run on a small Linux VPS
   (Docker or systemd). The dashboard stays for details.
4. Bet calculator in the arb row: the user enters a bankroll, the UI shows the amount per leg (fees, rounding,
   limits). Needed for bookmakers (equal payout on both legs).
5. New venues (main lever for volume). Before the second new venue: group one match across all venues (cluster),
   take the best price per outcome over all venues, one row per match instead of one row per venue pair.
6. Stake adapter (first new venue) — design:
   - `backend/adapters/stake.py`, `StakeAdapter(MarketAdapter)`; config section `stake:` with
     `adapter: backend.adapters.stake:StakeAdapter`, game slugs (`counter-strike` → cs2, `dota-2`, `league-of-legends`,
     `valorant`, `overwatch`, `rainbow-six` → r6), `max_stake_usd` (assumed limit, e.g. 50), poll interval;
     `fees: stake:` with zero fees (the margin is inside the odds).
   - Discovery: `/schedule/sport/<slug>` per game; odds: `/fixtures/<slug>`; only `Match Winner - Twoway`,
     market `active`, outcome `active`, pre-match first (`preMatchEnabled`; live has bet delays).
   - Mapping: price = 1 / odds; one `Level` per outcome with size = `max_stake_usd` × odds contracts; fee 0. The engine,
     minimums, N-second rule and history work unchanged. `min_order_size` is in contracts; a minimum stake in $ needs
     a small model change (contracts = stake × odds differ per outcome).
   - `scanner.py` passes all discovered markets to `subscribe_prices`; poll only fixtures that are in a pair (or slow
     polling for the rest) to keep the request rate low.
   - Rules (`backend/matching/rules.py`): a Stake profile; bookmakers usually void bets on postponement or walkover
     (the value `void` = "возврат/аннулирование" exists). Exclude three-way markets (BO2 draws) at first.
   - Matching: team aliases (`aliases.yaml`); `Scanner.rematch` already pairs every two platforms, so Stake ↔ Polymarket
     and Stake ↔ Kalshi (and later Stake ↔ BC.Game) need no engine change.
   - UI: show decimal odds next to the price (2,50 = 0,40); platform name/color come from the config.
   - Tests on recorded responses (`tests/fixtures`), like the other adapters; a mock bookmaker for UI checks.
7. BC.Game: no official API → an aggregator (odds-api.io lists Stake and BC.Game) or the BETBY widget's internal
   API (fragile, may break the site rules). Only after step 2 shows value.
8. Risks to show in the UI/README for bookmaker legs: the bookmaker can change odds, reject or void a bet ("obvious
   error"), leaving the exchange leg unhedged; accounts that only take arbs get limited; KYC on withdrawal; access and
   legality depend on the country; money must sit on every venue in advance.
9. Not now: auto-trading (keys, wallets, risk of errors); maps/totals/handicaps (rule differences) — after statistics.

## Done in session 3

PR #3 opened (gone now); exact Node liveness assertion; per-order minimum per instrument; log lines from the user's
Windows log (error types, reconnect/recovery with the data gap, `ARB ended` with a reason, one-line discovery
failure); README Windows steps and `run-windows.bat`; review fixes; fixes for the testing findings (split
instrument on two lines, pairs quotes show the prices the engine uses).
