"""Console report from the SQLite history: ``python report.py [--days 7] [--json]`` (from the project root)."""

from __future__ import annotations

import argparse
import asyncio
import json
import math
import sqlite3
import sys
from pathlib import Path
from typing import Any

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from backend.config import Settings, load_settings, set_dotted, validate_timezone  # noqa: E402
from backend.stats import MAX_DAYS, collect, format_text  # noqa: E402
from backend.storage.db import Database  # noqa: E402


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Command-line options."""
    parser = argparse.ArgumentParser(description="Отчёт по истории вилок из SQLite (вилки по дням, прибыль, время жизни)")
    parser.add_argument("--days", type=int, default=7, help=f"сколько последних дней показать, 1–{MAX_DAYS} (по умолчанию 7)")
    parser.add_argument("--db", help="файл SQLite (по умолчанию из конфига: data/arb_history.db)")
    parser.add_argument("--mock", action="store_true", help="история режима --mock (data/arb_history_mock.db)")
    parser.add_argument("--config", help="путь к config.yaml (по умолчанию backend/config.yaml)")
    parser.add_argument("--tz", help="часовой пояс для дней, например Europe/Moscow (по умолчанию stats.timezone)")
    parser.add_argument("--top", type=int, default=10, help="сколько матчей показать в топе (по умолчанию 10)")
    parser.add_argument("--bankroll", type=float, help="банкролл, $ (по умолчанию stats.bankroll_usd)")
    parser.add_argument("--max-stake", type=float, help="не больше стольких $ на вилку, 0 — без лимита "
                                                          "(по умолчанию stats.max_stake_per_arb_usd)")
    parser.add_argument("--exclude-top", type=int, help="итог без N крупнейших вилок (по умолчанию stats.exclude_top_n)")
    parser.add_argument("--json", action="store_true", help="вывести отчёт в JSON")
    parser.add_argument("-o", "--output", help="записать отчёт в файл (UTF-8) вместо вывода в консоль")
    return parser.parse_args(argv)


def db_path(settings: Settings, args: argparse.Namespace) -> Path:
    """The same database as ``run.py`` with the same flags."""
    path = args.db or settings.storage.path
    if args.mock and not args.db:
        path = str(Path(path).with_name("arb_history_mock.db"))
    return settings.resolve_path(path)


async def _collect(path: Path, settings: Settings, days: int, tz_name: str, top: int) -> dict[str, Any]:
    db = Database(path, read_only=True)
    await db.connect()
    try:
        # Values saved in the UI (e.g. the confirmation threshold) win over config.yaml, as in the scanner.
        try:
            saved = await db.get_settings()
        except sqlite3.OperationalError:
            saved = {}
        for key, value in saved.items():
            try:
                set_dotted(settings, key, value)
            except ValueError:
                pass
        return await collect(db, settings, days, tz_name=tz_name, top=top)
    finally:
        await db.close()


def _prepare_output() -> None:
    """UTF-8 when the output goes to a file or a pipe (a Windows console prints Unicode anyway)."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        if not stream.isatty():
            reconfigure(encoding="utf-8")
        reconfigure(errors="replace")


def main(argv: list[str] | None = None) -> int:
    """Print the report; return the exit code."""
    args = parse_args(argv)
    _prepare_output()
    if not 1 <= args.days <= MAX_DAYS:
        print(f"--days: нужно число от 1 до {MAX_DAYS}", file=sys.stderr)
        return 2
    if args.top < 1:
        print("--top: нужно число больше 0", file=sys.stderr)
        return 2
    settings = load_settings(args.config)
    try:
        tz_name = validate_timezone(args.tz) if args.tz else settings.stats.timezone
    except ValueError as exc:
        print(f"--tz: {exc}", file=sys.stderr)
        return 2
    for flag, value, field in (("--bankroll", args.bankroll, "bankroll_usd"), ("--max-stake", args.max_stake,
                               "max_stake_per_arb_usd"), ("--exclude-top", args.exclude_top, "exclude_top_n")):
        if value is None:
            continue
        if not math.isfinite(value) or value < 0:
            print(f"{flag}: нужно число не меньше 0", file=sys.stderr)
            return 2
        setattr(settings.stats, field, value)
    path = db_path(settings, args)
    if not path.is_file():
        run = "python run.py --mock" if args.mock else "python run.py"
        print(
            f"Файл истории не найден: {path}\n"
            f"Файл появляется при первом запуске сканера ({run}). Другой файл можно указать флагом --db.",
            file=sys.stderr,
        )
        return 1
    try:
        report = asyncio.run(_collect(path, settings, args.days, tz_name, args.top))
    except sqlite3.DatabaseError as exc:  # not a history file, or a damaged one
        print(f"Не удалось прочитать историю из {path}: {exc}", file=sys.stderr)
        return 1
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n" if args.json else format_text(report, db_path=path)
    if args.output:
        out = Path(args.output).resolve()
        if out in {path.resolve(), Path(f"{path}-wal").resolve(), Path(f"{path}-shm").resolve()}:
            print(f"-o: {args.output} — это файл истории сканера; укажите другой файл для отчёта", file=sys.stderr)
            return 2
        # A file written by Python itself: PowerShell 5.1 would re-encode redirected output (">") and garble Cyrillic.
        try:
            Path(args.output).write_text(text, encoding="utf-8")
        except OSError as exc:
            print(f"Не удалось записать {args.output}: {exc}", file=sys.stderr)
            return 1
        print(f"Отчёт сохранён: {Path(args.output).absolute()}")
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
