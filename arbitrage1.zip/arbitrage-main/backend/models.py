"""Shared pydantic models: the unified internal format used by every layer."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, Field


def utcnow() -> datetime:
    """Return the current time as an aware UTC datetime."""
    return datetime.now(timezone.utc)


class Level(BaseModel):
    """One order-book level: price in dollars (0..1), size in contracts/shares."""

    price: float
    size: float
    instrument: str | None = None  # what you actually buy, e.g. "YES KXCS2GAME-...-TL"


class FeeSpec(BaseModel):
    """Fee parameters of one market; interpreted by ``engine.fees``."""

    model: Literal["none", "polymarket", "kalshi", "flat"] = "none"
    rate: float = 0.0
    exponent: float = 1.0
    multiplier: float = 1.0
    round_up_cents: bool = False
    flat_per_contract: float = 0.0


class NormalizedMarket(BaseModel):
    """One two-outcome market (team A vs team B) on one platform.

    ``asks_a`` / ``asks_b`` hold the buy side of the book for each outcome, best price first.
    The scalar ``outcome_*`` fields mirror the top of those books.
    """

    platform: str
    market_id: str
    event_title: str
    game: str
    team_a: str
    team_b: str
    start_time: datetime | None = None
    outcome_a_ask: float | None = None
    outcome_b_ask: float | None = None
    outcome_a_bid: float | None = None
    outcome_b_bid: float | None = None
    liquidity_at_best: float | None = None  # $ notional available at both best asks
    url: str = ""
    resolution_rules: str = ""
    updated_at: datetime | None = None

    # Extensions of the base format.
    tournament: str | None = None
    best_of: int | None = None
    market_type: str = "match_winner"
    line: float | None = None
    outcome_a_ask_size: float | None = None
    outcome_b_ask_size: float | None = None
    asks_a: list[Level] = Field(default_factory=list)
    asks_b: list[Level] = Field(default_factory=list)
    min_order_size: float = 0.0
    fee: FeeSpec = Field(default_factory=FeeSpec)
    is_live: bool = False
    accepting_orders: bool = True
    extra: dict[str, Any] = Field(default_factory=dict)

    @property
    def key(self) -> str:
        """Globally unique key: ``platform:market_id``."""
        return f"{self.platform}:{self.market_id}"

    def set_books(
        self,
        asks_a: list[Level],
        asks_b: list[Level],
        bid_a: float | None,
        bid_b: float | None,
        ts: datetime | None = None,
    ) -> None:
        """Replace both ask books and refresh the derived top-of-book fields."""
        self.asks_a = asks_a
        self.asks_b = asks_b
        self.outcome_a_ask = asks_a[0].price if asks_a else None
        self.outcome_b_ask = asks_b[0].price if asks_b else None
        self.outcome_a_ask_size = asks_a[0].size if asks_a else None
        self.outcome_b_ask_size = asks_b[0].size if asks_b else None
        self.outcome_a_bid = bid_a
        self.outcome_b_bid = bid_b
        if asks_a and asks_b:
            self.liquidity_at_best = round(
                asks_a[0].price * asks_a[0].size + asks_b[0].price * asks_b[0].size, 2
            )
        else:
            self.liquidity_at_best = None
        self.updated_at = ts or utcnow()

    def live_now(self, now: datetime | None = None) -> bool:
        """True when the platform says the match is live or its start time has passed."""
        if self.is_live:
            return True
        if self.start_time is None:
            return False
        return self.start_time <= (now or utcnow())


class RuleWarning(BaseModel):
    """One difference between the resolution rules of two matched markets."""

    field: str
    severity: Literal["high", "medium", "info"]
    message: str
    left: str | None = None
    right: str | None = None


class MatchedPair(BaseModel):
    """Two markets on different platforms that describe the same match."""

    pair_key: str
    game: str
    left_key: str
    right_key: str
    left_platform: str
    right_platform: str
    swapped: bool = False  # True when right.team_a is the same team as left.team_b
    confidence: float = 0.0  # 0..100
    status: Literal["auto", "review", "confirmed", "blocked"] = "auto"
    team_score: float = 0.0
    time_diff_minutes: float | None = None
    format_check: Literal["match", "unknown", "mismatch"] = "unknown"
    auto_eligible: bool = True  # False: may only be shown after manual review/confirmation
    reasons: list[str] = Field(default_factory=list)
    warnings: list[RuleWarning] = Field(default_factory=list)


class ArbLeg(BaseModel):
    """One side of an arbitrage: what to buy, where, and at what price."""

    platform: str
    platform_name: str
    market_id: str
    outcome: str  # team name as shown on that platform
    instrument: str | None = None
    ask: float  # best ask used
    avg_price: float | None = None  # volume-weighted price when several levels are swept
    size: float
    fee_usd: float = 0.0
    url: str = ""


class ArbOpportunity(BaseModel):
    """A detected arbitrage for one pair and one direction at one moment."""

    arb_id: str
    pair_key: str
    direction: str
    game: str
    event_title: str
    tournament: str | None = None
    team_a: str
    team_b: str
    start_time: datetime | None = None
    is_live: bool = False
    leg1: ArbLeg
    leg2: ArbLeg
    sum_ask: float
    fees_usd: float
    extra_costs_usd: float = 0.0
    cost_per_contract: float
    profit_pct: float
    contracts: float
    volume_usd: float
    profit_usd: float
    confidence: float = 0.0
    pair_status: str = "auto"
    warnings: list[RuleWarning] = Field(default_factory=list)
    detected_at: datetime = Field(default_factory=utcnow)


class TrackedArb(BaseModel):
    """An arbitrage that is being tracked over time (5-second confirmation rule)."""

    arb_id: str
    first_seen: datetime
    last_seen: datetime
    age_sec: float = 0.0
    confirmed: bool = False
    confirmed_at: datetime | None = None
    max_profit_pct: float = 0.0
    max_volume_usd: float = 0.0
    max_profit_usd: float = 0.0
    current: ArbOpportunity


class ClosedArb(BaseModel):
    """An arbitrage that disappeared; stored in the history table."""

    arb_id: str
    first_seen: datetime
    last_seen: datetime
    lifetime_sec: float
    confirmed: bool
    max_profit_pct: float
    max_volume_usd: float
    max_profit_usd: float
    last: ArbOpportunity
    # Значения колонок для честной статистики (``engine.capture``); None — данных нет.
    capture: dict[str, Any] | None = None


class PlatformStatus(BaseModel):
    """Connection health of one platform adapter, shown in the top bar."""

    platform: str
    name: str
    color: str = "#888888"
    mode: str = "rest"
    connected: bool = False
    last_update: datetime | None = None
    latency_ms: float | None = None
    markets: int = 0
    error: str | None = None
