"""FastAPI app: REST endpoints, a WebSocket push channel and the static dashboard."""

from __future__ import annotations

import asyncio
import logging
import sqlite3
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Awaitable, Callable

from fastapi import Body, FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from backend.adapters import build_adapters
from backend.adapters.base import MarketAdapter
from backend.config import PROJECT_DIR, Settings
from backend.engine.scanner import Scanner
from backend.net import describe_error
from backend.stats import MAX_DAYS, collect
from backend.storage.db import Database

log = logging.getLogger(__name__)

FRONTEND_DIR = PROJECT_DIR / "frontend"
LOOPBACK = {"127.0.0.1", "localhost", "::1", "[::1]"}
# A WebSocket that has nothing new to send still sends a heartbeat this often, so the dashboard can tell
# "nothing changed" (link alive) from "the link is dead" (no messages at all).
HEARTBEAT_SECONDS = 2.0


def allowed_hosts(settings: Settings) -> list[str]:
    """Host names accepted in the Host/Origin headers (the bind address is always allowed)."""
    hosts = list(dict.fromkeys(settings.server.allowed_hosts))
    if settings.server.host not in ("0.0.0.0", "::") and settings.server.host not in hosts:
        hosts.append(settings.server.host)
    return hosts


def origin_allowed(origin: str | None, hosts: list[str]) -> bool:
    """A browser Origin header must point at one of our own host names."""
    if not origin or "*" in hosts:
        return True
    from urllib.parse import urlparse

    host = (urlparse(origin).hostname or "").lower()
    for pattern in hosts:
        pattern = pattern.lower().strip("[]")
        if host == pattern or (pattern.startswith("*.") and host.endswith(pattern[1:])):
            return True
    return False


class StatsBuilds:
    """Report builds for ``/api/stats``: one at a time, and identical requests share the build that is running.

    Builds run on the default thread pool, like the scanner's database writes; parallel builds of a long period (a
    held arrow key, repeated refreshes) could take every thread and stall the scanner. With one build at a time and
    one task per (days, top), the queue is bounded by the number of different requests.
    """

    def __init__(self, build: Callable[[int, int], Awaitable[dict[str, Any]]]):
        self._build = build
        self._lock = asyncio.Lock()
        self._inflight: dict[tuple[int, int], asyncio.Task[dict[str, Any]]] = {}

    async def get(self, days: int, top: int) -> dict[str, Any]:
        key = (days, top)
        task = self._inflight.get(key)
        if task is None:
            task = asyncio.create_task(self._run(days, top))
            self._inflight[key] = task

            def forget(done: asyncio.Task[dict[str, Any]]) -> None:
                if self._inflight.get(key) is done:
                    del self._inflight[key]

            task.add_done_callback(forget)
        return await asyncio.shield(task)  # a request that goes away does not cancel the build for the others

    async def _run(self, days: int, top: int) -> dict[str, Any]:
        async with self._lock:
            return await self._build(days, top)


def create_app(settings: Settings, adapters: dict[str, MarketAdapter] | None = None) -> FastAPI:
    """Build the application. ``adapters`` can be injected (tests)."""

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        db = Database(settings.resolve_path(settings.storage.path))
        await db.connect()
        scanner = Scanner(settings, adapters if adapters is not None else build_adapters(settings), db)
        await scanner.start()
        app.state.scanner = scanner
        app.state.db = db
        try:
            yield
        finally:
            await scanner.stop()
            await db.close()

    app = FastAPI(title="Esports Arb Scanner", version="1.0.0", lifespan=lifespan)
    hosts = allowed_hosts(settings)

    @app.middleware("http")
    async def no_cache_frontend(request: Request, call_next: Any) -> Response:
        """Block cross-site writes and make browsers revalidate the static UI files."""
        if request.method not in ("GET", "HEAD", "OPTIONS") and not origin_allowed(request.headers.get("origin"), hosts):
            return JSONResponse({"detail": "cross-origin request rejected"}, status_code=403)
        response = await call_next(request)
        if not request.url.path.startswith("/api/"):
            response.headers.setdefault("Cache-Control", "no-cache")
        return response

    def scanner_of() -> Scanner:
        return app.state.scanner  # type: ignore[no-any-return]

    @app.get("/api/health")
    async def health() -> dict[str, Any]:
        scanner = scanner_of()
        return {"ok": True, "mock_mode": settings.mock_mode, "last_eval_at": scanner.snapshot()["last_eval_at"]}

    @app.get("/api/meta")
    async def meta() -> dict[str, Any]:
        return scanner_of().meta()

    @app.get("/api/state")
    async def state() -> dict[str, Any]:
        return scanner_of().snapshot()

    @app.get("/api/history")
    async def history(
        limit: int = Query(200, ge=1, le=2000),
        offset: int = Query(0, ge=0),
        game: str | None = None,
        confirmed_only: bool = False,
        min_profit_pct: float | None = None,
        since: str | None = None,
        before_first_seen: str | None = None,
        before_id: int | None = None,
    ) -> dict[str, Any]:
        before = (before_first_seen, before_id) if before_first_seen and before_id is not None else None
        return await app.state.db.list_history(
            limit=limit, offset=offset, game=game or None, confirmed_only=confirmed_only,
            min_profit_pct=min_profit_pct, since=since, before=before,
        )

    @app.get("/api/history/{item_id}")
    async def history_item(item_id: int) -> dict[str, Any]:
        """Одна строка истории со снимками стаканов при подтверждении и на пике (для разбора вилки)."""
        item = await app.state.db.get_history_item(item_id)
        if item is None:
            raise HTTPException(status_code=404, detail="no such history row")
        return item  # type: ignore[no-any-return]

    @app.get("/api/history.csv")
    async def history_csv(
        game: str | None = None,
        confirmed_only: bool = False,
        min_profit_pct: float | None = None,
        since: str | None = None,
    ) -> Response:
        text = await app.state.db.history_csv(
            game=game or None, confirmed_only=confirmed_only, min_profit_pct=min_profit_pct, since=since
        )
        return Response(
            content="\ufeff" + text,  # BOM so Excel opens UTF-8 correctly
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": 'attachment; filename="arb_history.csv"'},
        )

    async def build_stats(days: int, top: int) -> dict[str, Any]:
        """Read through a read-only connection of its own: WAL readers do not block the scanner's writes, and the
        scanner's connection (and its lock) stays free while a long period is read."""
        reader = Database(settings.resolve_path(settings.storage.path), read_only=True)
        try:
            await reader.connect()
        except (OSError, sqlite3.Error) as exc:  # e.g. an in-memory database: fall back to the scanner's connection
            log.warning("stats: read-only access failed (%s), using the scanner's connection", describe_error(exc))
            return await collect(app.state.db, settings, days, top=top)
        try:
            return await collect(reader, settings, days, top=top)
        finally:
            await reader.close()

    stats_builds = StatsBuilds(build_stats)

    @app.get("/api/stats")
    async def stats(
        days: int = Query(7, ge=1, le=MAX_DAYS),
        top: int = Query(10, ge=1, le=50),
    ) -> dict[str, Any]:
        """Report from the history: days in ``stats.timezone`` (Europe/Moscow by default)."""
        return await stats_builds.get(days, top)

    @app.post("/api/pairs/override")
    async def set_override(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        pair_key = str(payload.get("pair_key") or "")
        status = str(payload.get("status") or "")
        if not pair_key or "|" not in pair_key:
            raise HTTPException(400, "pair_key is required")
        scanner = scanner_of()
        if status in ("confirmed", "blocked"):
            await scanner.set_override(pair_key, status)
        elif status in ("", "clear", "none"):
            await scanner.clear_override(pair_key)
        else:
            raise HTTPException(400, "status must be confirmed, blocked or clear")
        return {"ok": True, "pair_key": pair_key, "status": status or "clear"}

    @app.get("/api/settings")
    async def get_settings() -> dict[str, Any]:
        return scanner_of().meta()["settings"]

    @app.put("/api/settings")
    async def put_settings(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        try:
            return await scanner_of().update_settings(payload)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.websocket("/ws")
    async def ws_state(websocket: WebSocket) -> None:
        if not origin_allowed(websocket.headers.get("origin"), hosts):
            await websocket.close(code=1008)
            return
        await websocket.accept()
        scanner = scanner_of()
        interval = max(0.2, settings.engine.broadcast_interval_ms / 1000)
        loop = asyncio.get_running_loop()
        last_version = -1
        last_sent = loop.time()
        try:
            await websocket.send_json({"type": "meta", "data": scanner.meta()})
            while True:
                snap = scanner.snapshot()
                if snap["version"] != last_version:
                    await websocket.send_json({"type": "state", "data": snap})
                    last_version = snap["version"]
                    last_sent = loop.time()
                elif loop.time() - last_sent >= HEARTBEAT_SECONDS:
                    # Small "still alive" message: the UI checks the link with it, and how old the last
                    # evaluation is (server_time - last_eval_at, both on the server clock).
                    beat = {key: snap[key] for key in ("version", "started_at", "server_time", "last_eval_at")}
                    await websocket.send_json({"type": "heartbeat", "data": beat})
                    last_sent = loop.time()
                await asyncio.sleep(interval)
                await scanner.wait_update(timeout=interval)
        except WebSocketDisconnect:
            return
        except (RuntimeError, ConnectionError) as exc:
            log.debug("websocket closed: %s", exc)

    @app.exception_handler(Exception)
    async def unhandled(_: Any, exc: Exception) -> JSONResponse:
        log.exception("unhandled API error")
        return JSONResponse({"detail": f"internal error: {exc}"}, status_code=500)

    if "*" not in hosts:
        # Host names are passed as configured: Starlette keeps the brackets of an IPv6 Host header ("[::1]").
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)

    if FRONTEND_DIR.exists():
        app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
    else:
        log.warning("frontend directory %s not found; only the API is served", FRONTEND_DIR)
    return app
