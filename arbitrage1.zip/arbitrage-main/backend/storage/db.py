"""SQLite storage: arbitrage history, scanner uptime, manual pair overrides and runtime settings.

The stdlib ``sqlite3`` module is used from a worker thread (``asyncio.to_thread``)
behind a lock, which is plenty for the low write rate of the scanner.
"""

from __future__ import annotations

import asyncio
import csv
import io
import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, TypeVar

from backend.models import ClosedArb, utcnow

T = TypeVar("T")

SCHEMA = """
CREATE TABLE IF NOT EXISTS arb_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    arb_id TEXT NOT NULL,
    pair_key TEXT NOT NULL,
    game TEXT,
    event_title TEXT,
    tournament TEXT,
    team_a TEXT,
    team_b TEXT,
    start_time TEXT,
    direction TEXT,
    leg1_platform TEXT,
    leg1_outcome TEXT,
    leg1_ask REAL,
    leg1_url TEXT,
    leg2_platform TEXT,
    leg2_outcome TEXT,
    leg2_ask REAL,
    leg2_url TEXT,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    lifetime_sec REAL NOT NULL,
    confirmed INTEGER NOT NULL,
    max_profit_pct REAL,
    max_volume_usd REAL,
    max_profit_usd REAL,
    last_profit_pct REAL,
    last_sum_ask REAL,
    warnings TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_arb_history_first_seen ON arb_history(first_seen);
CREATE INDEX IF NOT EXISTS idx_arb_history_game ON arb_history(game);

CREATE TABLE IF NOT EXISTS pair_overrides (
    pair_key TEXT PRIMARY KEY,
    status TEXT NOT NULL CHECK (status IN ('confirmed', 'blocked')),
    note TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Бумажная проверка: через N секунд после подтверждения оба стакана перечитаны отдельным запросом (engine.paper).
-- Связь с появлением вилки: arb_id + first_seen (как в arb_history).
CREATE TABLE IF NOT EXISTS paper_checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    arb_id TEXT NOT NULL,
    pair_key TEXT,
    direction TEXT,
    first_seen TEXT NOT NULL,
    confirmed_at TEXT NOT NULL,
    delay_sec REAL NOT NULL,          -- задержка по настройке (paper.delays_sec)
    actual_delay_sec REAL,            -- фактическая: от подтверждения до запроса
    checked_at TEXT NOT NULL,
    status TEXT NOT NULL,             -- ok | error | late | unsupported
    arb_exists INTEGER,               -- 1: вилка осталась, 0: нет, NULL: данных нет (status не ok)
    reason TEXT,                      -- почему вилки нет, или ошибка запроса
    profit_usd REAL,                  -- котировка движка по стаканам из запроса
    profit_pct REAL,
    volume_usd REAL,
    contracts REAL,
    optimal_stake_usd REAL,           -- весь выгодный объём (обход стакана) и прибыль на нём
    optimal_profit_usd REAL,
    stake_profits TEXT,               -- JSON: прибыль при ставках capture.stake_sizes_usd
    scanner_exists INTEGER,           -- то же по стакану сканера в тот же момент
    scanner_profit_usd REAL,
    scanner_volume_usd REAL,
    books_match INTEGER,              -- 1: лучшие цена и размер обеих ног совпали с запросом
    confirm_profit_usd REAL,
    confirm_volume_usd REAL,
    latency_ms REAL,
    details TEXT,                     -- JSON: стаканы покупаемых исходов из запроса и у сканера, возраст, ошибки
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_paper_checks_arb ON paper_checks(arb_id, first_seen);

-- One row per minute while the scanner runs: the report shows how long it ran and had fresh data.
CREATE TABLE IF NOT EXISTS scanner_uptime (
    minute INTEGER PRIMARY KEY,  -- Unix time // 60 (UTC)
    healthy INTEGER NOT NULL     -- 1: every platform had fresh data at every check in this minute
);
"""

# Колонки, добавленные к первой версии ``arb_history`` (ALTER TABLE ... ADD COLUMN при открытии базы). Старые строки
# не меняются: у них эти поля NULL (capture_version = 0) — «данных нет». Значения пишет ``engine.capture``.
ARB_HISTORY_ADDED_COLUMNS: list[tuple[str, str]] = [
    ("capture_version", "INTEGER NOT NULL DEFAULT 0"),  # 0: строка до этой версии, 1: этой версии (см. capture.py)
    ("phase", "TEXT DEFAULT NULL"),  # prematch | live по времени старта при first_seen
    ("minutes_to_start", "REAL DEFAULT NULL"),  # старт − first_seen, мин (отрицательные: после старта)
    ("confirmed_at", "TEXT DEFAULT NULL"),
    ("confirm_profit_usd", "REAL DEFAULT NULL"),  # котировка движка при подтверждении
    ("confirm_profit_pct", "REAL DEFAULT NULL"),
    ("confirm_volume_usd", "REAL DEFAULT NULL"),
    ("peak_at", "TEXT DEFAULT NULL"),  # момент максимума прибыли $
    ("peak_profit_usd", "REAL DEFAULT NULL"),  # прибыль, процент и объём того же момента
    ("peak_profit_pct", "REAL DEFAULT NULL"),
    ("peak_volume_usd", "REAL DEFAULT NULL"),
    ("optimal_stake_usd", "REAL DEFAULT NULL"),  # при подтверждении: весь выгодный объём с обходом стакана
    ("optimal_profit_usd", "REAL DEFAULT NULL"),
    ("optimal_profit_pct", "REAL DEFAULT NULL"),
    ("stake_profits", "TEXT DEFAULT NULL"),  # JSON: прибыль при ставках capture.stake_sizes_usd
    ("liquidity_flags", "TEXT DEFAULT NULL"),  # JSON: флаги подозрительной ликвидности ({} — флагов нет)
    ("confirm_snapshot", "TEXT DEFAULT NULL"),  # JSON: стаканы, возраст данных, комиссии при подтверждении
    ("peak_snapshot", "TEXT DEFAULT NULL"),  # JSON: то же на пике
]
CAPTURE_COLUMNS = [name for name, _ in ARB_HISTORY_ADDED_COLUMNS]
SNAPSHOT_COLUMNS = ("confirm_snapshot", "peak_snapshot")  # большие: не в страницах истории и не в CSV
JSON_COLUMNS = ("stake_profits", "liquidity_flags")

HISTORY_COLUMNS = [
    "id", "first_seen", "last_seen", "lifetime_sec", "confirmed", "game", "event_title",
    "tournament", "team_a", "team_b", "start_time", "direction",
    "leg1_platform", "leg1_outcome", "leg1_ask", "leg2_platform", "leg2_outcome", "leg2_ask",
    "last_sum_ask", "max_profit_pct", "max_volume_usd", "max_profit_usd", "last_profit_pct",
    "leg1_url", "leg2_url", "warnings", "pair_key", "arb_id",
    *(c for c in CAPTURE_COLUMNS if c not in SNAPSHOT_COLUMNS),
]


# Columns of confirmed arbs that the statistics report reads.
STATS_COLUMNS = [
    "id", "arb_id", "pair_key", "game", "event_title", "tournament", "team_a", "team_b", "leg1_platform",
    "leg2_platform", "start_time", "first_seen", "lifetime_sec", "max_profit_pct", "max_volume_usd", "max_profit_usd",
    "capture_version", "phase", "minutes_to_start", "confirmed_at", "confirm_profit_usd", "confirm_profit_pct",
    "confirm_volume_usd", "optimal_stake_usd", "optimal_profit_usd", "stake_profits", "liquidity_flags",
]


def migrate(conn: sqlite3.Connection) -> None:
    """Добавить недостающие колонки ``arb_history`` (без потери строк)."""
    for name, declaration in ARB_HISTORY_ADDED_COLUMNS:
        if name in table_columns(conn, "arb_history"):
            continue
        try:
            conn.execute(f"ALTER TABLE arb_history ADD COLUMN {name} {declaration}")
        except sqlite3.OperationalError:  # другой процесс добавил её в это же время
            if name not in table_columns(conn, "arb_history"):
                raise
    conn.commit()


def table_columns(conn: sqlite3.Connection, table: str) -> list[str]:
    """Имена колонок таблицы по порядку (пусто, если таблицы нет)."""
    return [row[1] for row in conn.execute(f"PRAGMA table_info({table})")]


def _parse_json_columns(item: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    """Разобрать JSON-колонки ``keys`` строки (битый JSON — None); вернуть ту же строку."""
    for key in keys:
        if item.get(key):
            try:
                item[key] = json.loads(item[key])
            except ValueError:
                item[key] = None
    return item


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


def _csv_cell(value: Any) -> Any:
    """Neutralise spreadsheet formulas in text that comes from external APIs."""
    if isinstance(value, str) and value[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + value
    return value


PAPER_COLUMNS = [
    "arb_id", "pair_key", "direction", "first_seen", "confirmed_at", "delay_sec", "actual_delay_sec", "checked_at",
    "status",
    "arb_exists", "reason", "profit_usd", "profit_pct", "volume_usd", "contracts", "optimal_stake_usd",
    "optimal_profit_usd", "stake_profits", "scanner_exists", "scanner_profit_usd", "scanner_volume_usd",
    "books_match", "confirm_profit_usd", "confirm_volume_usd", "latency_ms", "details",
]

_BASE_INSERT_COLUMNS = [
    "arb_id", "pair_key", "game", "event_title", "tournament", "team_a", "team_b", "start_time",
    "direction", "leg1_platform", "leg1_outcome", "leg1_ask", "leg1_url",
    "leg2_platform", "leg2_outcome", "leg2_ask", "leg2_url", "first_seen", "last_seen",
    "lifetime_sec", "confirmed", "max_profit_pct", "max_volume_usd", "max_profit_usd",
    "last_profit_pct", "last_sum_ask", "warnings", "created_at",
]


class Database:
    """Async facade over a single SQLite connection.

    ``read_only=True`` (the report command) opens an existing file without creating it or its tables, so it can read
    the history while the scanner writes to it.
    """

    def __init__(self, path: str | Path, read_only: bool = False):
        self.path = Path(path)
        self.read_only = read_only
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        """Open the database and create tables (read-only: open the existing file as it is)."""
        if self.read_only:
            if not self.path.is_file():
                raise FileNotFoundError(str(self.path))
        elif self.path != Path(":memory:"):
            self.path.parent.mkdir(parents=True, exist_ok=True)

        def _open() -> sqlite3.Connection:
            if self.read_only:
                try:
                    # absolute(), not resolve(): a mapped network drive must not turn into a UNC host name.
                    uri = f"{self.path.absolute().as_uri()}?mode=ro"
                    conn = sqlite3.connect(uri, uri=True, check_same_thread=False)
                except sqlite3.OperationalError:  # e.g. a UNC path: SQLite refuses a URI with a host name
                    conn = sqlite3.connect(str(self.path), check_same_thread=False)  # the file exists (checked)
                    conn.execute("PRAGMA query_only = ON")
            else:
                conn = sqlite3.connect(str(self.path), check_same_thread=False)
                conn.execute("PRAGMA journal_mode=WAL")
                conn.executescript(SCHEMA)
                conn.commit()
                migrate(conn)
            conn.row_factory = sqlite3.Row
            return conn

        self._conn = await asyncio.to_thread(_open)

    async def close(self) -> None:
        """Close the connection."""
        if self._conn is not None:
            conn, self._conn = self._conn, None
            await asyncio.to_thread(conn.close)

    async def _run(self, fn: Any, *args: Any) -> Any:
        if self._conn is None:
            raise RuntimeError("database is not connected")
        async with self._lock:
            return await asyncio.to_thread(fn, self._conn, *args)

    # ---- history ---------------------------------------------------------------------

    async def add_history(self, items: list[ClosedArb]) -> None:
        """Insert closed arbitrage records."""
        if not items:
            return
        rows = []
        now = utcnow().isoformat()
        for item in items:
            arb = item.last
            capture = {"capture_version": 0, **(item.capture or {})}  # NOT NULL: 0 — строка без новых данных
            rows.append(
                (
                    item.arb_id, arb.pair_key, arb.game, arb.event_title, arb.tournament,
                    arb.team_a, arb.team_b, _iso(arb.start_time), arb.direction,
                    arb.leg1.platform, arb.leg1.outcome, arb.leg1.ask, arb.leg1.url,
                    arb.leg2.platform, arb.leg2.outcome, arb.leg2.ask, arb.leg2.url,
                    _iso(item.first_seen), _iso(item.last_seen), item.lifetime_sec,
                    1 if item.confirmed else 0, item.max_profit_pct, item.max_volume_usd,
                    item.max_profit_usd, arb.profit_pct, arb.sum_ask,
                    json.dumps([w.message for w in arb.warnings], ensure_ascii=False), now,
                    *(capture.get(name) for name in CAPTURE_COLUMNS),
                )
            )
        columns = ", ".join([*_BASE_INSERT_COLUMNS, *CAPTURE_COLUMNS])
        marks = ",".join("?" * (len(_BASE_INSERT_COLUMNS) + len(CAPTURE_COLUMNS)))

        def _insert(conn: sqlite3.Connection) -> None:
            conn.executemany(f"INSERT INTO arb_history ({columns}) VALUES ({marks})", rows)
            conn.commit()

        await self._run(_insert)

    @staticmethod
    def _history_where(
        game: str | None, confirmed_only: bool, min_profit_pct: float | None, since: str | None
    ) -> tuple[str, list[Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if game:
            clauses.append("game = ?")
            params.append(game)
        if confirmed_only:
            clauses.append("confirmed = 1")
        if min_profit_pct is not None:
            clauses.append("max_profit_pct >= ?")
            params.append(min_profit_pct)
        if since:
            clauses.append("first_seen >= ?")
            params.append(since)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        return where, params

    async def list_history(
        self,
        limit: int = 200,
        offset: int = 0,
        game: str | None = None,
        confirmed_only: bool = False,
        min_profit_pct: float | None = None,
        since: str | None = None,
        before: tuple[str, int] | None = None,
    ) -> dict[str, Any]:
        """Page through the history (newest first).

        ``before`` = (first_seen, id) of the last row already shown: the next page continues right after
        it, so rows written meanwhile cannot shift the page the way an offset does.
        """
        where, params = self._history_where(game, confirmed_only, min_profit_pct, since)
        page_where, page_params = where, list(params)
        if before is not None:
            cursor = "(first_seen < ? OR (first_seen = ? AND id < ?))"
            page_where = f"{where} AND {cursor}" if where else f"WHERE {cursor}"
            page_params += [before[0], before[0], before[1]]

        def _query(conn: sqlite3.Connection) -> dict[str, Any]:
            total = conn.execute(f"SELECT COUNT(*) FROM arb_history {where}", params).fetchone()[0]
            # Без больших снимков стаканов: страница из 200 строк осталась бы лёгкой (снимки — get_history_item).
            columns = ", ".join(c for c in table_columns(conn, "arb_history") if c not in SNAPSHOT_COLUMNS)
            cur = conn.execute(
                f"SELECT {columns} FROM arb_history {page_where} ORDER BY first_seen DESC, id DESC LIMIT ? OFFSET ?",
                [*page_params, limit, offset],
            )
            return {"total": total, "items": [_history_item(row) for row in cur.fetchall()]}

        return await self._run(_query)

    async def get_history_item(self, item_id: int) -> dict[str, Any] | None:
        """Одна строка истории со всеми полями, включая снимки стаканов (JSON разобран); None — такой строки нет."""

        def _query(conn: sqlite3.Connection) -> dict[str, Any] | None:
            row = conn.execute("SELECT * FROM arb_history WHERE id = ?", (item_id,)).fetchone()
            if row is None:
                return None
            item = _history_item(row)
            item["paper_checks"] = query_paper_checks_of(conn, item["arb_id"], item["first_seen"])
            return item

        return await self._run(_query)

    async def add_paper_checks(self, rows: list[dict[str, Any]]) -> None:
        """Записать результаты бумажных проверок (``engine.paper``)."""
        if not rows:
            return
        now = utcnow().isoformat()
        values = [[row.get(c) for c in PAPER_COLUMNS] + [now] for row in rows]
        sql = (f"INSERT INTO paper_checks ({', '.join(PAPER_COLUMNS)}, created_at) "
               f"VALUES ({','.join('?' * (len(PAPER_COLUMNS) + 1))})")

        def _insert(conn: sqlite3.Connection) -> None:
            conn.executemany(sql, values)
            conn.commit()

        await self._run(_insert)

    async def history_csv(
        self,
        game: str | None = None,
        confirmed_only: bool = False,
        min_profit_pct: float | None = None,
        since: str | None = None,
        limit: int = 100_000,
    ) -> str:
        """Export the history as CSV text."""
        where, params = self._history_where(game, confirmed_only, min_profit_pct, since)

        def _query(conn: sqlite3.Connection) -> str:
            cur = conn.execute(
                f"SELECT {_select_list(conn, HISTORY_COLUMNS, '')} FROM arb_history {where} "
                "ORDER BY first_seen DESC LIMIT ?",
                [*params, limit],
            )
            buf = io.StringIO()
            writer = csv.writer(buf)
            writer.writerow(HISTORY_COLUMNS)
            for row in cur.fetchall():
                writer.writerow([_csv_cell(row[c]) for c in HISTORY_COLUMNS])
            return buf.getvalue()

        return await self._run(_query)

    # ---- statistics ------------------------------------------------------------------

    async def mark_uptime(self, at: datetime, healthy: bool) -> None:
        """Record that the scanner ran in the minute of ``at``. The minute keeps "healthy" only if every check had it."""
        minute = int(at.timestamp() // 60)

        def _upsert(conn: sqlite3.Connection) -> None:
            conn.execute(
                """INSERT INTO scanner_uptime (minute, healthy) VALUES (?, ?)
                   ON CONFLICT(minute) DO UPDATE SET healthy = MIN(healthy, excluded.healthy)""",
                (minute, 1 if healthy else 0),
            )
            conn.commit()

        await self._run(_upsert)

    async def read(self, fn: Callable[[sqlite3.Connection], T]) -> T:
        """Run ``fn(connection)`` in the worker thread inside one fresh read snapshot (all its queries agree).

        A transaction left open (for example by a failed write) would pin an old snapshot and hide newer rows, so it
        is ended first; the snapshot is always rolled back afterwards (a read keeps nothing).
        """

        def _snapshot(conn: sqlite3.Connection) -> T:
            if conn.in_transaction:
                conn.rollback()
            conn.execute("BEGIN")
            try:
                return fn(conn)
            finally:
                conn.rollback()

        return await self._run(_snapshot)  # type: ignore[no-any-return]

    # The four wrappers below are for tests and tools; ``backend.stats.collect`` calls the queries inside ``read``.

    async def stats_arbs(self, since: str, until: str) -> list[dict[str, Any]]:
        """Confirmed arbs with ``since <= first_seen < until`` (ISO times in UTC); see ``query_stats_arbs``."""
        return await self.read(lambda conn: [dict(row) for row in query_stats_arbs(conn, since, until)])

    async def stats_candidates(self, days: list[tuple[Any, str, str]]) -> dict[Any, int]:
        """Unconfirmed appearances per day; ``days`` = (label, start, end) with ISO times in UTC."""
        return await self.read(lambda conn: query_stats_candidates(conn, days))

    async def stats_uptime(self, days: list[tuple[Any, int, int]]) -> dict[Any, tuple[int, int]]:
        """(minutes the scanner ran, minutes with fresh data) per day; ``days`` = (label, start, end) in Unix minutes."""
        return await self.read(lambda conn: query_stats_uptime(conn, days))

    async def uptime_first_minute(self) -> int | None:
        """The first uptime row (Unix minute): uptime tracking started then. None: no rows or no table."""
        return await self.read(query_uptime_first_minute)

    # ---- overrides -------------------------------------------------------------------

    async def get_overrides(self) -> dict[str, str]:
        """All manual pair decisions: pair_key -> confirmed|blocked."""

        def _query(conn: sqlite3.Connection) -> dict[str, str]:
            return {r["pair_key"]: r["status"] for r in conn.execute("SELECT * FROM pair_overrides")}

        return await self._run(_query)

    async def set_override(self, pair_key: str, status: str, note: str | None = None) -> None:
        """Confirm or block a pair."""
        if status not in ("confirmed", "blocked"):
            raise ValueError("status must be 'confirmed' or 'blocked'")

        def _upsert(conn: sqlite3.Connection) -> None:
            conn.execute(
                """INSERT INTO pair_overrides (pair_key, status, note, updated_at) VALUES (?,?,?,?)
                   ON CONFLICT(pair_key) DO UPDATE SET status=excluded.status, note=excluded.note,
                   updated_at=excluded.updated_at""",
                (pair_key, status, note, utcnow().isoformat()),
            )
            conn.commit()

        await self._run(_upsert)

    async def clear_override(self, pair_key: str) -> None:
        """Remove a manual decision."""

        def _delete(conn: sqlite3.Connection) -> None:
            conn.execute("DELETE FROM pair_overrides WHERE pair_key = ?", (pair_key,))
            conn.commit()

        await self._run(_delete)

    # ---- settings --------------------------------------------------------------------

    async def get_settings(self) -> dict[str, Any]:
        """Runtime settings saved from the UI."""

        def _query(conn: sqlite3.Connection) -> dict[str, Any]:
            out: dict[str, Any] = {}
            for row in conn.execute("SELECT key, value FROM settings"):
                try:
                    out[row["key"]] = json.loads(row["value"])
                except ValueError:
                    continue
            return out

        return await self._run(_query)

    async def save_settings(self, values: dict[str, Any]) -> None:
        """Persist runtime settings."""
        now = utcnow().isoformat()

        def _upsert(conn: sqlite3.Connection) -> None:
            conn.executemany(
                """INSERT INTO settings (key, value, updated_at) VALUES (?,?,?)
                   ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                [(k, json.dumps(v), now) for k, v in values.items()],
            )
            conn.commit()

        await self._run(_upsert)



# ---- statistics queries -------------------------------------------------------------------------------
# Plain functions of a connection, so that ``backend.stats.collect`` can run all of them and build the report in one
# worker-thread call (``Database.read``) without blocking the event loop.


def _select_list(conn: sqlite3.Connection, columns: list[str], alias: str = "h") -> str:
    """SELECT-список колонок ``arb_history``; колонки, которых нет в базе старой версии, читаются как NULL."""
    have = table_columns(conn, "arb_history")
    prefix = f"{alias}." if alias else ""
    return ", ".join(f"{prefix}{c}" if c in have else f"NULL AS {c}" for c in columns)


def _history_item(row: sqlite3.Row) -> dict[str, Any]:
    item = dict(row)
    item["confirmed"] = bool(item["confirmed"])
    try:
        item["warnings"] = json.loads(item.get("warnings") or "[]")
    except ValueError:
        item["warnings"] = []
    return _parse_json_columns(item, (*JSON_COLUMNS, *SNAPSHOT_COLUMNS))


def _has_table(conn: sqlite3.Connection, name: str) -> bool:
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (name,)).fetchone() is not None


def query_stats_arbs(conn: sqlite3.Connection, since: str, until: str) -> sqlite3.Cursor:
    """Confirmed arbs with ``since <= first_seen < until`` (ISO times in UTC) as a cursor (rows are not kept in memory).

    ``minute_healthy`` is the uptime row of the minute in which the arb appeared: 1 = every platform had fresh data,
    0 = not, None = no row (the scanner did not track its uptime then).
    """
    columns = _select_list(conn, STATS_COLUMNS)  # база старой версии, открытая только на чтение: новых колонок нет
    where = "WHERE h.confirmed = 1 AND h.first_seen >= ? AND h.first_seen < ? ORDER BY h.first_seen, h.id"
    if _has_table(conn, "scanner_uptime"):
        # first_seen is stored as a UTC isoformat string (the scanner writes nothing else): its first 19 characters are
        # the UTC time without the fraction. strftime('%s', first_seen) would round .9995 s into the next second.
        sql = (
            f"SELECT {columns}, u.healthy AS minute_healthy FROM arb_history h LEFT JOIN scanner_uptime u "
            f"ON u.minute = CAST(strftime('%s', substr(h.first_seen, 1, 19)) AS INTEGER) / 60 {where}"
        )
    else:  # a database of an older version, opened read-only
        sql = f"SELECT {columns}, NULL AS minute_healthy FROM arb_history h {where}"
    return conn.execute(sql, (since, until))


def query_stats_candidates(conn: sqlite3.Connection, days: list[tuple[Any, str, str]]) -> dict[Any, int]:
    """Unconfirmed appearances per day; ``days`` = (label, start, end) with ISO times in UTC."""
    sql = "SELECT COUNT(*) FROM arb_history WHERE confirmed = 0 AND first_seen >= ? AND first_seen < ?"
    return {label: conn.execute(sql, (start, end)).fetchone()[0] for label, start, end in days}


def query_stats_uptime(conn: sqlite3.Connection, days: list[tuple[Any, int, int]]) -> dict[Any, tuple[int, int]]:
    """(minutes the scanner ran, minutes with fresh data) per day; ``days`` = (label, start, end) in Unix minutes."""
    if not _has_table(conn, "scanner_uptime"):
        return {}
    sql = "SELECT COUNT(*), COALESCE(SUM(healthy), 0) FROM scanner_uptime WHERE minute >= ? AND minute < ?"
    return {label: tuple(conn.execute(sql, (start, end)).fetchone()) for label, start, end in days}


def query_paper_checks_of(conn: sqlite3.Connection, arb_id: str, first_seen: str) -> list[dict[str, Any]]:
    """Бумажные проверки одного появления по задержке (JSON разобран); пусто — проверок нет (или нет таблицы)."""
    if not _has_table(conn, "paper_checks"):
        return []
    cur = conn.execute(
        "SELECT * FROM paper_checks WHERE arb_id = ? AND first_seen = ? ORDER BY delay_sec, id", (arb_id, first_seen)
    )
    return [_parse_json_columns(dict(row), ("stake_profits", "details")) for row in cur.fetchall()]


PAPER_STATS_COLUMNS = [
    "arb_id", "first_seen", "delay_sec", "status", "arb_exists", "profit_usd", "volume_usd", "stake_profits",
    "optimal_stake_usd", "optimal_profit_usd", "books_match",
]


def query_stats_paper(conn: sqlite3.Connection, since: str, until: str) -> list[sqlite3.Row]:
    """Бумажные проверки появлений с ``since <= first_seen < until`` (отчёт связывает их с историей по arb_id +
    first_seen). Пусто — проверок нет или база старой версии без таблицы."""
    if not _has_table(conn, "paper_checks"):
        return []
    sql = (f"SELECT {', '.join(PAPER_STATS_COLUMNS)} FROM paper_checks WHERE first_seen >= ? AND first_seen < ? "
           "ORDER BY first_seen, delay_sec, id")
    return conn.execute(sql, (since, until)).fetchall()


def query_uptime_first_minute(conn: sqlite3.Connection) -> int | None:
    """The first uptime row (Unix minute). None: no rows, or no table (an older database)."""
    if not _has_table(conn, "scanner_uptime"):
        return None
    return conn.execute("SELECT MIN(minute) FROM scanner_uptime").fetchone()[0]
