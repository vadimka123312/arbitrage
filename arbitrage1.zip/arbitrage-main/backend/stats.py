"""Statistics from the SQLite history: arbs per day, profit, lifetime, games, platform pairs and matches.

Used by ``report.py`` (console report) and ``GET /api/stats`` (the "Статистика" tab). Days are counted in the
time zone ``stats.timezone`` of the config (Europe/Moscow by default).

Units of the report:

- an *arb* is one confirmed appearance: one history row with ``confirmed = 1``, the same as one "ARB confirmed" log
  line. The same pair and direction can disappear and appear again; every appearance counts;
- *distinct arbs* count each pair + direction (``arb_id``) once;
- *profit $* is the sum of the maximum profit of every appearance, after fees. It is an upper estimate: nobody catches
  every arb at its best moment with the full volume. ``profit_usd_distinct`` counts each arb once per day (its best
  appearance);
- *run hours* and *data hours* come from ``scanner_uptime`` (one row per minute while the scanner runs). Data hours
  are minutes in which every platform had fresh data at every check. The first row marks when tracking started:
  days before it have unknown hours (``None``), not zero hours;
- *per 24 h*: appearances in minutes with fresh data divided by the number of those minutes, times 1440; shown from
  24 hours of such minutes on (``RATE_MIN_DATA_MINUTES``).

The report is built inside the database worker thread (``collect``): the rows of the period are read once from a cursor
into compact per-appearance records (``honest_stats.ArbRecord``), which the honest metrics need several times (phases,
outliers, the bankroll simulation in time order).
"""

from __future__ import annotations

import statistics
from bisect import bisect_right
from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Iterable, Mapping
from zoneinfo import ZoneInfo

from backend import honest_stats as hs_mod
from backend.storage.db import (
    query_stats_arbs, query_stats_candidates, query_stats_paper, query_stats_uptime, query_uptime_first_minute,
)

if TYPE_CHECKING:
    import sqlite3

    from backend.config import Settings
    from backend.storage.db import Database

MAX_DAYS = 366
TOURNAMENTS_MAX = 50  # турниров в отчёте (JSON); всего — tournaments_total
# The rate per 24 h needs a whole day of minutes with fresh data: matches (and arbs) are not spread evenly over a day.
RATE_MIN_DATA_MINUTES = 24 * 60

# (label, lower bound, upper bound) in seconds; the upper bound is exclusive, None = no limit.
LIFETIME_BUCKETS: list[tuple[str, float, float | None]] = [
    ("до 15 с", 0, 15),
    ("15–30 с", 15, 30),
    ("30–60 с", 30, 60),
    ("1–5 мин", 60, 300),
    ("больше 5 мин", 300, None),
]

WEEKDAYS = ("пн", "вт", "ср", "чт", "пт", "сб", "вс")


@dataclass(frozen=True)
class Day:
    """One local calendar day of the report and its bounds in UTC (end exclusive)."""

    day: date
    start: datetime
    end: datetime

    @property
    def start_minute(self) -> int:
        return int(self.start.timestamp() // 60)

    @property
    def end_minute(self) -> int:
        return int(self.end.timestamp() // 60)


def period_days(tz: ZoneInfo, days: int, now: datetime) -> list[Day]:
    """The last ``days`` local days up to and including today, oldest first."""
    if not 1 <= days <= MAX_DAYS:
        raise ValueError(f"days must be between 1 and {MAX_DAYS}")
    today = now.astimezone(tz).date()
    out = []
    for back in range(days - 1, -1, -1):
        day = today - timedelta(days=back)
        start = datetime.combine(day, time(0), tzinfo=tz).astimezone(timezone.utc)
        end = datetime.combine(day + timedelta(days=1), time(0), tzinfo=tz).astimezone(timezone.utc)
        out.append(Day(day, start, end))
    return out


def _median(values: list[float]) -> float | None:
    return statistics.median(values) if values else None


def _round(value: float | None, digits: int) -> float | None:
    return None if value is None else round(value, digits)


def _hours(minutes: int | None) -> float | None:
    return None if minutes is None else round(minutes / 60, 2)


class _Group:
    """Running figures of a set of confirmed appearances."""

    __slots__ = ("arbs", "arb_ids", "profit", "trimmed", "confirm", "confirm_arbs", "best_pct", "lifetime_sum",
                 "arbs_list")

    def __init__(self) -> None:
        self.arbs = 0
        self.arb_ids: set[str] = set()
        self.profit = 0.0
        self.trimmed = 0.0  # без выбросов (stats.exclude_top_n)
        self.confirm = 0.0
        self.confirm_arbs = 0
        self.best_pct: float | None = None
        self.lifetime_sum = 0.0
        self.arbs_list: list[hs_mod.ArbRecord] = []

    def add(self, arb: hs_mod.ArbRecord) -> None:
        self.arbs += 1
        self.arb_ids.add(arb.arb_id)
        self.profit += arb.profit
        if not arb.outlier:
            self.trimmed += arb.profit
        if arb.captured:
            self.confirm += arb.confirm_profit or 0.0
            self.confirm_arbs += 1
        self.best_pct = arb.pct if self.best_pct is None else max(self.best_pct, arb.pct)
        self.lifetime_sum += arb.lifetime
        self.arbs_list.append(arb)

    def view(self) -> dict[str, Any]:
        return {
            "arbs": self.arbs,
            "distinct_arbs": len(self.arb_ids),
            "profit_usd": round(self.profit, 2),
            "profit_trimmed_usd": round(self.trimmed, 2),
            "confirm_profit_usd": round(self.confirm, 2) if self.confirm_arbs else None,
            "confirm_arbs": self.confirm_arbs,
            "median_profit_usd": _round(_median([a.profit for a in self.arbs_list]), 2),
            "best_profit_pct": _round(self.best_pct, 3),
            "median_lifetime_sec": _round(_median([a.lifetime for a in self.arbs_list]), 1),
        }


def _group_of(groups: dict[Any, _Group], key: Any) -> _Group:
    group = groups.get(key)
    if group is None:
        group = groups[key] = _Group()
    return group


def _field(row: Mapping[str, Any], key: str) -> Any:
    """A column that may be absent (``minute_healthy`` in rows built by hand)."""
    try:
        return row[key]
    except (KeyError, IndexError):
        return None


def count_matches(pair_keys: Iterable[str]) -> int:
    """Distinct matches among pair keys (``platform:market|platform:market``): pairs that share a market are one match.

    With two platforms every pair key is its own match. With three, one match can have up to three pairs
    (Polymarket ↔ Kalshi, Polymarket ↔ Stake, Kalshi ↔ Stake); they are joined through their common markets.
    """
    parent: dict[str, str] = {}

    def root(key: str) -> str:
        while parent.get(key, key) != key:
            key = parent[key]
        return key

    for pair_key in pair_keys:
        markets = pair_key.split("|")
        for market in markets:
            parent.setdefault(market, market)
        first = root(markets[0])
        for market in markets[1:]:
            other = root(market)
            if other != first:
                parent[other] = first
    return sum(1 for key in parent if root(key) == key)


def _platforms_key(legs: tuple[str | None, str | None], order: list[str]) -> tuple[str, ...]:
    """Both leg platforms in config order (a pair of venues does not depend on the leg order)."""
    found = {p for p in legs if p}
    return tuple(sorted(found, key=lambda p: (order.index(p) if p in order else len(order), p)))


@dataclass(frozen=True)
class HonestSettings:
    """Параметры честных метрик (``stats.*``, ``capture.large_volume_usd``, ``paper.delays_sec``)."""

    exclude_top_n: int = 10
    bankroll_usd: float = 1000.0
    max_stake_per_arb_usd: float = 100.0
    settle_hours: float = 3.0
    large_volume_usd: float = 1000.0
    paper_delays_sec: tuple[float, ...] = (5.0, 15.0, 60.0)
    paper_enabled: bool = True

    @classmethod
    def of(cls, settings: Settings) -> HonestSettings:
        st = settings.stats
        return cls(
            exclude_top_n=st.exclude_top_n, bankroll_usd=st.bankroll_usd, max_stake_per_arb_usd=st.max_stake_per_arb_usd,
            settle_hours=st.settle_hours, large_volume_usd=settings.capture.large_volume_usd,
            paper_delays_sec=tuple(settings.paper.delays_sec), paper_enabled=settings.paper.enabled,
        )


def build_report(
    rows: Iterable[Mapping[str, Any]],
    candidates: dict[date, int],
    uptime: dict[date, tuple[int, int]],
    days: list[Day],
    *,
    tracking_since: datetime | None,
    tz_name: str,
    now: datetime,
    platform_names: dict[str, str],
    game_names: dict[str, str],
    confirm_seconds: float,
    top: int = 10,
    paper: Iterable[Mapping[str, Any]] | None = None,
    honest: HonestSettings | None = None,
) -> dict[str, Any]:
    """Build the report (a JSON-ready dict) from the confirmed history rows of the period.

    ``rows``: mappings with ``STATS_COLUMNS`` (columns of newer versions may be absent) and optionally
    ``minute_healthy`` (a database cursor works). ``candidates``: unconfirmed appearances per local day. ``uptime``:
    (run minutes, data minutes) per local day. ``tracking_since``: the first uptime row (None: no rows). ``paper``:
    paper-check rows (``PAPER_STATS_COLUMNS``) of the period.
    """
    hs = honest or HonestSettings()
    tz = ZoneInfo(tz_name)
    order = list(platform_names)
    # Day of a row: its first_seen is a UTC isoformat string ("…+00:00"), so it can be compared with the day bounds as
    # a string (bisect), without a time-zone conversion per row. Other offsets are parsed.
    starts = [d.start.isoformat() for d in days]
    until = days[-1].end.isoformat()
    venue_keys: dict[tuple[str | None, str | None], tuple[str, ...]] = {}
    records: list[hs_mod.ArbRecord] = []
    for index_row, row in enumerate(rows):
        first_seen = row["first_seen"]
        if first_seen.endswith("+00:00"):
            index = bisect_right(starts, first_seen) - 1
            if index < 0 or first_seen >= until:
                continue
            local_day = days[index].day
        else:
            parsed = hs_mod.parse_utc(first_seen)  # without an offset: UTC, as the scanner writes it
            if parsed is None:
                continue
            local_day = parsed.astimezone(tz).date()
            if not days[0].day <= local_day <= days[-1].day:
                continue
        legs = (row["leg1_platform"], row["leg2_platform"])
        venue = venue_keys.get(legs)
        if venue is None:
            venue = venue_keys[legs] = _platforms_key(legs, order)
        rid = _field(row, "id")
        records.append(hs_mod.make_record(
            row, rid=int(rid) if rid is not None else index_row, day=local_day, venue=venue,
            healthy=_field(row, "minute_healthy") == 1, confirm_seconds=confirm_seconds,
            large_volume_usd=hs.large_volume_usd,
        ))
    # Задержки проверок: из настройки и те, что есть в истории (настройку могли поменять).
    delays = sorted(set(hs.paper_delays_sec) | set(hs_mod.attach_paper(records, paper or [])))
    outliers = hs_mod.mark_outliers(records, hs.exclude_top_n)

    total = _Group()
    per_day: dict[date, _Group] = {}
    games: dict[str, _Group] = {}
    venues: dict[tuple[str, ...], _Group] = {}
    pairs: dict[str, _Group] = {}
    latest: dict[str, hs_mod.ArbRecord] = {}  # per pair: its newest appearance
    best_of_day: dict[tuple[date, str], float] = {}  # (day, arb) -> the best appearance of that day
    distinct_healthy: set[tuple[date, str]] = set()
    matches: set[str] = set()
    best: hs_mod.ArbRecord | None = None
    rate_arbs, rate_profit = 0, 0.0  # appearances in minutes with fresh data
    for arb in records:
        for group in (
            total,
            _group_of(per_day, arb.day),
            _group_of(games, arb.game or ""),
            _group_of(venues, arb.venue),
            _group_of(pairs, arb.pair_key),
        ):
            group.add(arb)
        matches.add(arb.pair_key)
        key = (arb.day, arb.arb_id)
        best_of_day[key] = max(best_of_day.get(key, 0.0), arb.profit)
        if best is None or arb.profit > best.profit:
            best = arb
        newest = latest.get(arb.pair_key)
        if newest is None or arb.first_seen >= newest.first_seen:
            latest[arb.pair_key] = arb
        if arb.healthy:
            rate_arbs += 1
            rate_profit += arb.profit
            distinct_healthy.add(key)

    def known(d: Day) -> bool:
        """Hours of this day are known: tracking had started, and arbs of the day do not lack uptime rows."""
        if tracking_since is None or d.end <= tracking_since:
            return False
        return uptime.get(d.day, (0, 0))[0] > 0 or not (d.day in per_day or candidates.get(d.day))

    def minutes(d: Day, index: int) -> int | None:
        return uptime.get(d.day, (0, 0))[index] if known(d) else None

    def venue_label(key: tuple[str, ...]) -> str:
        return " ↔ ".join(platform_names.get(p, p) for p in key) or "—"

    def game_name(game: str | None) -> str:
        return game_names.get(game, game) if game else "—"

    distinct_of_day: dict[date, float] = {}
    for (day, _), value in best_of_day.items():
        distinct_of_day[day] = distinct_of_day.get(day, 0.0) + value

    by_day = []
    for d in days:
        by_day.append({
            "date": d.day.isoformat(),
            "weekday": WEEKDAYS[d.day.weekday()],
            "run_hours": _hours(minutes(d, 0)),
            "data_hours": _hours(minutes(d, 1)),
            "run_minutes": minutes(d, 0),
            "data_minutes": minutes(d, 1),
            **(per_day.get(d.day) or _Group()).view(),
            "profit_usd_distinct": round(distinct_of_day.get(d.day, 0.0), 2),
            "candidates": candidates.get(d.day, 0),
        })

    lifetimes = [a.lifetime for a in records]
    buckets = []
    for label, low, high in LIFETIME_BUCKETS:
        count = sum(1 for s in lifetimes if s >= low and (high is None or s < high))
        buckets.append({"label": label, "min_sec": low, "max_sec": high, "count": count})

    known_days = [d for d in days if known(d)]
    run_minutes = sum(minutes(d, 0) for d in known_days) if known_days else None
    data_minutes = sum(minutes(d, 1) for d in known_days) if known_days else None
    # Like with like: appearances in minutes with fresh data, divided by those minutes. A whole day of such minutes at
    # least, because matches (and arbs) are not spread evenly over the day.
    per_24h = None
    if (data_minutes or 0) >= RATE_MIN_DATA_MINUTES:
        per_24h = {
            "arbs": round(rate_arbs / data_minutes * 1440, 2),
            "profit_usd": round(rate_profit / data_minutes * 1440, 2),
            # Уникальные возможности: каждая вилка (пара + направление) один раз за день.
            "distinct_arbs": round(len(distinct_healthy) / data_minutes * 1440, 2),
        }

    cap = hs.max_stake_per_arb_usd
    # Один общий пул на все вилки; по фазам — доли той же симуляции (суммы фаз равны итогу).
    bankroll = hs_mod.simulate_bankroll(records, hs.bankroll_usd, cap, hs.settle_hours, group_of=lambda a: a.phase)
    by_phase_bankroll = bankroll.pop("by_group") if bankroll else {}
    honest_total = {
        **hs_mod.profit_block(records),
        "capped": hs_mod.capped_profit(records, cap),
        "bankroll": bankroll,
        "paper": hs_mod.paper_block(records, delays, cap),
        "flags": hs_mod.flag_counts(records),
    }
    totals = {
        **total.view(),
        "matches": count_matches(matches),
        "candidates": sum(candidates.get(d.day, 0) for d in days),
        "profit_usd_distinct": round(sum(best_of_day.values()), 2),
        "best_profit_usd": round(best.profit, 2) if best else None,
        "best_profit_usd_pct": _round(best.pct, 3) if best else None,
        "median_profit_usd": _round(_median([a.profit for a in records]), 2),
        "median_profit_pct": _round(_median([a.pct for a in records]), 3),
        "median_volume_usd": _round(_median([a.volume for a in records]), 2),
        "max_lifetime_sec": _round(max(lifetimes), 1) if lifetimes else None,
        "share_30s": hs_mod.share_at_least(lifetimes, 30),
        "share_60s": hs_mod.share_at_least(lifetimes, 60),
        "run_hours": _hours(run_minutes),
        "data_hours": _hours(data_minutes),
        "run_minutes": run_minutes,
        "data_minutes": data_minutes,
        "per_24h": per_24h,
        "rate_min_data_hours": RATE_MIN_DATA_MINUTES // 60,
        "captured_arbs": sum(1 for a in records if a.captured),
        "derived_phase_arbs": sum(1 for a in records if a.phase_derived),
        "honest": honest_total,
    }

    phases = []
    for phase, label in hs_mod.PHASES:
        group = [a for a in records if a.phase == phase]
        if not group and phase == "unknown":
            continue
        phases.append({
            "phase": phase,
            "label": label,
            **hs_mod.phase_summary(group),
            **hs_mod.profit_block(group, total.profit),
            "capped": hs_mod.capped_profit(group, cap),
            "bankroll": hs_mod.bankroll_share(by_phase_bankroll, phase) if bankroll else None,
            "paper": hs_mod.paper_block(group, delays, cap),
            "flags": hs_mod.flag_counts(group),
        })

    by_game = [{"game": game or None, "name": game_name(game), **g.view()} for game, g in games.items()]
    by_game.sort(key=lambda g: (-g["profit_usd"], -g["arbs"], g["name"]))

    by_platforms = [{"platforms": list(key), "label": venue_label(key), **g.view()} for key, g in venues.items()]
    by_platforms.sort(key=lambda v: (-v["profit_usd"], -v["arbs"], v["label"]))

    tournaments: dict[str, list[hs_mod.ArbRecord]] = {}
    for arb in records:
        tournaments.setdefault(arb.tournament or "", []).append(arb)
    by_tournament = []
    for name, group in tournaments.items():
        block = hs_mod.profit_block(group, total.profit)
        by_tournament.append({
            "tournament": name or None,
            "arbs": len(group),
            "distinct_arbs": len({a.arb_id for a in group}),
            "matches": count_matches(a.pair_key for a in group),
            "prematch_arbs": sum(1 for a in group if a.phase == "prematch"),
            "live_arbs": sum(1 for a in group if a.phase == "live"),
            "games": sorted({game_name(a.game) for a in group}),
            **block,
            "max_volume_usd": round(max(a.volume for a in group), 2),
            "median_volume_usd": _round(_median([a.volume for a in group]), 2),
        })
    by_tournament.sort(key=lambda t: (-t["profit_usd"], -t["arbs"], t["tournament"] or ""))
    tournaments_total = len(by_tournament)

    top_pairs = []
    for pair_key, g in pairs.items():
        info = latest[pair_key]
        top_pairs.append({
            "pair_key": pair_key,
            "game": info.game,
            "game_name": game_name(info.game),
            "team_a": info.team_a,
            "team_b": info.team_b,
            "event_title": info.event_title,
            "tournament": info.tournament,
            "platforms_label": venue_label(info.venue),
            "last_arb_at": info.first_seen,
            "total_lifetime_sec": round(g.lifetime_sum, 1),
            "phases": {phase: sum(1 for a in g.arbs_list if a.phase == phase) for phase, _ in hs_mod.PHASES},
            "max_volume_usd": round(max(a.volume for a in g.arbs_list), 2),
            "flags": hs_mod.flag_counts(g.arbs_list),
            **g.view(),
        })
    top_pairs.sort(key=lambda p: p["last_arb_at"], reverse=True)  # ties: the newest first
    top_pairs.sort(key=lambda p: (-p["profit_usd"], -p["arbs"]))

    return {
        "generated_at": now.astimezone(timezone.utc).isoformat(),
        "timezone": tz_name,
        "days": len(days),
        "period": {
            "from": days[0].day.isoformat(),
            "to": days[-1].day.isoformat(),
            "since": days[0].start.isoformat(),
            "until": days[-1].end.isoformat(),
        },
        "confirm_seconds": confirm_seconds,
        "settings": {**asdict(hs), "paper_delays_sec": delays},
        "uptime_tracked": tracking_since is not None,
        "uptime_since": tracking_since.isoformat() if tracking_since else None,
        "totals": totals,
        "phases": phases,
        "outliers": [_outlier_view(a, venue_label, game_name) for a in outliers],
        "by_day": by_day,
        "lifetime_buckets": buckets,
        "by_game": by_game,
        "by_platforms": by_platforms,
        "by_tournament": by_tournament[:TOURNAMENTS_MAX],
        "tournaments_total": tournaments_total,
        "top_pairs": top_pairs[:top],
        "pairs_total": len(top_pairs),
    }


def _outlier_view(a: hs_mod.ArbRecord, venue_label: Any, game_name: Any) -> dict[str, Any]:
    return {
        "first_seen": a.first_seen,
        "team_a": a.team_a,
        "team_b": a.team_b,
        "tournament": a.tournament,
        "game_name": game_name(a.game),
        "platforms_label": venue_label(a.venue),
        "phase": a.phase,
        "phase_derived": a.phase_derived,
        "lifetime_sec": round(a.lifetime, 1),
        "volume_usd": round(a.volume, 2),
        "profit_usd": round(a.profit, 2),
        "profit_pct": round(a.pct, 3),
        "confirm_profit_usd": a.confirm_profit,
        "large_volume": a.large,
        "flags": sorted(a.flags) if a.flags is not None else None,
    }


async def collect(
    db: Database,
    settings: Settings,
    days: int = 7,
    *,
    now: datetime | None = None,
    tz_name: str | None = None,
    top: int = 10,
) -> dict[str, Any]:
    """Read the period and build the report in one worker-thread call (the event loop is not blocked).

    Pass a read-only ``Database`` of its own where possible: the scanner's connection would be locked meanwhile.
    """
    tz_name = tz_name or settings.stats.timezone
    now = now or datetime.now(timezone.utc)
    period = period_days(ZoneInfo(tz_name), days, now)
    platform_names = {p: cfg.name for p, cfg in settings.platforms.items()}
    game_names = {g: cfg.short or cfg.name for g, cfg in settings.games.items()}
    confirm_seconds = settings.engine.confirm_seconds
    honest = HonestSettings.of(settings)

    def compute(conn: sqlite3.Connection) -> dict[str, Any]:
        candidates = query_stats_candidates(conn, [(d.day, d.start.isoformat(), d.end.isoformat()) for d in period])
        first_minute = query_uptime_first_minute(conn)
        tracking_since, uptime = None, {}
        if first_minute is not None:  # None: no uptime rows yet, or an older database without the table
            tracking_since = datetime.fromtimestamp(first_minute * 60, timezone.utc)
            uptime = query_stats_uptime(conn, [(d.day, d.start_minute, d.end_minute) for d in period])
        since, until = period[0].start.isoformat(), period[-1].end.isoformat()
        paper = query_stats_paper(conn, since, until)
        rows = query_stats_arbs(conn, since, until)
        return build_report(
            rows, candidates, uptime, period, tracking_since=tracking_since, tz_name=tz_name, now=now,
            platform_names=platform_names, game_names=game_names, confirm_seconds=confirm_seconds, top=top,
            paper=paper, honest=honest,
        )

    return await db.read(compute)


# ---- console text ------------------------------------------------------------------------------


def fmt_num(value: float | None, digits: int = 2) -> str:
    """Number with a decimal comma (as in the dashboard); None -> '—'."""
    if value is None:
        return "—"
    return f"{value:,.{digits}f}".replace(",", " ").replace(".", ",")


def fmt_duration(seconds: float | None) -> str:
    """45 с, 3 мин 05 с, 2 ч 07 мин."""
    if seconds is None:
        return "—"
    total = int(round(seconds))
    if total < 60:
        return f"{total} с"
    if total < 3600:
        return f"{total // 60} мин {total % 60:02d} с"
    return f"{total // 3600} ч {total % 3600 // 60:02d} мин"


def fmt_minutes(value: int | None) -> str:
    """12 мин, 34 ч 05 мин."""
    if value is None:
        return "—"
    return f"{value} мин" if value < 60 else f"{value // 60} ч {value % 60:02d} мин"


def fmt_hours(value: float | None) -> str:
    """Hours with one decimal; a few minutes show as "<0,1" instead of a misleading 0,0."""
    if value is not None and 0 < value < 0.05:
        return "<0,1"
    return fmt_num(value, 1)


def fmt_seconds(value: float) -> str:
    """5 or 2,5 (a threshold set in the UI can have a fraction)."""
    return fmt_num(value, 0 if float(value).is_integer() else 1)


def fmt_pct(value: float | None) -> str:
    return "—" if value is None else f"{fmt_num(value, 2)} %"


def _table(headers: list[str], rows: list[list[str]], left: int = 1) -> list[str]:
    """Plain-text table: the first ``left`` columns are left-aligned, the rest right-aligned."""
    widths = [max(map(len, column)) for column in zip(headers, *rows)]

    def line(cells: list[str]) -> str:
        parts = [c.ljust(w) if i < left else c.rjust(w) for i, (c, w) in enumerate(zip(cells, widths))]
        return "  " + "  ".join(parts).rstrip()

    return [line(headers), *(line(r) for r in rows)]


def uptime_note(report: dict[str, Any]) -> str:
    """Why some hours are unknown or partial ("" when every day of the period is fully known)."""
    if not report["uptime_tracked"]:
        return ""
    since = datetime.fromisoformat(report["uptime_since"])
    if since > datetime.fromisoformat(report["period"]["since"]):
        local = since.astimezone(ZoneInfo(report["timezone"]))
        return f"Время работы записывается с {local.strftime('%d.%m.%Y %H:%M')}: до этого часы неизвестны («—») или неполные."
    if any(d["run_hours"] is None for d in report["by_day"]):
        return "Для дней с «—» время работы неизвестно: в эти дни есть вилки, но нет отметок времени работы."
    return ""


NO_DATA = "данных нет"


def fmt_usd(value: float | None) -> str:
    return "—" if value is None else f"{fmt_num(value)} $"


def fmt_share(value: float | None) -> str:
    return "—" if value is None else f"{fmt_num(value * 100, 0)} %"


def _spread_text(spread: dict[str, Any] | None) -> str:
    """медиана …, p75 …, p90 …, максимум …"""
    if not spread:
        return "—"
    return (f"медиана {fmt_num(spread['p50'])}, p75 {fmt_num(spread['p75'])}, p90 {fmt_num(spread['p90'])}, "
            f"максимум {fmt_num(spread['max'])}")


def flags_text(flags: dict[str, int] | None, arbs: int | None = None) -> str:
    """Флаги подозрительной ликвидности для таблиц: «большой объём ×1, скачок ×2, нет снимков ×3»."""
    if not flags:
        return ""
    parts = []
    for key, label in (("large_volume", "большой объём"), ("size_jump", "скачок размера"),
                       ("stale_data", "устаревшие данные")):
        if flags.get(key):
            parts.append(f"{label} ×{flags[key]}")
    if flags.get("no_data"):
        parts.append("нет снимков" if arbs is not None and flags["no_data"] >= arbs else f"нет снимков ×{flags['no_data']}")
    return ", ".join(parts)


def _confirm_text(block: dict[str, Any]) -> str:
    """Прибыль при подтверждении группы: «—» (вилок нет), «данных нет» или сумма с «(у K из N)», если известна не у всех."""
    arbs, known = block.get("arbs") or 0, block.get("confirm_arbs") or 0
    if not arbs:
        return "—"
    if not known:
        return NO_DATA
    text = fmt_usd(block["confirm_profit_usd"])
    return text + (f" (у {known} из {arbs})" if known < arbs else "")


def _capped_text(capped: dict[str, Any] | None) -> str:
    if not capped:
        return "—"
    text = fmt_usd(capped["profit_usd"])
    if capped["estimated_arbs"]:
        text += "*" if capped["exact_arbs"] else "**"
    return text


def _paper_text(item: dict[str, Any]) -> str:
    if not item["checked"]:
        return f"без данных у {item['errors']}" if item["errors"] else NO_DATA
    return f"{item['left']} из {item['checked']} ({fmt_share(item['share_left'])})"


def format_text(report: dict[str, Any], db_path: Path | str | None = None) -> str:
    """Readable Russian report for the console."""
    t = report["totals"]
    h = t.get("honest") or {}
    cfg = report.get("settings") or {}
    n_top = h.get("outliers", 0)  # сколько вилок на самом деле исключено (меньше настройки, если вилок мало)
    trimmed_label = f"Без топ-{n_top} $" if n_top else "Сумма макс. $"
    cap = cfg.get("max_stake_per_arb_usd", 0)
    period = report["period"]
    first = date.fromisoformat(period["from"]).strftime("%d.%m.%Y")
    last = date.fromisoformat(period["to"]).strftime("%d.%m.%Y")
    lines = [
        f"Отчёт по истории вилок: {first} – {last} ({report['days']} дн., часовой пояс {report['timezone']})",
    ]
    if db_path:
        lines.append(f"База: {db_path}")
    lines.append(f"Вилка — появление, которое продержалось порог подтверждения (сейчас {fmt_seconds(report['confirm_seconds'])} с). "
                 "Повторное появление считается отдельно.")
    lines.append("Прибыль за жизнь вилки — максимум за время её жизни (верхняя оценка: прибыль, процент и объём могли быть "
                 "в разные моменты). Честнее — значение при подтверждении, медианы и итог без крупнейших вилок.")
    lines += ["", "Итого"]
    lines.append(f"  Вилок: {t['arbs']} (уникальных {t['distinct_arbs']}, матчей {t['matches']}). "
                 f"Не подтвердились (исчезли раньше порога): {t['candidates']}")
    if t["arbs"]:
        captured = t.get("captured_arbs", 0)
        if captured:
            lines.append(f"  Прибыль при подтверждении: {fmt_usd(h.get('confirm_profit_usd'))} "
                         f"(у {captured} из {t['arbs']} вилок есть данные при подтверждении); "
                         f"на вилку {_spread_text(h.get('confirm_profit_spread'))} $")
        else:
            lines.append(f"  Прибыль при подтверждении: {NO_DATA} (у всех {t['arbs']} вилок: записаны до этой версии сканера)")
        lines.append(f"  Прибыль за жизнь на вилку, $: {_spread_text(h.get('profit_spread'))}")
        lines.append(f"  Профит за жизнь, %: {_spread_text(h.get('pct_spread'))}; "
                     f"объём, $: {_spread_text(h.get('volume_spread'))}")
        if n_top:
            share = h["outliers_profit_usd"] / h["profit_usd"] if h.get("profit_usd") else None
            lines.append(f"  Итог без топ-{n_top} (сумма максимумов без {n_top} {_largest_word(n_top)}): "
                         f"{fmt_usd(h['profit_trimmed_usd'])}; топ-{n_top} дали {fmt_usd(h['outliers_profit_usd'])} — "
                         f"{fmt_share(share)} всей суммы максимумов {fmt_usd(h['profit_usd'])} (она — верхняя оценка)")
        else:
            lines.append(f"  Сумма максимумов: {fmt_usd(h.get('profit_usd'))} (верхняя оценка)")
        capped = h.get("capped")
        if capped:
            limit = f"до {fmt_num(cap, 0)} $ на вилку" if cap else "весь доступный объём каждой вилки"
            lines.append(f"  Ставка {limit}, без учёта банкролла: {_capped_text(capped)}" + _estimate_note(capped))
        bank = h.get("bankroll")
        if bank:
            limit = f"до {fmt_num(bank['max_stake_usd'], 0)} $ на вилку" if bank["max_stake_usd"] else "без лимита на вилку"
            hours = fmt_num(bank["settle_hours"], 0 if float(bank["settle_hours"]).is_integer() else 1)
            skipped = f"пропущено {bank['skipped_no_money']} (все деньги заняты)"
            if bank["skipped_no_depth"]:
                skipped += f" и {bank['skipped_no_depth']} (нет выгодного объёма)"
            lines.append(
                f"  Банкролл {fmt_num(bank['bankroll_usd'], 0)} $ (один на все площадки), {limit}, деньги заняты до "
                f"расчёта (старт матча или подтверждение, что позже, + {hours} ч): прибыль {_capped_text(bank)} "
                f"({fmt_num(bank['return_pct'])} % банкролла); взято {bank['taken']} из {bank['arbs']} вилок, "
                f"{skipped}" + _estimate_note(bank)
            )
        paper = h.get("paper") or []
        if any(p["checked"] or p["errors"] for p in paper):
            parts = [f"+{fmt_seconds(p['delay_sec'])} с — {_paper_text(p)}" for p in paper]
            lines.append("  Бумажная проверка (стаканы перечитаны отдельным запросом), осталось: " + "; ".join(parts))
        else:
            why = "проверки пишет эта версия сканера" if cfg.get("paper_enabled", True) else \
                "проверки выключены: paper.enabled = false"
            lines.append(f"  Бумажная проверка (стаканы перечитаны отдельным запросом): {NO_DATA} ({why})")
    lines.append(f"  Время жизни (вместе с порогом подтверждения): медиана {fmt_duration(t['median_lifetime_sec'])}, "
                 f"максимум {fmt_duration(t['max_lifetime_sec'])}; живут ≥ 30 с: {fmt_share(t['share_30s'])}, "
                 f"≥ 60 с: {fmt_share(t['share_60s'])}")
    if t["run_minutes"] is not None:
        lines.append(f"  Работа сканера: {fmt_minutes(t['run_minutes'])}, из них со свежими данными всех "
                     f"площадок: {fmt_minutes(t['data_minutes'])}")
        if t["per_24h"]:
            lines.append(f"  На 24 ч со свежими данными: вилок {fmt_num(t['per_24h']['arbs'], 1)}, уникальных "
                         f"{fmt_num(t['per_24h'].get('distinct_arbs'), 1)} (если сканер работал не круглые сутки, "
                         "оценка может быть завышена: матчи идут неравномерно)")
        else:
            lines.append(f"  На 24 ч: нужно хотя бы {t['rate_min_data_hours']} ч со свежими данными")
    else:
        lines.append("  Работа сканера: нет данных (время работы записывается с этой версии сканера)")
    note = uptime_note(report)
    if note:
        lines.append(f"  {note}")

    phases = report.get("phases") or []
    if t["arbs"] and phases:
        lines += ["", "По фазам (до старта / после старта матча)"]
        rows = []
        for ph in phases:
            rows.append([
                ph["label"], str(ph["arbs"]), str(ph["distinct_arbs"]),
                fmt_duration((ph.get("lifetime_spread") or {}).get("p50")),
                fmt_num((ph.get("volume_spread") or {}).get("p50")),
                fmt_num((ph.get("profit_spread") or {}).get("p50")),
                fmt_num(ph["profit_trimmed_usd"]), _confirm_text(ph), _capped_text(ph.get("capped")),
                _capped_text(ph.get("bankroll")),
            ])
        lines += _table(
            ["Фаза", "Вилок", "Уник.", "Медиана жизни", "Медиана объёма $", "Медиана $", trimmed_label,
             "При подтв.", f"До {fmt_num(cap, 0)} $/вилку" if cap else "Весь объём", "Банкролл (доля)"],
            rows,
        )
        if h.get("bankroll"):
            lines.append("  «Банкролл (доля)» — прибыль вилок этой фазы в общей симуляции с одним банкроллом: "
                         "суммы фаз равны итогу.")
        derived = t.get("derived_phase_arbs", 0)
        if derived:
            lines.append(f"  Фаза {derived} из {t['arbs']} вилок вычислена по времени старта из истории "
                         "(строки до этой версии сканера).")
        if any(_has_estimate(ph.get("capped")) or _has_estimate(ph.get("bankroll")) for ph in phases):
            lines.append("  * часть вилок группы оценена по максимумам (нет данных при подтверждении): min(прибыль, "
                         "ставка × процент); ** — оценены все вилки группы.")

    outliers = report.get("outliers") or []
    if outliers:
        lines += ["", f"Крупнейшие вилки (исключены из «без топ-{n_top}»)"]
        lines += _table(
            ["Матч", "Турнир", "Фаза", "Жила", "Объём $", "Прибыль $", "%", "Флаги"],
            [[f"{o['team_a'] or '?'} vs {o['team_b'] or '?'}", o["tournament"] or "—",
              hs_mod.PHASE_LABELS.get(o["phase"], "—"), fmt_duration(o["lifetime_sec"]), fmt_num(o["volume_usd"]),
              fmt_num(o["profit_usd"]), fmt_pct(o["profit_pct"]), _outlier_flags(o)] for o in outliers],
            left=3,
        )

    lines += ["", "По дням"]
    day_rows = [
        [
            f"{date.fromisoformat(d['date']).strftime('%d.%m')} {d['weekday']}",
            fmt_hours(d["run_hours"]), fmt_hours(d["data_hours"]), str(d["arbs"]), str(d["distinct_arbs"]),
            fmt_num(d.get("median_profit_usd")), fmt_num(d.get("profit_trimmed_usd")),
            _confirm_text(d), fmt_pct(d["best_profit_pct"]),
            fmt_duration(d["median_lifetime_sec"]), str(d["candidates"]),
        ]
        for d in report["by_day"]
    ]
    lines += _table(
        ["Дата", "Работа, ч", "Данные, ч", "Вилок", "Уник.", "Медиана $", trimmed_label, "При подтв.",
         "Макс. %", "Медиана жизни", "Кандидатов"],
        day_rows,
    )

    lines += ["", "Время жизни вилок"]
    peak = max((b["count"] for b in report["lifetime_buckets"]), default=0)
    for b in report["lifetime_buckets"]:
        bar = "█" * (round(b["count"] / peak * 30) if peak else 0)
        lines.append(f"  {b['label']:<13} {b['count']:>5}  {bar}")

    if report["by_game"]:
        lines += ["", "По играм"]
        lines += _table(
            ["Игра", "Вилок", "Уник.", "Медиана $", trimmed_label, "При подтв.", "Макс. %", "Медиана жизни"],
            [[g["name"], str(g["arbs"]), str(g["distinct_arbs"]), fmt_num(g.get("median_profit_usd")),
              fmt_num(g.get("profit_trimmed_usd")), _confirm_text(g), fmt_pct(g["best_profit_pct"]),
              fmt_duration(g["median_lifetime_sec"])] for g in report["by_game"]],
        )
    if report["by_platforms"]:
        lines += ["", "По парам площадок"]
        lines += _table(
            ["Площадки", "Вилок", "Уник.", "Медиана $", trimmed_label, "При подтв.", "Макс. %"],
            [[v["label"], str(v["arbs"]), str(v["distinct_arbs"]), fmt_num(v.get("median_profit_usd")),
              fmt_num(v.get("profit_trimmed_usd")), _confirm_text(v), fmt_pct(v["best_profit_pct"])]
             for v in report["by_platforms"]],
        )
    tournaments = report.get("by_tournament") or []
    if tournaments:
        shown = tournaments[:TOURNAMENTS_SHOWN]
        total = report.get("tournaments_total", len(tournaments))
        lines += ["", f"По турнирам (показано {len(shown)} из {total})"]
        lines += _table(
            ["Турнир", "Вилок", "До/после старта", "Медиана объёма $", "Макс. объём $", "Сумма макс. $", "Доля",
             trimmed_label, "При подтв.", "Большой объём"],
            [[x["tournament"] or "—", str(x["arbs"]), f"{x['prematch_arbs']}/{x['live_arbs']}",
              fmt_num(x["median_volume_usd"]), fmt_num(x["max_volume_usd"]), fmt_num(x["profit_usd"]),
              fmt_share(x.get("share_of_profit")), fmt_num(x["profit_trimmed_usd"]), _confirm_text(x),
              str(x["large_volume_arbs"])] for x in shown],
        )
    paper = h.get("paper") or []
    if any(p["checked"] or p["errors"] for p in paper):
        lines += ["", "Бумажная проверка (стаканы перечитаны отдельным REST-запросом)"]
        paper_rows = []
        for label, items in (("все", paper), *((ph["label"], ph.get("paper") or []) for ph in phases)):
            for p in items:
                paper_rows.append([
                    f"+{fmt_seconds(p['delay_sec'])} с", label, str(p["checked"]), str(p["left"]),
                    fmt_share(p["share_left"]), fmt_num(p["profit_usd"]), fmt_num(p["capped_profit_usd"]),
                    str(p["books_mismatch"]), str(p["errors"]), str(p["no_data"]),
                ])
        lines += _table(
            ["Через", "Фаза", "Проверено", "Осталось", "Доля", "Прибыль $", f"До {fmt_num(cap, 0)} $/вилку $" if cap
             else "Весь объём $", "Стакан сканера разошёлся", "Без данных", "Без проверки"],
            paper_rows, left=2,
        )
        lines.append("  «Без данных» — запрос не удался, опоздал или площадка не умеет запрос; «Без проверки» — "
                     "вилки без проверки на этой задержке.")
    if report["top_pairs"]:
        shown = len(report["top_pairs"])
        lines += ["", f"Матчи с наибольшей суммой максимумов (показано {shown} из {report['pairs_total']}), с флагами"]
        lines += _table(
            ["Матч", "Игра", "Вилок", "Жили всего", "Макс. объём $", "Сумма макс. $", trimmed_label,
             "Макс. %", "Флаги"],
            [[f"{p['team_a'] or '?'} vs {p['team_b'] or '?'}", p["game_name"], str(p["arbs"]),
              fmt_duration(p["total_lifetime_sec"]), fmt_num(p.get("max_volume_usd")), fmt_num(p["profit_usd"]),
              fmt_num(p.get("profit_trimmed_usd")), fmt_pct(p["best_profit_pct"]), flags_text(p.get("flags"), p["arbs"])]
             for p in report["top_pairs"]],
            left=2,
        )
    if not t["arbs"]:
        lines += ["", "За этот период подтверждённых вилок нет."]
    return "\n".join(lines) + "\n"


TOURNAMENTS_SHOWN = 15


def _largest_word(n: int) -> str:
    """«крупнейшей вилки» (1, 21, …) или «крупнейших вилок» — после «без N»."""
    return "крупнейшей вилки" if n % 10 == 1 and n % 100 != 11 else "крупнейших вилок"


def _has_estimate(block: dict[str, Any] | None) -> bool:
    return bool(block and block.get("estimated_arbs"))


def _estimate_note(block: dict[str, Any]) -> str:
    if not block.get("estimated_arbs"):
        return ""
    if not block.get("exact_arbs"):
        return f"; оценка по максимумам: у всех {block['estimated_arbs']} вилок нет данных при подтверждении"
    return (f"; из них {fmt_usd(block['estimated_profit_usd'])} — оценка по максимумам "
            f"для {block['estimated_arbs']} вилок без данных при подтверждении")


OUTLIER_FLAG_LABELS = {"size_jump": "скачок размера", "stale_data": "устаревшие данные"}


def _outlier_flags(o: dict[str, Any]) -> str:
    flags = []
    if o.get("large_volume"):
        flags.append("большой объём")
    if o.get("flags") is None:
        flags.append("нет снимков")
    else:
        flags += [OUTLIER_FLAG_LABELS[f] for f in o["flags"] if f in OUTLIER_FLAG_LABELS]
    return ", ".join(flags)
