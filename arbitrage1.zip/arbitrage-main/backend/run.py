"""Entry point: ``python run.py [--mock]`` (from the project root) or ``python backend/run.py``."""

from __future__ import annotations

import argparse
import logging
import sys
import threading
import webbrowser
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import uvicorn  # noqa: E402

from backend.adapters import apply_mock_mode  # noqa: E402
from backend.api.server import create_app  # noqa: E402
from backend.config import load_settings  # noqa: E402
from backend.logging_setup import setup_logging  # noqa: E402

log = logging.getLogger("run")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Command-line options."""
    parser = argparse.ArgumentParser(description="Esports Arb Scanner — сканер киберспортивных вилок")
    parser.add_argument("--mock", action="store_true", help="use synthetic data instead of real APIs")
    parser.add_argument("--config", help="path to config.yaml (default: backend/config.yaml)")
    parser.add_argument("--host", help="bind host (default from config: 127.0.0.1)")
    parser.add_argument("--port", type=int, help="bind port (default from config: 8000)")
    parser.add_argument("--no-browser", action="store_true", help="do not open the browser")
    parser.add_argument("--log-level", help="DEBUG, INFO, WARNING, ...")
    parser.add_argument("--db", help="SQLite file (default from config: data/arb_history.db)")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    """Load config, set up logging and run the web server."""
    args = parse_args(argv)
    settings = load_settings(args.config)
    if args.host:
        settings.server.host = args.host
    if args.port:
        settings.server.port = args.port
    if args.db:
        settings.storage.path = args.db
    if args.mock:
        settings = apply_mock_mode(settings)
        if not args.db:
            settings.storage.path = str(Path(settings.storage.path).with_name("arb_history_mock.db"))
        if settings.logging.file:
            log_path = Path(settings.logging.file)
            settings.logging.file = str(log_path.with_name(f"{log_path.stem}_mock{log_path.suffix}"))
    setup_logging(settings.logging, args.log_level)
    if settings.server.host not in ("127.0.0.1", "localhost", "::1"):
        log.warning(
            "binding to %s: other machines can connect, but only these host names are answered: %s "
            "(add more with ARB_ALLOWED_HOSTS)",
            settings.server.host, ", ".join(settings.server.allowed_hosts),
        )

    url = f"http://{'localhost' if settings.server.host in ('127.0.0.1', '0.0.0.0') else settings.server.host}:{settings.server.port}"
    log.info("starting Esports Arb Scanner%s on %s", " (MOCK DATA)" if args.mock else "", url)
    app = create_app(settings)
    if settings.server.open_browser and not args.no_browser:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    uvicorn.run(app, host=settings.server.host, port=settings.server.port, log_config=None, access_log=False)


if __name__ == "__main__":
    main()
