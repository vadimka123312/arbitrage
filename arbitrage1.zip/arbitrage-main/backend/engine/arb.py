"""Arbitrage maths for one matched pair.

For teams A and B (named as on the left platform) there are two directions:

* ``A``: buy A on the left platform + buy B on the right platform;
* ``B``: buy B on the left platform + buy A on the right platform.

``cost = ask_1 + ask_2 + fees/contract + extra costs/contract``; it is an arbitrage when
``cost < 1``; ``profit% = (1 - cost) / cost * 100``. Only asks are used (never mid/last).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field, replace
from datetime import datetime

from backend.config import PlatformFeeConfig, Settings
from backend.engine.fees import effective_fee_spec, fee_usd_fills, marginal_fee_per_contract
from backend.models import ArbLeg, ArbOpportunity, FeeSpec, Level, MatchedPair, NormalizedMarket

EPS = 1e-9


Fill = tuple[float, float, "str | None"]  # (price, contracts, instrument)


@dataclass
class Execution:
    """Result of buying ``contracts`` pairs across two books."""

    contracts: float
    fills1: list[Fill] = field(default_factory=list)
    fills2: list[Fill] = field(default_factory=list)
    fee1: float = 0.0
    fee2: float = 0.0
    extra: float = 0.0

    @property
    def gross(self) -> float:
        return sum(p * q for p, q, _ in self.fills1) + sum(p * q for p, q, _ in self.fills2)

    @property
    def total_cost(self) -> float:
        return self.gross + self.fee1 + self.fee2 + self.extra

    @property
    def profit(self) -> float:
        return self.contracts - self.total_cost

    @property
    def cost_per_contract(self) -> float:
        return self.total_cost / self.contracts if self.contracts > EPS else float("inf")

    @property
    def profit_pct(self) -> float:
        total = self.total_cost
        return self.profit / total * 100 if total > EPS else 0.0


@dataclass
class LegInput:
    """Everything the maths needs about one leg."""

    asks: list[Level]
    fee: FeeSpec
    fee_cfg: PlatformFeeConfig
    min_order_size: float = 0.0


def _by_instrument(fills: list[Fill]) -> dict[str | None, list[tuple[float, float]]]:
    """Group fills per instrument: each instrument is a separate order (e.g. Kalshi YES-A vs NO-B)."""
    groups: dict[str | None, list[tuple[float, float]]] = {}
    for price, qty, instrument in fills:
        groups.setdefault(instrument, []).append((price, qty))
    return groups


def _leg_costs(leg: LegInput, fills: list[Fill]) -> tuple[float, float]:
    """(fees, extra costs) of one leg; fees and fixed costs are counted per order."""
    groups = _by_instrument(fills)
    fees = sum(fee_usd_fills(leg.fee, group) for group in groups.values())
    contracts = sum(q for _, q, _ in fills)
    extra = leg.fee_cfg.extra_cost_per_contract * contracts + leg.fee_cfg.fixed_cost_per_trade_usd * len(groups)
    return fees, extra


def _execution(leg1: LegInput, leg2: LegInput, contracts: float, fills1: list[Fill], fills2: list[Fill]) -> Execution:
    fee1, extra1 = _leg_costs(leg1, fills1)
    fee2, extra2 = _leg_costs(leg2, fills2)
    return Execution(contracts=contracts, fills1=fills1, fills2=fills2, fee1=fee1, fee2=fee2, extra=extra1 + extra2)


def _take(levels: list[Level], qty: float) -> list[Fill]:
    """Fill ``qty`` contracts from ``levels`` in order."""
    fills: list[Fill] = []
    remaining = qty
    for level in levels:
        if remaining <= EPS:
            break
        take = min(level.size, remaining)
        if take > EPS:
            fills.append((level.price, take, level.instrument))
            remaining -= take
    return fills


def _small_orders(leg: LegInput, fills: list[Fill]) -> set[str | None]:
    """Instruments whose order would be below the leg's per-order minimum (each instrument is one order)."""
    if leg.min_order_size <= EPS:
        return set()
    return {
        instrument
        for instrument, group in _by_instrument(fills).items()
        if sum(q for _, q in group) < leg.min_order_size - EPS
    }


def _with_min_orders(
    execute: Callable[[LegInput, LegInput], Execution | None], leg1: LegInput, leg2: LegInput
) -> Execution | None:
    """Run ``execute``; when an order would be below the per-order minimum, drop that instrument and price again.

    A leg can be split into several orders (Kalshi "A wins" = YES «A» + NO «B»), and each order must reach the
    platform minimum on its own; a leg total below the minimum is the single-instrument case of the same check.
    Instruments of a split leg are dropped first: a small leftover there also shrinks the other leg's order (for
    example below Polymarket's 5 shares), and that leg must not be emptied while the leftover is the cause.
    Every retry removes at least one instrument, so the loop ends.
    """
    while True:
        result = execute(leg1, leg2)
        if result is None:
            return None
        small1, small2 = _small_orders(leg1, result.fills1), _small_orders(leg2, result.fills2)
        if not small1 and not small2:
            return result
        partial1 = bool(small1) and small1 != {lv.instrument for lv in leg1.asks}
        partial2 = bool(small2) and small2 != {lv.instrument for lv in leg2.asks}
        if partial1 or partial2:  # the leg keeps other instruments: drop only these and price again
            small1, small2 = (small1 if partial1 else set()), (small2 if partial2 else set())
        leg1 = replace(leg1, asks=[lv for lv in leg1.asks if lv.instrument not in small1])
        leg2 = replace(leg2, asks=[lv for lv in leg2.asks if lv.instrument not in small2])


def execute_best_level(leg1: LegInput, leg2: LegInput) -> Execution | None:
    """Buy as many pairs as the two best price levels allow (all instruments at that price)."""
    return _with_min_orders(_best_level, leg1, leg2)


def execute_walk_book(leg1: LegInput, leg2: LegInput) -> Execution | None:
    """Sweep both books while the marginal pair still costs less than $1."""
    return _with_min_orders(_walk_book, leg1, leg2)


def cap_levels(levels: list[Level], contracts: float) -> list[Level]:
    """Первые ``contracts`` контрактов стакана в его порядке (лучшая цена первой); остальное отбрасывается."""
    out: list[Level] = []
    remaining = contracts
    for level in levels:
        if remaining <= EPS:
            break
        take = min(level.size, remaining)
        if take > EPS:
            out.append(level if take >= level.size else level.model_copy(update={"size": take}))
            remaining -= take
    return out


BUDGET_STEPS = 60  # не больше стольких делений пополам при подборе объёма под бюджет
BUDGET_TOLERANCE = 1e-5  # …и до относительной точности 0,001 % числа контрактов (около 30 шагов на любом стакане)


def execute_budget(
    leg1: LegInput, leg2: LegInput, budget_usd: float, full: Execution | None = None
) -> Execution | None:
    """Обход стакана (``walk_book``), но потратить не больше ``budget_usd`` на обе ноги вместе с комиссиями.

    Обход покупает сначала самые дешёвые пары, поэтому его первые N контрактов — лучший способ потратить бюджет:
    результат — тот же обход по стаканам, обрезанным до N контрактов, с наибольшим N, которое укладывается в бюджет
    (комиссии, округление Kalshi и минимальные ордера считает сам ``execute_walk_book``). Если стакан мельче
    бюджета, результат — весь выгодный объём. None — выгодной пары нет или бюджет меньше минимального ордера.
    ``full`` — уже посчитанный ``execute_walk_book`` тех же ног (чтобы не считать его для каждой ставки заново).
    """
    if budget_usd <= EPS:
        return None
    if full is None:
        full = execute_walk_book(leg1, leg2)
    if full is None or full.profit <= EPS:
        return None
    if full.total_cost <= budget_usd + EPS:
        return full
    lo, hi, best = 0.0, full.contracts, None
    for _ in range(BUDGET_STEPS):
        if hi - lo <= BUDGET_TOLERANCE * max(1.0, hi):
            break
        mid = (lo + hi) / 2
        result = execute_walk_book(
            replace(leg1, asks=cap_levels(leg1.asks, mid)), replace(leg2, asks=cap_levels(leg2.asks, mid))
        )
        # None: ордер меньше минимального, то есть N слишком мало (а не слишком дорого).
        if result is None or result.total_cost <= budget_usd + EPS:
            lo = mid
            if result is not None:
                best = result
        else:
            hi = mid
    return best if best is not None and best.profit > EPS else None


def _best_level(leg1: LegInput, leg2: LegInput) -> Execution | None:
    if not leg1.asks or not leg2.asks:
        return None
    best1 = [lv for lv in leg1.asks if abs(lv.price - leg1.asks[0].price) < EPS]
    best2 = [lv for lv in leg2.asks if abs(lv.price - leg2.asks[0].price) < EPS]
    contracts = min(sum(lv.size for lv in best1), sum(lv.size for lv in best2))
    if contracts <= EPS:
        return None
    return _execution(leg1, leg2, contracts, _take(best1, contracts), _take(best2, contracts))


def _walk_book(leg1: LegInput, leg2: LegInput) -> Execution | None:
    asks1, asks2 = leg1.asks, leg2.asks
    if not asks1 or not asks2:
        return None
    i = j = 0
    rem1, rem2 = asks1[0].size, asks2[0].size
    fills1: list[Fill] = []
    fills2: list[Fill] = []
    contracts = 0.0
    per_contract_extra = leg1.fee_cfg.extra_cost_per_contract + leg2.fee_cfg.extra_cost_per_contract
    while i < len(asks1) and j < len(asks2):
        p1, p2 = asks1[i].price, asks2[j].price
        marginal = (
            p1
            + p2
            + marginal_fee_per_contract(leg1.fee, p1)
            + marginal_fee_per_contract(leg2.fee, p2)
            + per_contract_extra
        )
        if marginal >= 1 - EPS:
            break
        qty = min(rem1, rem2)
        if qty > EPS:
            fills1.append((p1, qty, asks1[i].instrument))
            fills2.append((p2, qty, asks2[j].instrument))
            contracts += qty
        rem1 -= qty
        rem2 -= qty
        if rem1 <= EPS:
            i += 1
            rem1 = asks1[i].size if i < len(asks1) else 0.0
        if rem2 <= EPS:
            j += 1
            rem2 = asks2[j].size if j < len(asks2) else 0.0
    if contracts <= EPS:
        return _best_level(leg1, leg2)
    result = _execution(leg1, leg2, contracts, fills1, fills2)
    if result.profit <= 0:
        # Rounding or fixed costs ate the edge of the deeper levels: fall back to the top level.
        return _best_level(leg1, leg2)
    return result


def is_fresh(market: NormalizedMarket, now: datetime, stale_seconds: float) -> bool:
    """True when the market book was updated within ``stale_seconds``."""
    if market.updated_at is None:
        return False
    return (now - market.updated_at).total_seconds() <= stale_seconds


def _leg_input(market: NormalizedMarket, outcome: str, settings: Settings) -> LegInput:
    fee_cfg = settings.fees.for_platform(market.platform)
    asks = market.asks_a if outcome == "a" else market.asks_b
    return LegInput(
        asks=asks,
        fee=effective_fee_spec(market.fee, fee_cfg),
        fee_cfg=fee_cfg,
        min_order_size=market.min_order_size,
    )


def _avg(fills: list[Fill]) -> float | None:
    qty = sum(q for _, q, _ in fills)
    return round(sum(p * q for p, q, _ in fills) / qty, 6) if qty > EPS else None


def describe_instruments(fills: list[Fill]) -> str | None:
    """What to buy: one instrument, or a split like ``YES «A» ×12 + NO «B» ×8``."""
    totals: dict[str | None, float] = {}
    for _, qty, instrument in fills:
        totals[instrument] = totals.get(instrument, 0.0) + qty
    if not totals or list(totals) == [None]:
        return None
    if len(totals) == 1:
        return next(iter(totals))
    return " + ".join(f"{inst or '?'} ×{qty:g}" for inst, qty in totals.items())


def direction_legs(pair: MatchedPair, direction: str) -> tuple[str, str]:
    """Which outcome to buy on the left and on the right market for a direction ('A'/'B').

    The right market must buy the *other* team: the opposite outcome, or the same outcome
    when the right market lists the teams in reverse order (``swapped``).
    """
    left_outcome = "a" if direction == "A" else "b"
    if pair.swapped:
        return left_outcome, left_outcome
    return left_outcome, "b" if left_outcome == "a" else "a"


def _arb_leg(
    market: NormalizedMarket,
    outcome: str,
    fills: list[Fill],
    fee: float,
    contracts: float,
    names: dict[str, str],
) -> ArbLeg:
    return ArbLeg(
        platform=market.platform,
        platform_name=names.get(market.platform, market.platform),
        market_id=market.market_id,
        outcome=market.team_a if outcome == "a" else market.team_b,
        instrument=describe_instruments(fills),
        ask=fills[0][0],
        avg_price=_avg(fills),
        size=round(contracts, 2),
        fee_usd=round(fee, 4),
        url=market.url,
    )


def direction_inputs(
    pair: MatchedPair,
    left: NormalizedMarket,
    right: NormalizedMarket,
    direction: str,
    settings: Settings,
) -> tuple[LegInput, LegInput]:
    """Обе ноги направления так, как их считает движок: стакан покупаемого исхода, комиссии, минимальный ордер."""
    lo, ro = direction_legs(pair, direction)
    return _leg_input(left, lo, settings), _leg_input(right, ro, settings)


def quote_direction(
    pair: MatchedPair,
    left: NormalizedMarket,
    right: NormalizedMarket,
    direction: str,
    settings: Settings,
) -> Execution | None:
    """Price one direction (profitable or not)."""
    leg1, leg2 = direction_inputs(pair, left, right, direction, settings)
    if settings.engine.depth_mode == "walk_book":
        return execute_walk_book(leg1, leg2)
    return execute_best_level(leg1, leg2)


def evaluate_pair(
    pair: MatchedPair,
    left: NormalizedMarket,
    right: NormalizedMarket,
    settings: Settings,
    now: datetime,
    platform_names: dict[str, str] | None = None,
) -> list[ArbOpportunity]:
    """Return the arbitrage opportunities (0..2) that exist right now for this pair."""
    eng = settings.engine
    if not (is_fresh(left, now, eng.stale_seconds) and is_fresh(right, now, eng.stale_seconds)):
        return []
    if not (left.accepting_orders and right.accepting_orders):
        return []
    names = platform_names or {}
    found: list[ArbOpportunity] = []
    for direction in ("A", "B"):
        execution = quote_direction(pair, left, right, direction, settings)
        if execution is None or execution.profit <= EPS:
            continue
        if execution.profit_pct < eng.min_profit_pct:
            continue
        volume = execution.total_cost
        if volume < eng.min_volume_usd:
            continue
        lo, ro = direction_legs(pair, direction)
        leg1 = _arb_leg(left, lo, execution.fills1, execution.fee1, execution.contracts, names)
        leg2 = _arb_leg(right, ro, execution.fills2, execution.fee2, execution.contracts, names)
        found.append(
            ArbOpportunity(
                arb_id=f"{pair.pair_key}|{direction}",
                pair_key=pair.pair_key,
                direction=direction,
                game=left.game,
                event_title=left.event_title,
                tournament=left.tournament or right.tournament,
                team_a=left.team_a,
                team_b=left.team_b,
                start_time=left.start_time or right.start_time,
                is_live=left.live_now(now) or right.live_now(now),
                leg1=leg1,
                leg2=leg2,
                sum_ask=round(leg1.ask + leg2.ask, 4),
                fees_usd=round(execution.fee1 + execution.fee2, 4),
                extra_costs_usd=round(execution.extra, 4),
                cost_per_contract=round(execution.cost_per_contract, 6),
                profit_pct=round(execution.profit_pct, 3),
                contracts=round(execution.contracts, 2),
                volume_usd=round(volume, 2),
                profit_usd=round(execution.profit, 2),
                confidence=pair.confidence,
                pair_status=pair.status,
                warnings=pair.warnings,
                detected_at=now,
            )
        )
    return found
