"""Scanner: the orchestrator that ties adapters, matching, arbitrage maths and tracking."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import sqlite3
from datetime import datetime
from typing import Any

from backend.adapters.base import MarketAdapter
from backend.config import Settings, runtime_settings_dict, set_dotted, validate_setting
from backend.engine.arb import describe_instruments, evaluate_pair, is_fresh, quote_direction
from backend.engine.capture import Capture
from backend.engine.paper import PaperChecker
from backend.engine.tracker import ArbTracker, TrackerUpdate
from backend.matching.matcher import Matcher
from backend.matching.normalizer import TeamNormalizer
from backend.matching.rules import RulesProfile, compare_rules, parse_rules
from backend.models import ClosedArb, MatchedPair, NormalizedMarket, RuleWarning, TrackedArb, utcnow
from backend.net import RETRY_STATUSES, HttpError, backoff_delay, describe_error
from backend.storage.db import Database

log = logging.getLogger(__name__)

BOOK_FIELDS = {
    "outcome_a_ask", "outcome_b_ask", "outcome_a_bid", "outcome_b_bid", "liquidity_at_best",
    "updated_at", "outcome_a_ask_size", "outcome_b_ask_size", "asks_a", "asks_b",
}
MATCHING_KEYS = {"matching.auto_threshold", "matching.review_threshold", "matching.time_tolerance_hours"}
# How often the scanner writes its uptime row (one row per minute; checks twice a minute so no minute is missed).
UPTIME_CHECK_SECONDS = 30.0


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


class Scanner:
    """Runs discovery per adapter, re-matches markets and evaluates arbitrage continuously."""

    def __init__(self, settings: Settings, adapters: dict[str, MarketAdapter], db: Database):
        self.settings = settings
        self.adapters = adapters
        self.db = db
        self.normalizer = TeamNormalizer.from_file(
            settings.resolve_path(settings.matching.aliases_file),
            subset_penalty_per_token=settings.matching.subset_penalty_per_token,
            qualifier_mismatch_cap=settings.matching.qualifier_mismatch_cap,
        )
        self.matcher = Matcher(settings.matching, self.normalizer)
        self.tracker = ArbTracker(settings.engine.confirm_seconds)
        self.capture = Capture(settings, adapters)  # данные для честной статистики (поиск от них не зависит)
        self._capture_failed = False
        # Бумажная проверка: оба стакана перечитываются отдельным запросом через paper.delays_sec после подтверждения.
        self.paper = PaperChecker(settings, adapters, db, self.market)
        self.markets: dict[str, dict[str, NormalizedMarket]] = {p: {} for p in adapters}
        self.pairs: list[MatchedPair] = []
        self.review: list[MatchedPair] = []
        self.blocked: list[MatchedPair] = []
        self.overrides: dict[str, str] = {}
        self.active: list[TrackedArb] = []
        self.started_at = utcnow()
        self.last_eval_at: datetime | None = None
        self.last_match_at: datetime | None = None
        self._rules_cache: dict[str, RulesProfile] = {}
        self._discovery_errors: dict[str, str] = {}
        self._announced: set[str] = set()  # arbs with an "ARB confirmed" log line and no "ARB ended" line yet
        self._tasks: list[asyncio.Task[Any]] = []
        self._version = 0
        self._event = asyncio.Event()
        self._snapshot: tuple[int, dict[str, Any]] | None = None
        self._lock = asyncio.Lock()

    # ---- life cycle ------------------------------------------------------------------

    async def start(self) -> None:
        """Load persisted state, start adapters, discovery and evaluation loops."""
        self.overrides = await self.db.get_overrides()
        for key, value in (await self.db.get_settings()).items():
            try:
                set_dotted(self.settings, key, value)
            except ValueError as exc:
                log.warning("ignoring saved setting %s: %s", key, exc)
        self.tracker.confirm_seconds = self.settings.engine.confirm_seconds
        for adapter in self.adapters.values():
            await adapter.start()
            self._tasks.append(asyncio.create_task(self._discovery_loop(adapter), name=f"discovery:{adapter.platform}"))
        self._tasks.append(asyncio.create_task(self._eval_loop(), name="eval"))
        self._tasks.append(asyncio.create_task(self._uptime_loop(), name="uptime"))
        self._tasks.append(asyncio.create_task(self.paper.run(), name="paper"))
        log.info("scanner started with platforms: %s", ", ".join(self.adapters) or "none")

    async def stop(self) -> None:
        """Stop loops and adapters; flush the still-active arbs to the history."""
        for task in self._tasks:
            task.cancel()
        for task in self._tasks:
            try:
                await task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001 - shutdown path
                pass
        self._tasks.clear()
        for adapter in self.adapters.values():
            try:
                await adapter.stop()
            except Exception:  # noqa: BLE001
                log.exception("error while stopping %s", adapter.platform)
        closed = self.tracker.close_all(utcnow())
        self.capture.finish(closed)
        for item in closed:
            self._log_ended(item, "scanner stopped")
        keep = [c for c in closed if c.lifetime_sec >= self.settings.engine.history_min_lifetime_sec]
        if keep:
            try:
                await self.db.add_history(keep)
            except Exception:  # noqa: BLE001
                log.exception("could not store arbs on shutdown")

    # ---- loops -----------------------------------------------------------------------

    async def _discovery_loop(self, adapter: MarketAdapter) -> None:
        attempt = 0
        while True:
            try:
                markets = await adapter.fetch_markets()
                self._merge(adapter.platform, markets)
                await adapter.subscribe_prices(list(self.markets[adapter.platform].values()), self._on_price)
                self.rematch()
                self._discovery_errors.pop(adapter.platform, None)
                attempt = 0
                delay = self.settings.discovery.refresh_seconds
                log.info("%s: %d markets", adapter.platform, len(self.markets[adapter.platform]))
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - keep the loop alive
                delay = backoff_delay(attempt, base=2.0, cap=120.0)
                attempt += 1
                if isinstance(exc, HttpError):  # network or API trouble after all retries: one line, no traceback
                    # A rejected request (4xx except timeouts and rate limits) points to our bug or an API change.
                    rejected = exc.status is not None and 400 <= exc.status < 500 and exc.status not in RETRY_STATUSES
                    log.log(logging.ERROR if rejected else logging.WARNING, "%s: discovery failed: %s (retry in %.0f s)",
                            adapter.platform, describe_error(exc), delay)
                else:
                    log.exception("%s: discovery failed", adapter.platform)
                self._discovery_errors[adapter.platform] = f"discovery: {exc}"[:300]
            await asyncio.sleep(delay)

    async def _eval_loop(self) -> None:
        while True:
            await asyncio.sleep(max(0.05, self.settings.engine.eval_interval_ms / 1000))
            try:
                await self.evaluate()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception("evaluation failed")

    async def _uptime_loop(self) -> None:
        failed: str | None = None  # what the last check ran into: "db" or "bug" (logged again when it changes)
        while True:
            try:
                await self.record_uptime(utcnow())
                if failed:
                    log.info("scanner uptime is written again")
                failed = None
            except asyncio.CancelledError:
                raise
            except (sqlite3.Error, OSError) as exc:  # disk full, database locked, ...: the scan goes on
                if failed != "db":
                    log.warning("could not write the scanner uptime: %s", describe_error(exc))
                failed = "db"
            except Exception:  # noqa: BLE001 - a bug in the check itself: keep its traceback (once per streak)
                if failed != "bug":
                    log.exception("scanner uptime check failed")
                failed = "bug"
            await asyncio.sleep(UPTIME_CHECK_SECONDS)

    async def record_uptime(self, now: datetime) -> None:
        """One uptime check for the report: the scanner runs; the data is fresh when every platform is healthy."""
        healthy = bool(self.adapters) and all(self._platform_view(a, now)["healthy"] for a in self.adapters.values())
        await self.db.mark_uptime(now, healthy)

    # ---- state updates ---------------------------------------------------------------

    def _on_price(self, market: NormalizedMarket) -> None:
        """Adapters call this on every book update (the eval loop does the work)."""

    def _merge(self, platform: str, fetched: list[NormalizedMarket]) -> None:
        current = self.markets.setdefault(platform, {})
        seen: set[str] = set()
        for market in fetched:
            seen.add(market.key)
            existing = current.get(market.key)
            if existing is None:
                current[market.key] = market
                continue
            keep_book = existing.updated_at is not None and (
                market.updated_at is None or existing.updated_at >= market.updated_at
            )
            for name in type(market).model_fields:
                if keep_book and name in BOOK_FIELDS:
                    continue
                if name == "extra":
                    existing.extra.update(market.extra)
                    continue
                setattr(existing, name, getattr(market, name))
        for key in list(current):
            if key not in seen:
                del current[key]

    def market(self, key: str) -> NormalizedMarket | None:
        """Look up a market by its global key."""
        platform = key.split(":", 1)[0]
        return self.markets.get(platform, {}).get(key)

    def _rules_profile(self, text: str) -> RulesProfile:
        digest = hashlib.sha1(text.encode("utf-8")).hexdigest()
        profile = self._rules_cache.get(digest)
        if profile is None:
            profile = parse_rules(text)
            self._rules_cache[digest] = profile
        return profile

    def _rule_warnings(self, pair: MatchedPair) -> list[RuleWarning]:
        """Rule differences plus pair-level risks (start-time gap, possible draw)."""
        left, right = self.market(pair.left_key), self.market(pair.right_key)
        if left is None or right is None:
            return []
        warnings: list[RuleWarning] = []
        if pair.time_diff_minutes is not None and pair.time_diff_minutes > 60:
            warnings.append(RuleWarning(
                field="start_time",
                severity="medium",
                message=f"Время старта на площадках различается на {pair.time_diff_minutes:.0f} мин: "
                        "проверьте, что это один и тот же матч",
            ))
        elif pair.time_diff_minutes is None:
            warnings.append(RuleWarning(
                field="start_time", severity="medium", message="Время старта неизвестно на одной из площадок",
            ))
        even = [m for m in (left, right) if m.best_of and m.best_of % 2 == 0]
        if even:
            warnings.append(RuleWarning(
                field="draw",
                severity="high",
                message=f"Формат BO{even[0].best_of}: возможна ничья. Ничья по-разному рассчитывается на площадках "
                        "(например, 50/50 против «Нет» у YES-контракта), вилка не гарантирована",
            ))
        warnings.extend(compare_rules(
            self._rules_profile(left.resolution_rules),
            self._rules_profile(right.resolution_rules),
            self._platform_name(left.platform),
            self._platform_name(right.platform),
        ))
        return warnings

    def _platform_name(self, platform: str) -> str:
        adapter = self.adapters.get(platform)
        return adapter.name if adapter else platform

    def rematch(self) -> None:
        """Re-run matching for every pair of platforms (config order)."""
        ids = list(self.adapters)
        pairs: list[MatchedPair] = []
        review: list[MatchedPair] = []
        blocked: list[MatchedPair] = []
        for i, left_id in enumerate(ids):
            for right_id in ids[i + 1:]:
                result = self.matcher.match(
                    list(self.markets.get(left_id, {}).values()),
                    list(self.markets.get(right_id, {}).values()),
                    self.overrides,
                )
                pairs.extend(result.pairs)
                review.extend(result.review)
                blocked.extend(result.blocked)
        for pair in (*pairs, *review, *blocked):
            pair.warnings = self._rule_warnings(pair)
        self.pairs, self.review, self.blocked = pairs, review, blocked
        self.last_match_at = utcnow()
        self._report_paired(pairs, review)
        self._bump()

    def _report_paired(self, pairs: list[MatchedPair], review: list[MatchedPair]) -> None:
        """Tell every adapter which of its markets are in a pair or in review (polling priority, nothing else)."""
        paired: dict[str, set[str]] = {platform: set() for platform in self.adapters}
        for pair in (*pairs, *review):
            for platform, key in ((pair.left_platform, pair.left_key), (pair.right_platform, pair.right_key)):
                paired.setdefault(platform, set()).add(key)
        for platform, adapter in self.adapters.items():
            try:
                adapter.set_paired(paired[platform])
            except Exception:  # noqa: BLE001 - a polling hint must never stop matching
                log.exception("%s: set_paired failed", platform)

    def _match_count(self) -> int:
        """Distinct matches: markets joined by pairs count once, also a match paired across three platforms."""
        parent: dict[str, str] = {}

        def root(key: str) -> str:
            while parent.get(key, key) != key:
                key = parent[key]
            return key

        joined = 0
        for pair in self.pairs:
            if self.market(pair.left_key) is None or self.market(pair.right_key) is None:
                continue  # a market removed by discovery just before the next matching run
            left, right = root(pair.left_key), root(pair.right_key)
            if left != right:
                parent[left] = right
                joined += 1
        return sum(len(m) for m in self.markets.values()) - joined

    async def evaluate(self) -> None:
        """Compute current arbs for all matched pairs and feed the tracker."""
        now = utcnow()
        names = {p: a.name for p, a in self.adapters.items()}
        found = []
        for pair in self.pairs:
            left, right = self.market(pair.left_key), self.market(pair.right_key)
            if left is None or right is None:
                continue
            try:
                found.extend(evaluate_pair(pair, left, right, self.settings, now, names))
            except Exception:  # noqa: BLE001 - one bad market must not stop the scan
                log.exception("evaluation failed for %s", pair.pair_key)
        self.tracker.confirm_seconds = self.settings.engine.confirm_seconds
        update = self.tracker.update(found, now)
        self._observe_capture(now, update)
        self.active = update.active
        self.last_eval_at = now
        self._schedule_paper(update.newly_confirmed)
        for tracked in update.newly_confirmed:
            arb = tracked.current
            self._announced.add(arb.arb_id)
            log.info(
                "ARB confirmed: %s | %s %s @%.3f + %s %s @%.3f | %.2f%% $%.2f",
                arb.event_title, arb.leg1.platform, arb.leg1.outcome, arb.leg1.ask,
                arb.leg2.platform, arb.leg2.outcome, arb.leg2.ask, arb.profit_pct, arb.volume_usd,
            )
        for closed in update.closed:
            if closed.arb_id in self._announced:
                self._log_ended(closed, self._end_reason(closed.last.pair_key, now, names))
        keep = [c for c in update.closed if c.lifetime_sec >= self.settings.engine.history_min_lifetime_sec]
        if keep:
            try:
                await self.db.add_history(keep)
            except Exception:  # noqa: BLE001 - the scan must go on even if the disk is full/locked
                log.exception("could not write %d closed arbs to the history", len(keep))
        self._bump()

    def _schedule_paper(self, confirmed: list[TrackedArb]) -> None:
        """Поставить бумажные проверки новых подтверждённых вилок; ошибка не мешает поиску."""
        if not confirmed or not self.settings.paper.enabled:
            return
        by_key = {p.pair_key: p for p in self.pairs}
        for tracked in confirmed:
            try:
                pair = by_key.get(tracked.current.pair_key)
                left = self.market(pair.left_key) if pair else None
                right = self.market(pair.right_key) if pair else None
                if pair is not None and left is not None and right is not None:
                    self.paper.schedule(tracked, pair, left, right)
            except Exception:  # noqa: BLE001 - проверка не должна мешать поиску вилок
                log.exception("could not schedule the paper checks of %s", tracked.arb_id)

    def _observe_capture(self, now: datetime, update: TrackerUpdate) -> None:
        """Данные для статистики (снимки, фаза, ставки, флаги). Ошибка не останавливает поиск: одна строка в лог."""
        try:
            self.capture.observe(now, self.pairs, self.market, update)
        except Exception:  # noqa: BLE001 - статистика не должна мешать поиску вилок
            if not self._capture_failed:
                log.exception("capture failed (arbs are still found and stored without the new data)")
            self._capture_failed = True
        else:
            self._capture_failed = False

    def _log_ended(self, closed: ClosedArb, reason: str) -> None:
        """The "ARB ended" line, only for arbs that had an "ARB confirmed" line (same legs, so they pair up)."""
        if closed.arb_id not in self._announced:
            return
        self._announced.discard(closed.arb_id)
        arb = closed.last
        log.info(
            "ARB ended: %s | %s %s + %s %s | lasted %.0f s, max %.2f%% $%.2f | %s",
            arb.event_title, arb.leg1.platform, arb.leg1.outcome, arb.leg2.platform, arb.leg2.outcome,
            closed.lifetime_sec, closed.max_profit_pct, closed.max_volume_usd, reason,
        )

    def _end_reason(self, pair_key: str, now: datetime, names: dict[str, str]) -> str:
        """Why a confirmed arb disappeared (for the log): data gap, paused trading, lost pair or the prices."""
        pair = next((p for p in self.pairs if p.pair_key == pair_key), None)
        if pair is None:
            return "pair no longer matched"
        for key in (pair.left_key, pair.right_key):
            platform = key.split(":", 1)[0]
            label = names.get(platform, platform)
            market = self.market(key)
            if market is None:
                return f"market gone ({label})"
            if not is_fresh(market, now, self.settings.engine.stale_seconds):
                return f"stale data ({label})"
            if not market.accepting_orders:
                return f"trading paused ({label})"
        return "prices, depth or filters changed"

    # ---- user actions ----------------------------------------------------------------

    async def set_override(self, pair_key: str, status: str) -> None:
        """Manually confirm or block a pair (persisted)."""
        await self.db.set_override(pair_key, status)
        self.overrides[pair_key] = status
        self.rematch()

    async def clear_override(self, pair_key: str) -> None:
        """Remove a manual decision (persisted)."""
        await self.db.clear_override(pair_key)
        self.overrides.pop(pair_key, None)
        self.rematch()

    async def update_settings(self, patch: dict[str, Any]) -> dict[str, Any]:
        """Validate all values first, then apply and persist them together (all or nothing)."""
        async with self._lock:
            applied = {key: validate_setting(key, value) for key, value in patch.items()}
            merged = {**runtime_settings_dict(self.settings), **applied}
            if merged["matching.review_threshold"] > merged["matching.auto_threshold"]:
                raise ValueError("matching.review_threshold must not exceed matching.auto_threshold")
            for key, value in applied.items():
                set_dotted(self.settings, key, value)
            if applied:
                await self.db.save_settings(applied)
            if MATCHING_KEYS & set(applied):
                self.rematch()
            self.tracker.confirm_seconds = self.settings.engine.confirm_seconds
            self._bump()
            return runtime_settings_dict(self.settings)

    # ---- snapshots -------------------------------------------------------------------

    def _bump(self) -> None:
        self._version += 1
        event, self._event = self._event, asyncio.Event()
        event.set()

    async def wait_update(self, timeout: float) -> None:
        """Wait until the state changes or ``timeout`` passes."""
        event = self._event
        try:
            await asyncio.wait_for(event.wait(), timeout)
        except asyncio.TimeoutError:
            pass

    def meta(self) -> dict[str, Any]:
        """Static-ish info for the UI: platforms and games."""
        return {
            "mock_mode": self.settings.mock_mode,
            "platforms": [
                {"id": p, "name": a.name, "color": a.status.color} for p, a in self.adapters.items()
            ],
            "games": [
                {"id": g, "name": cfg.name, "short": cfg.short or cfg.name}
                for g, cfg in self.settings.games.items()
            ],
            "settings": runtime_settings_dict(self.settings),
        }

    def _market_view(self, market: NormalizedMarket, now: datetime) -> dict[str, Any]:
        return {
            "key": market.key,
            "platform": market.platform,
            "platform_name": self._platform_name(market.platform),
            "market_id": market.market_id,
            "event_title": market.event_title,
            "team_a": market.team_a,
            "team_b": market.team_b,
            "start_time": _iso(market.start_time),
            "best_of": market.best_of,
            "tournament": market.tournament,
            "url": market.url,
            "ask_a": market.outcome_a_ask,
            "ask_b": market.outcome_b_ask,
            "bid_a": market.outcome_a_bid,
            "bid_b": market.outcome_b_bid,
            "ask_a_size": market.outcome_a_ask_size,
            "ask_b_size": market.outcome_b_ask_size,
            "instrument_a": market.asks_a[0].instrument if market.asks_a else None,
            "instrument_b": market.asks_b[0].instrument if market.asks_b else None,
            "updated_at": _iso(market.updated_at),
            "timestamp_kind": market.extra.get("timestamp_kind"),
            "source_book_timestamp": (
                market.extra.get("source_book_timestamps_ms")
                or market.extra.get("source_book_timestamp")
                or market.extra.get("source_generated_at")
            ),
            "actual_price_change_at": market.extra.get("actual_price_change_at"),
            "fresh": is_fresh(market, now, self.settings.engine.stale_seconds),
            "is_live": market.live_now(now),
            "fee_model": market.fee.model,
        }

    def _pair_view(self, pair: MatchedPair, now: datetime) -> dict[str, Any] | None:
        left, right = self.market(pair.left_key), self.market(pair.right_key)
        if left is None or right is None:
            return None
        quotes: dict[str, Any] = {}
        best: dict[str, Any] | None = None
        stale = self.settings.engine.stale_seconds
        actionable = (
            is_fresh(left, now, stale) and is_fresh(right, now, stale) and left.accepting_orders and right.accepting_orders
        )
        for direction in ("A", "B"):
            execution = quote_direction(pair, left, right, direction, self.settings)
            if execution is None:
                quotes[direction] = None
                continue
            left_price = execution.fills1[0][0]
            right_price = execution.fills2[0][0]
            quote = {
                "buy_left": left.team_a if direction == "A" else left.team_b,
                "sum_ask": round(left_price + right_price, 4),
                # What the engine actually buys (a split order part below the minimum is skipped, so this can
                # differ from the raw top of the book in the market views).
                "left_price": left_price,
                "right_price": right_price,
                "left_instrument": describe_instruments(execution.fills1),
                "right_instrument": describe_instruments(execution.fills2),
                "cost_per_contract": round(execution.cost_per_contract, 4),
                "profit_pct": round(execution.profit_pct, 3),
                "contracts": round(execution.contracts, 2),
                "actionable": actionable,  # False: stale quotes or trading paused
            }
            quotes[direction] = quote
            if best is None or quote["cost_per_contract"] < best["cost_per_contract"]:
                best = {"direction": direction, **quote}
        return {
            **pair.model_dump(mode="json"),
            "left": self._market_view(left, now),
            "right": self._market_view(right, now),
            "quotes": quotes,
            "best": best,
            "start_time": _iso(left.start_time or right.start_time),
            "is_live": left.live_now(now) or right.live_now(now),
        }

    def _arb_view(self, tracked: TrackedArb) -> dict[str, Any]:
        arb = tracked.current.model_dump(mode="json")
        arb.update(
            {
                "first_seen": _iso(tracked.first_seen),
                "last_seen": _iso(tracked.last_seen),
                "age_sec": tracked.age_sec,
                "confirmed": tracked.confirmed,
                "confirmed_at": _iso(tracked.confirmed_at),
                "max_profit_pct": tracked.max_profit_pct,
                "max_volume_usd": tracked.max_volume_usd,
                "max_profit_usd": tracked.max_profit_usd,
            }
        )
        return arb

    def _platform_view(self, adapter: MarketAdapter, now: datetime) -> dict[str, Any]:
        status = adapter.status.model_dump(mode="json")
        status["error"] = adapter.status.error or self._discovery_errors.get(adapter.platform)
        status["markets"] = len(self.markets.get(adapter.platform, {}))
        last = adapter.status.last_update
        status["seconds_since_update"] = round((now - last).total_seconds(), 1) if last else None
        status["healthy"] = bool(
            adapter.status.connected
            and last is not None
            and (now - last).total_seconds() <= max(self.settings.engine.stale_seconds, 5.0)
            and not status["error"]
        )
        return status

    def snapshot(self) -> dict[str, Any]:
        """JSON-ready full state for the UI (cached per state version)."""
        if self._snapshot is not None and self._snapshot[0] == self._version:
            return {**self._snapshot[1], "server_time": utcnow().isoformat()}
        now = utcnow()
        arbs = [self._arb_view(t) for t in self.active]
        pairs = [v for v in (self._pair_view(p, now) for p in self.pairs) if v is not None]
        review = [v for v in (self._pair_view(p, now) for p in self.review) if v is not None]
        blocked = [v for v in (self._pair_view(p, now) for p in self.blocked) if v is not None]
        data = {
            "version": self._version,
            "server_time": now.isoformat(),
            "started_at": self.started_at.isoformat(),
            "mock_mode": self.settings.mock_mode,
            "platforms": [self._platform_view(a, now) for a in self.adapters.values()],
            "counts": {
                "markets": sum(len(m) for m in self.markets.values()),
                # Distinct matches: a market pair on two platforms is one match (and a triangle on three is one too).
                "matches": self._match_count(),
                "markets_by_platform": {p: len(m) for p, m in self.markets.items()},
                "pairs": len(pairs),
                "review": len(review),
                "blocked": len(blocked),
                "active_arbs": sum(1 for a in arbs if a["confirmed"]),
                "pending_arbs": sum(1 for a in arbs if not a["confirmed"]),
            },
            "arbs": arbs,
            "pairs": pairs,
            "review": review,
            "blocked": blocked,
            "settings": runtime_settings_dict(self.settings),
            "last_eval_at": _iso(self.last_eval_at),
            "last_match_at": _iso(self.last_match_at),
        }
        self._snapshot = (self._version, data)
        return data
