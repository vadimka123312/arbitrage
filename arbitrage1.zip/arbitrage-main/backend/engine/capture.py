"""Данные для честной статистики. Поиск вилок от них не зависит: модуль только смотрит на то, что нашёл движок.

Для каждого появления вилки сканер запоминает:

- фазу: ``prematch``, если вилка появилась раньше времени старта матча, иначе ``live``; и минуты до старта в момент
  появления (отрицательные — после старта). Время старта берётся из первого наблюдения вилки;
- снимок при подтверждении и снимок на пике прибыли ($): верхние уровни стаканов обоих рынков (цена, размер,
  инструмент), возраст данных каждой площадки, применённые комиссии, идентификаторы инструментов (тикеры Kalshi,
  токены Polymarket), котировку движка в этот момент. Котировка на пике — согласованная тройка (прибыль, процент,
  объём одного момента), в отличие от независимых максимумов трекера;
- прибыль и средний процент при ставках ``capture.stake_sizes_usd`` с обходом стакана (``execute_budget``) и
  оптимальный размер — весь объём, на котором следующая пара ещё дешевле 1 $ с комиссиями (``execute_walk_book``).
  Лимит Stake (``max_stake_usd``) уже заложен в его стакан: один уровень на исход размером max_stake × коэф.;
- флаги подозрительной ликвидности: скачок размера на лучшей цене между соседними опросами (по той же или лучшей
  цене, без перерыва в данных; до подтверждения или пика), устаревшие данные, большой объём.

Всё это попадает в историю, когда появление заканчивается: ``Capture.finish`` кладёт значения колонок в
``ClosedArb.capture``, ``Database.add_history`` их пишет.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any

from backend.engine.arb import EPS, LegInput, direction_inputs, direction_legs, execute_budget, execute_walk_book
from backend.models import ArbLeg, ArbOpportunity, ClosedArb, Level, MatchedPair, NormalizedMarket, TrackedArb

if TYPE_CHECKING:
    from backend.adapters.base import MarketAdapter
    from backend.config import Settings
    from backend.engine.tracker import TrackerUpdate

log = logging.getLogger(__name__)

# Версия строки истории: 0 — записана до этой версии сканера (фаза не записана, данных при подтверждении нет); 1 —
# записана этой версией: фаза записана всегда, данные при подтверждении — если вилка подтверждена и сбор включён
# (их наличие видно по confirm_profit_usd и liquidity_flags).
CAPTURE_VERSION = 1


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


def to_json(value: Any) -> str:
    """Компактный JSON для колонок истории и бумажных проверок (даты и прочее — строкой)."""
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)


def phase_of(first_seen: datetime, start: datetime | None) -> tuple[str | None, float | None]:
    """(фаза, минуты до старта) в момент появления; без времени старта — (None, None)."""
    if start is None:
        return None, None
    minutes = (start - first_seen).total_seconds() / 60
    return ("prematch" if first_seen < start else "live"), round(minutes, 2)


def top_of_book(levels: list[Level]) -> tuple[float, float] | None:
    """(лучшая цена, размер на ней по всем инструментам); None — стакан пуст. Уровни идут от лучшей цены."""
    if not levels:
        return None
    price, size = levels[0].price, 0.0
    for level in levels:
        if abs(level.price - price) >= EPS:
            break
        size += level.size
    return price, size


def stake_table(leg1: LegInput, leg2: LegInput, stakes: Iterable[float]) -> list[dict[str, Any]]:
    """Прибыль и средний процент при каждой ставке (сумма на обе ноги с комиссиями) с обходом стакана.

    ``filled`` = false: весь выгодный объём стакана (или лимит Stake) меньше ставки, и ``cost_usd`` меньше неё. Пустые
    поля — при этой ставке выгодной покупки нет (например, ставка меньше минимального ордера).
    """
    full = execute_walk_book(leg1, leg2)
    rows = []
    for stake in stakes:
        result = execute_budget(leg1, leg2, stake, full)
        if result is None:
            rows.append({"stake_usd": stake, "cost_usd": None, "contracts": None, "profit_usd": None,
                         "profit_pct": None, "filled": False})
            continue
        rows.append({
            "stake_usd": stake,
            "cost_usd": round(result.total_cost, 2),
            "contracts": round(result.contracts, 2),
            "profit_usd": round(result.profit, 2),
            "profit_pct": round(result.profit_pct, 3),
            "filled": full is not None and full.total_cost >= stake - 0.01,
        })
    return rows


def optimal(leg1: LegInput, leg2: LegInput) -> dict[str, Any] | None:
    """Оптимальный размер: весь объём, на котором следующая пара ещё дешевле 1 $ (максимум прибыли в $)."""
    result = execute_walk_book(leg1, leg2)
    if result is None or result.profit <= EPS:
        return None
    return {
        "stake_usd": round(result.total_cost, 2),
        "contracts": round(result.contracts, 2),
        "profit_usd": round(result.profit, 2),
        "profit_pct": round(result.profit_pct, 3),
    }


def book_levels(levels: list[Level], depth: int) -> list[list[Any]]:
    """Первые ``depth`` уровней стакана для JSON: [цена, размер, инструмент], лучшая цена первой."""
    return [[lv.price, round(lv.size, 4), lv.instrument] for lv in levels[:depth]]


# Таблица ставок и оптимальный размер одного момента (по id его входов движка).
_Tables = dict[int, tuple[list[dict[str, Any]], "dict[str, Any] | None"]]


@dataclass
class _Moment:
    """Состояние обеих ног в один момент: снимок для истории и входы движка для расчёта ставок."""

    at: datetime
    kind: str
    opp: ArbOpportunity
    depth_mode: str
    inputs: tuple[LegInput, LegInput]
    legs: list[dict[str, Any]]

    def oldest(self) -> tuple[float, str] | None:
        """(возраст данных самой старой ноги, её площадка)."""
        ages = [(leg["age_sec"], leg["platform"]) for leg in self.legs if leg["age_sec"] is not None]
        return max(ages) if ages else None


MAX_JUMPS = 20  # скачков размера, которые помнит одно появление


@dataclass
class _State:
    """Что известно об одном появлении вилки, пока оно живо."""

    first_seen: datetime
    start_time: datetime | None
    confirm: _Moment | None = None
    peak: _Moment | None = None
    jumps: list[dict[str, Any]] = field(default_factory=list)  # скачки размера на ногах вилки за её жизнь


class Capture:
    """Собирает данные о появлениях вилок по шагам сканера; ничего не меняет в рынках, парах и вилках."""

    def __init__(self, settings: Settings, adapters: Mapping[str, MarketAdapter] | None = None):
        self.settings = settings
        self.adapters = adapters or {}
        self._arbs: dict[str, _State] = {}
        # (ключ рынка, исход) -> (updated_at, лучшая цена, размер на ней) по последнему шагу
        self._best: dict[tuple[str, str], tuple[datetime, float, float]] = {}
        # (ключ рынка, исход) -> последний скачок размера на лучшей цене
        self._jumps: dict[tuple[str, str], dict[str, Any]] = {}
        self._failing: set[str] = set()  # появления, на которых сбор данных падает (строка в лог один раз)

    @property
    def active(self) -> dict[str, _State]:
        return self._arbs

    # ---- шаг сканера ----------------------------------------------------------------

    def observe(
        self,
        now: datetime,
        pairs: list[MatchedPair],
        market: Callable[[str], NormalizedMarket | None],
        update: TrackerUpdate,
    ) -> None:
        """Один шаг: скачки размеров, новые появления, пики, подтверждения; закрытым — значения для истории."""
        self.finish(update.closed)  # закрытые появления не входят в active: их данные уже собраны
        enabled = self.settings.capture.enabled
        by_key = {p.pair_key: p for p in pairs}
        if enabled:
            self._track_sizes(now, by_key.values(), market)
        for tracked in update.active:
            state = self._arbs.get(tracked.arb_id)
            if state is None:
                state = self._arbs[tracked.arb_id] = _State(
                    first_seen=tracked.first_seen, start_time=tracked.current.start_time
                )
            if enabled:
                self._guarded(tracked.arb_id, self._observe_one, now, tracked, state, by_key, market)
        if enabled:
            for tracked in update.newly_confirmed:
                state = self._arbs.get(tracked.arb_id)
                if state is not None:
                    self._guarded(tracked.arb_id, self._confirm_one, now, tracked, state, by_key, market)
        if len(self._arbs) > len(update.active):  # страховка: состояние только у живых появлений
            alive = {t.arb_id for t in update.active}
            self._arbs = {k: v for k, v in self._arbs.items() if k in alive}

    def _guarded(self, arb_id: str, step: Callable[..., None], *args: Any) -> None:
        """Шаг одного появления: ошибка не мешает остальным появлениям (строка в лог один раз за серию)."""
        try:
            step(*args)
        except Exception:  # noqa: BLE001 - сбор данных одной вилки не должен останавливать сбор по остальным
            if arb_id not in self._failing:
                log.exception("capture: could not observe %s", arb_id)
            self._failing.add(arb_id)
        else:
            self._failing.discard(arb_id)

    def _observe_one(
        self, now: datetime, tracked: TrackedArb, state: _State, by_key: dict[str, MatchedPair],
        market: Callable[[str], NormalizedMarket | None],
    ) -> None:
        """Новый пик прибыли — снимок; скачки размера на ногах вилки — в её список."""
        opp = tracked.current
        legs = self._legs(by_key.get(opp.pair_key), market)
        if legs is None:
            return
        pair, left, right = legs
        if state.peak is None or opp.profit_usd > state.peak.opp.profit_usd + EPS:
            state.peak = self._moment(now, "peak", opp, pair, left, right)
        lookback = timedelta(seconds=self.settings.engine.stale_seconds)
        lo, ro = direction_legs(pair, opp.direction)
        for key in ((pair.left_key, lo), (pair.right_key, ro)):
            jump = self._jumps.get(key)
            if jump is None or jump["at"] < state.first_seen - lookback or any(j is jump for j in state.jumps):
                continue
            state.jumps = [*state.jumps, jump][-MAX_JUMPS:]

    def _confirm_one(
        self, now: datetime, tracked: TrackedArb, state: _State, by_key: dict[str, MatchedPair],
        market: Callable[[str], NormalizedMarket | None],
    ) -> None:
        legs = self._legs(by_key.get(tracked.current.pair_key), market)
        if legs is None:
            return
        peak = state.peak
        if peak is not None and peak.at == now and peak.opp is tracked.current:
            state.confirm = replace(peak, kind="confirm")  # тот же момент, без пересчёта
        else:
            state.confirm = self._moment(now, "confirm", tracked.current, *legs)

    def finish(self, closed: list[ClosedArb]) -> None:
        """Значения колонок истории для закончившихся появлений (``ClosedArb.capture``)."""
        for item in closed:
            state = self._arbs.pop(item.arb_id, None)
            try:
                item.capture = self._record(item, state)
            except Exception:  # noqa: BLE001 - без этих данных строка истории всё равно пишется
                log.exception("capture: could not prepare the data of %s", item.arb_id)
                item.capture = None

    # ---- размеры на лучшей цене -----------------------------------------------------

    def _track_sizes(
        self, now: datetime, pairs: Iterable[MatchedPair], market: Callable[[str], NormalizedMarket | None]
    ) -> None:
        """Сравнить размер на лучшей цене с прошлым шагом для каждого рынка в парах; запомнить скачки."""
        cfg = self.settings.capture
        markets: dict[str, tuple[NormalizedMarket, datetime]] = {}
        for pair in pairs:
            for key in (pair.left_key, pair.right_key):
                if key not in markets:
                    found = market(key)
                    if found is not None and found.updated_at is not None:
                        markets[key] = (found, found.updated_at)
        best: dict[tuple[str, str], tuple[datetime, float, float]] = {}
        gap = timedelta(seconds=self.settings.engine.stale_seconds)
        for key, (m, updated) in markets.items():
            for outcome, asks, team in (("a", m.asks_a, m.team_a), ("b", m.asks_b, m.team_b)):
                top = top_of_book(asks)
                if top is None:
                    continue
                k = (key, outcome)
                prev = self._best.get(k)
                if prev is not None and prev[0] == updated:
                    best[k] = prev  # стакан не обновлялся с прошлого шага
                    continue
                best[k] = (updated, top[0], top[1])
                if prev is None or prev[2] <= EPS or updated - prev[0] > gap:
                    continue  # нечего сравнивать, или между опросами был перерыв в данных
                price, size = top
                if price > prev[1] + EPS:
                    continue  # лучший уровень выкупили, и лучшей стала цена хуже: это не новая заявка
                added = (size - prev[2]) * price
                if size >= cfg.size_jump_ratio * prev[2] and added >= cfg.size_jump_min_usd:
                    self._jumps[k] = {
                        "at": now, "platform": m.platform, "market_id": m.market_id, "outcome": team,
                        "prev_price": prev[1], "prev_size": round(prev[2], 2), "price": price, "size": round(size, 2),
                        "ratio": round(size / prev[2], 1), "added_usd": round(added, 2),
                        "ratio_threshold": cfg.size_jump_ratio, "min_usd": cfg.size_jump_min_usd,
                    }
        self._best = best
        old = now - timedelta(seconds=self.settings.engine.stale_seconds)
        self._jumps = {k: j for k, j in self._jumps.items() if j["at"] >= old and k in best}

    # ---- снимки -------------------------------------------------------------------

    @staticmethod
    def _legs(
        pair: MatchedPair | None, market: Callable[[str], NormalizedMarket | None]
    ) -> tuple[MatchedPair, NormalizedMarket, NormalizedMarket] | None:
        if pair is None:
            return None
        left, right = market(pair.left_key), market(pair.right_key)
        if left is None or right is None:
            return None
        return pair, left, right

    def _moment(
        self, now: datetime, kind: str, opp: ArbOpportunity, pair: MatchedPair, left: NormalizedMarket,
        right: NormalizedMarket,
    ) -> _Moment:
        inputs = direction_inputs(pair, left, right, opp.direction, self.settings)
        lo, ro = direction_legs(pair, opp.direction)
        legs = [
            self._leg_view(now, left, lo, opp.leg1, inputs[0]),
            self._leg_view(now, right, ro, opp.leg2, inputs[1]),
        ]
        return _Moment(now, kind, opp, self.settings.engine.depth_mode, inputs, legs)

    def _leg_view(self, now: datetime, m: NormalizedMarket, outcome: str, leg: ArbLeg, inp: LegInput) -> dict[str, Any]:
        depth = self.settings.capture.book_levels
        adapter = self.adapters.get(m.platform)
        try:
            ids = adapter.instrument_ids(m) if adapter is not None else {}
        except Exception:  # noqa: BLE001 - подсказка для снимка, не должна мешать
            ids = {}
        return {
            "platform": m.platform,
            "market_id": m.market_id,
            "buy": outcome,  # какой исход этого рынка покупает нога: "a" или "b"
            "outcome": leg.outcome,
            "team_a": m.team_a,
            "team_b": m.team_b,
            "event_title": m.event_title,
            "tournament": m.tournament,
            "start_time": _iso(m.start_time),
            "best_of": m.best_of,
            "is_live": m.live_now(now),
            "accepting_orders": m.accepting_orders,
            "updated_at": _iso(m.updated_at),
            "age_sec": round((now - m.updated_at).total_seconds(), 3) if m.updated_at else None,
            # Что покупает движок в этот момент: лучшая цена, средняя цена, контракты, комиссия, инструменты.
            "ask": leg.ask,
            "avg_price": leg.avg_price,
            "contracts": leg.size,
            "fee_usd": leg.fee_usd,
            "instrument": leg.instrument,
            "fee": {
                **inp.fee.model_dump(),
                "extra_cost_per_contract": inp.fee_cfg.extra_cost_per_contract,
                "fixed_cost_per_trade_usd": inp.fee_cfg.fixed_cost_per_trade_usd,
            },
            "min_order_size": m.min_order_size,
            "asks_a": book_levels(m.asks_a, depth),
            "asks_b": book_levels(m.asks_b, depth),
            "bid_a": m.outcome_a_bid,
            "bid_b": m.outcome_b_bid,
            "instrument_ids": ids,
            "ids": dict(m.extra),
        }

    def _snapshot(self, moment: _Moment, tables: _Tables) -> dict[str, Any]:
        opp = moment.opp
        # Подтверждение и пик часто один и тот же момент (та же котировка): ставки считаются один раз.
        key = id(moment.inputs)
        if key not in tables:
            tables[key] = (stake_table(*moment.inputs, self.settings.capture.stake_sizes_usd), optimal(*moment.inputs))
        stakes, best = tables[key]
        return {
            "v": CAPTURE_VERSION,
            "kind": moment.kind,
            "at": moment.at.isoformat(),
            "depth_mode": moment.depth_mode,
            "quote": {
                "sum_ask": opp.sum_ask,
                "cost_per_contract": opp.cost_per_contract,
                "contracts": opp.contracts,
                "volume_usd": opp.volume_usd,
                "profit_usd": opp.profit_usd,
                "profit_pct": opp.profit_pct,
                "fees_usd": opp.fees_usd,
                "extra_costs_usd": opp.extra_costs_usd,
                "is_live": opp.is_live,
            },
            "legs": moment.legs,
            "stakes": stakes,
            "optimal": best,
        }

    # ---- строка истории -------------------------------------------------------------

    def _flags(self, item: ClosedArb, state: _State) -> dict[str, Any]:
        cfg = self.settings.capture
        flags: dict[str, Any] = {}
        # Скачок важен, только если он мог дать подтверждение или пик: позже он уже ничего не объясняет.
        until = max((m.at for m in (state.confirm, state.peak) if m is not None), default=item.last_seen)
        jumps = [j for j in state.jumps if j["at"] <= until]
        if jumps:
            jump = max(jumps, key=lambda j: j["added_usd"])
            flags["size_jump"] = {**jump, "at": _iso(jump["at"]), "count": len(jumps)}
        stale = None
        for moment in (state.confirm, state.peak):
            oldest = moment.oldest() if moment is not None else None
            if oldest is not None and oldest[0] > cfg.stale_age_sec and (stale is None or oldest[0] > stale["age_sec"]):
                stale = {"moment": moment.kind, "platform": oldest[1], "age_sec": oldest[0],
                         "threshold_sec": cfg.stale_age_sec}
        if stale is not None:
            flags["stale_data"] = stale
        if cfg.large_volume_usd > 0 and item.max_volume_usd >= cfg.large_volume_usd:
            flags["large_volume"] = {"volume_usd": item.max_volume_usd, "threshold_usd": cfg.large_volume_usd}
        return flags

    def _record(self, item: ClosedArb, state: _State | None) -> dict[str, Any]:
        """Значения новых колонок ``arb_history`` для одного появления."""
        start = state.start_time if state is not None else item.last.start_time
        phase, minutes = phase_of(item.first_seen, start)
        record: dict[str, Any] = {"capture_version": CAPTURE_VERSION, "phase": phase, "minutes_to_start": minutes}
        if not item.confirmed or state is None or not self.settings.capture.enabled:
            return record
        confirm, peak = state.confirm, state.peak
        tables: _Tables = {}
        if confirm is not None:
            snapshot = self._snapshot(confirm, tables)
            quote = snapshot["quote"]
            best = snapshot["optimal"] or {}
            record.update({
                "confirmed_at": _iso(confirm.at),
                "confirm_profit_usd": quote["profit_usd"],
                "confirm_profit_pct": quote["profit_pct"],
                "confirm_volume_usd": quote["volume_usd"],
                "optimal_stake_usd": best.get("stake_usd"),
                "optimal_profit_usd": best.get("profit_usd"),
                "optimal_profit_pct": best.get("profit_pct"),
                "stake_profits": to_json(snapshot["stakes"]),
                "confirm_snapshot": to_json(snapshot),
            })
        if peak is not None:
            record.update({
                "peak_at": _iso(peak.at),
                "peak_profit_usd": peak.opp.profit_usd,
                "peak_profit_pct": peak.opp.profit_pct,
                "peak_volume_usd": peak.opp.volume_usd,
                "peak_snapshot": to_json(self._snapshot(peak, tables)),
            })
        record["liquidity_flags"] = to_json(self._flags(item, state))
        return record
