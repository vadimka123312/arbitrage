"""Бумажная проверка исполнимости вилок. Ничего не покупает и не меняет поиск вилок.

Через ``paper.delays_sec`` секунд (по умолчанию 5, 15 и 60) после подтверждения вилки ``PaperChecker`` перечитывает
стаканы обоих рынков отдельным REST-запросом к каждой площадке (``MarketAdapter.fetch_book``; стаканы сканера и
адаптеров при этом не меняются) и считает по ним ту же вилку теми же правилами движка (``evaluate_pair``: свежесть,
приём ставок, фильтры прибыли и объёма). Какую команду покупать на каждом рынке, определяется по имени команды из
момента подтверждения, а не по порядку команд: площадка (Stake) может поменять порядок между подтверждением и
проверкой. В таблицу ``paper_checks`` пишется:

- осталась ли вилка (``arb_exists``), её прибыль, процент и объём по стаканам из запроса; если осталась — прибыль при
  ставках ``capture.stake_sizes_usd`` и оптимальный размер (обход стакана, как в ``engine.capture``);
- то же по стакану сканера в тот же момент и совпадают ли лучшие цена и размер обеих ног (``books_match``): так видно
  ошибку или отставание собственного стакана сканера (например, WebSocket Polymarket);
- статус: ``ok`` — оба стакана получены; ``error`` — запрос не удался, ответ пришёл слишком поздно, команды
  изменились или проверка не уложилась в ``paper.check_timeout_sec`` (``arb_exists`` пустой: «данных нет», а не
  «вилка исчезла»); ``late`` — проверка началась позже срока больше чем на ``paper.max_late_sec`` (например, после
  сна компьютера) и не выполнялась; ``unsupported`` — площадка не умеет отдельный запрос. ``actual_delay_sec`` —
  фактическая задержка от подтверждения до запроса.

Проверка связана с появлением вилки по ``arb_id`` и ``first_seen`` (как в ``arb_history``).
"""

from __future__ import annotations

import asyncio
import heapq
import itertools
import logging
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any

from backend.engine.arb import EPS, direction_inputs, evaluate_pair, is_fresh
from backend.engine.capture import book_levels, optimal, stake_table, to_json, top_of_book
from backend.models import MatchedPair, NormalizedMarket, TrackedArb, utcnow
from backend.net import describe_error

if TYPE_CHECKING:
    from backend.adapters.base import MarketAdapter
    from backend.config import Settings
    from backend.storage.db import Database

log = logging.getLogger(__name__)

SIZE_TOLERANCE = 0.01  # лучшие размеры стакана сканера и запроса «совпадают», если отличаются не больше чем на 1 %


def outcome_of(market: NormalizedMarket, team: str) -> str | None:
    """Исход рынка (``a``/``b``), который выигрывает команда ``team`` (имя как на этой площадке); None — такой нет."""
    if market.team_a == team:
        return "a"
    if market.team_b == team:
        return "b"
    return None


def priced_pair(pair: MatchedPair, left_outcome: str, right_outcome: str) -> tuple[MatchedPair, str]:
    """Копия пары и направление, при которых движок купит ``left_outcome`` слева и ``right_outcome`` справа."""
    direction = "A" if left_outcome == "a" else "B"
    return pair.model_copy(update={"swapped": left_outcome == right_outcome}), direction


@dataclass
class PaperJob:
    """Одна проверка одного подтверждённого появления."""

    arb_id: str
    direction: str
    first_seen: datetime
    confirmed_at: datetime
    delay_sec: float
    pair: MatchedPair
    left: NormalizedMarket  # копии рынков в момент подтверждения: идентификаторы, если сканер рынок уже убрал
    right: NormalizedMarket
    left_team: str  # какую команду покупает каждая нога (имя как на её площадке)
    right_team: str
    confirm_profit_usd: float
    confirm_volume_usd: float

    @property
    def due(self) -> datetime:
        return self.confirmed_at + timedelta(seconds=self.delay_sec)


@dataclass(order=True)
class _Due:
    due: datetime
    seq: int
    job: PaperJob = field(compare=False)


class PaperChecker:
    """Очередь проверок по времени и их выполнение (не больше ``paper.max_concurrency`` одновременно)."""

    def __init__(
        self,
        settings: Settings,
        adapters: Mapping[str, MarketAdapter],
        db: Database,
        market: Callable[[str], NormalizedMarket | None],
        clock: Callable[[], datetime] = utcnow,
    ):
        self.settings = settings
        self.adapters = adapters
        self.db = db
        self.market = market  # текущие рынки сканера по ключу
        self.clock = clock
        self._heap: list[_Due] = []
        self._seq = itertools.count()
        self._wake = asyncio.Event()
        self._running: set[asyncio.Task[Any]] = set()
        self._scheduled: dict[tuple[str, datetime], datetime] = {}  # появление -> срок его последней проверки
        self._full = False  # очередь была полна (строка в лог один раз за серию)
        self._failing: set[str] = set()  # площадки, чьи запросы сейчас не удаются (строка в лог один раз за серию)
        self._db_failing = False
        self.written = 0
        self.dropped = 0

    @property
    def pending(self) -> int:
        return len(self._heap) + len(self._running)

    def schedule(self, tracked: TrackedArb, pair: MatchedPair, left: NormalizedMarket, right: NormalizedMarket) -> None:
        """Поставить проверки подтверждённого появления (копии рынков берутся сейчас); одно появление — один раз."""
        cfg = self.settings.paper
        if not cfg.enabled:
            return
        now = self.clock()
        self._scheduled = {k: last for k, last in self._scheduled.items() if last >= now - timedelta(minutes=5)}
        key = (tracked.arb_id, tracked.first_seen)
        if key in self._scheduled:  # подтверждение после повышения порога на лету: проверки уже стоят
            return
        delays = list(cfg.delays_sec)
        if self.pending + len(delays) > cfg.max_pending:
            self.dropped += len(delays)
            if not self._full:
                log.warning("paper checks: %d pending, the checks of %s are skipped (paper.max_pending)",
                            self.pending, tracked.arb_id)
            self._full = True
            return
        self._full = False
        opp = tracked.current
        confirmed_at = tracked.confirmed_at or tracked.last_seen
        left_copy, right_copy = left.model_copy(deep=True), right.model_copy(deep=True)
        for delay in delays:
            job = PaperJob(
                arb_id=tracked.arb_id, direction=opp.direction, first_seen=tracked.first_seen,
                confirmed_at=confirmed_at, delay_sec=delay, pair=pair, left=left_copy, right=right_copy,
                left_team=opp.leg1.outcome, right_team=opp.leg2.outcome,
                confirm_profit_usd=opp.profit_usd, confirm_volume_usd=opp.volume_usd,
            )
            heapq.heappush(self._heap, _Due(job.due, next(self._seq), job))
        self._scheduled[key] = confirmed_at + timedelta(seconds=max(delays))
        self._wake.set()

    async def run(self) -> None:
        """Цикл: ждать ближайшую проверку, запустить её, записать результат. Отмена прекращает и текущие проверки."""
        semaphore = asyncio.Semaphore(self.settings.paper.max_concurrency)
        failed = False
        try:
            while True:
                try:
                    await self._next(semaphore)
                    failed = False
                except asyncio.CancelledError:
                    raise
                except Exception:  # noqa: BLE001 - ошибка в самом цикле: строка в лог, цикл продолжает
                    if not failed:
                        log.exception("paper checks: the queue loop failed")
                    failed = True
                    await asyncio.sleep(1.0)
        finally:
            left = self.pending
            running = list(self._running)
            for task in running:
                task.cancel()
            self._heap.clear()
            if running:
                await asyncio.gather(*running, return_exceptions=True)
            if left:
                log.info("paper checks: %d pending checks dropped on shutdown", left)

    async def _next(self, semaphore: asyncio.Semaphore) -> None:
        """Дождаться срока ближайшей проверки (или новой постановки) и запустить её в свободном слоте."""
        if not self._heap:
            self._wake.clear()
            await self._wake.wait()
            return
        wait = (self._heap[0].due - self.clock()).total_seconds()
        if wait > 0:
            self._wake.clear()
            try:
                await asyncio.wait_for(self._wake.wait(), timeout=wait)
            except asyncio.TimeoutError:
                pass
            return
        await semaphore.acquire()
        job = heapq.heappop(self._heap).job
        task = asyncio.create_task(self._run_one(job, semaphore), name=f"paper:{job.arb_id}:{job.delay_sec:g}")
        self._running.add(task)
        task.add_done_callback(self._running.discard)

    async def _run_one(self, job: PaperJob, semaphore: asyncio.Semaphore) -> None:
        timeout = self.settings.paper.check_timeout_sec
        try:
            row = await asyncio.wait_for(self.check(job), timeout=timeout)
        except asyncio.CancelledError:
            raise
        except asyncio.TimeoutError:
            row = self._row(job, self.clock(), "error", reason=f"timeout after {timeout:g} s")
        except Exception as exc:  # noqa: BLE001 - ошибка в самой проверке: строка с error, поиск не страдает
            log.exception("paper check of %s failed", job.arb_id)
            row = self._row(job, self.clock(), "error", reason=f"check failed: {describe_error(exc)}"[:300])
        finally:
            semaphore.release()
        try:
            await self.db.add_paper_checks([row])
            self.written += 1
            if self._db_failing:
                log.info("paper checks are written again")
            self._db_failing = False
        except Exception:  # noqa: BLE001 - диск полон и т. п.: проверка теряется, сканер работает дальше
            if not self._db_failing:
                log.exception("could not write a paper check of %s", job.arb_id)
            self._db_failing = True

    # ---- одна проверка ----------------------------------------------------------------

    async def check(self, job: PaperJob) -> dict[str, Any]:
        """Перечитать оба стакана запросом, посчитать вилку по ним и по стакану сканера; вернуть строку таблицы."""
        started = self.clock()
        late = (started - job.due).total_seconds()
        if late > self.settings.paper.max_late_sec:
            return self._row(job, started, "late", reason=f"started {late:.1f} s after its time")
        pair = job.pair
        current = [self.market(pair.left_key), self.market(pair.right_key)]
        bases = [current[0] or job.left, current[1] or job.right]
        adapters = [self.adapters.get(m.platform) for m in bases]
        if any(a is None for a in adapters):
            return self._row(job, started, "unsupported", reason="no adapter")
        loop = asyncio.get_running_loop()
        t0 = loop.time()
        results = await asyncio.gather(*(self._fetch(a, m) for a, m in zip(adapters, bases)))
        latency_ms = round((loop.time() - t0) * 1000, 1)
        now = self.clock()
        fresh = [r for r, _ in results]
        errors = [e for _, e in results]
        teams = (job.left_team, job.right_team)
        rest_outcomes = [outcome_of(m, t) if m is not None else None for m, t in zip(fresh, teams)]
        scan_outcomes = [outcome_of(m, t) if m is not None else None for m, t in zip(current, teams)]
        legs_info = self._legs_info(job, bases, fresh, current, errors, rest_outcomes, scan_outcomes, now)
        if any(f is None for f in fresh):
            status = "unsupported" if all(e is None for e in errors) else "error"
            reason = "; ".join(e if e.startswith(m.platform) else f"{m.platform}: {e}"
                               for m, e in zip(bases, errors) if e) or "fetch not supported"
            return self._row(job, started, status, reason=reason, latency_ms=latency_ms, details={"legs": legs_info})
        left, right = fresh[0], fresh[1]
        assert left is not None and right is not None
        stale = self.settings.engine.stale_seconds
        slow = [m.platform for m in (left, right) if not is_fresh(m, now, stale)]
        if slow:  # ответ пришёл позже порога свежести: это не «вилка исчезла», а «данных нет»
            return self._row(job, started, "error", reason=f"slow answer ({', '.join(slow)})", latency_ms=latency_ms,
                             details={"legs": legs_info})
        changed = [m.platform for m, o in zip((left, right), rest_outcomes) if o is None]
        if changed:
            return self._row(job, started, "error", reason=f"teams changed ({', '.join(changed)})",
                             latency_ms=latency_ms, details={"legs": legs_info})
        lo, ro = rest_outcomes
        assert lo is not None and ro is not None
        rest_pair, direction = priced_pair(pair, lo, ro)
        rest = self._quote(rest_pair, left, right, direction, now)
        scanner = None
        if current[0] is not None and current[1] is not None and None not in scan_outcomes:
            scan_pair, scan_direction = priced_pair(pair, scan_outcomes[0], scan_outcomes[1])  # type: ignore[arg-type]
            scanner = self._quote(scan_pair, current[0], current[1], scan_direction, now)
        matched = self._books_match(legs_info) if scanner is not None else None
        details = {"legs": legs_info, "rest_quote": rest["quote"],
                   "scanner_quote": scanner["quote"] if scanner else None}
        row = self._row(job, started, "ok", reason=rest["reason"], latency_ms=latency_ms, details=details)
        quote = rest["quote"]
        row.update({
            "arb_exists": 1 if rest["exists"] else 0,
            "scanner_exists": None if scanner is None else (1 if scanner["exists"] else 0),
            "scanner_profit_usd": scanner["quote"]["profit_usd"] if scanner and scanner["quote"] else None,
            "scanner_volume_usd": scanner["quote"]["volume_usd"] if scanner and scanner["quote"] else None,
            "books_match": None if matched is None else (1 if matched else 0),
        })
        if quote:  # прибыль при ставках — только у оставшейся вилки (иначе её нельзя было бы исполнить)
            inputs = direction_inputs(rest_pair, left, right, direction, self.settings)
            best = optimal(*inputs)
            row.update({
                "profit_usd": quote["profit_usd"],
                "profit_pct": quote["profit_pct"],
                "volume_usd": quote["volume_usd"],
                "contracts": quote["contracts"],
                "optimal_stake_usd": best["stake_usd"] if best else None,
                "optimal_profit_usd": best["profit_usd"] if best else None,
                "stake_profits": to_json(stake_table(*inputs, self.settings.capture.stake_sizes_usd)),
            })
        return row

    async def _fetch(
        self, adapter: MarketAdapter, market: NormalizedMarket
    ) -> tuple[NormalizedMarket | None, str | None]:
        platform = market.platform
        try:
            fresh = await adapter.fetch_book(market)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - ошибка запроса: проверка без данных
            error = describe_error(exc)[:200]
            if platform not in self._failing:
                log.warning("paper checks: %s book request failed: %s", platform, error)
            self._failing.add(platform)
            return None, error
        if platform in self._failing and fresh is not None:
            log.info("paper checks: %s book requests work again", platform)
        self._failing.discard(platform)
        return fresh, None

    def _quote(
        self, pair: MatchedPair, left: NormalizedMarket, right: NormalizedMarket, direction: str, now: datetime,
    ) -> dict[str, Any]:
        """Есть ли вилка этого направления по правилам движка, её котировка и причина, если её нет."""
        found = [o for o in evaluate_pair(pair, left, right, self.settings, now) if o.direction == direction]
        if found:
            opp = found[0]
            quote = {"profit_usd": opp.profit_usd, "profit_pct": opp.profit_pct, "volume_usd": opp.volume_usd,
                     "contracts": opp.contracts, "sum_ask": opp.sum_ask, "cost_per_contract": opp.cost_per_contract}
            return {"exists": True, "quote": quote, "reason": None}
        stale = self.settings.engine.stale_seconds
        for market in (left, right):
            if not is_fresh(market, now, stale):
                return {"exists": False, "quote": None, "reason": f"stale data ({market.platform})"}
            if not market.accepting_orders:
                return {"exists": False, "quote": None, "reason": f"trading paused ({market.platform})"}
        return {"exists": False, "quote": None, "reason": "prices, depth or filters changed"}

    def _legs_info(
        self, job: PaperJob, bases: list[NormalizedMarket], fresh: list[NormalizedMarket | None],
        current: list[NormalizedMarket | None], errors: list[str | None], rest_outcomes: list[str | None],
        scan_outcomes: list[str | None], now: datetime,
    ) -> list[dict[str, Any]]:
        """По каждой ноге: стакан покупаемого исхода из запроса и у сканера, их лучшие уровни, возраст, ошибка."""
        depth = self.settings.capture.book_levels

        def book(m: NormalizedMarket | None, outcome: str | None) -> dict[str, Any] | None:
            if m is None or outcome is None:
                return None
            asks = m.asks_a if outcome == "a" else m.asks_b
            return {
                "buy": outcome,
                "asks": book_levels(asks, depth),
                "best": list(top_of_book(asks) or []) or None,
                "updated_at": m.updated_at.isoformat() if m.updated_at else None,
                "age_sec": round((now - m.updated_at).total_seconds(), 3) if m.updated_at else None,
                "accepting_orders": m.accepting_orders,
            }

        info = []
        teams = (job.left_team, job.right_team)
        for base, rest, scan, error, team, ro, so in zip(bases, fresh, current, errors, teams, rest_outcomes,
                                                         scan_outcomes):
            entry = {"platform": base.platform, "market_id": base.market_id, "outcome": team,
                     "rest": book(rest, ro), "scanner": book(scan, so), "error": error}
            if rest is not None and ro is not None and "book_exchange_ts" in rest.extra:
                entry["exchange_ts"] = rest.extra["book_exchange_ts"].get(ro)
            info.append(entry)
        return info

    @staticmethod
    def _books_match(legs: list[dict[str, Any]]) -> bool | None:
        """Лучшая цена и размер (±1 %) покупаемого исхода совпадают у запроса и сканера на обеих ногах."""
        for leg in legs:
            rest, scan = leg["rest"], leg["scanner"]
            if rest is None or scan is None:
                return None
            if rest["best"] is None or scan["best"] is None:
                if rest["best"] != scan["best"]:
                    return False
                continue
            (p1, s1), (p2, s2) = rest["best"], scan["best"]
            if abs(p1 - p2) > EPS or abs(s1 - s2) > SIZE_TOLERANCE * max(s1, s2):
                return False
        return True

    @staticmethod
    def _row(
        job: PaperJob, checked_at: datetime, status: str, *, reason: str | None = None, latency_ms: float | None = None,
        details: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return {
            "arb_id": job.arb_id,
            "pair_key": job.pair.pair_key,
            "direction": job.direction,
            "first_seen": job.first_seen.isoformat(),
            "confirmed_at": job.confirmed_at.isoformat(),
            "delay_sec": job.delay_sec,
            "actual_delay_sec": round((checked_at - job.confirmed_at).total_seconds(), 3),
            "checked_at": checked_at.isoformat(),
            "status": status,
            "arb_exists": None,
            "reason": reason,
            "confirm_profit_usd": job.confirm_profit_usd,
            "confirm_volume_usd": job.confirm_volume_usd,
            "latency_ms": latency_ms,
            "details": to_json(details) if details is not None else None,
        }
