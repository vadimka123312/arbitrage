"""Lifetime tracking of arbitrage opportunities (the "N seconds" rule).

An arb is *confirmed* only after it has existed continuously for ``confirm_seconds``.
When it disappears (or its data turns stale, which makes it disappear from the input),
the timer is reset and a ``ClosedArb`` record is produced for the history table.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from backend.models import ArbOpportunity, ClosedArb, TrackedArb


@dataclass
class TrackerUpdate:
    """Result of one tracker step."""

    active: list[TrackedArb] = field(default_factory=list)
    closed: list[ClosedArb] = field(default_factory=list)
    newly_confirmed: list[TrackedArb] = field(default_factory=list)


class ArbTracker:
    """Keeps ``first_seen`` / ``last_seen`` and max stats for every live arb."""

    def __init__(self, confirm_seconds: float = 5.0):
        self.confirm_seconds = confirm_seconds
        self._active: dict[str, TrackedArb] = {}

    @property
    def active(self) -> dict[str, TrackedArb]:
        """Currently tracked arbs by id."""
        return self._active

    def update(self, current: list[ArbOpportunity], now: datetime) -> TrackerUpdate:
        """Feed the arbs detected at ``now``; return active/closed/newly confirmed arbs."""
        result = TrackerUpdate()
        seen: set[str] = set()
        for opp in current:
            if opp.arb_id in seen:
                continue
            seen.add(opp.arb_id)
            tracked = self._active.get(opp.arb_id)
            if tracked is None:
                tracked = TrackedArb(
                    arb_id=opp.arb_id,
                    first_seen=now,
                    last_seen=now,
                    max_profit_pct=opp.profit_pct,
                    max_volume_usd=opp.volume_usd,
                    max_profit_usd=opp.profit_usd,
                    current=opp,
                )
                self._active[opp.arb_id] = tracked
            else:
                tracked.last_seen = now
                tracked.current = opp
                tracked.max_profit_pct = max(tracked.max_profit_pct, opp.profit_pct)
                tracked.max_volume_usd = max(tracked.max_volume_usd, opp.volume_usd)
                tracked.max_profit_usd = max(tracked.max_profit_usd, opp.profit_usd)
            tracked.age_sec = round((now - tracked.first_seen).total_seconds(), 3)
            was_confirmed = tracked.confirmed
            tracked.confirmed = tracked.age_sec >= self.confirm_seconds
            if tracked.confirmed and not was_confirmed:
                tracked.confirmed_at = now
                result.newly_confirmed.append(tracked)
            if not tracked.confirmed:
                tracked.confirmed_at = None

        for arb_id in list(self._active):
            if arb_id in seen:
                continue
            tracked = self._active.pop(arb_id)
            lifetime = (tracked.last_seen - tracked.first_seen).total_seconds()
            result.closed.append(
                ClosedArb(
                    arb_id=arb_id,
                    first_seen=tracked.first_seen,
                    last_seen=tracked.last_seen,
                    lifetime_sec=round(lifetime, 3),
                    confirmed=lifetime >= self.confirm_seconds,
                    max_profit_pct=tracked.max_profit_pct,
                    max_volume_usd=tracked.max_volume_usd,
                    max_profit_usd=tracked.max_profit_usd,
                    last=tracked.current,
                )
            )

        result.active = sorted(self._active.values(), key=lambda t: -t.current.profit_pct)
        return result

    def close_all(self, now: datetime) -> list[ClosedArb]:
        """Close every active arb (used on shutdown)."""
        return self.update([], now).closed
