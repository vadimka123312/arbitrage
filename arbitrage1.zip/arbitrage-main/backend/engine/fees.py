"""Trading-fee models.

* Polymarket (taker only, Oct 2026): ``fee = C * rate * (p * (1 - p)) ** exponent``,
  rounded to 5 decimals; ``rate``/``exponent`` come from the market ``feeSchedule``
  (sports: rate 0.05, exponent 1).
* Kalshi (taker, ``fee_type: quadratic``): ``fee = roundup_cent(rate * M * C * P * (1 - P))``
  with ``rate = 0.07`` and ``M = fee_multiplier`` of the series.
"""

from __future__ import annotations

import math

from backend.config import PlatformFeeConfig
from backend.models import FeeSpec


def round_up_cents(value: float) -> float:
    """Round a dollar amount up to the next cent (float-safe)."""
    if value <= 0:
        return 0.0
    return math.ceil(round(value * 100, 9)) / 100


def marginal_fee_per_contract(spec: FeeSpec, price: float) -> float:
    """Fee per contract at ``price`` without any rounding."""
    if price <= 0 or price >= 1:
        return 0.0
    if spec.model == "polymarket":
        return spec.rate * (price * (1 - price)) ** spec.exponent
    if spec.model == "kalshi":
        return spec.rate * spec.multiplier * price * (1 - price)
    if spec.model == "flat":
        return spec.flat_per_contract
    return 0.0


def _finish(spec: FeeSpec, raw: float) -> float:
    if spec.round_up_cents:
        return round_up_cents(raw)
    if spec.model == "polymarket":
        return round(raw, 5)  # Polymarket fee precision
    return raw


def fee_usd(spec: FeeSpec, price: float, contracts: float) -> float:
    """Total taker fee in dollars for one fill of ``contracts`` at ``price``."""
    if contracts <= 0:
        return 0.0
    return _finish(spec, contracts * marginal_fee_per_contract(spec, price))


def fee_usd_fills(spec: FeeSpec, fills: list[tuple[float, float]]) -> float:
    """Fee for one order that sweeps several price levels ``[(price, contracts), ...]``.

    Polymarket charges each fill separately; Kalshi accumulates rounding per order, so the
    total converges to one rounded fee for the whole order.
    """
    if spec.model == "polymarket":
        return round(sum(fee_usd(spec, p, c) for p, c in fills if c > 0), 5)
    raw = sum(c * marginal_fee_per_contract(spec, p) for p, c in fills if c > 0)
    return _finish(spec, raw)


def effective_fee_spec(spec: FeeSpec, override: PlatformFeeConfig | None) -> FeeSpec:
    """Apply config overrides (``fees.<platform>``) to the fee spec published by a market."""
    if override is None:
        return spec
    changes: dict[str, object] = {}
    if override.taker_rate is not None:
        changes["rate"] = override.taker_rate
        if spec.model == "none":
            changes["model"] = "polymarket"
    if override.exponent is not None:
        changes["exponent"] = override.exponent
    if override.round_up_cents is not None:
        changes["round_up_cents"] = override.round_up_cents
    return spec.model_copy(update=changes) if changes else spec
