"""Kalshi adapter.

* Discovery: ``GET /events?series_ticker=<KX...GAME>&status=open&with_nested_markets=true``.
  One esports match = one event with two binary markets (one per team).
* Prices: batched ``GET /markets/orderbooks?tickers=...`` polling (no auth, up to 100 markets per
  request). Optional authenticated WebSocket (``orderbook_delta``) when API keys are configured.
* Prices are fixed-point dollar strings; books contain bids only:
  ask(YES) = 1 - best NO bid, ask(NO) = 1 - best YES bid.
* "Team A wins" can be bought as YES on A's market or NO on B's market; both books are merged
  (``use_no_side_of_opponent``) so the cheapest instrument is used.
"""

from __future__ import annotations

import asyncio
import base64
import json
import os
import re
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import websockets

from backend.adapters.base import MarketAdapter, PriceCallback
from backend.adapters.common import parse_best_of, slugify, split_teams, to_float
from backend.config import PlatformConfig, Settings
from backend.matching.normalizer import TeamNormalizer
from backend.models import FeeSpec, Level, NormalizedMarket, utcnow
from backend.net import HttpClient, backoff_delay, describe_error

EASTERN = ZoneInfo("America/New_York")
MONTHS = {m: i for i, m in enumerate(
    ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"], start=1)}
_TICKER_TIME_RE = re.compile(r"-(\d{2})([A-Z]{3})(\d{2})(\d{4})")
_RULES_TIME_RE = re.compile(
    r"scheduled for ([A-Z][a-z]{2,8})\.? (\d{1,2}), (\d{4})(?: at (\d{1,2}):(\d{2}) ?([AP]M) ?([A-Z]{2,4})?)?"
)
_TOURNAMENT_RE = re.compile(r"\bwins the (.+?): ")

Book = dict[str, list[tuple[float, float]]]  # {"yes": [(price, size) best first], "no": [...]}


def parse_ticker_time(event_ticker: str) -> datetime | None:
    """``KXCS2GAME-26OCT160400TLNIP`` -> 2026-10-16 04:00 America/New_York (as UTC)."""
    match = _TICKER_TIME_RE.search(event_ticker or "")
    if not match:
        return None
    yy, mon, dd, hhmm = match.groups()
    month = MONTHS.get(mon)
    if month is None:
        return None
    try:
        local = datetime(2000 + int(yy), month, int(dd), int(hhmm[:2]), int(hhmm[2:]), tzinfo=EASTERN)
    except ValueError:
        return None
    return local.astimezone(timezone.utc)


def parse_rules_time(text: str) -> datetime | None:
    """"originally scheduled for Oct 15, 2026 at 4:00 AM EDT" -> aware UTC datetime."""
    match = _RULES_TIME_RE.search(text or "")
    if not match:
        return None
    mon, day, year, hour, minute, ampm, _tz = match.groups()
    month = MONTHS.get(mon[:3].upper())
    if month is None or hour is None:
        return None
    h = int(hour) % 12 + (12 if ampm == "PM" else 0)
    try:
        local = datetime(int(year), month, int(day), h, int(minute), tzinfo=EASTERN)
    except ValueError:
        return None
    return local.astimezone(timezone.utc)


def parse_book(orderbook: dict[str, Any]) -> Book:
    """Parse ``orderbook_fp`` (or the legacy integer-cent ``orderbook``) into bids, best first."""
    out: Book = {"yes": [], "no": []}
    for side in ("yes", "no"):
        levels = orderbook.get(f"{side}_dollars")
        if levels is None:
            levels = orderbook.get(f"{side}_dollars_fp")
        if levels is None and orderbook.get(side) is not None:  # legacy cents
            levels = [[float(p) / 100.0, q] for p, q in orderbook.get(side) or []]
        parsed = []
        for level in levels or []:
            price, size = to_float(level[0]), to_float(level[1])
            if price is not None and size is not None and size > 0:
                parsed.append((price, size))
        parsed.sort(key=lambda x: -x[0])
        out[side] = parsed
    return out


def instrument_label(side: str, team: str) -> str:
    """Подпись инструмента в стакане: ``YES «A»`` (YES на рынке A) или ``NO «B»`` (NO на рынке B)."""
    return f"{side} «{team}»"


def book_from_market(market: dict[str, Any]) -> Book:
    """Top-of-book from a market object (``yes_bid_dollars`` etc.)."""
    yes_bid = to_float(market.get("yes_bid_dollars"))
    yes_ask = to_float(market.get("yes_ask_dollars"))
    book: Book = {"yes": [], "no": []}
    if yes_bid and yes_bid > 0:
        book["yes"].append((yes_bid, to_float(market.get("yes_bid_size_fp")) or 0.0))
    if yes_ask and 0 < yes_ask < 1:
        # A YES ask at p is a NO bid at 1 - p.
        book["no"].append((round(1 - yes_ask, 4), to_float(market.get("yes_ask_size_fp")) or 0.0))
    return book


WS_STABLE_SECONDS = 30.0  # a stream must stay up this long before its reconnect backoff resets


class KalshiAdapter(MarketAdapter):
    """Kalshi esports match-winner events."""

    def __init__(self, platform_id: str, cfg: PlatformConfig, settings: Settings):
        super().__init__(platform_id, cfg, settings)
        self.base_url = str(cfg.opt("rest_url", "https://external-api.kalshi.com/trade-api/v2")).rstrip("/")
        self.http = HttpClient(self.base_url, "kalshi", float(cfg.opt("rate_limit_per_sec", 10)))
        self.web_url = str(cfg.opt("web_url", "https://kalshi.com")).rstrip("/")
        self.ws_url = str(cfg.opt("ws_url", "wss://external-api-ws.kalshi.com/trade-api/ws/v2"))
        self.poll_sec = float(cfg.opt("poll_interval_sec", 1.5))
        self.batch = min(100, int(cfg.opt("orderbook_batch_size", 100)))
        self.depth = int(cfg.opt("book_depth", 10))
        self.use_no_side = bool(cfg.opt("use_no_side_of_opponent", True))
        self.taker_rate = float(cfg.opt("taker_fee_rate", 0.07))
        self.min_contracts = float(cfg.opt("min_contracts", 1.0))
        self.key_id = os.getenv("KALSHI_API_KEY_ID", "").strip()
        self.key_path = os.getenv("KALSHI_PRIVATE_KEY_PATH", "").strip()
        ws_opt = str(cfg.opt("use_websocket", "auto")).lower()
        has_keys = bool(self.key_id and self.key_path)
        self.use_ws = ws_opt == "force" or (ws_opt in ("auto", "true", "yes", "1") and has_keys)
        self.status.mode = "ws" if self.use_ws else "rest"
        self.series_meta: dict[str, dict[str, Any]] = {}
        self._series_checked: dict[str, float] = {}
        self.books: dict[str, Book] = {}
        self.book_ts: dict[str, datetime] = {}  # when each book was last received
        self.trading_active: dict[int, bool] = {}  # exchange_index -> trading active (from /exchange/status)
        self._status_checked = 0.0
        # Tickers whose books the current WebSocket connection maintains (snapshot + deltas). The stream is
        # the only writer for them: REST polling skips them, so a slower poll cannot overwrite a newer book.
        self._ws_owned: set[str] = set()
        self._poll_task: asyncio.Task[Any] | None = None
        self._ws_task: asyncio.Task[Any] | None = None
        self._ws_tickers: frozenset[str] = frozenset()
        self._name_sim = TeamNormalizer()

    async def stop(self) -> None:
        await super().stop()
        await self.http.aclose()

    # ---- discovery -------------------------------------------------------------------

    async def _series(self, ticker: str) -> dict[str, Any]:
        checked = self._series_checked.get(ticker, 0.0)
        if ticker in self.series_meta and time.monotonic() - checked < 3600:
            return self.series_meta[ticker]
        try:
            data = await self.http.get_json(f"/series/{ticker}")
            series = data.get("series") if isinstance(data, dict) else None
            if not isinstance(series, dict):
                raise ValueError("Kalshi: malformed series response")
            self.series_meta[ticker] = series
        except Exception as exc:  # noqa: BLE001
            self.log.warning("series %s metadata unavailable: %s", ticker, exc)
            self.series_meta.setdefault(ticker, {})
            return self.series_meta[ticker]
        self._series_checked[ticker] = time.monotonic()
        return self.series_meta[ticker]

    async def refresh_exchange_status(self) -> None:
        """Read ``/exchange/status`` (public) so paused trading blocks arbs (e.g. weekly maintenance)."""
        # Also counts a failed check: a flaky status endpoint is retried in 30 s, not before every book poll.
        self._status_checked = time.monotonic()
        try:
            data = await self.http.get_json("/exchange/status", retries=1)
        except Exception as exc:  # noqa: BLE001 - keep the last known state
            self.log.warning("exchange status unavailable: %s", exc)
            return
        if not isinstance(data, dict):
            self.log.warning("exchange status: unexpected response (%s)", type(data).__name__)
            return
        overall = bool(data.get("exchange_active", True)) and bool(data.get("trading_active", True))
        statuses = {-1: overall}
        for item in data.get("exchange_index_statuses") or []:
            try:
                index = int(item.get("exchange_index"))
            except (TypeError, ValueError):
                continue
            statuses[index] = overall and bool(item.get("exchange_active", True)) and bool(item.get("trading_active", True))
        self.trading_active = statuses
        for market in self._subscribed.values():
            market.accepting_orders = self._is_trading(market.extra.get("exchange_index"))

    def _is_trading(self, exchange_index: Any) -> bool:
        if not self.trading_active:
            return True
        try:
            return self.trading_active.get(int(exchange_index), self.trading_active.get(-1, True))
        except (TypeError, ValueError):
            return self.trading_active.get(-1, True)

    async def _fetch_events(self, series: str) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        cursor: str | None = None
        for _ in range(10):
            params: dict[str, Any] = {
                "series_ticker": series, "status": "open", "with_nested_markets": "true", "limit": 200,
            }
            if cursor:
                params["cursor"] = cursor
            data = await self.http.get_json("/events", params=params)
            page = data.get("events") if isinstance(data, dict) else None
            if not isinstance(page, list):
                raise ValueError("Kalshi: malformed events response (expected an events list)")
            events.extend(page)
            cursor = data.get("cursor") or None
            if not cursor:
                return events
        raise ValueError("Kalshi: events pagination limit reached before the last page")

    async def fetch_markets(self) -> list[NormalizedMarket]:
        """Discover open match-winner events for every configured game."""
        await self.refresh_exchange_status()
        markets: list[NormalizedMarket] = []
        for game, flt in self.game_filters().items():
            for series in flt.get("series_tickers", []) or []:
                meta = await self._series(series)
                for event in await self._fetch_events(series):
                    markets.extend(self._normalize_event(event, game, series, meta))
        self.status.markets = len(markets)
        if not self.use_ws:
            self.status.latency_ms = self.http.last_latency_ms
        return markets

    def normalize(self, raw: Any) -> list[NormalizedMarket]:
        """Normalise one Kalshi event (game inferred from its series ticker)."""
        series = str(raw.get("series_ticker") or "")
        for game, flt in self.game_filters().items():
            if series in (flt.get("series_tickers") or []):
                return self._normalize_event(raw, game, series, self.series_meta.get(series, {}))
        return []

    def _order_markets(self, title: str, markets: list[dict[str, Any]]) -> list[dict[str, Any]]:
        teams = split_teams(title)
        if not teams:
            return markets
        first = markets[0].get("yes_sub_title") or ""
        second = markets[1].get("yes_sub_title") or ""
        direct = self._name_sim.similarity(teams[0], first) + self._name_sim.similarity(teams[1], second)
        crossed = self._name_sim.similarity(teams[0], second) + self._name_sim.similarity(teams[1], first)
        return markets if direct >= crossed else [markets[1], markets[0]]

    def _normalize_event(
        self, event: dict[str, Any], game: str, series: str, meta: dict[str, Any]
    ) -> list[NormalizedMarket]:
        raw_markets = [m for m in event.get("markets") or [] if m.get("status") in ("active", "open")]
        if len(raw_markets) != 2:
            return []  # e.g. a 3-way market with a draw, or a settled leg
        title = str(event.get("title") or "")
        market_a, market_b = self._order_markets(title, raw_markets)
        team_a = str(market_a.get("yes_sub_title") or market_a.get("title") or "").strip()
        team_b = str(market_b.get("yes_sub_title") or market_b.get("title") or "").strip()
        if not team_a or not team_b:
            return []
        event_ticker = str(event.get("event_ticker") or "")
        rules_primary = str(market_a.get("rules_primary") or "")
        start = parse_rules_time(rules_primary) or parse_ticker_time(event_ticker)
        disc = self.settings.discovery
        now = utcnow()
        if start is not None:
            if start > now + timedelta(hours=disc.horizon_hours):
                return []
            if start < now - timedelta(hours=disc.live_grace_hours):
                return []
        tournament_match = _TOURNAMENT_RE.search(rules_primary)
        series_title = str(meta.get("title") or series)
        url = f"{self.web_url}/markets/{series.lower()}/{slugify(series_title)}/{event_ticker.lower()}"
        multiplier = to_float(meta.get("fee_multiplier"))
        fee_multiplier = 1.0 if multiplier is None else multiplier
        if meta.get("fee_type") not in (None, "quadratic", "quadratic_with_maker_fees", "quadratic_with_combo_maker_fees"):
            self.log.debug("series %s has fee_type %s; using the quadratic taker formula", series, meta.get("fee_type"))
        market = NormalizedMarket(
            platform=self.platform,
            market_id=event_ticker,
            event_title=title,
            game=game,
            team_a=team_a,
            team_b=team_b,
            start_time=start,
            url=url,
            resolution_rules=f"{rules_primary}\n{market_a.get('rules_secondary') or ''}".strip(),
            tournament=tournament_match.group(1).strip() if tournament_match else None,
            best_of=parse_best_of(rules_primary, market_a.get("rules_secondary")),
            min_order_size=self.min_contracts,
            fee=FeeSpec(model="kalshi", rate=self.taker_rate, multiplier=fee_multiplier, round_up_cents=True),
            accepting_orders=self._is_trading(event.get("exchange_index")),
            extra={
                "ticker_a": market_a.get("ticker"),
                "ticker_b": market_b.get("ticker"),
                "series_ticker": series,
                "event_ticker": event_ticker,
                "mutually_exclusive": bool(event.get("mutually_exclusive", True)),
                "exchange_index": event.get("exchange_index"),
            },
        )
        # Prefer the cached full-depth books when they are recent; otherwise use the top of book
        # that came with this very response (it is current as of now, but only one level deep).
        ticker_a, ticker_b = str(market.extra["ticker_a"]), str(market.extra["ticker_b"])
        cached = [self.book_ts.get(ticker_a), self.book_ts.get(ticker_b)]
        recent = all(ts is not None and (now - ts).total_seconds() <= self.settings.engine.stale_seconds for ts in cached)
        if not (recent and self._apply_books(market)):
            self._set_books(market, book_from_market(market_a), book_from_market(market_b), now)
        return [market]

    # ---- books -----------------------------------------------------------------------

    def _set_books(self, market: NormalizedMarket, book_a: Book, book_b: Book, ts: datetime) -> None:
        team_a, team_b = market.team_a, market.team_b
        yes_a, yes_b = instrument_label("YES", team_a), instrument_label("YES", team_b)
        asks_a = [Level(price=round(1 - p, 4), size=s, instrument=yes_a) for p, s in book_a["no"]]
        asks_b = [Level(price=round(1 - p, 4), size=s, instrument=yes_b) for p, s in book_b["no"]]
        bid_a = book_a["yes"][0][0] if book_a["yes"] else None
        bid_b = book_b["yes"][0][0] if book_b["yes"] else None
        if self.use_no_side and market.extra.get("mutually_exclusive", True):
            # NO on B pays when A wins (two-team event): its ask is 1 - best YES bid of B.
            no_a, no_b = instrument_label("NO", team_a), instrument_label("NO", team_b)
            asks_a += [Level(price=round(1 - p, 4), size=s, instrument=no_b) for p, s in book_b["yes"]]
            asks_b += [Level(price=round(1 - p, 4), size=s, instrument=no_a) for p, s in book_a["yes"]]
            no_bid_b = book_b["no"][0][0] if book_b["no"] else None
            no_bid_a = book_a["no"][0][0] if book_a["no"] else None
            bid_a = max((b for b in (bid_a, no_bid_b) if b is not None), default=None)
            bid_b = max((b for b in (bid_b, no_bid_a) if b is not None), default=None)
        asks_a.sort(key=lambda lv: (lv.price, not (lv.instrument or "").startswith("YES")))
        asks_b.sort(key=lambda lv: (lv.price, not (lv.instrument or "").startswith("YES")))
        market.set_books(asks_a[: self.depth], asks_b[: self.depth], bid_a, bid_b, ts)
        market.extra["timestamp_kind"] = "local_confirmation_of_coherent_book_state"
        market.extra["source_book_timestamp"] = None
        market.extra["actual_price_change_at"] = None

    async def fetch_book(self, market: NormalizedMarket) -> NormalizedMarket | None:
        """Оба стакана события одним запросом ``/markets/orderbooks`` без повторов (кэш стаканов не меняется)."""
        tickers = [str(market.extra.get("ticker_a") or ""), str(market.extra.get("ticker_b") or "")]
        if not all(tickers):
            raise ValueError("market has no tickers")
        asked = utcnow()
        data = await self.http.get_json("/markets/orderbooks", params=[("tickers", t) for t in tickers], retries=0)
        books: dict[str, Book] = {}
        for item in (data.get("orderbooks") if isinstance(data, dict) else None) or []:
            if isinstance(item, dict):
                books[str(item.get("ticker"))] = parse_book(item.get("orderbook_fp") or item.get("orderbook") or {})
        missing = [t for t in tickers if t not in books]
        if missing:
            raise ValueError(f"no orderbook for {', '.join(missing)}")
        copy = market.model_copy(deep=True)
        self._set_books(copy, books[tickers[0]], books[tickers[1]], asked)
        return copy

    def instrument_ids(self, market: NormalizedMarket) -> dict[str, str]:
        """Тикер и сторона для каждой подписи уровня: «YES «A»» → ``<тикер A> YES``, «NO «B»» → ``<тикер B> NO``."""
        out: dict[str, str] = {}
        tickers = ((market.team_a, market.extra.get("ticker_a")), (market.team_b, market.extra.get("ticker_b")))
        for team, ticker in tickers:
            if ticker:
                out[instrument_label("YES", team)] = f"{ticker} YES"
                out[instrument_label("NO", team)] = f"{ticker} NO"
        return out

    def _apply_books(self, market: NormalizedMarket) -> bool:
        """Copy cached books into the market, stamped with when the older one was received."""
        ticker_a, ticker_b = str(market.extra.get("ticker_a")), str(market.extra.get("ticker_b"))
        book_a, book_b = self.books.get(ticker_a), self.books.get(ticker_b)
        ts_a, ts_b = self.book_ts.get(ticker_a), self.book_ts.get(ticker_b)
        if book_a is None or book_b is None or ts_a is None or ts_b is None:
            return False
        self._set_books(market, book_a, book_b, min(ts_a, ts_b))
        return True

    async def subscribe_prices(self, markets: list[NormalizedMarket], on_update: PriceCallback) -> None:
        """Poll (or stream) the order books of ``markets``."""
        self._callback = on_update
        self._subscribed = {m.key: m for m in markets}
        wanted = {str(t) for m in markets for t in (m.extra.get("ticker_a"), m.extra.get("ticker_b")) if t}
        self.books = {t: b for t, b in self.books.items() if t in wanted}
        self.book_ts = {t: ts for t, ts in self.book_ts.items() if t in wanted}
        if self.use_ws:
            tickers = frozenset(
                str(t) for m in markets for t in (m.extra.get("ticker_a"), m.extra.get("ticker_b")) if t
            )
            if tickers != self._ws_tickers or self._ws_task is None or self._ws_task.done():
                if self._ws_task is not None:
                    self._ws_task.cancel()
                self._ws_tickers = tickers
                self._ws_task = self.spawn(self._ws_loop(sorted(tickers)), "ws")
        if self._poll_task is None or self._poll_task.done():
            self._poll_task = self.spawn(self._poll_loop(), "poll")

    async def _poll_loop(self) -> None:
        last_ok = time.monotonic()  # last successful poll (the start counts): the data gap of an outage
        failing = False
        while self._running:
            started = time.monotonic()
            try:
                if time.monotonic() - self._status_checked > 30:
                    await self.refresh_exchange_status()
                polled = await self.poll_once()
                if polled:
                    self.status.connected = True
                    self.status.error = None
                if polled and failing:
                    self.log.info("orderbook polling recovered, no data for %.1f s", time.monotonic() - last_ok)
                # Nothing to poll (the stream has every book) also ends an outage, without a log line.
                failing, last_ok = False, time.monotonic()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.log.warning("orderbook poll failed: %s", describe_error(exc))
                failing = True
                self.status.connected = False
                self.status.error = f"poll: {describe_error(exc)}"[:200]
            await asyncio.sleep(max(0.1, self.poll_sec - (time.monotonic() - started)))

    async def poll_once(self) -> bool:
        """Fetch the subscribed order books not covered by the WebSocket (batched) and update the markets.

        Returns False when there was nothing to poll (the stream maintains every book).
        """
        markets = list(self._subscribed.values())
        tickers = [
            str(t) for m in markets for t in (m.extra.get("ticker_a"), m.extra.get("ticker_b"))
            if t and str(t) not in self._ws_owned
        ]
        if not tickers:
            return False
        pending: dict[str, tuple[Book, datetime, datetime | None]] = {}
        for idx in range(0, len(tickers), self.batch):
            batch = tickers[idx: idx + self.batch]
            before = {ticker: self.book_ts.get(ticker) for ticker in batch}
            data = await self.http.get_json("/markets/orderbooks", params=[("tickers", t) for t in batch])
            rows = data.get("orderbooks") if isinstance(data, dict) else None
            if not isinstance(rows, list):
                raise ValueError("Kalshi: malformed orderbooks response (expected an orderbooks list)")
            batch_time = utcnow()  # when THIS batch arrived
            updates: dict[str, Book] = {}
            for item in rows:
                if not isinstance(item, dict):
                    continue
                ticker = str(item.get("ticker"))
                raw = item.get("orderbook_fp") if "orderbook_fp" in item else item.get("orderbook")
                if ticker not in batch or not isinstance(raw, dict):
                    continue
                updates[ticker] = parse_book(raw)
            missing = set(batch) - updates.keys() - self._ws_owned
            if missing:
                raise ValueError(f"Kalshi: incomplete orderbooks response ({len(missing)} ticker(s) missing)")
            pending.update({ticker: (book, batch_time, before[ticker]) for ticker, book in updates.items()})
        received: set[str] = set()
        for ticker, (book, stamp, before) in pending.items():
            # A stream update during this multi-batch pass wins even if the stream disconnected before this commit.
            if ticker in self._ws_owned or self.book_ts.get(ticker) != before:
                continue
            self.books[ticker] = book
            self.book_ts[ticker] = stamp
            received.add(ticker)
        for market in markets:
            # Markets with a book from this poll; the older of the two books stamps the market, so a ticker
            # missing from the response keeps the market as old as its oldest book.
            if received & {str(market.extra.get("ticker_a")), str(market.extra.get("ticker_b"))}:
                if self._apply_books(market):
                    self.notify(market)
        self.status.last_update = utcnow()
        self.status.latency_ms = self.http.last_latency_ms
        return True

    # ---- optional authenticated WebSocket --------------------------------------------

    def _auth_headers(self) -> dict[str, str]:
        try:
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import ed25519, padding
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError("pip install cryptography to use the Kalshi WebSocket") from exc
        key = serialization.load_pem_private_key(Path(self.key_path).read_bytes(), password=None)
        timestamp = str(int(time.time() * 1000))
        message = (timestamp + "GET" + "/trade-api/ws/v2").encode("utf-8")
        if isinstance(key, ed25519.Ed25519PrivateKey):
            signature = key.sign(message)
        else:
            signature = key.sign(  # type: ignore[call-arg, union-attr]
                message,
                padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH),
                hashes.SHA256(),
            )
        return {
            "KALSHI-ACCESS-KEY": self.key_id,
            "KALSHI-ACCESS-SIGNATURE": base64.b64encode(signature).decode("ascii"),
            "KALSHI-ACCESS-TIMESTAMP": timestamp,
        }

    async def _ws_loop(self, tickers: list[str]) -> None:
        attempt = 0
        while self._running:
            snapshotted: set[str] = set()  # tickers that got a snapshot on THIS connection
            seqs: dict[int, int] = {}
            try:
                async with websockets.connect(
                    self.ws_url, additional_headers=self._auth_headers(), open_timeout=15, ping_interval=10
                ) as ws:
                    await ws.send(json.dumps({
                        "id": 1, "cmd": "subscribe",
                        "params": {"channels": ["orderbook_delta"], "market_tickers": tickers},
                    }))
                    self.status.connected = True
                    self._ws_owned = snapshotted  # the stream owns each book from its snapshot on
                    opened = time.monotonic()
                    keepalive = asyncio.create_task(self._ws_keepalive(ws, snapshotted))
                    try:
                        async for raw in ws:
                            result = self._on_ws_message(raw, snapshotted, seqs)
                            if result == "resync":
                                self.log.warning("kalshi ws: sequence gap or error, resubscribing")
                                break
                            if result == "data":
                                # Reset the backoff only for a stream that stayed up: a server that sends an
                                # error frame shortly after the first snapshots must not cause a reconnect loop.
                                if attempt and time.monotonic() - opened > WS_STABLE_SECONDS:
                                    attempt = 0
                                self.status.error = None
                    finally:
                        keepalive.cancel()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - reconnect on any error
                self.log.warning("kalshi ws error: %s (REST polling covers the gap)", describe_error(exc))
                self.status.error = f"ws: {describe_error(exc)}"[:200]
            finally:
                if self._ws_owned is snapshotted:
                    self._ws_owned = set()  # REST polling takes these books over until the stream is back
            self.status.connected = False
            await asyncio.sleep(backoff_delay(attempt, base=1.0, cap=30.0))
            attempt += 1

    async def _ws_keepalive(self, ws: Any, snapshotted: set[str]) -> None:
        """While pings succeed the stream is alive, so books snapshotted on it are still current."""
        while True:
            await asyncio.sleep(5)
            started = time.monotonic()
            try:
                waiter = await ws.ping()
                await asyncio.wait_for(waiter, timeout=5)
            except Exception:  # noqa: BLE001 - dead connection: close it so the loop reconnects
                await ws.close()
                return
            self.status.latency_ms = round((time.monotonic() - started) * 1000, 1)
            now = utcnow()
            for ticker in snapshotted:
                if ticker in self.books:
                    self.book_ts[ticker] = now
            for market in self._subscribed.values():
                if {str(market.extra.get("ticker_a")), str(market.extra.get("ticker_b"))} <= snapshotted:
                    self._apply_books(market)
            self.status.last_update = now

    def _on_ws_message(self, raw: Any, snapshotted: set[str] | None = None, seqs: dict[int, int] | None = None) -> str:
        """Apply one frame. Returns "data", "resync" (seq gap / error) or "" (ignored)."""
        snapshotted = snapshotted if snapshotted is not None else set()
        seqs = seqs if seqs is not None else {}
        try:
            data = json.loads(raw)
        except ValueError:
            return ""
        if not isinstance(data, dict):
            return ""
        kind = data.get("type")
        msg = data.get("msg") or {}
        if kind == "error":
            self.log.warning("kalshi ws error message: %s", msg)
            self.status.error = f"ws: {msg}"[:200]
            return "resync"
        if kind not in ("orderbook_snapshot", "orderbook_delta"):
            return ""
        sid, seq = data.get("sid"), data.get("seq")
        if isinstance(sid, int) and isinstance(seq, int):
            # One sequence per subscription across all its tickers (snapshots included): any gap means
            # a missed frame, possibly for another ticker.
            if sid in seqs and seq != seqs[sid] + 1:
                return "resync"
            seqs[sid] = seq
        ticker = str(msg.get("market_ticker") or "")
        if kind == "orderbook_snapshot":
            self.books[ticker] = parse_book(msg)
            snapshotted.add(ticker)
        else:
            book = self.books.get(ticker)
            price, delta = to_float(msg.get("price_dollars")), to_float(msg.get("delta_fp"))
            side = str(msg.get("side") or "")
            if book is None or ticker not in snapshotted or price is None or delta is None or side not in ("yes", "no"):
                return ""
            levels = dict(book[side])
            levels[price] = round(levels.get(price, 0.0) + delta, 2)
            book[side] = sorted(((p, q) for p, q in levels.items() if q > 0), key=lambda x: -x[0])
        now = utcnow()
        self.book_ts[ticker] = now
        for market in self._subscribed.values():
            if ticker in (market.extra.get("ticker_a"), market.extra.get("ticker_b")):
                if self._apply_books(market):
                    self.notify(market)
        self.status.last_update = now
        return "data"
