"""Polymarket adapter.

* Discovery: Gamma ``GET /events?series_id=<game series>&closed=false&end_date_min=<now>``;
  only ``sportsMarketType == "moneyline"`` (match winner) markets are used.
* Prices: CLOB market WebSocket (``book`` snapshots + ``price_change`` deltas) with an
  application-level ``PING`` every few seconds, plus a periodic REST ``POST /books`` resync.
  With ``use_websocket: false`` the REST refresh becomes the only (polling) price source.
"""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Any

import websockets

from backend.adapters.base import MarketAdapter, PriceCallback
from backend.adapters.common import json_list, parse_best_of, parse_dt, to_float
from backend.config import PlatformConfig, Settings
from backend.models import FeeSpec, Level, NormalizedMarket, utcnow
from backend.net import HttpClient, backoff_delay, describe_error


class TokenBook:
    """Local order book of one outcome token."""

    __slots__ = ("bids", "asks", "ts", "ready", "received_at")

    def __init__(self) -> None:
        self.bids: dict[float, float] = {}
        self.asks: dict[float, float] = {}
        self.ts = 0  # exchange timestamp (ms) of the last applied message
        self.ready = False
        self.received_at: datetime | None = None  # when we last got data confirming this book

    @staticmethod
    def _levels(raw: list[dict[str, Any]]) -> dict[float, float]:
        levels: dict[float, float] = {}
        for item in raw:
            if not isinstance(item, dict):
                continue
            price, size = to_float(item.get("price")), to_float(item.get("size"))
            if price is not None and size is not None and size > 0:
                levels[price] = size
        return levels

    def snapshot(
        self, bids: list[dict[str, Any]], asks: list[dict[str, Any]], ts: int, received_at: datetime | None = None
    ) -> bool:
        """Replace the book unless the snapshot is older than what we have."""
        if ts and ts < self.ts:
            return False
        self.bids = self._levels(bids)
        self.asks = self._levels(asks)
        self.ts = max(self.ts, ts)
        self.ready = True
        self.received_at = received_at or utcnow()
        return True

    def apply(self, price: float, size: float, side: str, ts: int, received_at: datetime | None = None) -> bool:
        """Set one price level (size 0 removes it). Unknown sides are ignored."""
        side = side.upper()
        if side not in ("BUY", "SELL"):
            return False
        book = self.bids if side == "BUY" else self.asks
        if size <= 0:
            book.pop(price, None)
        else:
            book[price] = size
        self.ts = max(self.ts, ts)
        self.received_at = received_at or utcnow()
        return True

    def top_asks(self, depth: int) -> list[tuple[float, float]]:
        return sorted(self.asks.items())[:depth]

    def best_bid(self) -> float | None:
        return max(self.bids) if self.bids else None


class WsConn:
    """Per-connection heartbeat state."""

    __slots__ = ("ready", "last_pong", "ping_sent")

    def __init__(self) -> None:
        self.ready: set[str] = set()  # tokens that got a "book" snapshot on this connection
        self.last_pong = time.monotonic()
        self.ping_sent: float | None = None


class WsLink:
    """What one WebSocket loop knows about its link. A loop whose link is down hands it to the loop that replaces
    it (a new subscription after discovery), so the recovery is still logged with the whole data gap."""

    __slots__ = ("connected", "last_data", "failed_since")

    def __init__(self, last_data: float | None = None, failed_since: float | None = None) -> None:
        self.connected = False
        # Last frame of any earlier connection (the first connection's start until a frame arrives): the data gap.
        # A connection that opens but delivers nothing does not reset it.
        self.last_data = last_data
        self.failed_since = failed_since  # start of the first failed attempt before any connection (log line)


def _ts(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


class PolymarketAdapter(MarketAdapter):
    """Polymarket (international, polymarket.com) esports match-winner markets."""

    def __init__(self, platform_id: str, cfg: PlatformConfig, settings: Settings):
        super().__init__(platform_id, cfg, settings)
        rate = float(cfg.opt("rate_limit_per_sec", 20))
        self.gamma = HttpClient(cfg.opt("gamma_url", "https://gamma-api.polymarket.com"), "polymarket-gamma", rate)
        self.clob = HttpClient(cfg.opt("clob_url", "https://clob.polymarket.com"), "polymarket-clob", rate)
        self.ws_url = cfg.opt("ws_url", "wss://ws-subscriptions-clob.polymarket.com/ws/market")
        self.web_url = str(cfg.opt("web_url", "https://polymarket.com")).rstrip("/")
        self.use_ws = bool(cfg.opt("use_websocket", True))
        self.ws_chunk = int(cfg.opt("ws_max_assets_per_connection", 200))
        self.ping_interval = float(cfg.opt("ws_ping_interval_sec", 5))
        self.resync_sec = float(cfg.opt("rest_resync_sec", 30))
        self.poll_sec = float(cfg.opt("rest_poll_interval_sec", 2))
        self.page_size = int(cfg.opt("page_size", 100))
        self.max_pages = int(cfg.opt("max_pages", 10))
        self.depth = int(cfg.opt("book_depth", 10))
        self.match_winner_types = set(cfg.opt("match_winner_types", ["moneyline"]))
        self.books: dict[str, TokenBook] = {}
        self.token_index: dict[str, tuple[str, str]] = {}
        self._ws_tokens: frozenset[str] = frozenset()
        self._ws_tasks: list[asyncio.Task[Any]] = []
        self._ws_alive: dict[int, bool] = {}
        self._ws_links: dict[int, WsLink] = {}
        self._ws_generation = 0
        self._resync_task: asyncio.Task[Any] | None = None
        self._series_to_game: dict[str, str] = {}
        for game, flt in self.game_filters().items():
            for sid in flt.get("series_ids", []) or []:
                self._series_to_game[str(sid)] = game
        self.status.mode = "ws" if self.use_ws else "rest"

    async def stop(self) -> None:
        await super().stop()
        await self.gamma.aclose()
        await self.clob.aclose()

    # ---- discovery -------------------------------------------------------------------

    async def _fetch_events(self, params: dict[str, Any]) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        offset = 0
        end_min = (utcnow() - timedelta(minutes=5)).strftime("%Y-%m-%dT%H:%M:%SZ")
        for _ in range(self.max_pages):
            page = await self.gamma.get_json(
                "/events",
                params={**params, "closed": "false", "end_date_min": end_min, "limit": self.page_size, "offset": offset},
            )
            if not isinstance(page, list):
                raise ValueError("Polymarket: malformed events response (expected a list)")
            events.extend(page)
            if len(page) < self.page_size:
                return events
            offset += self.page_size
        raise ValueError("Polymarket: events pagination limit reached before the last page")

    async def fetch_markets(self) -> list[NormalizedMarket]:
        """Discover match-winner markets for every configured game."""
        markets: list[NormalizedMarket] = []
        seen: set[str] = set()
        for game, flt in self.game_filters().items():
            queries = [{"series_id": sid} for sid in flt.get("series_ids", []) or []]
            queries += [{"tag_id": tid} for tid in flt.get("tag_ids", []) or []]
            for query in queries:
                for event in await self._fetch_events(query):
                    for market in self._normalize_event(event, game):
                        if market.key not in seen:
                            seen.add(market.key)
                            markets.append(market)
        self.status.markets = len(markets)
        if not self.use_ws:
            self.status.latency_ms = self.gamma.last_latency_ms
        return markets

    def _game_of(self, event: dict[str, Any]) -> str | None:
        for series in event.get("series") or []:
            game = self._series_to_game.get(str(series.get("id")))
            if game:
                return game
        return None

    def normalize(self, raw: Any) -> list[NormalizedMarket]:
        """Normalise one Gamma event (game inferred from its series)."""
        game = self._game_of(raw)
        return self._normalize_event(raw, game) if game else []

    def _fee_spec(self, market: dict[str, Any]) -> FeeSpec:
        if not market.get("feesEnabled"):
            return FeeSpec(model="none")
        schedule = market.get("feeSchedule") or {}
        rate = to_float(schedule.get("rate"))
        if rate is None:
            rate = float(self.cfg.opt("default_taker_rate", 0.05))
        exponent = to_float(schedule.get("exponent")) or 1.0
        return FeeSpec(model="polymarket", rate=rate, exponent=exponent)

    @staticmethod
    def _tournament(event: dict[str, Any]) -> str | None:
        title = event.get("title") or ""
        if " - " in title:
            return title.split(" - ", 1)[1].strip() or None
        meta = event.get("eventMetadata") or {}
        parts = [meta.get("league"), meta.get("serie"), meta.get("tournament")]
        text = " ".join(p for p in parts if p)
        return text or None

    def _normalize_event(self, event: dict[str, Any], game: str) -> list[NormalizedMarket]:
        if event.get("closed") or event.get("ended") is True or event.get("archived"):
            return []
        title = str(event.get("title") or "")
        now = utcnow()
        event_start = parse_dt(event.get("startTime"))
        disc = self.settings.discovery
        out: list[NormalizedMarket] = []
        for raw in event.get("markets") or []:
            if raw.get("sportsMarketType") not in self.match_winner_types:
                continue
            if raw.get("closed") or raw.get("active") is False or raw.get("enableOrderBook") is False:
                continue
            outcomes = [str(o) for o in json_list(raw.get("outcomes"))]
            if raw.get("version") == "v2" and raw.get("positionIds"):
                tokens = [str(t) for t in json_list(raw.get("positionIds"))]
            else:
                tokens = [str(t) for t in json_list(raw.get("clobTokenIds"))]
            if len(outcomes) != 2 or len(tokens) != 2:
                continue
            if {o.lower() for o in outcomes} == {"yes", "no"}:
                continue  # not a team-vs-team market
            start = parse_dt(raw.get("gameStartTime")) or parse_dt(raw.get("eventStartTime")) or event_start
            if start is not None:
                if start > now + timedelta(hours=disc.horizon_hours):
                    continue
                if start < now - timedelta(hours=disc.live_grace_hours):
                    continue
            market = NormalizedMarket(
                platform=self.platform,
                market_id=str(raw.get("id")),
                event_title=title,
                game=game,
                team_a=outcomes[0],
                team_b=outcomes[1],
                start_time=start,
                url=f"{self.web_url}/event/{event.get('slug')}",
                resolution_rules=str(raw.get("description") or event.get("description") or ""),
                tournament=self._tournament(event),
                best_of=parse_best_of(title, event.get("score"), raw.get("question")),
                min_order_size=to_float(raw.get("orderMinSize")) or 0.0,
                fee=self._fee_spec(raw),
                is_live=bool(event.get("live")),
                accepting_orders=bool(raw.get("acceptingOrders", True)),
                extra={
                    "token_a": tokens[0],
                    "token_b": tokens[1],
                    "condition_id": raw.get("conditionId"),
                    "event_slug": event.get("slug"),
                    "event_id": event.get("id"),
                    "tick_size": to_float(raw.get("orderPriceMinTickSize")),
                    "seconds_delay": raw.get("secondsDelay"),
                    "clear_book_on_start": raw.get("clearBookOnStart"),
                },
            )
            if not self._apply_book(market, notify=False):
                # Indicative top of book from Gamma (no sizes, not "fresh") until the CLOB answers.
                best_ask, best_bid = to_float(raw.get("bestAsk")), to_float(raw.get("bestBid"))
                if best_ask is not None and best_bid is not None:
                    market.set_books(
                        [Level(price=best_ask, size=0.0)],
                        [Level(price=round(1 - best_bid, 4), size=0.0)],
                        best_bid,
                        round(1 - best_ask, 4),
                    )
                    market.updated_at = None
            out.append(market)
        return out

    # ---- prices ----------------------------------------------------------------------

    async def subscribe_prices(self, markets: list[NormalizedMarket], on_update: PriceCallback) -> None:
        """Track the books of ``markets`` (WebSocket + REST resync, or REST polling)."""
        self._callback = on_update
        self._subscribed = {m.key: m for m in markets}
        index: dict[str, tuple[str, str]] = {}
        for market in markets:
            index[str(market.extra["token_a"])] = (market.key, "a")
            index[str(market.extra["token_b"])] = (market.key, "b")
        self.token_index = index
        self.books = {t: b for t, b in self.books.items() if t in index}  # drop books of gone markets
        for market in markets:
            self._apply_book(market, notify=False)
        if self.use_ws:
            self._ensure_ws()
        if self._resync_task is None or self._resync_task.done():
            self._resync_task = self.spawn(self._resync_loop(), "rest-books")

    async def fetch_book(self, market: NormalizedMarket) -> NormalizedMarket | None:
        """Стаканы обоих токенов одним ``POST /books`` без повторов; стаканы WebSocket и кэш не меняются."""
        tokens = [str(market.extra.get("token_a") or ""), str(market.extra.get("token_b") or "")]
        if not all(tokens):
            raise ValueError("market has no tokens")
        asked = utcnow()
        data = await self.clob.post_json("/books", [{"token_id": t} for t in tokens], retries=0)
        books: dict[str, TokenBook] = {}
        for item in data if isinstance(data, list) else []:
            if not isinstance(item, dict):
                continue
            book = TokenBook()
            book.snapshot(item.get("bids") or [], item.get("asks") or [], _ts(item.get("timestamp")), asked)
            books[str(item.get("asset_id"))] = book
        missing = [t for t in tokens if t not in books]
        if missing:
            raise ValueError(f"no book for token {', '.join(missing)}")
        copy = market.model_copy(deep=True)
        book_a, book_b = books[tokens[0]], books[tokens[1]]
        copy.set_books(
            [Level(price=p, size=s) for p, s in book_a.top_asks(self.depth)],
            [Level(price=p, size=s) for p, s in book_b.top_asks(self.depth)],
            book_a.best_bid(),
            book_b.best_bid(),
            asked,
        )
        # Время стаканов на бирже (мс): показывает, давно ли они менялись.
        copy.extra["book_exchange_ts"] = {"a": book_a.ts, "b": book_b.ts}
        return copy

    def _apply_book(self, market: NormalizedMarket, notify: bool = True) -> bool:
        """Copy the token books into the market, stamped with when the older book was received."""
        book_a = self.books.get(str(market.extra.get("token_a")))
        book_b = self.books.get(str(market.extra.get("token_b")))
        if book_a is None or book_b is None or not (book_a.ready and book_b.ready):
            return False
        received = [b.received_at for b in (book_a, book_b) if b.received_at is not None]
        market.set_books(
            [Level(price=p, size=s) for p, s in book_a.top_asks(self.depth)],
            [Level(price=p, size=s) for p, s in book_b.top_asks(self.depth)],
            book_a.best_bid(),
            book_b.best_bid(),
            min(received) if len(received) == 2 else None,
        )
        if len(received) != 2:
            market.updated_at = None
        market.extra["timestamp_kind"] = "local_confirmation_of_coherent_book_state"
        market.extra["source_book_timestamps_ms"] = {
            "a": book_a.ts or None,
            "b": book_b.ts or None,
        }
        market.extra["actual_price_change_at"] = None
        if notify:
            self.notify(market)
        return True

    def _ensure_ws(self) -> None:
        tokens = frozenset(self.token_index)
        alive = [t for t in self._ws_tasks if not t.done()]
        if tokens == self._ws_tokens and len(alive) == len(self._ws_tasks) and self._ws_tasks:
            return
        # Matched by connection number: after the market set changes, connection N may carry other markets, which
        # is close enough for a log line (today all markets fit on connection 0).
        handover = {cid: link for cid, link in self._ws_links.items() if not link.connected}
        for task in self._ws_tasks:
            task.cancel()
        self._ws_tasks = []
        self._ws_alive = {}
        self._ws_links = {}
        self._ws_generation += 1
        self._ws_tokens = tokens
        # Keep both tokens of a market on the same connection.
        markets = list(self._subscribed.values())
        per_conn = max(1, self.ws_chunk // 2)
        for idx in range(0, len(markets), per_conn):
            chunk = markets[idx: idx + per_conn]
            assets = []
            for market in chunk:
                assets += [str(market.extra["token_a"]), str(market.extra["token_b"])]
            conn_id = idx // per_conn
            old = handover.get(conn_id)
            link = self._ws_links[conn_id] = WsLink(old.last_data, old.failed_since) if old else WsLink()
            self._ws_tasks.append(
                self.spawn(self._ws_loop(conn_id, assets, self._ws_generation, link), f"ws-{conn_id}")
            )
        if not markets:
            self.status.connected = True

    def _set_alive(self, conn_id: int, generation: int, alive: bool) -> None:
        if generation == self._ws_generation:  # ignore late updates from replaced connections
            self._ws_alive[conn_id] = alive
            values = list(self._ws_alive.values())
            self.status.connected = bool(values) and all(values)

    async def _ws_loop(self, conn_id: int, assets: list[str], generation: int, link: WsLink | None = None) -> None:
        link = link if link is not None else WsLink()
        attempt = 0
        while self._running:
            conn = WsConn()
            attempt_started = time.monotonic()
            try:
                async with websockets.connect(
                    self.ws_url, ping_interval=20, ping_timeout=20, open_timeout=15, close_timeout=5, max_size=2**24
                ) as ws:
                    conn.last_pong = time.monotonic()  # the PONG timeout starts after the handshake, not before
                    await ws.send(json.dumps({"assets_ids": assets, "type": "market"}))
                    self._set_alive(conn_id, generation, True)
                    now = time.monotonic()
                    if link.last_data is not None:
                        self.log.info("ws %d reconnected, no data for %.1f s", conn_id, now - link.last_data)
                    elif link.failed_since is not None:
                        self.log.info("ws %d connected after %.1f s of failed attempts", conn_id, now - link.failed_since)
                    # Up only from here: no await between the log line and the flag, so a replacement either takes
                    # over a down link (and logs the recovery itself) or finds it up after the line was written.
                    link.connected, link.failed_since = True, None
                    if link.last_data is None:
                        link.last_data = now
                    pinger = asyncio.create_task(self._ping_loop(ws, conn, conn_id, link))
                    try:
                        async for raw in ws:
                            link.last_data = time.monotonic()
                            if self._on_ws_message(raw, conn) and attempt:
                                attempt = 0  # reset backoff only once real data flows
                    finally:
                        link.connected = False  # data stopped: down already during the closing handshake
                        pinger.cancel()
                self.log.info("ws %d closed (code %s), reconnecting", conn_id, ws.close_code)
            except asyncio.CancelledError:
                link.connected = False
                self._set_alive(conn_id, generation, False)
                raise
            except Exception as exc:  # noqa: BLE001 - reconnect on any error
                link.connected = False
                self.log.warning("ws %d error: %s", conn_id, describe_error(exc))
                self.status.error = f"ws: {describe_error(exc)}"[:200]
                if link.last_data is None and link.failed_since is None:
                    link.failed_since = attempt_started  # a silent drop fails only after open_timeout
            self._set_alive(conn_id, generation, False)
            delay = backoff_delay(attempt, base=1.0, cap=30.0)
            attempt += 1
            await asyncio.sleep(delay)

    async def _ping_loop(self, ws: Any, conn: WsConn, conn_id: int, link: WsLink | None = None) -> None:
        """Application-level heartbeat; a connection without PONG for 3 intervals is closed."""
        while True:
            await asyncio.sleep(self.ping_interval)
            if time.monotonic() - conn.last_pong > 3 * self.ping_interval:
                self.log.warning("ws %d: no PONG for %.0f s, reconnecting", conn_id, 3 * self.ping_interval)
                if link is not None:
                    link.connected = False  # the link is dead now, not only after the close handshake
                await ws.close()
                return
            conn.ping_sent = time.monotonic()
            await ws.send("PING")

    def _on_ws_message(self, raw: Any, conn: WsConn | None = None) -> bool:
        """Apply one WebSocket frame; return True when it carried book data."""
        now = utcnow()
        conn = conn if conn is not None else WsConn()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "ignore")
        if raw.strip().upper() == "PONG":
            conn.last_pong = time.monotonic()
            if conn.ping_sent:
                self.status.latency_ms = round((time.monotonic() - conn.ping_sent) * 1000, 1)
            # The connection is alive, so books that were snapshotted on it are current as of now.
            keys = set()
            for token in conn.ready:
                book = self.books.get(token)
                if book is not None and book.ready:
                    book.received_at = now
                    keys.add(self.token_index.get(token, ("", ""))[0])
            for key in keys:
                market = self._subscribed.get(key)
                if market is not None:
                    self._apply_book(market, notify=False)
            self.status.last_update = now
            self.status.error = None
            return False
        try:
            data = json.loads(raw)
        except ValueError:
            return False
        touched: set[str] = set()
        for msg in data if isinstance(data, list) else [data]:
            if not isinstance(msg, dict):
                continue
            try:
                self._apply_ws_event(msg, now, conn.ready, touched)
            except Exception as exc:  # noqa: BLE001 - one bad event must not kill the connection
                self.log.debug("ws: skipped malformed event %s: %s", msg.get("event_type"), exc)
        keys = {self.token_index[t][0] for t in touched if t in self.token_index}
        for key in keys:
            market = self._subscribed.get(key)
            if market is not None:
                self._apply_book(market)
        if keys:
            self.status.last_update = now
        return bool(touched)

    def _apply_ws_event(self, msg: dict[str, Any], now: datetime, ready: set[str], touched: set[str]) -> None:
        kind = msg.get("event_type")
        if kind == "book":
            token = str(msg.get("asset_id"))
            book = self.books.setdefault(token, TokenBook())
            if book.snapshot(msg.get("bids") or [], msg.get("asks") or [], _ts(msg.get("timestamp")), now):
                touched.add(token)
            ready.add(token)
        elif kind == "price_change":
            ts = _ts(msg.get("timestamp"))
            changes = msg.get("price_changes")
            if changes is None:  # legacy format
                changes = [dict(c, asset_id=msg.get("asset_id")) for c in msg.get("changes") or []]
            for change in changes:
                token = str(change.get("asset_id"))
                book = self.books.get(token)
                if book is None or not book.ready:
                    continue
                price, size = to_float(change.get("price")), to_float(change.get("size"))
                if price is None or size is None:
                    continue
                if book.apply(price, size, str(change.get("side", "")), ts, now):
                    touched.add(token)

    async def _resync_loop(self) -> None:
        last_ok = time.monotonic()  # last successful refresh (the start counts): the data gap of an outage
        succeeded = False  # a REST refresh worked at least once
        failing = False
        while self._running:
            started = time.monotonic()
            try:
                await self._rest_refresh()
                if not self.use_ws:
                    self.status.connected = True
                    self.status.error = None
                if failing:
                    gap = time.monotonic() - last_ok
                    if not self.use_ws:
                        self.log.info("REST book refresh recovered, no data for %.1f s", gap)
                    elif succeeded:  # REST is only the backup here: the WebSocket may have delivered data meanwhile
                        self.log.info("REST book refresh recovered, last success %.1f s ago", gap)
                    else:
                        self.log.info("REST book refresh recovered, first success %.1f s after start", gap)
                failing, last_ok, succeeded = False, time.monotonic(), True
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.log.warning("REST book refresh failed: %s", describe_error(exc))
                failing = True
                if not self.use_ws:
                    self.status.connected = False
                    self.status.error = f"rest: {describe_error(exc)}"[:200]
            interval = self.resync_sec if self.use_ws else self.poll_sec
            await asyncio.sleep(max(0.2, interval - (time.monotonic() - started)))

    async def _rest_refresh(self) -> None:
        tokens = list(self.token_index)
        pending: dict[str, TokenBook] = {}
        for idx in range(0, len(tokens), 100):
            batch = tokens[idx: idx + 100]
            data = await self.clob.post_json("/books", [{"token_id": t} for t in batch])
            if not isinstance(data, list):
                raise ValueError("Polymarket: malformed books response (expected a list)")
            batch_time = utcnow()  # when THIS batch arrived, not when the last one did
            updates: dict[str, TokenBook] = {}
            for item in data:
                if not isinstance(item, dict):
                    continue
                token = str(item.get("asset_id"))
                if token not in batch or "bids" not in item or "asks" not in item:
                    continue
                if not isinstance(item["bids"], list) or not isinstance(item["asks"], list):
                    continue
                book = TokenBook()
                book.snapshot(item["bids"], item["asks"], _ts(item.get("timestamp")), batch_time)
                updates[token] = book
            missing = set(batch) - updates.keys()
            if missing:
                raise ValueError(f"Polymarket: incomplete books response ({len(missing)} token(s) missing)")
            pending.update(updates)
        received = set(pending)
        for token, incoming in pending.items():
            current = self.books.get(token)
            if current is not None and current.ts:
                # A response without a source timestamp cannot replace a timestamped WebSocket book. An equal source
                # timestamp also keeps the later local confirmation (for example a PONG while another batch loaded).
                if not incoming.ts or incoming.ts < current.ts:
                    continue
                if (incoming.ts == current.ts and current.received_at is not None
                        and incoming.received_at is not None and current.received_at >= incoming.received_at):
                    continue
            self.books[token] = incoming
        for market in list(self._subscribed.values()):
            if {str(market.extra.get("token_a")), str(market.extra.get("token_b"))} <= received:
                self._apply_book(market)
        if not self.use_ws and received:
            self.status.last_update = utcnow()
            self.status.latency_ms = self.clob.last_latency_ms
