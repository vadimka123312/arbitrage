"""Mock adapter for ``--mock`` mode.

Every mock platform reads from one shared ``MockWorld``: a set of synthetic matches whose
fair probability follows a random walk. Each platform quotes asks around that probability
with its own spread and naming style. Random short "dislocations" make one platform's ask
drop for 1-40 seconds, which creates arbitrage opportunities of different lifetimes (so the
N-second confirmation rule can be seen in the UI).
"""

from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any

from backend.adapters.base import MarketAdapter, PriceCallback
from backend.adapters.stake import odds_level
from backend.config import PlatformConfig, Settings
from backend.matching.rules import BCGAME_RULES, STAKE_RULES
from backend.models import FeeSpec, Level, NormalizedMarket, utcnow

POLY_RULES = (
    "This market refers to the {game} match between {a} and {b} in the {tournament}.\n\n"
    'This market will resolve to "{a}" if {a} win the match against {b}.\n\n'
    "If the match is canceled (not played at all) or ends in a tie, this market will resolve to 50-50.\n\n"
    "If the match is postponed, it must be rescheduled to a start time on or before 14 calendar days "
    "after the originally scheduled start. Otherwise, this market resolves 50-50.\n\n"
    "If the match begins but is not completed, and one team wins due to the opponent's forfeiture, "
    "disqualification, or walkover, this market will resolve to the team who wins.\n\n"
    "If the match ends in a forfeit, disqualification, or walkover (team withdraws before the start "
    "and the other wins automatically), this market will resolve to 50-50."
)
KALSHI_RULES = (
    "If {a} wins the {tournament}: {a} vs. {b} {game} match, then the market resolves to Yes.\n"
    "If the relevant match is postponed and not started within 48 hours of its originally scheduled "
    "start time, the market will resolve to the fair market price.\n"
    "If the relevant match is cancelled before play begins, the market will resolve to the fair market price.\n"
    "If the relevant match is forfeited before any play occurs, the market will resolve to the fair market price.\n"
    "If the relevant match begins and is subsequently forfeited, the market will resolve according to "
    "the official result published by the governing body or tournament organizer."
)

# Names per platform are given in canonical team order (teams[0], teams[1]).
# `swap` lists platforms that display the teams in the reverse order (tests orientation).
# `shift` moves the start time on one platform (minutes) to create a "needs review" case.
MOCK_MATCHES: list[dict[str, Any]] = [
    {"game": "cs2", "teams": ("Natus Vincere", "FaZe Clan"),
     "names": {"polymarket": ("Natus Vincere", "FaZe"), "kalshi": ("NAVI", "FaZe Clan")},
     "swap": {"kalshi", "bcgame"}, "start": 120, "bo": 3, "tournament": "IEM Mock Masters"},
    {"game": "cs2", "teams": ("Team Vitality", "G2 Esports"),
     "names": {"polymarket": ("Team Vitality", "G2"), "kalshi": ("Vitality", "G2 Esports")},
     "start": -40, "bo": 3, "tournament": "BLAST Mock Finals"},
    {"game": "cs2", "teams": ("Ninjas in Pyjamas", "Team Liquid"),
     "names": {"polymarket": ("Ninjas in Pyjamas", "Team Liquid"), "kalshi": ("NIP", "Liquid")},
     "swap": {"kalshi"}, "start": 300, "bo": 3, "tournament": "ESL Mock League"},
    {"game": "cs2", "teams": ("Spirit Academy", "MOUZ NXT"),
     "names": {"polymarket": ("Spirit Academy", "MOUZ NXT"), "kalshi": ("Spirit Academy", "MOUZ NXT")},
     "start": 60, "bo": 1, "tournament": "CCT Mock Series"},
    {"game": "cs2", "teams": ("Team Spirit", "MOUZ"),
     "names": {"polymarket": ("Team Spirit", "MOUZ"), "kalshi": ("Spirit", "MOUZ")},
     "start": 90, "bo": 3, "tournament": "IEM Mock Masters"},
    {"game": "cs2", "teams": ("Heroic", "Astralis"),
     "names": {"polymarket": ("Heroic", "Astralis")},
     "start": 200, "bo": 3, "tournament": "ESL Mock League"},
    {"game": "dota2", "teams": ("Team Spirit", "Gaimin Gladiators"),
     "names": {"polymarket": ("Team Spirit", "Gaimin Gladiators"), "kalshi": ("Spirit", "Gaimin")},
     "start": 180, "bo": 3, "tournament": "DreamLeague Mock"},
    {"game": "dota2", "teams": ("Tundra Esports", "BetBoom Team"),
     "names": {"polymarket": ("Tundra Esports", "BetBoom Team"), "kalshi": ("Tundra", "BetBoom")},
     "swap": {"kalshi"}, "start": -20, "bo": 3, "tournament": "DreamLeague Mock"},
    {"game": "dota2", "teams": ("OG", "Team Secret"),
     "names": {"kalshi": ("OG", "Team Secret")},
     "start": 240, "bo": 3, "tournament": "EPL Mock"},
    {"game": "lol", "teams": ("T1", "Gen.G"),
     "names": {"polymarket": ("T1", "Gen.G"), "kalshi": ("T1", "Gen.G Esports")},
     "start": 360, "bo": 5, "tournament": "Worlds Mock"},
    {"game": "lol", "teams": ("G2 Esports", "Fnatic"),
     "names": {"polymarket": ("G2 Esports", "Fnatic"), "kalshi": ("G2", "FNATIC")},
     "swap": {"kalshi"}, "start": 1560, "bo": 3, "tournament": "LEC Mock"},
    {"game": "lol", "teams": ("Cloud9", "Karmine Corp"),
     "names": {"polymarket": ("Cloud9", "Karmine Corp"), "kalshi": ("Cloud9", "Karmine Corp")},
     "swap": {"kalshi"}, "shift": {"kalshi": 270}, "start": 600, "bo": 5,
     "tournament": "Worlds Mock Play-In"},
    {"game": "valorant", "teams": ("Sentinels", "Paper Rex"),
     "names": {"polymarket": ("Sentinels", "Paper Rex"), "kalshi": ("Sentinels", "PRX")},
     "start": 240, "bo": 3, "tournament": "VCT Mock Champions"},
    {"game": "valorant", "teams": ("MIBR Female", "FlyQuest RED"),
     "names": {"polymarket": ("MIBR GC", "FlyQuest RED"), "kalshi": ("MIBR Female", "FlyQuest RED")},
     "start": 480, "bo": 5, "tournament": "VCT Game Changers Mock"},
    {"game": "mlbb", "teams": ("ONIC PH", "Team Liquid PH"),
     "names": {"polymarket": ("ONIC PH", "Team Liquid PH"), "kalshi": ("ONIC", "Team Liquid PH")},
     "start": 150, "bo": 5, "tournament": "MPL Mock PH"},
    {"game": "r6", "teams": ("DarkZero Esports", "M80"),
     "names": {"polymarket": ("DarkZero Esports", "M80"), "kalshi": ("DarkZero", "M80")},
     "start": 150, "bo": 3, "tournament": "R6 Mock League"},
    {"game": "overwatch", "teams": ("Team Falcons", "Crazy Raccoon"),
     "names": {"polymarket": ("Team Falcons", "Crazy Raccoon"), "kalshi": ("Falcons", "Crazy Raccoon")},
     "start": 1800, "bo": 5, "tournament": "OWCS Mock"},
]

PROFILE_STYLE = {
    "polymarket": {"half_spread": 0.010, "fee": FeeSpec(model="polymarket", rate=0.05, exponent=1.0),
                   "min_order": 5.0},
    "kalshi": {"half_spread": 0.015,
               "fee": FeeSpec(model="kalshi", rate=0.07, multiplier=1.0, round_up_cents=True),
               "min_order": 1.0},
    # A bookmaker: margin inside the odds, one level per outcome (odds rounded to 0.01), no fee, no bids.
    "stake": {"half_spread": 0.025, "fee": FeeSpec(), "min_order": 0.0},
    "bcgame": {"half_spread": 0.025, "fee": FeeSpec(), "min_order": 0.0},
}
DEFAULT_STYLE = {"half_spread": 0.012, "fee": FeeSpec(), "min_order": 1.0}


@dataclass
class Dislocation:
    match_idx: int
    profile: str
    outcome: str  # "a" | "b" (canonical team order)
    drop: float
    until: float


@dataclass
class MockMatch:
    idx: int
    spec: dict[str, Any]
    start: datetime
    prob: float
    bias: dict[str, tuple[float, float]] = field(default_factory=dict)


class MockWorld:
    """Shared synthetic market state for all mock platforms."""

    def __init__(self, seed: int, arb_rate_per_min: float, tick_ms: int):
        self.rng = random.Random(seed)
        self.arb_rate_per_min = arb_rate_per_min
        self.tick_sec = tick_ms / 1000.0
        self.started = utcnow()
        self.matches: list[MockMatch] = []
        for idx, spec in enumerate(MOCK_MATCHES):
            start = self.started + timedelta(minutes=spec["start"])
            self.matches.append(MockMatch(idx=idx, spec=spec, start=start, prob=self.rng.uniform(0.3, 0.7)))
        self.dislocations: list[Dislocation] = []
        self._last_tick = 0.0

    def advance(self) -> None:
        """Step the random walk and dislocations (idempotent within one tick)."""
        now = time.monotonic()
        if now - self._last_tick < self.tick_sec * 0.9:
            return
        steps = 1 if self._last_tick == 0 else max(1, int((now - self._last_tick) / self.tick_sec))
        self._last_tick = now
        for _ in range(min(steps, 20)):
            for match in self.matches:
                match.prob = min(0.92, max(0.08, match.prob + self.rng.gauss(0, 0.002)))
                for profile in ("polymarket", "kalshi"):
                    ba, bb = match.bias.get(profile, (0.0, 0.0))
                    ba = max(-0.006, min(0.006, ba + self.rng.gauss(0, 0.0008)))
                    bb = max(-0.006, min(0.006, bb + self.rng.gauss(0, 0.0008)))
                    match.bias[profile] = (ba, bb)
            per_tick = self.arb_rate_per_min / 60.0 * self.tick_sec
            if self.rng.random() < per_tick:
                candidates = [m for m in self.matches if len(m.spec["names"]) >= 2]
                if candidates:
                    match = self.rng.choice(candidates)
                    profile = self.rng.choice(sorted(match.spec["names"]))
                    life = min(40.0, max(1.0, self.rng.expovariate(1 / 9.0)))
                    self.dislocations.append(
                        Dislocation(
                            match_idx=match.idx,
                            profile=profile,
                            outcome=self.rng.choice(["a", "b"]),
                            drop=self.rng.uniform(0.06, 0.12),
                            until=now + life,
                        )
                    )
        self.dislocations = [d for d in self.dislocations if d.until > now]

    def books(self, match: MockMatch, profile: str) -> tuple[list[Level], list[Level], float, float]:
        """Asks for canonical team a/b plus best bids on one platform."""
        style = PROFILE_STYLE.get(profile, DEFAULT_STYLE)
        hs = style["half_spread"]
        ba, bb = match.bias.get(profile, (0.0, 0.0))
        ask_a = match.prob + hs + ba
        ask_b = (1 - match.prob) + hs + bb
        for d in self.dislocations:
            if d.match_idx == match.idx and d.profile == profile:
                if d.outcome == "a":
                    ask_a -= d.drop
                else:
                    ask_b -= d.drop
        ask_a = min(0.99, max(0.01, round(ask_a, 2)))
        ask_b = min(0.99, max(0.01, round(ask_b, 2)))
        sizes = random.Random(hash((match.idx, profile, int(time.monotonic() / 7))))
        asks_a = [
            Level(price=round(min(0.99, ask_a + 0.01 * k), 2), size=round(sizes.uniform(20, 600), 2))
            for k in range(5)
        ]
        asks_b = [
            Level(price=round(min(0.99, ask_b + 0.01 * k), 2), size=round(sizes.uniform(20, 600), 2))
            for k in range(5)
        ]
        bid_a = round(max(0.01, 1 - ask_b - 0.01), 2)
        bid_b = round(max(0.01, 1 - ask_a - 0.01), 2)
        return asks_a, asks_b, bid_a, bid_b


_WORLDS: dict[int, MockWorld] = {}


def get_world(settings: Settings) -> MockWorld:
    """Return the world shared by all mock adapters of this process."""
    seed = settings.mock.seed
    if seed not in _WORLDS:
        _WORLDS[seed] = MockWorld(seed, settings.mock.arb_rate_per_min, settings.mock.tick_ms)
    return _WORLDS[seed]


def reset_worlds() -> None:
    """Forget all worlds (tests)."""
    _WORLDS.clear()


class MockAdapter(MarketAdapter):
    """Synthetic platform; ``mock_profile`` selects naming style, fees and URLs."""

    def __init__(self, platform_id: str, cfg: PlatformConfig, settings: Settings):
        super().__init__(platform_id, cfg, settings)
        self.profile = str(cfg.opt("mock_profile", platform_id))
        self.world = get_world(settings)
        self.status.mode = "mock"
        self._rng = random.Random(hash(platform_id))

    def _names(self, match: MockMatch) -> tuple[str, str, bool] | None:
        """Display names (platform order) and whether they are reversed vs canonical order."""
        names = match.spec["names"]
        if self.profile in names:
            a, b = names[self.profile]
        elif self.profile not in ("polymarket", "kalshi"):
            if self.cfg.games and match.spec["game"] not in self.cfg.games:
                return None  # only the games of its config section (the Stake mock: platforms.stake.games)
            a, b = match.spec["teams"]  # extra mock platforms list every match of their games
        else:
            return None
        swapped = self.profile in match.spec.get("swap", ())
        return (b, a, True) if swapped else (a, b, False)

    def normalize(self, raw: Any) -> list[NormalizedMarket]:
        """Build the market of one mock match for this platform."""
        match: MockMatch = raw
        names = self._names(match)
        if names is None:
            return []
        team_a, team_b, swapped = names
        spec = match.spec
        style = PROFILE_STYLE.get(self.profile, DEFAULT_STYLE)
        start = match.start + timedelta(minutes=spec.get("shift", {}).get(self.profile, 0))
        game_name = self.settings.games[spec["game"]].name if spec["game"] in self.settings.games else spec["game"]
        if self.profile == "kalshi":
            ticker = f"KXMOCK{spec['game'].upper()}-{match.idx:03d}"
            market_id = ticker
            url = f"https://kalshi.com/markets/kxmock/mock/{ticker.lower()}"
            rules = KALSHI_RULES.format(a=team_a, b=team_b, game=game_name, tournament=spec["tournament"])
            title = f"{team_a} vs. {team_b}"
            best_of = None
        elif self.profile in ("stake", "bcgame"):
            market_id = f"{self.profile}-{match.idx:03d}"
            host = "stake.com" if self.profile == "stake" else "bc.game"
            url = f"https://{host}/sports/mock/{market_id}"
            rules = STAKE_RULES if self.profile == "stake" else BCGAME_RULES
            title = f"{team_a} - {team_b}"
            best_of = spec["bo"]
        else:
            slug = f"mock-{spec['game']}-{match.idx:03d}"
            market_id = f"{self.profile}-{match.idx:03d}"
            url = f"https://polymarket.com/event/{slug}" if self.profile == "polymarket" else f"https://example.com/{slug}"
            rules = POLY_RULES.format(a=team_a, b=team_b, game=game_name, tournament=spec["tournament"])
            title = f"{game_name}: {team_a} vs {team_b} (BO{spec['bo']}) - {spec['tournament']}"
            best_of = spec["bo"]
        market = NormalizedMarket(
            platform=self.platform,
            market_id=market_id,
            event_title=title,
            game=spec["game"],
            team_a=team_a,
            team_b=team_b,
            start_time=start,
            url=url,
            resolution_rules=rules,
            tournament=spec["tournament"],
            best_of=best_of,
            min_order_size=style["min_order"],
            fee=style["fee"],
            extra={"mock_idx": match.idx, "swapped": swapped},
        )
        self._apply_book(market, match)
        return [market]

    def _apply_book(self, market: NormalizedMarket, match: MockMatch) -> None:
        asks_a, asks_b, bid_a, bid_b = self.world.books(match, self.profile)
        if market.extra.get("swapped"):
            asks_a, asks_b, bid_a, bid_b = asks_b, asks_a, bid_b, bid_a
        if self.profile in ("stake", "bcgame"):
            # Коэффициент лучшего ask: один уровень на исход, лимит ставки в долларах, без bid.
            max_stake = float(self.cfg.opt("max_stake_usd", 50.0))
            asks_a, asks_b = [
                [lv for lv in [odds_level(round(1 / asks[0].price, 2), max_stake, team)] if lv is not None]
                for asks, team in ((asks_a, market.team_a), (asks_b, market.team_b))
            ]
            bid_a = bid_b = None
        market.set_books(asks_a, asks_b, bid_a, bid_b, utcnow())

    async def fetch_book(self, market: NormalizedMarket) -> NormalizedMarket | None:
        """Копия рынка с текущим состоянием мира (как будто отдельный запрос к площадке)."""
        await asyncio.sleep(0.01)
        match = next((m for m in self.world.matches if m.idx == market.extra.get("mock_idx")), None)
        if match is None:
            raise ValueError("mock match is gone")
        copy = market.model_copy(deep=True)
        self._apply_book(copy, match)
        return copy

    async def fetch_markets(self) -> list[NormalizedMarket]:
        """Return the mock matches available on this platform."""
        await asyncio.sleep(0.05)
        self.world.advance()
        markets: list[NormalizedMarket] = []
        horizon = utcnow() + timedelta(hours=self.settings.discovery.horizon_hours)
        for match in self.world.matches:
            if match.start > horizon:
                continue
            markets.extend(self.normalize(match))
        self.status.markets = len(markets)
        self.status.connected = True
        self.status.last_update = utcnow()
        return markets

    async def subscribe_prices(self, markets: list[NormalizedMarket], on_update: PriceCallback) -> None:
        """Start (once) the tick loop that refreshes the given markets."""
        self._subscribed = {m.key: m for m in markets}
        self._callback = on_update
        if not self._tasks:
            self.spawn(self._tick_loop(), "tick")

    async def _tick_loop(self) -> None:
        tick = self.settings.mock.tick_ms / 1000.0
        while self._running:
            self.world.advance()
            by_idx = {m.idx: m for m in self.world.matches}
            for market in list(self._subscribed.values()):
                match = by_idx.get(market.extra.get("mock_idx", -1))
                if match is None:
                    continue
                self._apply_book(market, match)
                self.notify(market)
            self.status.connected = True
            self.status.last_update = utcnow()
            self.status.latency_ms = round(self._rng.uniform(15, 80), 1)
            await asyncio.sleep(tick)


