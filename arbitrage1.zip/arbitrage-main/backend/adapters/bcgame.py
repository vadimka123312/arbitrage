"""BC.Game: гостевой REST-фид BETBY, только двухисходный победитель esports матча.

Публичный клиент использует snapshot из нескольких частей и последующие delta-ответы.
Успешная атомарная синхронизация подтверждает текущее состояние на момент начала запроса,
как REST-ответ Stake. Неполный snapshot и ошибка не обновляют книги.
Ключ и вход не нужны. Адаптер не решает challenge, не меняет IP и не размещает ставки.
"""

from __future__ import annotations

import asyncio
import copy
import math
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from typing import Any
from urllib.parse import quote, urlsplit

import httpx

from backend.adapters.base import MarketAdapter, PriceCallback
from backend.adapters.bcgame_clock import (QuoteEvidence, QuoteKey, QuoteTimeRegression, effective_best_of,
                                           finalize_snapshot_times, quote_times, update_quote_times)
from backend.adapters.common import to_float
from backend.adapters.stake import odds_level
from backend.config import PlatformConfig, Settings
from backend.matching.rules import BCGAME_RULES
from backend.models import FeeSpec, NormalizedMarket, utcnow
from backend.net import RETRY_STATUSES, HttpError, RateLimiter, backoff_delay

PROXY_ENV = "ARB_BCGAME_PROXY_URL"
DEFAULT_API = "https://api-k-c7818b61-623.sptpub.com"
DEFAULT_BRAND = "2103509236163162112"
WINNER_ID = "186"  # опубликованный словарь: Winner, исходы 4/5, без specifier
_NUMERIC = re.compile(r"^[0-9]{1,24}$")
_TABLES = ("sports", "categories", "tournaments", "events")
_UNKNOWN_TIME = datetime(1970, 1, 1, tzinfo=timezone.utc)


class SnapshotExpired(ValueError):
    """Сервер больше не хранит запрошенную версию или сменил epoch."""


def _number(value: Any) -> str:
    text = str(value)
    if isinstance(value, bool) or not _NUMERIC.fullmatch(text):
        raise ValueError("BC.Game: invalid feed version or epoch")
    return text


def _merge_dict(old: dict, patch: dict) -> dict:
    """Рекурсивное слияние delta: null удаляет ключ; исходный объект не меняется."""
    result = copy.deepcopy(old)
    for key, value in patch.items():
        if value is None:
            result.pop(key, None)
        elif isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge_dict(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def merge_payload(old: dict, patch: dict) -> dict:
    """Состояние публичного клиента: справочники и события, включая shouldResetEvent."""
    result = copy.deepcopy(old)
    for table in _TABLES:
        changes = patch.get(table, {})
        if not isinstance(changes, dict):
            raise ValueError(f"BC.Game: malformed {table} table")
        target = result.setdefault(table, {})
        for key, value in changes.items():
            if value is None:
                target.pop(key, None)
                continue
            if not isinstance(value, dict):
                raise ValueError(f"BC.Game: malformed {table} entry")
            previous = target.get(key, {})
            if table == "events":
                if value.get("shouldResetEvent"):
                    previous = {}
                before_desc = previous.get("desc") or {}
                after_desc = value.get("desc", before_desc)
                before = before_desc.get("competitors") if isinstance(before_desc, dict) else None
                after = after_desc.get("competitors", before) if isinstance(after_desc, dict) else None
                if before and after != before:
                    # Старые коэффициенты нельзя перенести на другой порядок команд или другого соперника.
                    previous.setdefault("markets", {}).pop(WINNER_ID, None)
            target[key] = _merge_dict(previous, value)
    return result


@dataclass
class FeedState:
    """Один согласованный канал: метаданные, рынки и непрозрачная версия сервера."""

    data: dict = field(default_factory=lambda: {key: {} for key in _TABLES})
    epoch: str = ""
    version: str = ""
    asked_at: datetime | None = None
    generated_at: datetime | None = None
    quote_evidence: dict[QuoteKey, QuoteEvidence] = field(default_factory=dict)
    seen_versions: tuple[str, ...] = ()
    last_delta_generated_at: datetime | None = None
    confirmed_at: datetime | None = None


class BcGameAdapter(MarketAdapter):
    """Один общий delta-запрос обновляет фид; пары получают котировки чаще остальных."""

    def __init__(self, platform_id: str, cfg: PlatformConfig, settings: Settings):
        super().__init__(platform_id, cfg, settings)
        self.api_url = str(cfg.opt("api_url", DEFAULT_API)).rstrip("/")
        api = urlsplit(self.api_url)
        if api.scheme != "https" or not api.hostname or api.username or api.password or api.query or api.fragment:
            raise ValueError("BC.Game: api_url must be an HTTPS URL without credentials or query")
        self.brand = _number(cfg.opt("brand_id", DEFAULT_BRAND))
        self.language = str(cfg.opt("language", "en"))
        if not re.fullmatch(r"[a-zA-Z-]{2,16}", self.language):
            raise ValueError("BC.Game: invalid language")
        self.web_url = str(cfg.opt("web_url", "https://bc.game/sports")).rstrip("/")
        self.max_stake = float(cfg.opt("max_stake_usd", 50))
        self.poll_sec = float(cfg.opt("poll_interval_sec", 3))
        self.slow_poll_sec = float(cfg.opt("slow_poll_interval_sec", 120))
        rate = float(cfg.opt("rate_limit_per_sec", 1))
        timeout = float(cfg.opt("request_timeout_sec", 5))
        if any(not math.isfinite(v) or v <= 0 for v in (self.max_stake, self.poll_sec, self.slow_poll_sec, rate, timeout)):
            raise ValueError("BC.Game: stake, intervals, rate and timeout must be positive finite numbers")
        self.max_parts = max(1, min(64, int(cfg.opt("max_snapshot_parts", 16))))
        self.max_bytes = max(1024, int(cfg.opt("max_response_bytes", 10_000_000)))
        self.request_retries = max(0, min(5, int(cfg.opt("request_retries", 2))))
        self.clock_skew_sec = float(cfg.opt("clock_skew_tolerance_sec", 5))
        if not math.isfinite(self.clock_skew_sec) or self.clock_skew_sec < 0:
            raise ValueError("BC.Game: clock skew tolerance must be a non-negative finite number")
        self._limit = RateLimiter(rate)
        self._semaphore = asyncio.Semaphore(max(1, min(8, int(cfg.opt("max_concurrency", 2)))))
        proxy = os.getenv(PROXY_ENV, "").strip() or None
        try:
            self.http = httpx.AsyncClient(base_url=self.api_url, timeout=timeout, follow_redirects=False,
                                          proxy=proxy, trust_env=False)
        except (ValueError, ImportError, httpx.InvalidURL):
            raise ValueError("BC.Game: invalid proxy configuration or missing SOCKS dependency") from None
        self.include_live = bool(cfg.opt("include_live", False))
        self.channels = ("prematch", "live") if self.include_live else ("prematch",)
        self.feeds: dict[str, FeedState] = {}
        self._lock = asyncio.Lock()
        self._paired: set[str] | None = None
        self._published: dict[str, float] = {}
        self._matched_metadata: dict[str, tuple] = {}
        self._needs_rematch: set[str] = set()
        self._poll_task: asyncio.Task | None = None
        self._sleep = asyncio.sleep
        self._backoff = 0.0
        self._retry_until = 0.0
        self._blocked: int | None = None
        self._blocked_error: str | None = None
        self.status.mode = "rest"

    async def stop(self) -> None:
        await super().stop()
        await self.http.aclose()

    def _check_access(self) -> None:
        if self._blocked:
            raise HttpError(self._blocked_error or "BC.Game: access denied; restart after access is authorized",
                            self._blocked)
        if self._retry_until > time.monotonic():
            raise HttpError("BC.Game: Retry-After cooldown", 429)

    async def _get(self, channel: str, version: str) -> tuple[dict, datetime]:
        self._check_access()
        path = f"/api/v4/{channel}/brand/{self.brand}/{self.language}/{_number(version)}"
        async with self._semaphore:
            for attempt in range(self.request_retries + 1):
                self._check_access()
                await self._limit.acquire()
                self._check_access()  # отказ другого запроса мог прийти, пока этот запрос ждал токен
                asked = utcnow()
                started = time.monotonic()
                try:
                    response = await self.http.get(path)
                except RuntimeError:
                    if self.http.is_closed:
                        raise HttpError("BC.Game: network error (client closed)") from None
                    raise
                except httpx.TransportError as exc:
                    if attempt < self.request_retries:
                        await self._sleep(backoff_delay(attempt))
                        continue
                    # Не публикуем текст исключения: в нём могут оказаться учётные данные прокси.
                    raise HttpError(f"BC.Game: network error ({type(exc).__name__})") from None
                self.status.latency_ms = round((time.monotonic() - started) * 1000, 1)
                blocked = self._access_block_error(response)
                if blocked:
                    self._blocked = response.status_code
                    self._blocked_error = blocked
                    break
                if response.status_code in RETRY_STATUSES - {429} and attempt < self.request_retries:
                    await self._sleep(backoff_delay(attempt))
                    continue
                break
        if response.status_code in (401, 403):
            self._blocked = response.status_code
            self._blocked_error = f"BC.Game: HTTP {response.status_code}; access denied"
        if self._blocked_error:
            raise HttpError(self._blocked_error, response.status_code)
        if response.status_code == 429:
            raw = response.headers.get("Retry-After", "")
            delay = to_float(raw)
            if delay is None:
                try:
                    delay = (parsedate_to_datetime(raw) - utcnow()).total_seconds()
                except (TypeError, ValueError, OverflowError):
                    delay = 0
            if delay is not None and math.isfinite(delay):
                self._retry_until = max(self._retry_until, time.monotonic() + max(0, delay))
        if response.status_code != 200:
            suffix = "; redirect not followed" if response.is_redirect else ""
            raise HttpError(f"BC.Game: HTTP {response.status_code}{suffix}", response.status_code)
        if len(response.content) > self.max_bytes:
            raise ValueError("BC.Game: response exceeds the configured size limit")
        try:
            data = response.json()
        except (ValueError, UnicodeError):
            raise ValueError("BC.Game: invalid JSON response") from None
        if not isinstance(data, dict):
            raise ValueError("BC.Game: expected a JSON object")
        return data, asked

    @staticmethod
    def _access_block_error(response: httpx.Response) -> str | None:
        if response.status_code != 503:
            return None
        reason = response.headers.get("bb-rsn", "").strip()
        try:
            body = response.json()
        except ValueError:
            body = None
        error = str(body.get("error", "")).strip().casefold() if isinstance(body, dict) else ""
        if reason.casefold() == "bc" or error == "access blocked":
            detail = f" (bb-rsn: {reason})" if reason else ""
            return f"BC.Game: access blocked by CloudFront{detail}"
        return None

    def _identity(self, payload: dict) -> tuple[str, str, datetime]:
        epoch, version = _number(payload.get("epoch")), _number(payload.get("version"))
        generated = to_float(payload.get("generated"))
        if generated is None or not math.isfinite(generated) or generated < 946_684_800_000:
            raise ValueError("BC.Game: missing or invalid Unix-millisecond source timestamp")
        try:
            stamp = datetime.fromtimestamp(generated / 1000, timezone.utc)
        except (ValueError, OverflowError, OSError):
            raise ValueError("BC.Game: invalid source timestamp") from None
        now = utcnow()
        if stamp > now + timedelta(seconds=self.clock_skew_sec):
            raise ValueError("BC.Game: source timestamp is in the future")
        stamp = min(stamp, now)
        # Long-poll может создать сообщение ПОСЛЕ отправки запроса. asked — только диагностика.
        return epoch, version, stamp

    def _update_evidence(self, previous: dict[QuoteKey, QuoteEvidence], data: dict, patch: dict,
                         generated: datetime, epoch: str, version: str, channel: str,
                         filter_sports: bool = False) -> dict[QuoteKey, QuoteEvidence]:
        """Source clock is diagnostic: its regression must not reject a coherent feed state."""
        options = {"active_statuses": self._active_statuses(channel)}
        if filter_sports:
            options["eligible_sports"] = self._eligible_sports(data)
        try:
            return update_quote_times(previous, data, patch, generated, epoch, version, **options)
        except QuoteTimeRegression:
            return update_quote_times({}, data, patch, generated, epoch, version, **options)

    async def _snapshot(self, channel: str, previous: FeedState | None = None) -> FeedState:
        index, asked = await self._get(channel, "0")
        epoch, _, generated = self._identity(index)
        top, rest = index.get("top_events_versions"), index.get("rest_events_versions")
        if not isinstance(top, list) or not isinstance(rest, list):
            raise ValueError("BC.Game: missing snapshot part index")
        versions = list(dict.fromkeys(_number(v) for v in top + rest))
        if not versions or len(versions) > self.max_parts or "0" in versions:
            raise ValueError("BC.Game: invalid snapshot part count")
        state = FeedState(epoch=epoch, asked_at=asked, generated_at=generated,
                          quote_evidence=previous.quote_evidence.copy() if previous else {})
        complete = False
        for version in versions:
            part, requested = await self._get(channel, version)
            part_epoch, cursor, stamp = self._identity(part)
            if part_epoch != epoch or cursor == "0" or "top_events_versions" in part:
                raise SnapshotExpired("BC.Game: snapshot expired; no partial state was published")
            state.data = merge_payload(state.data, part)
            state.quote_evidence = self._update_evidence(state.quote_evidence, state.data, part, stamp, epoch,
                                                         cursor, channel)
            state.asked_at = min(state.asked_at, requested)
            state.generated_at = min(state.generated_at, stamp)
            state.version = cursor
            complete = part.get("snapshot_complete") is True
        if not complete:
            raise SnapshotExpired("BC.Game: incomplete snapshot")
        eligible = self._eligible_sports(state.data)
        known = previous.quote_evidence if previous else {}
        kept = {}
        for key, saved in state.quote_evidence.items():
            event = state.data["events"].get(key[0], {})
            desc = event.get("desc") if isinstance(event, dict) else None
            if key in known or isinstance(desc, dict) and str(desc.get("sport")) in eligible:
                kept[key] = saved
        state.quote_evidence = kept
        # Отсутствие подтверждает полный manifest; старый посторонний part не ослабляет этот барьер.
        # Это только ограничение повторного появления, не время цены и не точное время удаления.
        state.quote_evidence = finalize_snapshot_times(state.quote_evidence, state.data, generated,
                                                       self._active_statuses(channel))
        state.seen_versions = (state.version,)
        state.confirmed_at = utcnow()
        return state

    async def _read(self, channel: str, previous: FeedState | None) -> FeedState:
        if previous is None:
            return await self._snapshot(channel)
        patch, asked = await self._get(channel, previous.version)
        epoch, version, generated = self._identity(patch)
        if version == "0" or epoch != previous.epoch or "top_events_versions" in patch:
            return await self._snapshot(channel, previous)
        data = merge_payload(previous.data, patch)
        if version == previous.version:
            if data != previous.data:
                raise SnapshotExpired("BC.Game: duplicate version contains different data")
            # Ответ с тем же cursor подтверждает, что сервер не изменил согласованное состояние.
            # Как и полный REST-ответ Stake, это обновляет время подтверждения, но не source evidence.
            confirmed = copy.deepcopy(previous)
            confirmed.asked_at = asked
            confirmed.generated_at = generated
            confirmed.last_delta_generated_at = generated
            confirmed.confirmed_at = utcnow()
            return confirmed
        if version in previous.seen_versions:
            raise SnapshotExpired("BC.Game: previously accepted version replayed out of order")
        if previous.last_delta_generated_at is not None and generated < previous.last_delta_generated_at:
            raise SnapshotExpired("BC.Game: delta source time regressed")
        evidence = self._update_evidence(previous.quote_evidence, data, patch, generated, epoch, version, channel, True)
        return FeedState(data, epoch, version, asked, generated, evidence,
                         (*previous.seen_versions, version)[-256:], generated, utcnow())

    async def _sync(self) -> None:
        # Discovery и polling не могут перемешать версии одного фида.
        async with self._lock:
            next_feeds = {}
            for channel in self.channels:
                next_feeds[channel] = await self._read(channel, self.feeds.get(channel))
            self.feeds = next_feeds
            self.status.connected = True
            self.status.error = None
            self.status.last_update = min(f.confirmed_at or f.asked_at for f in self.feeds.values())

    def set_paired(self, keys: set[str]) -> None:
        """Пары получают каждый delta, остальные рынки публикуются с медленным интервалом.

        BETBY отдаёт один общий фид, а не запрос на каждый матч. Новых сетевых запросов на каждую пару нет.
        """
        self._paired = set(keys)
        released = False
        # Scanner вызывает hook только после завершённого rematch. Старые метаданные не подтверждают новый фид.
        for key, market in self._subscribed.items():
            fresh = self._latest_market(market.market_id)
            if fresh is not None and self._matching_signature(fresh) == self._matching_signature(market):
                self._matched_metadata[key] = self._matching_signature(market)
                if key in self._needs_rematch:
                    self._needs_rematch.remove(key)
                    self._published.pop(key, None)
                    released = True
        if released:
            self._publish()

    @staticmethod
    def _matching_signature(market: NormalizedMarket) -> tuple:
        return (market.game, market.market_type, market.line, market.start_time, market.best_of,
                market.is_live, tuple(sorted((market.team_a, market.team_b))))

    def _invalidate(self, market: NormalizedMarket) -> None:
        """Не даём старой паре использовать книгу до повторного сопоставления новых метаданных."""
        self._needs_rematch.add(market.key)
        affected = [market]
        existing = self._subscribed.get(market.key)
        if existing is not None and existing is not market:
            affected.append(existing)
        stamp = utcnow()
        for item in affected:
            item.accepting_orders = False
            item.set_books([], [], None, None, stamp)

    def _latest_market(self, event_id: str) -> NormalizedMarket | None:
        for channel in reversed(self.channels):
            state = self.feeds.get(channel)
            if state is not None and event_id in state.data["events"]:
                return self._market(event_id, state, channel)
        return None

    @staticmethod
    def _best_of(event: dict) -> int | None:
        return effective_best_of(event)

    @staticmethod
    def _active_statuses(channel: str) -> tuple[int, ...]:
        return (0,) if channel == "prematch" else (0, 1)

    def _eligible_sports(self, data: dict) -> set[str]:
        slugs = {slug for cfg in self.game_filters().values() for slug in cfg.get("sport_slugs", [])}
        return {key for key, value in data.get("sports", {}).items() if value.get("slug") in slugs}

    def _market(self, event_id: str, state: FeedState, channel: str) -> NormalizedMarket | None:
        event = state.data["events"].get(event_id)
        if not isinstance(event, dict) or not _NUMERIC.fullmatch(event_id):
            return None
        desc, status = event.get("desc"), event.get("state")
        if not isinstance(desc, dict) or not isinstance(status, dict) or desc.get("type") != "match":
            return None
        live = channel == "live"
        if isinstance(status.get("status"), bool) or status.get("status") not in ((0, 1) if live else (0,)):
            return None
        sport = state.data["sports"].get(str(desc.get("sport")), {})
        game = next((g for g, flt in self.game_filters().items()
                     if sport.get("slug") in flt.get("sport_slugs", [])), None)
        if game is None:
            return None
        scheduled = to_float(desc.get("scheduled"))
        if scheduled is None or scheduled <= 0:
            return None
        try:
            start = datetime.fromtimestamp(scheduled, timezone.utc)
        except (ValueError, OverflowError, OSError):
            return None
        now = utcnow()
        if start > now + timedelta(hours=self.settings.discovery.horizon_hours):
            return None
        if live:
            if not self.include_live or start < now - timedelta(hours=self.settings.discovery.live_grace_hours):
                return None
        elif start <= now:  # не включаем начавшийся матч только из-за задержки флага площадки
            return None
        teams = desc.get("competitors")
        if not isinstance(teams, list) or len(teams) != 2 or not all(isinstance(t, dict) for t in teams):
            return None
        names = [str(t.get("name") or "").strip() for t in teams]
        if not all(names) or names[0].casefold() == names[1].casefold():
            return None
        markets = event.get("markets", {})
        if not isinstance(markets, dict):
            return None
        best_of = self._best_of(event)
        if best_of is not None and best_of % 2 == 0:
            return None
        if isinstance(markets.get("1"), dict) and "" in markets["1"]:
            return None  # match-level 1x2 означает возможность ничьей
        variants = markets.get(WINNER_ID)
        selections = variants.get("") if isinstance(variants, dict) else None
        if not isinstance(selections, dict) or set(selections) != {"4", "5"}:
            return None
        levels = []
        for outcome, name in zip(("4", "5"), names):
            value = selections[outcome]
            if not isinstance(value, dict) or value.get("b") in (1, "1"):
                return None
            level = odds_level(value.get("k"), self.max_stake, name)
            if level is None:
                return None
            levels.append(level)
        category = state.data["categories"].get(str(desc.get("category")), {})
        tournament = state.data["tournaments"].get(str(desc.get("tournament")), {})
        slugs = [sport.get("slug"), category.get("slug"), tournament.get("slug"), desc.get("slug")]
        if all(isinstance(s, str) and s for s in slugs):
            url = self.web_url + "/" + "/".join(quote(s, safe="-") for s in slugs) + "-" + event_id
        else:
            url = self.web_url
        market = NormalizedMarket(
            platform=self.platform, market_id=event_id, event_title=f"{names[0]} - {names[1]}", game=game,
            team_a=names[0], team_b=names[1], start_time=start, url=url, resolution_rules=BCGAME_RULES,
            tournament=tournament.get("name"), best_of=best_of, fee=FeeSpec(model="none"),
            is_live=live, min_order_size=0.0,
            extra={"channel": channel, "sport_id": desc.get("sport"), "market_id": WINNER_ID,
                   "max_stake_usd": self.max_stake, "stake_limit_assumed": True},
        )
        clocks = quote_times(state.data, event_id, state.quote_evidence)
        market.extra["bcgame_quote_times"] = {k: v.isoformat() if v else None for k, v in clocks.items()}
        market.extra["bcgame_quote_sources"] = {
            outcome: {"epoch": saved.epoch, "version": saved.version}
            if clocks[outcome] is not None and (saved := state.quote_evidence.get((event_id, outcome))) else None
            for outcome in ("4", "5")
        }
        market.extra["source_generated_at"] = state.generated_at.isoformat() if state.generated_at else None
        market.extra["timestamp_kind"] = "response_time_after_coherent_feed_sync"
        market.extra["actual_price_change_at"] = None  # источник этого поля не предоставляет
        self._set_source_books(market, [levels[0]], [levels[1]], state.confirmed_at or state.asked_at)
        return market

    @staticmethod
    def _set_source_books(market: NormalizedMarket, a: list, b: list, stamp: datetime | None) -> None:
        # Общий set_books подставляет utcnow при None; неизвестная котировка не должна стать свежей.
        market.set_books(a, b, None, None, stamp if stamp is not None else _UNKNOWN_TIME)
        market.updated_at = stamp

    def normalize(self, raw: Any) -> list[NormalizedMarket]:
        """Рынок по {id, channel} из последнего согласованного фида."""
        if not isinstance(raw, dict):
            return []
        channel = raw.get("channel", "prematch")
        state = self.feeds.get(channel)
        market = self._market(str(raw.get("id", "")), state, channel) if state else None
        return [market] if market else []

    def _failure(self, exc: Exception) -> None:
        self.status.connected = False
        # Прошлое время успешного ответа и время ответа с ошибкой не должны выглядеть текущей метрикой.
        self.status.latency_ms = None
        if isinstance(exc, HttpError):
            self.status.error = str(exc)[:200]
        else:
            detail = str(exc).strip()
            suffix = f": {detail}" if detail else ""
            self.status.error = f"BC.Game: feed unavailable ({type(exc).__name__}){suffix}"[:200]

    async def fetch_markets(self) -> list[NormalizedMarket]:
        """Полный список из атомарно обновлённого фида; ошибка не выдаёт пустой список."""
        try:
            await self._sync()
        except Exception as exc:
            self._failure(exc)
            raise HttpError(self.status.error, getattr(exc, "status", None)) from None
        markets = {}
        for channel, state in self.feeds.items():
            for event_id in state.data["events"]:
                market = self._market(event_id, state, channel)
                if market:
                    previous = self._matched_metadata.get(market.key)
                    if (market.key in self._needs_rematch
                            or previous is not None and previous != self._matching_signature(market)):
                        self._invalidate(market)
                    markets[market.key] = market
        self.status.markets = len(markets)
        return list(markets.values())

    def _publish(self, force: bool = False) -> None:
        now = time.monotonic()
        for market in self._subscribed.values():
            # Live заменяет pre-match при переходе; при include_live=false начавшийся матч исчезает.
            fresh = self._latest_market(market.market_id)
            same_teams = fresh is not None and {fresh.team_a, fresh.team_b} == {market.team_a, market.team_b}
            matched = self._matched_metadata.get(market.key, self._matching_signature(market))
            if (not same_teams or market.key in self._needs_rematch
                    or self._matching_signature(fresh) != matched):
                self._invalidate(market)
                self.notify(market)
                continue
            paired = self._paired is None or market.key in self._paired
            if not force and not paired and now - self._published.get(market.key, float("-inf")) < self.slow_poll_sec:
                continue
            a, b = (fresh.asks_a, fresh.asks_b) if fresh.team_a == market.team_a else (fresh.asks_b, fresh.asks_a)
            self._set_source_books(market, a, b, fresh.updated_at)
            market.start_time, market.is_live = fresh.start_time, fresh.is_live
            market.url, market.tournament, market.best_of = fresh.url, fresh.tournament, fresh.best_of
            market.accepting_orders = True
            market.extra.update(fresh.extra)
            self._published[market.key] = now
            self.notify(market)

    async def subscribe_prices(self, markets: list[NormalizedMarket], on_update: PriceCallback) -> None:
        self._callback = on_update
        self._subscribed = {m.key: m for m in markets}
        self._matched_metadata = {k: v for k, v in self._matched_metadata.items() if k in self._subscribed}
        self._needs_rematch &= self._subscribed.keys()
        for market in markets:
            self._matched_metadata.setdefault(market.key, self._matching_signature(market))
        self._published = {k: v for k, v in self._published.items() if k in self._subscribed}
        self._publish(force=True)
        if self._poll_task is None or self._poll_task.done():
            self._poll_task = self.spawn(self._poll_loop(), "poll")

    async def poll_once(self) -> None:
        """Один общий запрос delta на канал, затем обновление подписанных рынков."""
        await self._sync()
        self._publish()

    async def _poll_loop(self) -> None:
        failed = False
        while self._running:
            started = time.monotonic()
            try:
                await self.poll_once()
                if failed:
                    self.log.info("Гостевой фид BC.Game снова доступен")
                failed, self._backoff = False, 0.0
                delay = max(0, self.poll_sec - (time.monotonic() - started))
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self._failure(exc)
                if not failed:
                    self.log.warning("Гостевой фид BC.Game недоступен: %s", self.status.error)
                failed = True
                if self._blocked:
                    return  # 401/403: не обходим ограничение и не повторяем запросы
                self._backoff = min(60.0, max(10.0, 2 * self._backoff))
                delay = max(self._backoff, self._retry_until - time.monotonic())
            await self._sleep(delay)

    async def fetch_book(self, market: NormalizedMarket) -> NormalizedMarket:
        """Отдельное REST-чтение для бумажной проверки, без изменения книг и версии сканера."""
        market = market.model_copy(deep=True)  # фиксируем контракт и ориентацию до первого await
        channel = str(market.extra.get("channel", "prematch"))
        if channel not in self.channels:
            raise ValueError("BC.Game: unsupported feed channel")
        async with self._lock:
            previous = self.feeds.get(channel)
        state = await self._read(channel, previous)
        fresh = self._market(market.market_id, state, channel)
        if fresh is None:
            raise ValueError("BC.Game: match winner market is unavailable")
        if {fresh.team_a, fresh.team_b} != {market.team_a, market.team_b}:
            raise ValueError("BC.Game: teams changed")
        if self._matching_signature(fresh) != self._matching_signature(market):
            raise ValueError("BC.Game: matching metadata changed")
        if fresh.updated_at is None:
            raise ValueError("BC.Game: quote source timestamp is unavailable")
        result = market
        a, b = (fresh.asks_a, fresh.asks_b) if fresh.team_a == market.team_a else (fresh.asks_b, fresh.asks_a)
        result.set_books(a, b, None, None, fresh.updated_at)
        result.extra.update(fresh.extra)
        result.is_live, result.accepting_orders = fresh.is_live, fresh.accepting_orders
        return result
