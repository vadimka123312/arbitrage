"""Консервативное время свидетельства по каждому исходу BETBY, а не по всему фиду.

Время изменения цены в бизнес-системе источник не сообщает. Используется только
generated сообщения, которое действительно изменило этот исход или его доступность.
Время отправки/получения HTTP не становится временем котировки. Неизменившийся
исход сохраняет прежнюю отметку даже после нового snapshot или смены epoch.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace
from datetime import datetime
import re
from typing import Any

QuoteKey = tuple[str, str]
_FORMAT = re.compile(r"(?:best[_ -]?of[= :_-]*|\bbo\s*)(\d+)", re.I)


class QuoteTimeRegression(ValueError):
    """Новые значения нельзя связать с более старым свидетельством источника."""


@dataclass(frozen=True)
class QuoteEvidence:
    identity: tuple
    fingerprint: tuple | None
    source_at: datetime | None
    watermark_at: datetime
    epoch: str
    version: str
    unavailable_at: datetime | None = None


def effective_best_of(event: dict) -> int | None:
    """Единая семантика формата для нормализации и привязки времени к контракту."""
    desc = event.get("desc") or {}
    if not isinstance(desc, dict):
        return None
    explicit = desc.get("best_of")
    if isinstance(explicit, int) and not isinstance(explicit, bool) and 1 <= explicit <= 9:
        return explicit
    texts = [str(desc.get(k, "")) for k in ("name", "format", "slug")]
    markets = event.get("markets") or {}
    if isinstance(markets, dict):
        for variants in markets.values():
            if isinstance(variants, dict):
                texts.extend(s for s in variants if isinstance(s, str) and "mapnr=" not in s)
    for text in texts:
        found = _FORMAT.search(text)
        if found and 1 <= int(found.group(1)) <= 9:
            return int(found.group(1))
    return None


def _selection(event: dict, outcome: str) -> dict | None:
    markets = event.get("markets")
    winner = markets.get("186") if isinstance(markets, dict) else None
    selections = winner.get("") if isinstance(winner, dict) else None
    value = selections.get(outcome) if isinstance(selections, dict) else None
    return value if isinstance(value, dict) else None


def contract_identity(event: Any, sports: dict | None = None) -> tuple | None:
    if not isinstance(event, dict):
        return None
    desc = event.get("desc")
    teams = desc.get("competitors") if isinstance(desc, dict) else None
    if not isinstance(teams, list) or len(teams) != 2:
        return None
    identities = []
    for team in teams:
        if not isinstance(team, dict):
            return None
        identity = team.get("id") or team.get("name")
        if not identity:
            return None
        identities.append((str(team.get("id") or ""), str(team.get("name") or "")))
    sport = (sports or {}).get(str(desc.get("sport")), {})
    slug = sport.get("slug") if isinstance(sport, dict) else None
    return (str(desc.get("sport")), slug, str(desc.get("type")), tuple(identities),
            str(desc.get("scheduled")), effective_best_of(event))


def fingerprint(event: Any, outcome: str) -> tuple | None:
    """Одинаковая строка коэффициента не обязательна: 2, 2.0 и '2.00' — одно значение."""
    if not isinstance(event, dict):
        return None
    value = _selection(event, outcome)
    if value is None:
        return None
    try:
        odds = float(value.get("k"))
    except (TypeError, ValueError, OverflowError):
        return None
    if not math.isfinite(odds) or odds <= 1:
        return None
    blocked = value.get("b") in (1, "1")
    return odds, blocked


def update_quote_times(
    previous: dict[QuoteKey, QuoteEvidence],
    data: dict,
    patch: dict,
    source_at: datetime,
    epoch: str,
    version: str,
    *,
    active_statuses: tuple[int, ...] = (0, 1),
    eligible_sports: set[str] | None = None,
) -> dict[QuoteKey, QuoteEvidence]:
    """Обновляет только явно переданные, действительно изменённые исходы.

    История удалённых исходов сохраняется: повторный snapshot не омолаживает старую цену.
    Все операции выполняются на копии; повреждённый пакет не меняет принятые отметки.
    """
    result = previous.copy()
    changes = dict(patch.get("events") or {})
    if isinstance(patch.get("sports"), dict):
        changed_sports = set(patch["sports"])
        for event_id, _ in previous:
            event = data.get("events", {}).get(event_id)
            desc = event.get("desc") if isinstance(event, dict) else None
            if isinstance(desc, dict) and str(desc.get("sport")) in changed_sports:
                changes.setdefault(event_id, {})  # только метаданные, не выдуманная новая цена
    for event_id, event_patch in changes.items():
        if event_patch is None:
            for outcome in ("4", "5"):
                _unavailable(result, (event_id, outcome), source_at)
            continue
        event = data.get("events", {}).get(event_id)
        if eligible_sports is not None:
            desc = event.get("desc") if isinstance(event, dict) else None
            sport = str(desc.get("sport")) if isinstance(desc, dict) else ""
            if sport not in eligible_sports and not any((event_id, o) in result for o in ("4", "5")):
                continue
        identity = contract_identity(event, data.get("sports"))
        if not isinstance(event_patch, dict):
            continue
        markets = event_patch.get("markets")
        winner = markets.get("186") if isinstance(markets, dict) else None
        selections = winner.get("") if isinstance(winner, dict) else None
        selections = selections if isinstance(selections, dict) else {}
        for outcome in ("4", "5"):
            key = (event_id, outcome)
            old = result.get(key)
            value = fingerprint(event, outcome)
            if _explicit_unavailable(event_patch, event, outcome, active_statuses):
                _unavailable(result, key, source_at)
                continue
            if identity is None:
                continue
            if old is not None and old.unavailable_at is not None and outcome in selections:
                if source_at <= old.unavailable_at:
                    raise QuoteTimeRegression("BC.Game: old evidence cannot cancel unavailability")
                old = replace(old, unavailable_at=None, watermark_at=max(old.watermark_at, source_at))
                result[key] = old
            if old is not None and old.identity != identity:
                if source_at < old.watermark_at:
                    raise QuoteTimeRegression("BC.Game: contract source time regressed")
                # Метаданные не подтверждают цену для нового контракта. Нужен явный исход, не чужой score.
                old = QuoteEvidence(identity, value, None, source_at, epoch, version)
                result[key] = old
            if outcome not in selections or value is None:
                continue
            if old is not None and old.fingerprint == value and old.source_at is not None:
                continue
            if old is not None and source_at < old.watermark_at:
                raise QuoteTimeRegression("BC.Game: quote source time regressed")
            result[key] = QuoteEvidence(identity, value, source_at, source_at, epoch, version)
    return result


def _available(event: Any, statuses: tuple[int, ...]) -> bool:
    if not isinstance(event, dict):
        return False
    desc = event.get("desc")
    markets = event.get("markets")
    winner = markets.get("186") if isinstance(markets, dict) else None
    selections = winner.get("") if isinstance(winner, dict) else None
    if (not isinstance(desc, dict) or desc.get("type") != "match"
            or not isinstance(selections, dict) or set(selections) != {"4", "5"}):
        return False
    teams = desc.get("competitors")
    if not isinstance(teams, list) or len(teams) != 2 or not all(isinstance(t, dict) for t in teams):
        return False
    names = [str(t.get("name") or "").strip() for t in teams]
    if not all(names) or names[0].casefold() == names[1].casefold():
        return False
    if isinstance(markets.get("1"), dict) and "" in markets["1"]:
        return False
    best_of = effective_best_of(event)
    if best_of is not None and best_of % 2 == 0:
        return False
    state = event.get("state")
    status = state.get("status") if isinstance(state, dict) else None
    values = [fingerprint(event, side) for side in ("4", "5")]
    return (not isinstance(status, bool) and status in statuses
            and all(value is not None and not value[1] for value in values))


def _explicit_unavailable(patch: dict, event: Any, outcome: str, statuses: tuple[int, ...]) -> bool:
    markets = patch.get("markets")
    if ("state" in patch or "desc" in patch) and not _available(event, statuses):
        return True
    if "markets" in patch and not isinstance(markets, dict):
        return True
    if isinstance(markets, dict) and not _available(event, statuses):
        return True  # в том числе third/1x2/BO2 без повторной передачи 4/5
    if isinstance(markets, dict) and "186" in markets:
        winner = markets["186"]
        if not isinstance(winner, dict) or "" in winner and not isinstance(winner[""], dict):
            return True
        selections = winner.get("") if isinstance(winner, dict) else None
        if isinstance(selections, dict) and outcome in selections and not _available(event, statuses):
            return True
    return bool(patch.get("shouldResetEvent") and not _available(event, statuses))


def _unavailable(records: dict[QuoteKey, QuoteEvidence], key: QuoteKey, stamp: datetime) -> None:
    old = records.get(key)
    if old is not None:
        if stamp < old.watermark_at:
            raise QuoteTimeRegression("BC.Game: unavailability source time regressed")
        records[key] = replace(old, watermark_at=stamp, unavailable_at=stamp)


def finalize_snapshot_times(records: dict[QuoteKey, QuoteEvidence], data: dict, stamp: datetime,
                            active_statuses: tuple[int, ...]) -> dict[QuoteKey, QuoteEvidence]:
    """Только полный snapshot подтверждает отсутствие; частичные части не удаляют чужие исходы."""
    result = records.copy()
    for key, old in records.items():
        if not _available(data.get("events", {}).get(key[0]), active_statuses):
            # Старый snapshot не имеет права уменьшить уже известный барьер недоступности.
            _unavailable(result, key, max(stamp, old.watermark_at))
    return result


def quote_times(data: dict, event_id: str, evidence: dict[QuoteKey, QuoteEvidence]) -> dict[str, datetime | None]:
    event = data.get("events", {}).get(event_id)
    result = {}
    for outcome in ("4", "5"):
        saved = evidence.get((event_id, outcome))
        result[outcome] = (saved.source_at if saved is not None and saved.unavailable_at is None
                           and saved.identity == contract_identity(event, data.get("sports"))
                           and saved.fingerprint is not None and saved.fingerprint == fingerprint(event, outcome)
                           else None)
    return result
