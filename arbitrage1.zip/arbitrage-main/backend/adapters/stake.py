"""Stake adapter: the official STAKE Sports Data API (``https://odds-data.stake.com``), read only.

* Discovery: ``GET /sport/<sport slug>/fixture?limit=50&offset=<n>`` per game (exact start time, status, tournament
  name). ``/schedule/sport/<slug>`` lists the same fixtures, but rounds the start time down to the hour and has no
  tournament. The web link needs the category and tournament slugs: ``/sport/<slug>/category`` and
  ``/sport/<slug>/tournament`` (cached for ``meta_refresh_sec``). A game whose list fails keeps its last list.
* Odds: ``GET /fixtures/<fixture slug>`` per fixture; there is no batch endpoint and no WebSocket, so odds are polled.
  Only the market ``Match Winner - Twoway`` is used (no map markets, no three-way markets): the market must be
  ``active`` and each outcome ``active`` with decimal odds above 1. A fixture where a draw is possible (BO2, or a
  match-level three-way market) is skipped: a draw voids the two-way bet.
* Order-book model: price = 1 / odds; one level per outcome with size = ``max_stake_usd`` x odds contracts (a winning
  bet of ``max_stake_usd`` pays that many dollars, like that many $1 contracts). No fee: the bookmaker margin is
  inside the odds. Bids do not exist.
* Pre-match only by default (``include_live: false``): live bets are accepted with a delay and the odds jump.
* Polling: fixtures in a pair or in manual review (``set_paired``) are asked every ``poll_interval_sec``; the others
  every ``slow_poll_interval_sec``, only with the requests left in a pass. Each answer is applied as soon as it arrives
  and is stamped with the time the request was sent. Two passes in a row where most requests fail mark Stake as down,
  and the loop backs off (10 s doubling to 60 s); so do two passes in a row with an HTTP 429.
* The API answers without a key (checked 2026-10-16), although its spec declares an ``X-API-KEY`` header: the key from
  the environment variable ``ARB_STAKE_API_KEY`` (``.env``) is sent when it is set. It is never logged, and redirects
  are not followed (httpx would carry a custom header to another host).
"""

from __future__ import annotations

import asyncio
import math
import os
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Iterator
from urllib.parse import quote

from backend.adapters.base import MarketAdapter, PriceCallback
from backend.adapters.common import to_float
from backend.config import PlatformConfig, Settings
from backend.matching.rules import STAKE_RULES
from backend.models import FeeSpec, Level, NormalizedMarket, utcnow
from backend.net import HttpClient, HttpError, describe_error

API_KEY_ENV = "ARB_STAKE_API_KEY"
DEFAULT_MARKET = "Match Winner - Twoway"
MAX_PAGE_SIZE = 50  # the list endpoints reject a larger limit ("numberLessEqual")
MAX_BACKOFF_SEC = 60.0
_BEST_OF_RE = re.compile(r"(?:^|\|)best_of=(\d+)")


def ms_to_dt(value: Any) -> datetime | None:
    """Milliseconds since the Unix epoch -> aware UTC datetime (None for missing or zero values)."""
    number = to_float(value)
    if number is None or number <= 0:
        return None
    return datetime.fromtimestamp(number / 1000, timezone.utc)


def iter_markets(groups: Any) -> Iterator[dict[str, Any]]:
    """Every market of a fixture response once.

    The spec describes ``groups[].markets`` as a list of markets; the live API returns a list of market lists. Both
    are accepted. The same market is listed in several groups (``winner``, ``main``, ``threeway``): deduplicated by id.
    """
    seen: set[str] = set()
    for group in groups or []:
        if not isinstance(group, dict):
            continue
        for item in group.get("markets") or []:
            for market in item if isinstance(item, list) else [item]:
                if not isinstance(market, dict):
                    continue
                key = str(market.get("id") or "") or f"#{id(market)}"
                if key in seen:
                    continue
                seen.add(key)
                yield market


def _clean(text: Any) -> str:
    return " ".join(str(text or "").split()).casefold()


def find_match_winner(markets: list[dict[str, Any]], name: str = DEFAULT_MARKET) -> dict[str, Any] | None:
    """The two-way match winner market of a fixture: the configured name, two outcomes, not a map, not three-way."""
    wanted = _clean(name)
    for market in markets:
        specifiers = str(market.get("specifiers") or "")
        if _clean(market.get("name")) != wanted or "map=" in specifiers or "way=three" in specifiers:
            continue
        outcomes = market.get("outcomes")
        if isinstance(outcomes, list) and len(outcomes) == 2 and all(isinstance(o, dict) for o in outcomes):
            return market
    return None


def parse_best_of(markets: list[dict[str, Any]]) -> int | None:
    """Match format from a match-level specifier such as ``best_of=3`` (market "Correct Score"); None if absent."""
    for market in markets:
        specifiers = str(market.get("specifiers") or "")
        match = _BEST_OF_RE.search(specifiers)
        if match and "map=" not in specifiers:
            return int(match.group(1))
    return None


def draw_possible(markets: list[dict[str, Any]], best_of: int | None) -> bool:
    """A draw of the match is possible: an even best-of (BO2) or a match-level three-way market (1X2)."""
    if best_of and best_of % 2 == 0:
        return True
    for market in markets:
        specifiers = str(market.get("specifiers") or "")
        if "map=" not in specifiers and ("way=three" in specifiers or "threeway" in _clean(market.get("name"))):
            return True
    return False


def fmt_odds(odds: float) -> str:
    """Decimal odds as on the dashboard: ``1,78``, ``10``."""
    return f"{odds:g}".replace(".", ",")


def odds_level(odds: Any, max_stake_usd: float, team: str) -> Level | None:
    """The level of a bet on ``team``: price 1 / odds, size max_stake_usd x odds contracts; None when not offered."""
    value = to_float(odds)
    if (value is None or not math.isfinite(value) or value <= 1.0
            or not math.isfinite(max_stake_usd) or max_stake_usd <= 0):
        return None
    size = max_stake_usd * value
    if not math.isfinite(size):
        return None
    return Level(
        price=1.0 / value,
        size=round(size, 6),
        instrument=f"Ставка «{team}», коэф. {fmt_odds(value)}",
    )


@dataclass
class FixtureOdds:
    """The last ``/fixtures/<slug>`` response of one fixture, parsed."""

    asked_at: datetime  # when the request was sent: the answer is at least this fresh
    fixture: dict[str, Any]
    market: dict[str, Any] | None  # the two-way match winner market (None: not offered)
    best_of: int | None
    draw_possible: bool = False


class StakeAdapter(MarketAdapter):
    """Stake sportsbook: two-way match winner odds of esports fixtures (only reads odds, never places bets)."""

    def __init__(self, platform_id: str, cfg: PlatformConfig, settings: Settings):
        super().__init__(platform_id, cfg, settings)
        self.api_url = str(cfg.opt("api_url", "https://odds-data.stake.com")).rstrip("/")
        self.web_url = str(cfg.opt("web_url", "https://stake.com/sports")).rstrip("/")
        self.rate = float(cfg.opt("rate_limit_per_sec", 8))
        api_key = os.getenv(API_KEY_ENV, "").strip()
        self.http = HttpClient(
            self.api_url, "stake", self.rate, timeout=float(cfg.opt("request_timeout_sec", 3.0)),
            headers={"X-API-KEY": api_key} if api_key else None, follow_redirects=False,
        )
        self.market_name = str(cfg.opt("market_name", DEFAULT_MARKET))
        self.max_stake_usd = float(cfg.opt("max_stake_usd", 50.0))
        self.poll_sec = float(cfg.opt("poll_interval_sec", 5.0))
        self.slow_poll_sec = float(cfg.opt("slow_poll_interval_sec", 120.0))
        self.include_live = bool(cfg.opt("include_live", False))
        self.page_size = max(1, min(MAX_PAGE_SIZE, int(cfg.opt("page_size", MAX_PAGE_SIZE))))
        self.max_pages = max(1, int(cfg.opt("max_pages", 10)))
        self.meta_refresh_sec = float(cfg.opt("meta_refresh_sec", 3600))
        self.concurrency = max(1, int(cfg.opt("max_concurrency", 4)))
        self.status.mode = "rest"
        self.sport_game: dict[str, str] = {}
        for game, flt in self.game_filters().items():
            for sport in flt.get("sport_slugs", []) or []:
                self.sport_game[str(sport)] = game
        self.odds: dict[str, FixtureOdds] = {}  # fixture slug -> last odds
        self._fetched: dict[str, float] = {}  # fixture slug -> monotonic time of the last odds request
        self._lists: dict[str, list[dict[str, Any]]] = {}  # sport -> last fixture list that arrived
        self._list_failing: set[str] = set()  # sports whose fixture list failed (logged once)
        self._links: dict[str, dict[str, str]] = {}  # sport -> tournament id -> "<category slug>/<tournament slug>"
        self._links_checked: dict[str, float] = {}
        self._failing: set[str] = set()  # fixtures whose last odds request failed (logged once)
        self._paired: set[str] | None = None  # None until the scanner reports the pairs: every fixture is fast
        self._apply_failing: set[str] = set()  # fixtures whose answer could not be applied (a bug; logged once)
        self._odds_down = False  # discovery: every new fixture's odds request failed (logged once)
        self._backoff = 0.0
        self._sleep = asyncio.sleep  # replaced in tests
        self._poll_task: asyncio.Task[Any] | None = None

    async def stop(self) -> None:
        await super().stop()
        await self.http.aclose()

    def set_paired(self, keys: set[str]) -> None:
        """Markets in a pair or in review are polled every ``poll_interval_sec``, the rest less often."""
        self._paired = set(keys)

    # ---- discovery -------------------------------------------------------------------

    async def _list(self, path: str, key: str) -> list[dict[str, Any]]:
        """All items of a paged list endpoint (``limit`` / ``offset``)."""
        items: dict[str, dict[str, Any]] = {}
        for page in range(self.max_pages):
            data = await self.http.get_json(
                path, params={"limit": self.page_size, "offset": page * self.page_size}, retries=2,
            )
            batch = data.get(key) if isinstance(data, dict) else None
            if not isinstance(batch, list):  # not an empty list but another answer: the caller keeps its last list
                raise ValueError(f"unexpected answer from {path} (no '{key}' list)")
            before = len(items)
            for item in batch:
                if isinstance(item, dict):
                    items[str(item.get("slug") or item.get("id") or len(items))] = item
            if len(batch) < self.page_size or len(items) == before:  # last page (or the offset was ignored)
                return list(items.values())
        raise ValueError(f"Stake: pagination limit reached before the last page ({path})")

    async def _refresh_links(self, sport: str, fixtures: list[dict[str, Any]]) -> None:
        """Tournament and category slugs of the web links: hourly, or after 5 min when a fixture has an unknown one."""
        known = self._links.get(sport, {})
        unknown = any(str(f.get("tournamentId") or "") not in known for f in fixtures)
        checked = self._links_checked.get(sport)
        age = time.monotonic() - checked if checked is not None else float("inf")
        if age < self.meta_refresh_sec and not (unknown and age >= 300):
            return
        self._links_checked[sport] = time.monotonic()
        try:
            categories = await self._list(f"/sport/{sport}/category", "category")
            tournaments = await self._list(f"/sport/{sport}/tournament", "tournament")
        except Exception as exc:  # noqa: BLE001 - links fall back to the sport page
            self.log.warning("%s: tournament list unavailable (%s), links lead to the sport page",
                             sport, describe_error(exc))
            return
        category_slug = {str(c.get("id")): str(c.get("slug")) for c in categories if c.get("id") and c.get("slug")}
        links: dict[str, str] = {}
        for tournament in tournaments:
            category = category_slug.get(str(tournament.get("categoryId") or ""))
            if tournament.get("id") and tournament.get("slug") and category:
                links[str(tournament["id"])] = f"{category}/{tournament['slug']}"
        self._links[sport] = links

    def _url(self, sport: str, tournament_id: str, slug: str) -> str:
        path = self._links.get(sport, {}).get(tournament_id)
        return f"{self.web_url}/{sport}/{path}/{slug}" if path else f"{self.web_url}/{sport}"

    def _open(self, fixture: dict[str, Any]) -> bool:
        """The fixture takes bets: enabled, not blacklisted, pre-match (live only with ``include_live``)."""
        if fixture.get("enabled") is False or fixture.get("blacklisted"):
            return False
        if fixture.get("status") == "live":
            return self.include_live and fixture.get("inPlayEnabled") is not False
        return fixture.get("status") == "active" and fixture.get("preMatchEnabled") is not False

    def _wanted(self, fixture: dict[str, Any], now: datetime) -> bool:
        """An open match in the discovery window."""
        if not fixture.get("slug") or fixture.get("type") not in (None, "match") or not self._open(fixture):
            return False
        start = ms_to_dt(fixture.get("startTime"))
        if start is not None:
            disc = self.settings.discovery
            if start > now + timedelta(hours=disc.horizon_hours) or start < now - timedelta(hours=disc.live_grace_hours):
                return False
        return True

    async def _fixture_lists(self) -> dict[str, list[dict[str, Any]]]:
        """Fixture list per sport. A failed list is replaced by the last one that arrived; all failed -> raise."""
        lists: dict[str, list[dict[str, Any]]] = {}
        errors: dict[str, BaseException] = {}
        for sport in self.sport_game:
            try:
                lists[sport] = self._lists[sport] = await self._list(f"/sport/{sport}/fixture", "fixture")
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - one game must not stop the others
                errors[sport] = exc
        if errors and not lists:
            raise next(iter(errors.values()))  # the scanner logs the failed discovery and keeps the known markets
        for sport, exc in errors.items():
            if sport not in self._list_failing:
                self._list_failing.add(sport)
                self.log.warning("%s: fixture list unavailable (%s), its last list is used", sport, describe_error(exc))
            lists[sport] = self._lists.get(sport, [])
        for sport in self._list_failing - errors.keys():
            self._list_failing.discard(sport)
            self.log.info("%s: fixture list available again", sport)
        return lists

    async def fetch_markets(self) -> list[NormalizedMarket]:
        """Discover open two-way match winner markets for every configured game."""
        now = utcnow()
        found: list[tuple[dict[str, Any], str, str]] = []
        for sport, fixtures in (await self._fixture_lists()).items():
            if sport not in self._list_failing:
                await self._refresh_links(sport, fixtures)
            found += [(f, sport, self.sport_game[sport]) for f in fixtures if self._wanted(f, now)]
        listed = {str(f["slug"]) for f, _, _ in found}
        self.odds = {slug: state for slug, state in self.odds.items() if slug in listed}
        self._fetched = {slug: ts for slug, ts in self._fetched.items() if slug in listed}
        self._failing &= listed
        # Odds of fixtures that have no answer yet (new, or every request so far failed), and a fresh look at those
        # without a usable two-way market (none, unnamed teams, a draw) after slow_poll_interval_sec. The poll loop
        # keeps the others up to date.
        mono = time.monotonic()
        missing = [
            slug for slug in listed
            if slug not in self.odds
            or (not self._usable(self.odds[slug]) and mono - self._fetched.get(slug, 0.0) >= self.slow_poll_sec)
        ]
        results = await self._fetch_many(missing)
        markets = [m for m in (self._build_market(f, sport, game) for f, sport, game in found) if m is not None]
        errors = [error for error in results.values() if error is not None]
        if errors and len(errors) == len(results):  # not one odds request answered (a key now required? blocked?)
            recent = now - timedelta(seconds=2 * self.slow_poll_sec)
            if not markets and not any(state.asked_at >= recent for state in self.odds.values()):
                raise errors[-1]  # no odds at all: the scanner logs a failed discovery and Stake is not healthy
            if not self._odds_down:
                self.log.warning("odds unavailable for all %d new fixtures: %s", len(errors), describe_error(errors[-1]))
            self._odds_down = True
        elif results and self._odds_down:
            self._odds_down = False
            self.log.info("odds of new fixtures available again")
        self.status.markets = len(markets)
        self.status.latency_ms = self.http.last_latency_ms
        return markets

    def normalize(self, raw: Any) -> list[NormalizedMarket]:
        """Normalise one ``/fixtures/<slug>`` response with the sport slug added as ``raw["sport"]``."""
        if not isinstance(raw, dict) or not isinstance(raw.get("fixture"), dict):
            return []
        fixture, sport = raw["fixture"], str(raw.get("sport") or "")
        game = self.sport_game.get(sport)
        if not game or not fixture.get("slug"):
            return []
        self.odds[str(fixture["slug"])] = self._parse(raw, utcnow())
        market = self._build_market(fixture, sport, game)
        return [market] if market is not None else []

    def _parse(self, data: Any, asked: datetime) -> FixtureOdds:
        if not isinstance(data, dict) or not isinstance(data.get("fixture"), dict):
            raise ValueError("unexpected fixture response (no 'fixture' object)")
        groups = data.get("groups")
        if not isinstance(groups, list):
            raise ValueError("unexpected fixture response (no 'groups' list)")
        markets = list(iter_markets(groups))
        best_of = parse_best_of(markets)
        return FixtureOdds(
            asked_at=asked,
            fixture=data["fixture"],
            market=find_match_winner(markets, self.market_name),
            best_of=best_of,
            draw_possible=draw_possible(markets, best_of),
        )

    @staticmethod
    def _teams(state: FixtureOdds) -> tuple[str, str] | None:
        """The two team names of the two-way market (None: no market, a name missing or both the same)."""
        if state.market is None:
            return None
        names = [str(o.get("name") or "").strip() for o in state.market.get("outcomes") or []]
        return (names[0], names[1]) if len(names) == 2 and all(names) and names[0] != names[1] else None

    @classmethod
    def _usable(cls, state: FixtureOdds) -> bool:
        """A market can be built: a two-way market with two named teams, and no draw possible."""
        return cls._teams(state) is not None and not state.draw_possible

    def _build_market(self, fixture: dict[str, Any], sport: str, game: str) -> NormalizedMarket | None:
        slug = str(fixture.get("slug") or "")
        state = self.odds.get(slug)
        teams = self._teams(state) if state is not None else None
        if state is None or teams is None or state.draw_possible:
            return None  # no usable two-way market, or a draw is possible (it would void the bet)
        tournament_id = str(fixture.get("tournamentId") or "")
        market = NormalizedMarket(
            platform=self.platform,
            market_id=slug,
            event_title=str(fixture.get("name") or f"{teams[0]} - {teams[1]}"),
            game=game,
            team_a=teams[0],
            team_b=teams[1],
            start_time=ms_to_dt(state.fixture.get("startTime")) or ms_to_dt(fixture.get("startTime")),
            url=self._url(sport, tournament_id, slug),
            resolution_rules=STAKE_RULES,
            tournament=str(fixture.get("tournament") or "") or None,
            best_of=state.best_of,
            min_order_size=0.0,
            fee=FeeSpec(model="none"),
            extra={
                "sport": sport,
                "fixture_id": fixture.get("id"),
                "tournament_id": tournament_id or None,
                "category": fixture.get("category"),
            },
        )
        self._apply(market, state)
        return market

    # ---- odds ------------------------------------------------------------------------

    def _apply(self, market: NormalizedMarket, state: FixtureOdds) -> None:
        """Copy one odds response into the market (odds mapped to the teams by name), stamped with its request time."""
        winner = state.market
        # The same two teams as the market, in any order: a changed team (another opponent) is another match, and its
        # odds must not be priced against this market's pairs until discovery builds it anew.
        teams = self._teams(state)
        same_match = teams is not None and set(teams) == {market.team_a, market.team_b}
        active = winner is not None and winner.get("status") == "active" and not state.draw_possible and same_match
        asks: dict[str, list[Level]] = {"a": [], "b": []}
        if active:
            outcomes = {str(o.get("name") or "").strip(): o for o in winner.get("outcomes") or []}
            for side, team in (("a", market.team_a), ("b", market.team_b)):
                outcome = outcomes.get(team)
                if outcome is not None and outcome.get("active") is not False:
                    level = odds_level(outcome.get("odds"), self.max_stake_usd, team)
                    if level is not None:
                        asks[side].append(level)
        market.is_live = state.fixture.get("status") == "live"
        market.accepting_orders = active and self._open(state.fixture)
        market.set_books(asks["a"], asks["b"], None, None, state.asked_at)
        market.extra["timestamp_kind"] = "request_time_before_complete_fixture_response"
        market.extra["source_book_timestamp"] = None
        market.extra["actual_price_change_at"] = None

    async def _fetch(self, slug: str) -> None:
        self._fetched[slug] = time.monotonic()
        asked = utcnow()
        data = await self.http.get_json(f"/fixtures/{quote(slug, safe='')}", retries=0)
        state = self._parse(data, asked)
        current = self.odds.get(slug)
        if current is None or current.asked_at <= asked:  # discovery and polling can overlap: keep the newer answer
            self.odds[slug] = state

    async def fetch_book(self, market: NormalizedMarket) -> NormalizedMarket | None:
        """Коэффициенты матча новым запросом ``/fixtures/<slug>`` без повторов; кэш ответов адаптера не меняется."""
        slug = market.market_id
        asked = utcnow()
        data = await self.http.get_json(f"/fixtures/{quote(slug, safe='')}", retries=0)
        state = self._parse(data, asked)
        teams = self._teams(state)
        if teams is not None and set(teams) != {market.team_a, market.team_b}:
            raise ValueError(f"teams changed on Stake: {teams[0]} - {teams[1]}")  # другой матч, а не «вилка исчезла»
        copy = market.model_copy(deep=True)
        self._apply(copy, state)
        return copy

    def _apply_subscribed(self, slug: str) -> None:
        market = self._subscribed.get(f"{self.platform}:{slug}")
        state = self.odds.get(slug)
        if market is not None and state is not None:
            self._apply(market, state)
            self.notify(market)

    async def _fetch_many(self, slugs: list[str], apply: bool = False) -> dict[str, BaseException | None]:
        """Odds of several fixtures, ``max_concurrency`` at a time (rate-limited); fixture -> error or None.

        With ``apply`` every answer goes into its subscribed market at once, so a long pass does not age the quotes
        that already arrived. A failed request or an answer that cannot be applied only affects its own fixture; only
        failed requests count as errors.
        """
        semaphore = asyncio.Semaphore(self.concurrency)

        async def one(slug: str) -> None:
            async with semaphore:
                await self._fetch(slug)
            if apply:
                try:
                    self._apply_subscribed(slug)
                except Exception:  # noqa: BLE001 - a bug, not an API failure: traceback once per fixture
                    if slug not in self._apply_failing:
                        self._apply_failing.add(slug)
                        self.log.exception("could not apply the odds of %s", slug)
                else:
                    self._apply_failing.discard(slug)

        unique = list(dict.fromkeys(slugs))
        results = dict(zip(unique, await asyncio.gather(*map(one, unique), return_exceptions=True)))
        errors = {slug: error for slug, error in results.items() if error is not None}
        if len(errors) < len(results):  # some fixtures answered: name the others (a full outage is one line)
            for slug, error in errors.items():
                if slug not in self._failing:
                    self._failing.add(slug)
                    self.log.info("no odds for %s (%s)", slug, describe_error(error))
        for slug in results.keys() - errors.keys():
            if slug in self._failing:
                self._failing.discard(slug)
                self.log.info("odds of %s available again", slug)
        return results

    async def subscribe_prices(self, markets: list[NormalizedMarket], on_update: PriceCallback) -> None:
        """Poll the odds of ``markets`` from now on (fixtures in a pair fast, the others slowly)."""
        self._callback = on_update
        self._subscribed = {m.key: m for m in markets}
        for market in markets:
            state = self.odds.get(market.market_id)
            if state is not None:
                # Always: Scanner._merge keeps a book that is not older, but takes the team names of the new discovery
                # result. When Stake lists the outcomes in another order, only this keeps odds and names together.
                self._apply(market, state)
        if self._poll_task is None or self._poll_task.done():
            self._poll_task = self.spawn(self._poll_loop(), "poll")

    def _due(self, now: float) -> list[NormalizedMarket]:
        """Fixtures to ask in this pass: every paired one, then the other fixtures that waited longest.

        The others only get the requests that fit into one interval at the rate limit (80 %) after the paired ones,
        at least one: they must not stretch the pass and age the quotes of the paired fixtures.
        """
        fast, slow = [], []
        for market in self._subscribed.values():
            if self._paired is None or market.key in self._paired:
                fast.append(market)
            elif now - self._fetched.get(market.market_id, float("-inf")) >= self.slow_poll_sec:
                slow.append(market)
        slow.sort(key=lambda m: self._fetched.get(m.market_id, float("-inf")))
        budget = max(1, int(self.rate * self.poll_sec * 0.8) - len(fast))
        return fast + slow[:budget]

    async def poll_once(self) -> tuple[int, int, str | None, bool]:
        """One polling pass. Returns (fixtures answered, requests failed, the last error, rate-limited by the API)."""
        due = self._due(time.monotonic())
        results = await self._fetch_many([m.market_id for m in due], apply=True)
        errors = [error for error in results.values() if error is not None]
        limited = any(isinstance(error, HttpError) and error.status == 429 for error in errors)
        return len(results) - len(errors), len(errors), describe_error(errors[-1]) if errors else None, limited

    async def _poll_loop(self) -> None:
        last_good = time.monotonic()  # the last pass in which most requests answered (the start counts)
        failing = slow = crashed = False
        bad_passes = limited_passes = 0  # in a row: passes with more failures than answers / with an HTTP 429
        while self._running:
            started = time.monotonic()
            delay: float | None = None
            try:
                answered, failed, error, limited = await self.poll_once()
                crashed = False
                if answered or failed:  # a pass without requests changes nothing
                    bad_passes = bad_passes + 1 if failed > answered else 0
                    limited_passes = limited_passes + 1 if limited else 0
                    if bad_passes >= 2:  # not one bad pass (a timeout, a removed fixture): two in a row
                        if not failing:
                            if answered:
                                self.log.warning("odds polling failed for %d of %d fixtures: %s",
                                                 failed, failed + answered, error)
                            else:
                                self.log.warning("odds polling failed for all %d fixtures: %s", failed, error)
                        failing = True
                        self.status.connected = answered > 0
                        self.status.error = f"poll: {failed} of {failed + answered} failed: {error}"[:200]
                    elif not bad_passes:
                        if failing:
                            self.log.info("odds polling recovered after %.1f s", time.monotonic() - last_good)
                        failing, last_good = False, time.monotonic()
                        self.status.connected = True
                        self.status.error = None
                        self.status.last_update = utcnow()
                        self.status.latency_ms = self.http.last_latency_ms
                elif not failing:  # nothing to ask, so nothing of Stake can be stale (also with no markets at all)
                    self.status.connected = True
                    self.status.last_update = utcnow()
                if failing or limited_passes >= 2:  # an API without published limits must not be hammered
                    self._backoff = min(MAX_BACKOFF_SEC, max(2 * self.poll_sec, 2 * self._backoff))
                    delay = self._backoff
                else:
                    self._backoff = 0.0
                # A pass longer than the interval delays the next one: a fixture is asked again only after the whole
                # pass, so its quote nears engine.stale_seconds.
                took = time.monotonic() - started
                too_slow = took > self.settings.engine.stale_seconds - 3
                if too_slow and not slow:
                    self.log.warning("odds polling pass took %.1f s for %d fixtures: Stake quotes can turn stale "
                                     "(raise rate_limit_per_sec or poll fewer games)", took, answered + failed)
                slow = too_slow
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - a bug in one pass: its traceback once per streak, keep polling
                if not crashed:
                    self.log.exception("odds polling pass failed")
                crashed = True
                self.status.connected = False
                self.status.error = f"poll: {describe_error(exc)}"[:200]
            await self._sleep(delay if delay is not None else max(0.2, self.poll_sec - (time.monotonic() - started)))
