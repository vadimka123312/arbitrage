"""Platform adapters and the dynamic loader."""

from __future__ import annotations

import importlib

from backend.adapters.base import MarketAdapter
from backend.config import PlatformConfig, Settings


def load_adapter_class(path: str) -> type[MarketAdapter]:
    """Import ``package.module:ClassName``."""
    module_name, _, class_name = path.partition(":")
    if not module_name or not class_name:
        raise ValueError(f"adapter path must look like 'package.module:Class', got {path!r}")
    module = importlib.import_module(module_name)
    cls = getattr(module, class_name)
    if not isinstance(cls, type) or not issubclass(cls, MarketAdapter):
        raise TypeError(f"{path} is not a MarketAdapter subclass")
    return cls


def build_adapters(settings: Settings) -> dict[str, MarketAdapter]:
    """Instantiate every enabled platform from the config (in config order)."""
    adapters: dict[str, MarketAdapter] = {}
    for platform_id, cfg in settings.platforms.items():
        if not cfg.enabled:
            continue
        cls = load_adapter_class(cfg.adapter)
        adapters[platform_id] = cls(platform_id, cfg, settings)
    return adapters


def apply_mock_mode(settings: Settings) -> Settings:
    """Replace every enabled adapter with the mock adapter (``--mock``)."""
    platforms: dict[str, PlatformConfig] = {}
    for platform_id, cfg in settings.platforms.items():
        data = cfg.model_dump()
        data["adapter"] = "backend.adapters.mock:MockAdapter"
        data["mock_profile"] = platform_id
        data["name"] = f"{cfg.name} (mock)"
        platforms[platform_id] = PlatformConfig.model_validate(data)
    return settings.model_copy(update={"platforms": platforms, "mock_mode": True})
