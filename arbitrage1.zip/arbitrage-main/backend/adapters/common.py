"""Small parsing helpers shared by adapters."""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any

_BO_RE = re.compile(r"\b(?:BO|Bo|bo)\s?(\d)\b|best[- ]of[- ](\d)", re.I)
_SLUG_RE = re.compile(r"[^a-z0-9]+")


def parse_dt(value: Any) -> datetime | None:
    """Parse ISO-8601-ish timestamps (``Z``, ``+00``, space separator) into aware UTC."""
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    text = str(value).strip().replace(" ", "T", 1)
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    if re.search(r"[+-]\d{2}$", text):  # "+00" -> "+00:00"
        text += ":00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def parse_best_of(*texts: Any) -> int | None:
    """Find "BO3" / "Bo5" / "best of 3" in any of the given texts."""
    for text in texts:
        if not text:
            continue
        match = _BO_RE.search(str(text))
        if match:
            return int(match.group(1) or match.group(2))
    return None


def json_list(value: Any) -> list[Any]:
    """Gamma returns some lists as JSON strings; accept both."""
    if value is None:
        return []
    if isinstance(value, list):
        return value
    try:
        parsed = json.loads(value)
    except (TypeError, ValueError):
        return []
    return parsed if isinstance(parsed, list) else []


def to_float(value: Any) -> float | None:
    """Float or None."""
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def slugify(text: str) -> str:
    """``"Counter-Strike 2 Game"`` -> ``"counterstrike-2-game"`` (Kalshi URL style)."""
    cleaned = re.sub(r"[^a-z0-9\s]", "", text.lower())
    return _SLUG_RE.sub("-", cleaned).strip("-") or "market"


def split_teams(title: str) -> tuple[str, str] | None:
    """Split "Prefix: Team A vs. Team B (BO3) - Suffix" into the two team names."""
    text = title
    if ":" in text.split(" vs", 1)[0]:
        text = text.split(":", 1)[1]
    text = re.sub(r"\((?:BO|Bo)\d\)", "", text)
    text = text.split(" - ", 1)[0]
    parts = re.split(r"\s+vs\.?\s+", text.strip(), maxsplit=1, flags=re.I)
    if len(parts) != 2:
        return None
    a, b = parts[0].strip(), parts[1].strip()
    return (a, b) if a and b else None
