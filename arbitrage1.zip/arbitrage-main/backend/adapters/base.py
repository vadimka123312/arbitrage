"""Abstract market adapter. A new platform = a new subclass + a config section."""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Any, Callable

from backend.config import PlatformConfig, Settings
from backend.models import NormalizedMarket, PlatformStatus

PriceCallback = Callable[[NormalizedMarket], None]


class MarketAdapter(ABC):
    """Base class of all platform adapters.

    Life cycle (driven by ``engine.scanner.Scanner``):

    1. ``start()`` once;
    2. ``fetch_markets()`` periodically (discovery, metadata, initial prices);
    3. ``subscribe_prices(markets, callback)`` after every discovery round: the adapter keeps
       the books of exactly these market objects fresh (WebSocket or polling), mutates them in
       place via ``NormalizedMarket.set_books`` and calls ``callback(market)``;
    4. ``stop()`` on shutdown.
    """

    def __init__(self, platform_id: str, cfg: PlatformConfig, settings: Settings):
        self.platform = platform_id
        self.cfg = cfg
        self.settings = settings
        self.log = logging.getLogger(f"adapter.{platform_id}")
        self.status = PlatformStatus(platform=platform_id, name=cfg.name, color=cfg.color)
        self._tasks: list[asyncio.Task[Any]] = []
        self._subscribed: dict[str, NormalizedMarket] = {}
        self._callback: PriceCallback | None = None
        self._running = False

    @property
    def name(self) -> str:
        """Human-readable platform name."""
        return self.cfg.name

    async def start(self) -> None:
        """Open clients / start background work that does not depend on markets."""
        self._running = True

    async def stop(self) -> None:
        """Cancel background tasks and close clients."""
        self._running = False
        for task in self._tasks:
            task.cancel()
        for task in self._tasks:
            try:
                await task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001 - shutdown path
                pass
        self._tasks.clear()

    def spawn(self, coro: Any, name: str) -> asyncio.Task[Any]:
        """Start a tracked background task."""
        self._tasks = [t for t in self._tasks if not t.done()]
        task = asyncio.create_task(coro, name=f"{self.platform}:{name}")
        self._tasks.append(task)
        return task

    def game_filters(self) -> dict[str, dict[str, Any]]:
        """Platform-specific filters of the games that are configured for this platform."""
        return {g: f for g, f in self.cfg.games.items() if g in self.settings.games}

    def notify(self, market: NormalizedMarket) -> None:
        """Report a price update to the scanner."""
        if self._callback is not None:
            self._callback(market)

    def set_paired(self, keys: set[str]) -> None:
        """Keys of this platform's markets that are in a matched pair or in manual review (after every matching run).

        A hint for adapters that poll market by market (Stake): they refresh these markets first and the others less
        often. The default ignores it; matching and the arbitrage maths do not depend on it.
        """

    async def fetch_book(self, market: NormalizedMarket) -> NormalizedMarket | None:
        """Копия ``market`` со стаканами из нового REST-запроса (для бумажной проверки); None — площадка не умеет.

        Не меняет ни переданный рынок, ни стаканы самого адаптера: сканер продолжает работать со своими. Отметка
        времени копии — момент запроса. Ошибка запроса выбрасывается (проверка записывается как ``error``).
        """
        return None

    def instrument_ids(self, market: NormalizedMarket) -> dict[str, str]:
        """Идентификаторы инструментов площадки по подписи уровня стакана (``Level.instrument``), для снимков истории.

        По умолчанию пусто; Kalshi отдаёт тикер и сторону для «YES «A»» / «NO «B»». Математика вилок от этого не
        зависит.
        """
        return {}

    @abstractmethod
    async def fetch_markets(self) -> list[NormalizedMarket]:
        """Discover current esports match-winner markets (with initial prices if cheap)."""

    @abstractmethod
    async def subscribe_prices(self, markets: list[NormalizedMarket], on_update: PriceCallback) -> None:
        """Keep the books of ``markets`` fresh from now on (replaces the previous set)."""

    @abstractmethod
    def normalize(self, raw: Any) -> list[NormalizedMarket]:
        """Convert one raw platform object (event) into normalised markets."""
