"""Cross-platform event matching with a confidence score.

A candidate pair needs: same game, same market type/line, compatible best-of format,
start times within the tolerance and similar team names (in either order).

``confidence = 100 * (w_team * team + w_time * time + w_format * format)`` where every
component is in 0..1. Pairs at or above ``auto_threshold`` are shown automatically, pairs
between ``review_threshold`` and ``auto_threshold`` go to "needs manual review".
Manual overrides (confirmed / blocked) always win.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from backend.config import MatchingConfig
from backend.matching.normalizer import TeamNormalizer
from backend.models import MatchedPair, NormalizedMarket


def make_pair_key(key_a: str, key_b: str) -> str:
    """Order-independent key of a pair of markets."""
    first, second = sorted((key_a, key_b))
    return f"{first}|{second}"


@dataclass
class MatchResult:
    """Output of one matching run."""

    pairs: list[MatchedPair] = field(default_factory=list)  # auto + confirmed
    review: list[MatchedPair] = field(default_factory=list)
    blocked: list[MatchedPair] = field(default_factory=list)


def _bo(value: int | None) -> str:
    return f"BO{value}" if value else "?"


class Matcher:
    """Scores and assigns market pairs between two platforms."""

    def __init__(self, cfg: MatchingConfig, normalizer: TeamNormalizer):
        self.cfg = cfg
        self.normalizer = normalizer

    def time_score(self, left: datetime | None, right: datetime | None) -> tuple[float, float | None]:
        """Return (score 0..1, |difference| in minutes or None)."""
        if left is None or right is None:
            return self.cfg.unknown_time_score, None
        diff = abs((left - right).total_seconds()) / 60.0
        full = self.cfg.time_full_score_minutes
        tolerance = self.cfg.time_tolerance_hours * 60.0
        if diff <= full:
            return 1.0, diff
        if diff > tolerance or tolerance <= full:
            return 0.0, diff
        return max(0.0, 1.0 - (diff - full) / (tolerance - full)), diff

    def score(self, left: NormalizedMarket, right: NormalizedMarket, force: bool = False) -> MatchedPair | None:
        """Score one candidate pair. Hard constraints are skipped when ``force`` is set."""
        if left.game != right.game and not force:
            return None
        if (left.market_type != right.market_type or left.line != right.line) and not force:
            return None
        reasons: list[str] = []

        if left.best_of and right.best_of:
            format_check = "match" if left.best_of == right.best_of else "mismatch"
        else:
            format_check = "unknown"
        if format_check == "mismatch" and not force:
            return None
        format_score = {"match": 1.0, "unknown": self.cfg.unknown_format_score, "mismatch": 0.0}[format_check]
        reasons.append(f"Формат: {_bo(left.best_of)} / {_bo(right.best_of)}")

        time_score, diff = self.time_score(left.start_time, right.start_time)

        sim = self.normalizer.similarity
        game = left.game
        d1, d2 = sim(left.team_a, right.team_a, game), sim(left.team_b, right.team_b, game)
        s1, s2 = sim(left.team_a, right.team_b, game), sim(left.team_b, right.team_a, game)
        direct, crossed = min(d1, d2), min(s1, s2)
        swapped = crossed > direct
        team = crossed if swapped else direct
        if team < self.cfg.min_team_score and not force:
            return None

        auto_eligible = True
        if diff is None:
            reasons.append("Время старта: неизвестно на одной из площадок")
            auto_eligible = self.cfg.unknown_time_auto
        else:
            reasons.append(f"Время старта: разница {diff:.0f} мин")
            if diff > self.cfg.time_tolerance_hours * 60:
                # Same names but far apart: maybe a postponed match (Kalshi keeps the original time),
                # maybe a rematch. Never automatic; review only for identical names.
                if not force and (team < 100 or diff > self.cfg.review_max_hours * 60):
                    return None
                auto_eligible = False
                reasons.append("Старт отличается больше допуска: перенос или другой матч?")
            elif diff > self.cfg.time_auto_max_minutes:
                auto_eligible = False
        if swapped:
            reasons.append(
                f"Команды: {left.team_a} = {right.team_b} ({s1:.0f}%), {left.team_b} = {right.team_a} ({s2:.0f}%)"
            )
        else:
            reasons.append(
                f"Команды: {left.team_a} = {right.team_a} ({d1:.0f}%), {left.team_b} = {right.team_b} ({d2:.0f}%)"
            )

        confidence = 100.0 * (
            self.cfg.weight_team * team / 100.0
            + self.cfg.weight_time * time_score
            + self.cfg.weight_format * format_score
        )
        return MatchedPair(
            pair_key=make_pair_key(left.key, right.key),
            game=left.game,
            left_key=left.key,
            right_key=right.key,
            left_platform=left.platform,
            right_platform=right.platform,
            swapped=swapped,
            confidence=round(confidence, 1),
            team_score=round(team, 1),
            time_diff_minutes=None if diff is None else round(diff, 1),
            format_check=format_check,  # type: ignore[arg-type]
            auto_eligible=auto_eligible,
            reasons=reasons,
        )

    def match(
        self,
        left: list[NormalizedMarket],
        right: list[NormalizedMarket],
        overrides: dict[str, str] | None = None,
    ) -> MatchResult:
        """Match two platforms' markets; ``overrides`` maps pair_key -> confirmed|blocked."""
        overrides = overrides or {}
        by_game: dict[str, list[NormalizedMarket]] = {}
        for market in right:
            by_game.setdefault(market.game, []).append(market)
        right_by_key = {m.key: m for m in right}

        candidates: dict[str, MatchedPair] = {}
        for lm in left:
            for rm in by_game.get(lm.game, []):
                pair = self.score(lm, rm)
                if pair is not None:
                    candidates[pair.pair_key] = pair

        # Confirmed pairs are kept even when a hard constraint now rejects them.
        left_by_key = {m.key: m for m in left}
        for pair_key, status in overrides.items():
            if status != "confirmed" or pair_key in candidates:
                continue
            first, _, second = pair_key.partition("|")
            lm = left_by_key.get(first) or left_by_key.get(second)
            rm = right_by_key.get(second) or right_by_key.get(first)
            if lm is not None and rm is not None:
                forced = self.score(lm, rm, force=True)
                if forced is not None:
                    candidates[pair_key] = forced

        result = MatchResult()
        for pair in candidates.values():
            status = overrides.get(pair.pair_key)
            if status == "blocked":
                pair.status = "blocked"
            elif status == "confirmed":
                pair.status = "confirmed"

        ordered = sorted(
            candidates.values(),
            key=lambda p: (p.status != "confirmed", -p.confidence),
        )
        used_left: set[str] = set()
        used_right: set[str] = set()
        held_left: set[str] = set()  # markets of strong pairs that may only be shown after manual review
        held_right: set[str] = set()
        for pair in ordered:
            if pair.status == "blocked":
                result.blocked.append(pair)
                continue
            if pair.left_key in used_left or pair.right_key in used_right:
                continue
            if pair.status == "confirmed":
                result.pairs.append(pair)
                used_left.add(pair.left_key)
                used_right.add(pair.right_key)
            elif pair.confidence >= self.cfg.auto_threshold:
                if not pair.auto_eligible:
                    # A better candidate that failed only the time rules keeps its markets for review, so a
                    # weaker candidate cannot pair one of them automatically and hide it.
                    held_left.add(pair.left_key)
                    held_right.add(pair.right_key)
                elif pair.left_key not in held_left and pair.right_key not in held_right:
                    pair.status = "auto"
                    result.pairs.append(pair)
                    used_left.add(pair.left_key)
                    used_right.add(pair.right_key)

        review_left: set[str] = set()
        review_right: set[str] = set()
        for pair in ordered:
            if pair.status in ("blocked", "confirmed"):
                continue
            if pair.confidence >= self.cfg.auto_threshold and pair.auto_eligible:
                continue  # was an auto candidate but lost the one-to-one assignment
            if pair.confidence < self.cfg.review_threshold:
                continue
            if pair.left_key in used_left or pair.right_key in used_right:
                continue
            if pair.left_key in review_left or pair.right_key in review_right:
                continue
            pair.status = "review"
            result.review.append(pair)
            review_left.add(pair.left_key)
            review_right.add(pair.right_key)
        return result
