"""Team-name normalisation, aliases and fuzzy similarity."""

from __future__ import annotations

import logging
import re
import unicodedata
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from rapidfuzz import fuzz

log = logging.getLogger(__name__)

DEFAULT_NOISE_TOKENS = {"team", "gaming", "club", "gg", "the", "org", "clan", "ex"}

# Tokens that change *which* team it is (academy / female / reserve squads).
# Each token is replaced by its class name, and a class mismatch caps the similarity.
DEFAULT_QUALIFIERS: dict[str, list[str]] = {
    "academy": [
        "academy", "acad", "academia", "youth", "junior", "juniors", "jr", "young",
        "prospects", "prospect", "next", "nxt", "talent", "talents", "rising",
        "development", "u21", "u19", "u20",
    ],
    "female": ["female", "fe", "women", "womens", "woman", "ladies", "girls", "gc", "fem", "wmn", "w"],
    "reserve": ["2", "ii", "b", "reserve", "reserves"],
}

_ESPORTS_RE = re.compile(r"\be[\s\-.]?sports?\b")
_SPONSOR_RE = re.compile(r"\s+by\s+.+$")
_APOSTROPHE_RE = re.compile(r"[’'`´]")
_NON_ALNUM_RE = re.compile(r"[^a-z0-9]+")


def strip_accents(text: str) -> str:
    """Remove diacritics: ``Honvéd`` -> ``Honved``."""
    decomposed = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch))


def raw_tokens(name: str) -> list[str]:
    """Lower-case alphanumeric tokens, nothing removed (used for acronyms)."""
    text = _APOSTROPHE_RE.sub("", strip_accents(name).lower().replace("&", " and "))
    return _NON_ALNUM_RE.sub(" ", text).split()


class TeamNormalizer:
    """Turns team names into comparable canonical strings and scores their similarity."""

    def __init__(
        self,
        aliases: dict[str, Any] | None = None,
        subset_penalty_per_token: float = 15.0,
        qualifier_mismatch_cap: float = 40.0,
    ):
        aliases = aliases or {}
        self.subset_penalty = subset_penalty_per_token
        self.qualifier_cap = qualifier_mismatch_cap
        self.noise_tokens = set(DEFAULT_NOISE_TOKENS) | {
            str(t).lower() for t in aliases.get("noise_tokens", []) or []
        }
        qualifiers = {k: list(v) for k, v in DEFAULT_QUALIFIERS.items()}
        for cls, tokens in (aliases.get("qualifiers") or {}).items():
            qualifiers[cls] = [str(t).lower() for t in tokens]
        self.qualifier_map: dict[str, str] = {}
        for cls, tokens in qualifiers.items():
            for token in tokens:
                self.qualifier_map[token] = cls
        self.qualifier_classes = set(qualifiers)
        self.global_aliases: dict[str, str] = {}
        self.game_aliases: dict[str, dict[str, str]] = {}
        self._load_alias_section(aliases.get("global") or {}, self.global_aliases)
        for game, section in (aliases.get("games") or {}).items():
            self.game_aliases[game] = {}
            self._load_alias_section(section or {}, self.game_aliases[game])
        # Per-instance caches (lru_cache on methods would leak across instances).
        self._clean = lru_cache(maxsize=20000)(self._clean_uncached)
        self._norm = lru_cache(maxsize=20000)(self._normalize_uncached)

    @classmethod
    def from_file(cls, path: str | Path, **kwargs: Any) -> "TeamNormalizer":
        """Build a normaliser from an ``aliases.yaml`` file."""
        data: dict[str, Any] = {}
        path = Path(path)
        if path.exists():
            with path.open("r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
        else:
            log.warning("aliases file %s not found, using built-in rules only", path)
        return cls(data, **kwargs)

    def _load_alias_section(self, section: dict[str, Any], target: dict[str, str]) -> None:
        for canonical, alias_list in section.items():
            canonical_key = self._clean_uncached(str(canonical))
            target[canonical_key] = canonical_key
            for alias in alias_list or []:
                alias_key = self._clean_uncached(str(alias))
                if alias_key and alias_key in target and target[alias_key] != canonical_key:
                    log.debug("alias %r maps to several teams; keeping the first", alias)
                    continue
                if alias_key:
                    target[alias_key] = canonical_key

    def _clean_uncached(self, name: str) -> str:
        text = strip_accents(name).lower().strip()
        text = text.replace("&", " and ")
        text = _APOSTROPHE_RE.sub("", text)
        text = _ESPORTS_RE.sub(" ", text)
        text = _SPONSOR_RE.sub("", text)
        tokens = _NON_ALNUM_RE.sub(" ", text).split()
        tokens = [self.qualifier_map.get(t, t) for t in tokens]
        kept = [t for t in tokens if t not in self.noise_tokens]
        return " ".join(kept or tokens)

    def _normalize_uncached(self, name: str, game: str | None) -> str:
        cleaned = self._clean(name)
        if game and game in self.game_aliases and cleaned in self.game_aliases[game]:
            return self.game_aliases[game][cleaned]
        return self.global_aliases.get(cleaned, cleaned)

    def normalize(self, name: str, game: str | None = None) -> str:
        """Canonical comparable form of a team name (after aliases)."""
        return self._norm(name or "", game)

    def qualifiers(self, normalized: str) -> set[str]:
        """Qualifier classes present in a normalised name."""
        return {t for t in normalized.split() if t in self.qualifier_classes}

    def _acronym_score(self, short: str, long: str) -> float:
        short_tokens = raw_tokens(short)
        if len(short_tokens) != 1:
            return 0.0
        token = short_tokens[0]
        if not (2 <= len(token) <= 5) or not token.isalpha():
            return 0.0
        long_raw = raw_tokens(long)
        long_clean = self._clean(long).split()
        candidates = set()
        if len(long_raw) >= 2:
            candidates.add("".join(t[0] for t in long_raw))
        if len(long_clean) >= 2:
            candidates.add("".join(t[0] for t in long_clean))
        return 90.0 if token in candidates else 0.0

    def similarity(self, a: str, b: str, game: str | None = None) -> float:
        """Similarity of two team names, 0..100."""
        na, nb = self.normalize(a, game), self.normalize(b, game)
        if not na or not nb:
            return 0.0
        if na == nb:
            return 100.0
        ta, tb = set(na.split()), set(nb.split())
        score = max(
            fuzz.token_sort_ratio(na, nb),
            fuzz.ratio(na.replace(" ", ""), nb.replace(" ", "")),
        )
        if ta and tb and (ta <= tb or tb <= ta):
            extra = len(ta ^ tb)
            score = max(score, 100.0 - self.subset_penalty * extra)
        score = max(score, self._acronym_score(a, b), self._acronym_score(b, a))
        if self.qualifiers(na) != self.qualifiers(nb):
            score = min(score, self.qualifier_cap)
        return float(round(score, 2))
