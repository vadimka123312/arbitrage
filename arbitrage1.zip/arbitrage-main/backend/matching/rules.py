"""Resolution-rules comparison.

Rules are free text. We extract a few clauses that matter for an arbitrage
(cancellation, postponement window, forfeit before/after start, tie) and report the
differences between two markets. Unknown clauses stay ``None`` (no false alarms).
"""

from __future__ import annotations

import re

from pydantic import BaseModel

from backend.models import RuleWarning

OUTCOME_LABELS = {
    "50-50": "50/50",
    "no": "«Нет» (No)",
    "yes": "«Да» (Yes)",
    "fair_price": "справедливая рыночная цена",
    "void": "возврат/аннулирование",
    "official": "официальный результат",
}

FIELD_LABELS = {
    "cancel": "Отмена матча",
    "postpone_window_hours": "Перенос матча (окно)",
    "postpone_fallback": "Перенос сверх окна",
    "forfeit_before_start": "Форфейт до начала",
    "forfeit_after_start": "Форфейт после начала",
    "tie": "Ничья",
}

FIELD_SEVERITY = {
    "cancel": "high",
    "forfeit_before_start": "high",
    "tie": "high",
    "forfeit_after_start": "medium",
    "postpone_fallback": "medium",
    "postpone_window_hours": "medium",
}


class RulesProfile(BaseModel):
    """Structured view of the clauses found in a rules text."""

    cancel: str | None = None
    postpone_window_hours: float | None = None
    postpone_fallback: str | None = None
    forfeit_before_start: str | None = None
    forfeit_after_start: str | None = None
    tie: str | None = None


# Bookmakers publish no rules per market. Stake: a short summary of the clauses of its sportsbook rules that matter for
# an arbitrage (https://stake.com/policies/sportsbook, "Esports General" and "Push Rule (2-way Markets)"; read on
# 2026-10-16 from the web-archive copy of 2026-10-11, stake.com itself answers 403 to the dev sandbox). The Stake
# adapter puts it into every market, and parse_rules() reads it like any other rules text; STAKE_PROFILE is what it
# yields (checked by a test). Stake voids the bet (returns the stake) on a postponement over 24 h, a cancellation, a
# walkover, a retirement during the match and a draw. Polymarket settles these at 50-50 (a retirement during the match:
# the official result) and Kalshi at the fair market price (a retirement: the official result; no draw clause).
STAKE_RULES = (
    "Stake sportsbook rules for esports match winner bets (summary).\n"
    "If a match is postponed before its start for more than 24 hours of the original start time, all bets are void.\n"
    "If a match is cancelled and not played, all bets are void.\n"
    "If a match is declared a walkover win by the tournament organizer before the start, all bets are void.\n"
    "If a team retires or is disqualified after the match has started, the match winner market is void.\n"
    "If a two-way winner market ends in a draw, the market is settled as void."
)
STAKE_PROFILE = RulesProfile(
    cancel="void",
    postpone_window_hours=24.0,
    postpone_fallback="void",
    forfeit_before_start="void",
    forfeit_after_start="void",
    tie="void",
)

# Официальная страница BC.Game: https://bc.game/help/terms-sports.
# Пока текст условий не подтверждён, ни один исход расчёта не считается известным.
BCGAME_RULES = (
    "BC.Game: https://bc.game/help/terms-sports\n"
    "Правила отмены, переноса, форфейта и ничьей пока не подтверждены. "
    "Проверьте официальные условия перед использованием коэффициентов."
)
BCGAME_PROFILE = RulesProfile()

_SPLIT_RE = re.compile(r"\n+|(?<=[.!?])\s+(?=If\b|In the event\b|Otherwise\b|Should\b)")
_WINDOW_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(?:calendar\s+)?(hours?|hrs?|days?)\b", re.I)


def _outcome(chunk: str) -> str | None:
    text = chunk.lower()
    if re.search(r"50\s*[-/–]\s*50|fifty[- ]fifty", text):
        return "50-50"
    if "fair market price" in text or "fair price" in text or "fair value" in text:
        return "fair_price"
    if re.search(r"\bvoid\b|\brefund", text) or "resolve to n/a" in text:
        return "void"
    if (
        "official result" in text
        or "team who wins" in text
        or "team that wins" in text
        or "declared winner" in text
        or "resolve to the winner" in text
        or "advancing team" in text
    ):
        return "official"
    if re.search(r"resolves? (?:to )?(?:\"|“)?no\b", text):
        return "no"
    if re.search(r"resolves? (?:to )?(?:\"|“)?yes\b", text):
        return "yes"
    return None


_FORFEIT_RE = re.compile(r"forfeit|walkover|disqualif|withdraw")
_AFTER_START_RE = re.compile(
    r"\bbegins?\b.*(forfeit|not completed|disqualif)|subsequently|not completed|in progress|mid-?match"
    r"|after (the )?(match |game |play )?(has )?(started|begun|begins|start)"
    r"|after (the )?(start|play)|during (the )?(match|play|game)|once (the )?(match |play )?has (started|begun)"
)
_BEFORE_START_RE = re.compile(r"before (the )?(start|play|any play|the match|it starts)|not (yet )?started|prior to")


def parse_rules(text: str) -> RulesProfile:
    """Extract the arbitrage-relevant clauses from a rules text.

    A chunk may fill several clauses (e.g. "cancelled or forfeited before play -> fair price").
    """
    profile = RulesProfile()
    if not text:
        return profile
    chunks = [c.strip() for c in _SPLIT_RE.split(text) if c and c.strip()]
    postpone_seen = False
    for chunk in chunks:
        low = chunk.lower()
        outcome = _outcome(chunk)
        if _FORFEIT_RE.search(low) and outcome:
            after = bool(_AFTER_START_RE.search(low)) and not _BEFORE_START_RE.search(low)
            if after and profile.forfeit_after_start is None:
                profile.forfeit_after_start = outcome
            elif not after and profile.forfeit_before_start is None:
                profile.forfeit_before_start = outcome
        if re.search(r"postpone|reschedul|delayed", low):
            postpone_seen = True
            match = _WINDOW_RE.search(chunk)
            if match and profile.postpone_window_hours is None:
                value = float(match.group(1))
                unit = match.group(2).lower()
                profile.postpone_window_hours = value * 24 if unit.startswith("day") else value
            if outcome and profile.postpone_fallback is None:
                profile.postpone_fallback = outcome
        elif postpone_seen and low.startswith("otherwise") and outcome and profile.postpone_fallback is None:
            profile.postpone_fallback = outcome
        if re.search(r"cancel", low) and outcome and profile.cancel is None:
            profile.cancel = outcome
        if re.search(r"\btie\b|\bdraw\b|\bties\b", low) and outcome and profile.tie is None:
            profile.tie = outcome
    return profile


def _fmt(field: str, value: object) -> str:
    if value is None:
        return "не указано"
    if field == "postpone_window_hours":
        hours = float(value)  # type: ignore[arg-type]
        return f"{hours / 24:g} дн." if hours > 48 and hours % 24 == 0 else f"{hours:g} ч"
    return OUTCOME_LABELS.get(str(value), str(value))


def compare_rules(
    left: RulesProfile,
    right: RulesProfile,
    left_name: str,
    right_name: str,
) -> list[RuleWarning]:
    """List the differences between two rule profiles (only clauses found on both sides
    are compared; a clause found on one side only is reported as ``info``)."""
    warnings: list[RuleWarning] = []
    for field, label in FIELD_LABELS.items():
        lv = getattr(left, field)
        rv = getattr(right, field)
        if lv is None and rv is None:
            continue
        if lv is not None and rv is not None:
            if lv == rv:
                continue
            severity = FIELD_SEVERITY[field]
        else:
            severity = "info"
        left_text, right_text = _fmt(field, lv), _fmt(field, rv)
        warnings.append(
            RuleWarning(
                field=field,
                severity=severity,  # type: ignore[arg-type]
                message=f"{label}: {left_name} — {left_text}, {right_name} — {right_text}",
                left=left_text,
                right=right_text,
            )
        )
    return warnings
