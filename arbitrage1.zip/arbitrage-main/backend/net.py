"""Async HTTP helpers: token-bucket rate limiter, retries with exponential backoff."""

from __future__ import annotations

import asyncio
import logging
import random
import time
from typing import Any

import httpx

log = logging.getLogger(__name__)

RETRY_STATUSES = {408, 425, 429, 500, 502, 503, 504}


class HttpError(Exception):
    """Non-retryable HTTP error (or retries exhausted)."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class RateLimiter:
    """Simple async token bucket: ``rate`` tokens per second, burst capacity ``max(1, rate)``."""

    def __init__(self, rate_per_sec: float):
        self.rate = max(rate_per_sec, 0.01)
        self.capacity = max(1.0, rate_per_sec)
        self._tokens = self.capacity
        self._updated = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self, tokens: float = 1.0) -> None:
        """Wait until ``tokens`` are available, then consume them."""
        async with self._lock:
            while True:
                now = time.monotonic()
                self._tokens = min(self.capacity, self._tokens + (now - self._updated) * self.rate)
                self._updated = now
                if self._tokens >= tokens:
                    self._tokens -= tokens
                    return
                await asyncio.sleep((tokens - self._tokens) / self.rate)


def backoff_delay(attempt: int, base: float = 0.5, cap: float = 30.0) -> float:
    """Exponential backoff with full jitter (attempt starts at 0)."""
    return random.uniform(0.5, 1.0) * min(cap, base * (2**attempt))


def describe_error(exc: BaseException) -> str:
    """Error text for logs: ``Type: message``, or just ``Type`` when the message is empty (e.g. httpx timeouts).

    HttpError messages already name the client, the request and the cause, so they are used as they are.
    """
    text = str(exc).strip()
    if isinstance(exc, HttpError):
        return text or type(exc).__name__
    return f"{type(exc).__name__}: {text}" if text else type(exc).__name__


class HttpClient:
    """Thin httpx wrapper with rate limiting, retries and latency stats."""

    def __init__(
        self,
        base_url: str,
        name: str,
        rate_per_sec: float = 10.0,
        timeout: float = 10.0,
        max_retries: int = 5,
        backoff_base: float = 0.5,
        backoff_cap: float = 30.0,
        headers: dict[str, str] | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
        follow_redirects: bool = True,
    ):
        self.name = name
        self.limiter = RateLimiter(rate_per_sec)
        self.max_retries = max_retries
        self.backoff_base = backoff_base
        self.backoff_cap = backoff_cap
        default_headers = {"User-Agent": "esports-arb-scanner/1.0", "Accept": "application/json"}
        default_headers.update(headers or {})
        self._client = httpx.AsyncClient(
            base_url=base_url,
            timeout=timeout,
            headers=default_headers,
            transport=transport,
            # False for clients with a key in a custom header: httpx drops only Authorization on a cross-host redirect.
            follow_redirects=follow_redirects,
        )
        self.last_latency_ms: float | None = None

    async def get_json(self, path: str, params: Any = None, retries: int | None = None) -> Any:
        """GET and decode JSON. ``retries`` overrides ``max_retries`` for this call."""
        return await self._request("GET", path, retries=retries, params=params)

    async def post_json(self, path: str, payload: Any = None, retries: int | None = None) -> Any:
        """POST JSON and decode JSON. ``retries`` overrides ``max_retries`` for this call."""
        return await self._request("POST", path, retries=retries, json=payload)

    async def _request(self, method: str, path: str, retries: int | None = None, **kwargs: Any) -> Any:
        max_retries = self.max_retries if retries is None else retries
        attempt = 0
        network_errors = 0  # a recovery after these is logged; 429/5xx retries explain themselves
        while True:
            await self.limiter.acquire()
            started = time.monotonic()
            try:
                resp = await self._client.request(method, path, **kwargs)
            except httpx.TransportError as exc:
                if attempt >= max_retries:
                    raise HttpError(f"{self.name}: {method} {path} failed: {describe_error(exc)}") from exc
                delay = backoff_delay(attempt, self.backoff_base, self.backoff_cap)
                log.warning("%s: network error on %s (%s), retry in %.1fs", self.name, path, describe_error(exc), delay)
                await asyncio.sleep(delay)
                attempt += 1
                network_errors += 1
                continue

            self.last_latency_ms = round((time.monotonic() - started) * 1000, 1)
            if resp.status_code in RETRY_STATUSES:
                if attempt >= max_retries:
                    raise HttpError(f"{self.name}: {method} {path} -> {resp.status_code}", resp.status_code)
                delay = backoff_delay(attempt, self.backoff_base, self.backoff_cap)
                retry_after = resp.headers.get("Retry-After")
                if retry_after:
                    try:
                        delay = min(self.backoff_cap, max(delay, float(retry_after)))
                    except ValueError:
                        pass
                log.warning("%s: HTTP %s on %s, retry in %.1fs", self.name, resp.status_code, path, delay)
                await asyncio.sleep(delay)
                attempt += 1
                continue
            if resp.status_code >= 400:
                raise HttpError(
                    f"{self.name}: {method} {path} -> {resp.status_code}: {resp.text[:200]}",
                    resp.status_code,
                )
            if resp.is_redirect:  # only without follow_redirects: an answer that points elsewhere is no answer
                target = httpx.URL(resp.headers.get("location", "")).host or "the same host"
                raise HttpError(
                    f"{self.name}: {method} {path} -> {resp.status_code}: redirect to {target} not followed",
                    resp.status_code,
                )
            try:
                data = resp.json()
            except ValueError as exc:
                raise HttpError(f"{self.name}: invalid JSON from {path}") from exc
            if network_errors:
                log.info("%s: %s %s succeeded after %d retr%s", self.name, method, path, attempt,
                         "y" if attempt == 1 else "ies")
            return data

    async def aclose(self) -> None:
        """Close the underlying connection pool."""
        await self._client.aclose()
