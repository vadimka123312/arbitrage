"""Configuration: ``backend/config.yaml`` + ``.env`` (environment variables win)."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated, Any, Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import yaml
from pydantic import AfterValidator, BaseModel, ConfigDict, Field

BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BACKEND_DIR.parent
DEFAULT_CONFIG_PATH = BACKEND_DIR / "config.yaml"


class ServerConfig(BaseModel):
    host: str = "127.0.0.1"
    port: int = 8000
    open_browser: bool = True
    # Host names the server answers to (DNS-rebinding protection). "*" disables the check.
    allowed_hosts: list[str] = Field(default_factory=lambda: ["localhost", "127.0.0.1", "[::1]", "::1"])


class LoggingConfig(BaseModel):
    level: str = "INFO"
    file: str = "logs/scanner.log"
    max_bytes: int = 5_000_000
    backup_count: int = 3


class StorageConfig(BaseModel):
    path: str = "data/arb_history.db"


class GameConfig(BaseModel):
    name: str
    short: str | None = None


class PlatformConfig(BaseModel):
    """Generic platform section. Adapter-specific keys are kept as extra fields."""

    model_config = ConfigDict(extra="allow")

    enabled: bool = True
    adapter: str
    name: str
    color: str = "#888888"
    games: dict[str, dict[str, Any]] = Field(default_factory=dict)

    def opt(self, key: str, default: Any = None) -> Any:
        """Read an adapter-specific option."""
        extra = self.model_extra or {}
        return extra.get(key, default)


class DiscoveryConfig(BaseModel):
    refresh_seconds: float = 60.0
    horizon_hours: float = 72.0  # ignore matches that start later than this
    live_grace_hours: float = 8.0  # keep matches this long after their start time


class MatchingConfig(BaseModel):
    auto_threshold: float = 85.0
    review_threshold: float = 60.0
    time_tolerance_hours: float = 6.0
    time_auto_max_minutes: float = 90.0  # larger start-time gaps can only go to manual review
    review_max_hours: float = 48.0  # identical names further apart than the tolerance -> review (postponed?)
    unknown_time_auto: bool = False  # a missing start time blocks automatic matching
    time_full_score_minutes: float = 30.0
    unknown_time_score: float = 0.5
    unknown_format_score: float = 0.5
    weight_team: float = 0.7
    weight_time: float = 0.2
    weight_format: float = 0.1
    subset_penalty_per_token: float = 15.0
    qualifier_mismatch_cap: float = 40.0
    min_team_score: float = 50.0
    aliases_file: str = "backend/matching/aliases.yaml"


class EngineConfig(BaseModel):
    confirm_seconds: float = 5.0
    stale_seconds: float = 10.0
    min_profit_pct: float = 0.0
    min_volume_usd: float = 0.0
    depth_mode: Literal["best_level", "walk_book"] = "best_level"
    eval_interval_ms: int = 500
    history_min_lifetime_sec: float = 1.0
    # The dashboard treats 6 s without a message as a dead link; idle sockets get a heartbeat every
    # 2 s or every 2 x this interval, so the interval is capped at 2 s.
    broadcast_interval_ms: int = Field(default=1000, ge=200, le=2000)


class PlatformFeeConfig(BaseModel):
    """Fee overrides and extra costs for one platform."""

    taker_rate: float | None = None  # None = use the rate published by the platform
    exponent: float | None = None
    round_up_cents: bool | None = None
    extra_cost_per_contract: float = 0.0  # e.g. spread lost on withdrawal, per $1 contract
    fixed_cost_per_trade_usd: float = 0.0  # e.g. gas


class FeesConfig(BaseModel):
    model_config = ConfigDict(extra="allow")

    default: PlatformFeeConfig = Field(default_factory=PlatformFeeConfig)

    def for_platform(self, platform: str) -> PlatformFeeConfig:
        """Return the fee config of a platform (or the default one)."""
        raw = (self.model_extra or {}).get(platform)
        return self.default if raw is None else PlatformFeeConfig.model_validate(raw)


def validate_timezone(name: str) -> str:
    """An IANA time zone name such as ``Europe/Moscow`` (raises ValueError)."""
    try:
        ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, OSError) as exc:  # OSError: a folder such as "Europe"
        raise ValueError(f"unknown time zone {name!r} (example: Europe/Moscow)") from exc
    return name


class StatsConfig(BaseModel):
    """The history report (``report.py``, ``GET /api/stats``)."""

    # Days of the report are counted in this time zone.
    timezone: Annotated[str, AfterValidator(validate_timezone)] = "Europe/Moscow"
    # Итог без N самых прибыльных появлений (выбросов): они исключаются из «без топ-N» во всех разбивках.
    exclude_top_n: int = Field(default=10, ge=0, le=1000)
    # Оценка прибыли с ограниченным капиталом: один общий пул на все площадки; ставка на вилку не больше
    # max_stake_per_arb_usd (0 — без ограничения), свободных денег и доступного объёма; деньги вилки заняты до расчёта —
    # позднее из (старт матча, подтверждение) плюс settle_hours. Прибыль не реинвестируется.
    bankroll_usd: float = Field(default=1000.0, ge=0)
    max_stake_per_arb_usd: float = Field(default=100.0, ge=0)
    settle_hours: float = Field(default=3.0, ge=0)


def _stake_sizes(values: list[float]) -> list[float]:
    """Размеры ставок: положительные, без повторов, по возрастанию."""
    if any(v <= 0 for v in values):
        raise ValueError("stake sizes must be positive")
    return sorted(set(values))


class CaptureConfig(BaseModel):
    """Данные для честной статистики, которые пишутся в историю вместе с вилкой (поиск вилок от них не зависит)."""

    enabled: bool = True
    book_levels: int = Field(default=10, ge=1, le=50)  # уровней каждого стакана в снимке
    # Общая сумма ставки на обе ноги (с комиссиями), для которой считается прибыль по стакану (walk_book).
    stake_sizes_usd: Annotated[list[float], AfterValidator(_stake_sizes)] = Field(
        default_factory=lambda: [10.0, 25.0, 50.0, 100.0, 250.0]
    )
    # Флаг «устаревшие данные»: стакан ноги старше этого. 7 с — больше обычного возраста при исправной связи (пинг
    # Polymarket и опрос Stake раз в 5 с, Kalshi раз в 1,5 с) и меньше порога движка engine.stale_seconds (10 с).
    stale_age_sec: float = Field(default=7.0, ge=0)
    large_volume_usd: float = Field(default=1000.0, ge=0)  # флаг «большой объём» (0 — выключен)
    size_jump_ratio: float = Field(default=5.0, gt=1)  # флаг «скачок размера»: размер на лучшей цене вырос в N раз…
    size_jump_min_usd: float = Field(default=500.0, ge=0)  # …и не меньше чем на столько долларов


def _delays(values: list[float]) -> list[float]:
    """Задержки проверок: положительные, без повторов, по возрастанию."""
    if any(v <= 0 for v in values):
        raise ValueError("delays must be positive")
    return sorted(set(values))


class PaperConfig(BaseModel):
    """Бумажная проверка исполнимости: через N секунд после подтверждения вилки оба стакана перечитываются отдельным
    REST-запросом к каждой площадке, и записывается, осталась ли вилка, на каком объёме и с какой прибылью (ничего не
    покупается). Заодно стакан из запроса сравнивается со стаканом сканера в тот же момент."""

    enabled: bool = True
    delays_sec: Annotated[list[float], AfterValidator(_delays)] = Field(default_factory=lambda: [5.0, 15.0, 60.0])
    max_concurrency: int = Field(default=4, ge=1, le=32)  # проверок одновременно (по запросу на каждую площадку)
    max_pending: int = Field(default=600, ge=1)  # ждущих проверок; лишние не ставятся (строка в лог)
    # Проверка, начавшаяся позже срока больше чем на столько секунд (очередь, сон компьютера), не выполняется: late.
    max_late_sec: float = Field(default=5.0, ge=0)
    check_timeout_sec: float = Field(default=30.0, gt=0)  # дольше — строка error «timeout», слот освобождается


class MockConfig(BaseModel):
    seed: int = 42
    tick_ms: int = 500
    arb_rate_per_min: float = 6.0


class Settings(BaseModel):
    server: ServerConfig = Field(default_factory=ServerConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    games: dict[str, GameConfig] = Field(default_factory=dict)
    platforms: dict[str, PlatformConfig] = Field(default_factory=dict)
    discovery: DiscoveryConfig = Field(default_factory=DiscoveryConfig)
    matching: MatchingConfig = Field(default_factory=MatchingConfig)
    engine: EngineConfig = Field(default_factory=EngineConfig)
    fees: FeesConfig = Field(default_factory=FeesConfig)
    stats: StatsConfig = Field(default_factory=StatsConfig)
    capture: CaptureConfig = Field(default_factory=CaptureConfig)
    paper: PaperConfig = Field(default_factory=PaperConfig)
    mock: MockConfig = Field(default_factory=MockConfig)
    mock_mode: bool = False

    def resolve_path(self, value: str) -> Path:
        """Resolve a path from the config relative to the project directory."""
        path = Path(value)
        return path if path.is_absolute() else PROJECT_DIR / path


# Settings that the UI may change at runtime: dotted path -> (type, min, max).
RUNTIME_SETTINGS: dict[str, tuple[type, float, float]] = {
    "engine.confirm_seconds": (float, 0.0, 300.0),
    "engine.stale_seconds": (float, 1.0, 600.0),
    "engine.min_profit_pct": (float, -100.0, 100.0),
    "engine.min_volume_usd": (float, 0.0, 1_000_000.0),
    "matching.auto_threshold": (float, 0.0, 100.0),
    "matching.review_threshold": (float, 0.0, 100.0),
    "matching.time_tolerance_hours": (float, 0.0, 72.0),
}
RUNTIME_CHOICES: dict[str, tuple[str, ...]] = {
    "engine.depth_mode": ("best_level", "walk_book"),
}


def get_dotted(settings: Settings, dotted: str) -> Any:
    """Read ``section.field`` from settings."""
    section, field = dotted.split(".", 1)
    return getattr(getattr(settings, section), field)


def validate_setting(dotted: str, value: Any) -> Any:
    """Validate one runtime setting and return it converted to its type (raises ValueError)."""
    if dotted in RUNTIME_CHOICES:
        if value not in RUNTIME_CHOICES[dotted]:
            raise ValueError(f"{dotted}: invalid value {value!r}")
        typed: Any = value
    elif dotted in RUNTIME_SETTINGS:
        kind, low, high = RUNTIME_SETTINGS[dotted]
        try:
            typed = kind(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{dotted}: expected a number") from exc
        if not low <= typed <= high:
            raise ValueError(f"{dotted}: must be between {low} and {high}")
    else:
        raise ValueError(f"{dotted}: not a runtime setting")
    return typed


def set_dotted(settings: Settings, dotted: str, value: Any) -> Any:
    """Validate and write one runtime setting; return the stored value."""
    typed = validate_setting(dotted, value)
    section, field = dotted.split(".", 1)
    setattr(getattr(settings, section), field, typed)
    return typed


def runtime_settings_dict(settings: Settings) -> dict[str, Any]:
    """Current values of all runtime-tunable settings."""
    keys = list(RUNTIME_SETTINGS) + list(RUNTIME_CHOICES)
    return {key: get_dotted(settings, key) for key in keys}


def _load_dotenv() -> None:
    try:
        from dotenv import load_dotenv
    except ImportError:  # pragma: no cover - optional dependency
        return
    load_dotenv(PROJECT_DIR / ".env", override=False)


def _env_overrides(data: dict[str, Any]) -> None:
    """Apply a few well-known environment variables on top of the YAML data."""
    server = data.setdefault("server", {})
    if os.getenv("ARB_HOST"):
        server["host"] = os.environ["ARB_HOST"]
    if os.getenv("ARB_PORT"):
        server["port"] = int(os.environ["ARB_PORT"])
    if os.getenv("ARB_ALLOWED_HOSTS"):
        extra = [h.strip() for h in os.environ["ARB_ALLOWED_HOSTS"].split(",") if h.strip()]
        server["allowed_hosts"] = list(server.get("allowed_hosts") or ServerConfig().allowed_hosts) + extra
    if os.getenv("LOG_LEVEL"):
        data.setdefault("logging", {})["level"] = os.environ["LOG_LEVEL"]
    if os.getenv("ARB_DB_PATH"):
        data.setdefault("storage", {})["path"] = os.environ["ARB_DB_PATH"]


def load_settings(config_path: str | Path | None = None) -> Settings:
    """Load settings from YAML, then apply ``.env`` / environment overrides."""
    _load_dotenv()
    path = Path(config_path or os.getenv("ARB_CONFIG") or DEFAULT_CONFIG_PATH)
    data: dict[str, Any] = {}
    if path.exists():
        with path.open("r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
    _env_overrides(data)
    return Settings.model_validate(data)
