"""Честные метрики отчёта по истории вилок (используются в ``backend.stats``).

Сумма максимумов прибыли за жизнь каждой вилки — верхняя оценка: на реальных данных 16–18.10.2026 15 появлений с
объёмом от 1000 $ дали 76 % такой суммы. Поэтому отчёт показывает:

- значения при подтверждении (то, что увидел бы человек); у строк до сбора этих данных — «данных нет»;
- медианы и процентили (p25, p50, p75, p90) прибыли, процента и объёма;
- итог без N самых прибыльных появлений (выбросов, ``stats.exclude_top_n``);
- прибыль при ограничении ставки на вилку и при банкролле с блокировкой денег до расчёта;
- долю вилок, оставшихся при бумажной проверке через +5/+15/+60 с, и прибыль на них;
- фазу (до старта / после старта), разбивку по турнирам, флаги подозрительной ликвидности.

Строка истории без данных при подтверждении (записана до этой версии сканера) обрабатывается без ошибок: фаза
вычисляется по сохранённому времени старта, прибыль при ставке оценивается по максимумам
(min(прибыль, ставка × процент / 100)) и помечается как оценка, флаг большого объёма — по максимальному объёму.
"""

from __future__ import annotations

import heapq
import json
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any

PERCENTILES = (25, 50, 75, 90)
PHASES: tuple[tuple[str, str], ...] = (
    ("prematch", "до старта"),
    ("live", "после старта"),
    ("unknown", "старт неизвестен"),
)
PHASE_LABELS = dict(PHASES)
CENT = 0.005  # меньше полуцента — «денег нет»


def _num(value: Any) -> float:
    return float(value) if value is not None else 0.0


def _opt(value: Any) -> float | None:
    return float(value) if value is not None else None


def parse_utc(value: Any) -> datetime | None:
    """Время из истории; без часового пояса — UTC (сканер пишет UTC со смещением, но строки могут прийти извне)."""
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=timezone.utc)


def _json(value: Any) -> Any:
    if not value:
        return None
    if not isinstance(value, str):
        return value
    try:
        return json.loads(value)
    except ValueError:
        return None


def percentile(ordered: Sequence[float], q: float) -> float | None:
    """Процентиль ``q`` (0..100) отсортированного ряда, линейная интерполяция между соседними (как в numpy)."""
    if not ordered:
        return None
    if len(ordered) == 1:
        return ordered[0]
    pos = (len(ordered) - 1) * q / 100
    low = int(pos)
    high = min(low + 1, len(ordered) - 1)
    return ordered[low] + (ordered[high] - ordered[low]) * (pos - low)


def share_at_least(values: Sequence[float], threshold: float) -> float | None:
    """Доля значений не меньше ``threshold`` (3 знака); None — значений нет."""
    return round(sum(1 for v in values if v >= threshold) / len(values), 3) if values else None


def spread(values: Iterable[float], digits: int = 2) -> dict[str, Any] | None:
    """{p25, p50, p75, p90, max, count} ряда; None — значений нет."""
    ordered = sorted(values)
    if not ordered:
        return None
    out: dict[str, Any] = {f"p{q}": round(percentile(ordered, q) or 0.0, digits) for q in PERCENTILES}
    out["max"] = round(ordered[-1], digits)
    out["count"] = len(ordered)
    return out


def profit_curve(stakes: Any, optimal_stake: Any, optimal_profit: Any) -> list[tuple[float, float]] | None:
    """Точки (потрачено $, прибыль $) обхода стакана при подтверждении: таблица ставок и оптимальный размер.

    Обход покупает сначала самые дешёвые пары, поэтому прибыль от суммы — вогнутая ломаная; прямые между точками
    лежат не выше неё (оценка снизу). None — данных нет.
    """
    points: dict[float, float] = {0.0: 0.0}
    for item in stakes if isinstance(stakes, list) else []:
        if not isinstance(item, dict):
            continue
        cost, profit = _opt(item.get("cost_usd")), _opt(item.get("profit_usd"))
        if cost is not None and profit is not None and cost > 0:
            points[cost] = max(points.get(cost, profit), profit)
    best_stake, best_profit = _opt(optimal_stake), _opt(optimal_profit)
    if best_stake is not None and best_profit is not None and best_stake > 0:
        points[best_stake] = max(points.get(best_stake, best_profit), best_profit)
    if len(points) < 2:
        return None
    curve = sorted(points.items())
    out = [curve[0]]
    for cost, profit in curve[1:]:  # прибыль не убывает с суммой: обход останавливается, когда пара невыгодна
        out.append((cost, max(profit, out[-1][1])))
    return out


@dataclass(slots=True)
class ArbRecord:
    """Одно подтверждённое появление вилки так, как его видит отчёт."""

    id: int
    arb_id: str
    pair_key: str
    day: date
    first_seen: str
    first_dt: datetime
    phase: str  # prematch | live | unknown
    phase_derived: bool  # фаза вычислена по времени старта из истории (строка до этой версии сканера)
    start: datetime | None
    confirmed_at: datetime
    profit: float  # максимум за жизнь (верхняя оценка)
    pct: float
    volume: float
    lifetime: float
    game: str | None
    tournament: str | None
    venue: tuple[str, ...]
    team_a: str | None
    team_b: str | None
    event_title: str | None
    healthy: bool
    captured: bool  # есть данные при подтверждении
    confirm_profit: float | None
    confirm_pct: float | None
    confirm_volume: float | None
    curve: list[tuple[float, float]] | None  # None у строки с данными — при подтверждении выгодной ставки не было
    flags: dict[str, Any] | None  # None — данных нет (строка до этой версии)
    large: bool  # объём за жизнь не меньше stats/capture порога большого объёма
    outlier: bool = False
    paper: dict[float, dict[str, Any]] = field(default_factory=dict)  # задержка -> проверка


def make_record(
    row: Mapping[str, Any], *, rid: int, day: date, venue: tuple[str, ...], healthy: bool, confirm_seconds: float,
    large_volume_usd: float,
) -> ArbRecord:
    """Строка истории (``STATS_COLUMNS``) → запись отчёта; недостающие поля старых строк — «данных нет»."""
    first_seen = str(row["first_seen"])
    first_dt = parse_utc(first_seen)
    if first_dt is None:
        raise ValueError(f"bad first_seen {first_seen!r}")
    start = parse_utc(_get(row, "start_time"))
    phase, derived = _get(row, "phase"), False
    if phase not in ("prematch", "live"):
        # Строка до этой версии: фаза по сохранённому времени старта. Строка этой версии без фазы — старт неизвестен.
        derived = not _get(row, "capture_version")
        phase = "unknown" if start is None else ("prematch" if first_dt < start else "live")
    captured = _get(row, "confirm_profit_usd") is not None
    confirmed_at = parse_utc(_get(row, "confirmed_at")) or first_dt + timedelta(seconds=confirm_seconds)
    volume = _num(row["max_volume_usd"])
    flags = _json(_get(row, "liquidity_flags")) if _get(row, "capture_version") else None
    return ArbRecord(
        id=rid,
        arb_id=str(row["arb_id"]),
        pair_key=str(row["pair_key"]),
        day=day,
        first_seen=first_seen,
        first_dt=first_dt,
        phase=phase,
        phase_derived=derived,
        start=start,
        confirmed_at=confirmed_at,
        profit=_num(row["max_profit_usd"]),
        pct=_num(row["max_profit_pct"]),
        volume=volume,
        lifetime=_num(row["lifetime_sec"]),
        game=row["game"],
        tournament=row["tournament"],
        venue=venue,
        team_a=row["team_a"],
        team_b=row["team_b"],
        event_title=row["event_title"],
        healthy=healthy,
        captured=captured,
        confirm_profit=_opt(_get(row, "confirm_profit_usd")),
        confirm_pct=_opt(_get(row, "confirm_profit_pct")),
        confirm_volume=_opt(_get(row, "confirm_volume_usd")),
        curve=profit_curve(_json(_get(row, "stake_profits")), _get(row, "optimal_stake_usd"),
                           _get(row, "optimal_profit_usd")) if captured else None,
        flags=flags if isinstance(flags, dict) else None,
        large=large_volume_usd > 0 and volume >= large_volume_usd,
    )


def _get(row: Mapping[str, Any], key: str) -> Any:
    try:
        return row[key]
    except (KeyError, IndexError):
        return None


def on_curve(curve: list[tuple[float, float]], stake: float | None) -> tuple[float, float]:
    """(потрачено $, прибыль $) при ставке ``stake`` (None — весь выгодный объём) по точкам обхода стакана."""
    top_cost, top_profit = curve[-1]
    if stake is None or stake >= top_cost:
        return top_cost, top_profit
    for (c0, p0), (c1, p1) in zip(curve, curve[1:]):
        if c0 <= stake <= c1:
            return stake, p0 + (p1 - p0) * (stake - c0) / (c1 - c0)
    return 0.0, 0.0  # ставка меньше нуля


def profit_at(arb: ArbRecord, stake: float | None) -> tuple[float, float, bool]:
    """(потрачено $, прибыль $, точно) при ставке ``stake`` (None — без ограничения) по данным при подтверждении.

    Без данных при подтверждении — оценка по максимумам: прибыль min(прибыль за жизнь, ставка × процент за жизнь / 100),
    потрачено min(ставка, объём за жизнь); ``точно`` = False. Строка с данными, у которой при подтверждении не было
    выгодной ставки, даёт (0, 0, точно).
    """
    if arb.captured:
        return (*on_curve(arb.curve, stake), True) if arb.curve else (0.0, 0.0, True)
    if stake is None:
        return arb.volume, arb.profit, False
    return min(stake, arb.volume), min(arb.profit, stake * arb.pct / 100), False


def capped_profit(arbs: Iterable[ArbRecord], cap: float) -> dict[str, Any]:
    """Сумма прибыли, если на каждую вилку ставить не больше ``cap`` (0 — весь доступный объём), без банкролла."""
    exact = estimated = 0.0
    exact_n = estimated_n = 0
    for arb in arbs:
        _, profit, is_exact = profit_at(arb, cap if cap > 0 else None)
        if is_exact:
            exact += profit
            exact_n += 1
        else:
            estimated += profit
            estimated_n += 1
    return {
        "max_stake_usd": cap,
        "profit_usd": round(exact + estimated, 2),
        "exact_arbs": exact_n,
        "exact_profit_usd": round(exact, 2),
        "estimated_arbs": estimated_n,
        "estimated_profit_usd": round(estimated, 2),
    }


class _Tally:
    """Итоги симуляции банкролла по одной группе вилок (всё или одна фаза)."""

    __slots__ = ("arbs", "taken", "no_money", "no_depth", "exact", "estimated", "exact_n", "estimated_n", "turnover")

    def __init__(self) -> None:
        self.arbs = self.taken = self.no_money = self.no_depth = self.exact_n = self.estimated_n = 0
        self.exact = self.estimated = self.turnover = 0.0

    def view(self) -> dict[str, Any]:
        return {
            "arbs": self.arbs,
            "taken": self.taken,
            "skipped_no_money": self.no_money,
            "skipped_no_depth": self.no_depth,
            "profit_usd": round(self.exact + self.estimated, 2),
            "turnover_usd": round(self.turnover, 2),
            "exact_arbs": self.exact_n,
            "exact_profit_usd": round(self.exact, 2),
            "estimated_arbs": self.estimated_n,
            "estimated_profit_usd": round(self.estimated, 2),
        }


def simulate_bankroll(
    arbs: Iterable[ArbRecord], bankroll: float, cap: float, settle_hours: float,
    group_of: Callable[[ArbRecord], str] | None = None,
) -> dict[str, Any] | None:
    """Прибыль с общим капиталом ``bankroll``: вилки по времени подтверждения, ставка = min(``cap``, свободные деньги,
    доступный объём); потраченное возвращается при расчёте — позднее из (старт, подтверждение) + ``settle_hours``.
    Прибыль не реинвестируется. None — банкролл 0.

    ``group_of`` — разбить итог по группам (например, по фазе) внутри той же симуляции: ``by_group`` — доля каждой
    группы в общем пуле, суммы групп равны итогу.
    """
    if bankroll <= 0:
        return None
    order = sorted(arbs, key=lambda a: (a.confirmed_at, a.first_seen, a.id))
    locks: list[tuple[datetime, int, float]] = []
    free, peak_locked = bankroll, 0.0
    total = _Tally()
    groups: dict[str, _Tally] = {}
    hold = timedelta(hours=settle_hours)
    for arb in order:
        tallies = [total]
        if group_of is not None:
            key = group_of(arb)
            tallies.append(groups.setdefault(key, _Tally()))
        for tally in tallies:
            tally.arbs += 1
        while locks and locks[0][0] <= arb.confirmed_at:
            free += heapq.heappop(locks)[2]
        want = min(cap, free) if cap > 0 else free
        if want < CENT:
            for tally in tallies:
                tally.no_money += 1
            continue
        used, profit, is_exact = profit_at(arb, want)
        if used < CENT or profit <= 0:
            for tally in tallies:
                tally.no_depth += 1
            continue
        free -= used
        settle = max(arb.start or arb.confirmed_at, arb.confirmed_at) + hold
        heapq.heappush(locks, (settle, arb.id, used))
        peak_locked = max(peak_locked, bankroll - free)
        for tally in tallies:
            tally.taken += 1
            tally.turnover += used
            if is_exact:
                tally.exact += profit
                tally.exact_n += 1
            else:
                tally.estimated += profit
                tally.estimated_n += 1
    view = total.view()
    out = {
        "bankroll_usd": bankroll,
        "max_stake_usd": cap,
        "settle_hours": settle_hours,
        **view,
        "return_pct": round(view["profit_usd"] / bankroll * 100, 2),
        "peak_locked_usd": round(peak_locked, 2),
    }
    if group_of is not None:
        out["by_group"] = {key: {**tally.view(), "shared_pool": True} for key, tally in groups.items()}
    return out


def bankroll_share(by_group: Mapping[str, dict[str, Any]], key: str) -> dict[str, Any]:
    """Доля группы в общей симуляции банкролла (нули, если у группы не было вилок)."""
    return by_group.get(key) or {**_Tally().view(), "shared_pool": True}


def mark_outliers(arbs: list[ArbRecord], n: int) -> list[ArbRecord]:
    """Отметить N самых прибыльных появлений (по максимуму прибыли; при равенстве — раньше появившееся)."""
    if n <= 0:
        return []
    top = sorted(arbs, key=lambda a: (-a.profit, a.first_seen, a.id))[:n]
    for arb in top:
        arb.outlier = True
    return top


def profit_block(arbs: Sequence[ArbRecord], total_profit: float | None = None) -> dict[str, Any]:
    """Честные цифры группы появлений: при подтверждении, процентили, без выбросов (и сумма максимумов для сравнения)."""
    profits = [a.profit for a in arbs]
    confirmed = [a for a in arbs if a.captured]
    trimmed = sum(a.profit for a in arbs if not a.outlier)
    upper = sum(profits)
    block = {
        "profit_usd": round(upper, 2),  # сумма максимумов — верхняя оценка
        "profit_trimmed_usd": round(trimmed, 2),
        "outliers": sum(1 for a in arbs if a.outlier),
        "outliers_profit_usd": round(upper - trimmed, 2),
        "confirm_arbs": len(confirmed),
        "no_data_arbs": len(arbs) - len(confirmed),
        "confirm_profit_usd": round(sum(a.confirm_profit or 0.0 for a in confirmed), 2) if confirmed else None,
        "profit_spread": spread(profits),
        "pct_spread": spread([a.pct for a in arbs], 3),
        "volume_spread": spread([a.volume for a in arbs]),
        "confirm_profit_spread": spread([a.confirm_profit for a in confirmed if a.confirm_profit is not None]),
        "confirm_volume_spread": spread([a.confirm_volume for a in confirmed if a.confirm_volume is not None]),
        "large_volume_arbs": sum(1 for a in arbs if a.large),
    }
    if total_profit:
        block["share_of_profit"] = round(upper / total_profit, 4)
    return block


def attach_paper(arbs: Iterable[ArbRecord], checks: Iterable[Mapping[str, Any]]) -> list[float]:
    """Привязать бумажные проверки к появлениям (arb_id + first_seen; первая проверка на задержку) и разобрать их
    таблицы ставок один раз. Вернуть задержки, которые встретились у проверок этих появлений."""
    by_key = {(a.arb_id, a.first_seen): a for a in arbs}
    delays: set[float] = set()
    for check in checks:
        arb = by_key.get((check["arb_id"], check["first_seen"]))
        if arb is None:
            continue
        delay = float(check["delay_sec"])
        if delay in arb.paper:
            continue
        item = dict(check)
        item["curve"] = profit_curve(_json(item.get("stake_profits")), item.get("optimal_stake_usd"),
                                     item.get("optimal_profit_usd"))
        arb.paper[delay] = item
        delays.add(delay)
    return sorted(delays)


def paper_block(arbs: Sequence[ArbRecord], delays: Sequence[float], cap: float) -> list[dict[str, Any]]:
    """По задержке: сколько появлений проверено, сколько вилок осталось, доля, прибыль на оставшихся.

    ``errors`` — проверки без данных (ошибка запроса, опоздание, площадка не умеет запрос); ``no_data`` — появления
    без проверки на этой задержке.
    """
    out = []
    for delay in delays:
        checked = left = mismatched = errors = 0
        profit = capped = 0.0
        for arb in arbs:
            check = arb.paper.get(delay)
            if check is None:
                continue
            if check["status"] != "ok":
                errors += 1
                continue
            checked += 1
            if check.get("books_match") == 0:
                mismatched += 1
            if check.get("arb_exists") != 1:
                continue
            left += 1
            profit += _num(check.get("profit_usd"))
            curve = check.get("curve")
            if curve:
                capped += on_curve(curve, cap if cap > 0 else None)[1]
        out.append({
            "delay_sec": delay,
            "arbs": len(arbs),
            "checked": checked,
            "errors": errors,
            "no_data": len(arbs) - checked - errors,
            "left": left,
            "share_left": round(left / checked, 4) if checked else None,
            "profit_usd": round(profit, 2),
            "capped_profit_usd": round(capped, 2),
            "max_stake_usd": cap,
            "books_mismatch": mismatched,
        })
    return out


def flag_counts(arbs: Iterable[ArbRecord]) -> dict[str, int]:
    """Сколько появлений с каждым флагом; ``no_data`` — строк без снимков (флаги скачка и устаревших данных неизвестны)."""
    counts = {"large_volume": 0, "size_jump": 0, "stale_data": 0, "no_data": 0}
    for arb in arbs:
        if arb.large:
            counts["large_volume"] += 1
        if arb.flags is None:
            counts["no_data"] += 1
            continue
        for key in ("size_jump", "stale_data"):
            if key in arb.flags:
                counts[key] += 1
    return counts


def phase_summary(arbs: Sequence[ArbRecord]) -> dict[str, Any]:
    """Время жизни, процентили и прочее одной фазы (или всего)."""
    lifetimes = [a.lifetime for a in arbs]
    return {
        "arbs": len(arbs),
        "distinct_arbs": len({a.arb_id for a in arbs}),
        "derived_phase_arbs": sum(1 for a in arbs if a.phase_derived),
        "lifetime_spread": spread(lifetimes, 1),
        "share_30s": share_at_least(lifetimes, 30),
        "share_60s": share_at_least(lifetimes, 60),
    }
