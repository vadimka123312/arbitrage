@echo off
rem Esports Arb Scanner for Windows: double-click this file, or run "run-windows.bat --mock" in a console.
rem The first start creates .venv and installs the dependencies. Needs Python 3.11+ from python.org.
setlocal
pushd "%~dp0"
set "VPY=.venv\Scripts\python.exe"

if not exist "run.py" goto notextracted
if exist "%VPY%" goto checkvenv
echo Creating the virtual environment .venv ...
where py >nul 2>nul && py -3 -m venv .venv
if not exist "%VPY%" python -m venv .venv
if not exist "%VPY%" goto nopython

:checkvenv
"%VPY%" -c "import sys; raise SystemExit(sys.version_info < (3, 11))" 2>nul
if errorlevel 1 goto brokenvenv
"%VPY%" -m pip --version >nul 2>nul
if errorlevel 1 goto brokenvenv

echo Checking the dependencies. The first start can take a few minutes, do not close this window ...
"%VPY%" -m pip install --disable-pip-version-check -q -r requirements.txt
if errorlevel 1 goto pipfailed

"%VPY%" run.py %*
set "CODE=%errorlevel%"
echo.
echo The scanner has stopped.
pause
popd
exit /b %CODE%

:notextracted
echo run.py was not found next to this file. Extract the whole ZIP archive to a folder, then start run-windows.bat there.
goto fail

:nopython
echo.
echo Python 3.11 or newer was not found.
echo Install it from https://www.python.org/downloads/ with the option "Add python.exe to PATH", then run run-windows.bat again.
goto fail

:brokenvenv
echo.
echo The .venv folder is broken or uses Python older than 3.11.
echo Delete the .venv folder, install Python 3.11+ if needed, then run run-windows.bat again.
goto fail

:pipfailed
echo.
echo The dependencies were not installed: read the messages above and check the internet connection.
echo If it keeps failing, delete the .venv folder and run run-windows.bat again.
goto fail

:fail
pause
popd
exit /b 1
