"""Недоступность и формат контракта не отменяются старым snapshot. Только mock HTTP."""

import copy
from datetime import timedelta
from types import SimpleNamespace

import httpx
import pytest

import backend.adapters.bcgame as bcgame
from backend.adapters.bcgame_clock import contract_identity
from backend.engine.scanner import Scanner
from backend.storage.db import Database
from tests.conftest import make_market
from tests.test_bcgame import NOW, adapter, feed, first, markets, response_api, transport
from tests.test_bcgame_freshness import accept, engine_result, price_patch


def snapshot_responses(requests, generated, omit=None):
    native = response_api(requests, delta={"version": 0})
    def handler(request):
        value = native(request).json()
        value["generated"] = int(generated.timestamp()*1000)
        if omit:
            value.get("events", {}).pop(omit, None)
        return httpx.Response(200, json=value)
    return handler


@pytest.mark.parametrize("kind", ["event", "winner", "outcome", "paused_outcome", "paused_event",
                                  "desc_null", "state_null", "selections_null", "reset", "third", "threeway"])
async def test_complete_snapshot_can_restore_market_after_unavailability(adapter, monkeypatch, tmp_path, kind):
    market = markets(adapter)[0]
    await adapter.subscribe_prices([market], lambda m: None)
    peer = make_market(team_a=market.team_a, team_b=market.team_b, game=market.game, start=market.start_time,
                       best_of=None, asks_a=[(.001, 100)], asks_b=[(.001, 100)], updated_at=NOW)
    stub = SimpleNamespace(name="Polymarket", set_paired=lambda keys: None)
    scanner = Scanner(adapter.settings, {"polymarket": stub, "bcgame": adapter}, Database(tmp_path/'reuse.db'))
    scanner.markets = {"polymarket": {peer.key: peer}, "bcgame": {market.key: market}}
    scanner.rematch()
    assert engine_result(adapter, market, NOW)
    eid = market.market_id
    changes = {
        "event": None,
        "winner": {"markets": {"186": None}},
        "outcome": {"markets": {"186": {"": {"4": None}}}},
        "paused_outcome": {"markets": {"186": {"": {"4": {"b": 1}}}}},
        "paused_event": {"state": {"status": 2}},
        "desc_null": {"desc": None},
        "state_null": {"state": None},
        "selections_null": {"markets": {"186": {"": None}}},
        "reset": {"shouldResetEvent": True, "state": {"status": 0}},
        "third": {"markets": {"186": {"": {"6": {"k": "3.0"}}}}},
        "threeway": {"markets": {"1": {"": {"1": {}, "2": {}, "3": {}}}}},
    }
    unavailable = NOW + timedelta(seconds=1)
    await accept(adapter, monkeypatch, {"events": {eid: changes[kind]}}, unavailable)
    assert not market.accepting_orders
    monkeypatch.setattr(bcgame, 'utcnow', lambda: NOW + timedelta(seconds=2))
    await transport(adapter, snapshot_responses([], NOW - timedelta(seconds=60)))
    await adapter.poll_once()
    scanner.rematch()
    adapter._publish()
    assert market.accepting_orders and market.asks_a and market.asks_b
    assert engine_result(adapter, market, NOW + timedelta(seconds=2))


async def test_complete_snapshot_can_restore_event_after_prior_absence(adapter, monkeypatch):
    market = markets(adapter)[0]
    await adapter.subscribe_prices([market], lambda m: None)
    monkeypatch.setattr(bcgame, 'utcnow', lambda: NOW + timedelta(seconds=1))
    await transport(adapter, snapshot_responses([], NOW + timedelta(seconds=1), omit=market.market_id))
    await adapter.poll_once()
    assert market.market_id not in adapter.feeds['prematch'].data['events']
    monkeypatch.setattr(bcgame, 'utcnow', lambda: NOW + timedelta(seconds=2))
    await transport(adapter, snapshot_responses([], NOW - timedelta(seconds=60)))
    await adapter.poll_once()
    adapter.set_paired({market.key})
    assert market.accepting_orders


async def test_newer_snapshot_restores_availability_and_confirms_same_price(adapter, monkeypatch):
    old = NOW - timedelta(seconds=60)
    adapter.feeds = {'prematch': feed(stamp=old)}
    eid, _ = first(adapter)
    await accept(adapter, monkeypatch, {'events': {eid: None}}, NOW + timedelta(seconds=1))
    current = NOW + timedelta(seconds=2)
    monkeypatch.setattr(bcgame, 'utcnow', lambda: current)
    await transport(adapter, snapshot_responses([], current))
    found = await adapter.fetch_markets()
    target = next(m for m in found if m.market_id == eid)
    assert target.updated_at == current
    assert engine_result(adapter, target, current)


@pytest.mark.parametrize('location', ['name', 'slug', 'specifier'])
async def test_effective_format_has_one_definition_for_clock_and_normalization(adapter, monkeypatch, location):
    data = copy.deepcopy(adapter.feeds['prematch'].data)
    eid = next(iter(data['events']))
    event = data['events'][eid]
    if location == 'specifier':
        event['markets']['9999'] = {'best_of=3': {}}
        patch = {'markets': {'9999': {'best_of=3': None, 'best_of=5': {}}}}
    else:
        event['desc'][location] = 'match-BO3'
        patch = {'desc': {location: 'match-BO5'}}
    adapter.feeds = {'prematch': feed(data=data)}
    assert adapter._best_of(event) == contract_identity(event)[-1] == 3
    await accept(adapter, monkeypatch, {'events': {eid: patch}}, NOW + timedelta(seconds=1))
    current = adapter.feeds['prematch'].data['events'][eid]
    assert adapter._best_of(current) == contract_identity(current)[-1] == 5
    normalized = adapter.normalize({'id': eid})[0]
    assert normalized.updated_at == NOW + timedelta(seconds=1)
    assert engine_result(adapter, normalized, NOW + timedelta(seconds=1))


async def test_paper_provenance_describes_the_returned_book_not_the_input(adapter, monkeypatch):
    eid, event = first(adapter)
    market = adapter.normalize({'id': eid})[0]
    original = copy.deepcopy(market.extra)
    current = NOW + timedelta(seconds=1)
    patch = price_patch(eid, event)
    monkeypatch.setattr(bcgame, 'utcnow', lambda: current)
    await transport(adapter, response_api([], delta={**patch, 'generated': int(current.timestamp()*1000)}))
    checked = await adapter.fetch_book(market)
    assert checked.updated_at == current
    assert checked.extra['bcgame_quote_times'] == {'4': current.isoformat(), '5': current.isoformat()}
    assert market.extra == original


async def test_snapshot_tracks_only_configured_esports_quote_history(adapter):
    adapter.feeds = {}
    native = response_api([])
    def handler(request):
        value = native(request).json()
        if request.url.path.endswith('/101'):
            value['sports']['999'] = {'slug': 'tennis', 'name': 'Tennis'}
            item = copy.deepcopy(next(iter(value['events'].values())))
            item['desc']['sport'] = '999'
            value['events']['9990001'] = item
        return httpx.Response(200, json=value)
    await transport(adapter, handler)
    assert len(await adapter.fetch_markets()) == 7
    assert len(adapter.feeds['prematch'].quote_evidence) == 14
    assert not any(key[0] == '9990001' for key in adapter.feeds['prematch'].quote_evidence)


async def test_absence_uses_manifest_boundary_not_an_old_unrelated_part(adapter, monkeypatch):
    market = markets(adapter)[0]
    await adapter.subscribe_prices([market], lambda m: None)
    clock = NOW + timedelta(seconds=5)
    monkeypatch.setattr(bcgame, 'utcnow', lambda: clock)
    native = response_api([], delta={'version': 0})
    def absent(request):
        value = native(request).json()
        value.get('events', {}).pop(market.market_id, None)
        stamp = NOW - timedelta(seconds=60) if request.url.path.endswith('/102') else clock
        value['generated'] = int(stamp.timestamp()*1000)
        return httpx.Response(200, json=value)
    await transport(adapter, absent)
    await adapter.poll_once()
    saved = adapter.feeds['prematch'].quote_evidence[(market.market_id, '4')]
    assert saved.unavailable_at == clock
    assert saved.source_at == NOW
    clock = NOW + timedelta(seconds=6)
    native = response_api([], delta={'version': 0})
    def old_book(request):
        value = native(request).json()
        stamp = clock if request.url.path.endswith('/0') else NOW + timedelta(seconds=1)
        value['generated'] = int(stamp.timestamp()*1000)
        return httpx.Response(200, json=value)
    await transport(adapter, old_book)
    await adapter.poll_once()
    await adapter.fetch_book(market)
    adapter.set_paired({market.key})
    assert market.accepting_orders


async def test_complete_snapshot_restores_configured_game_metadata(adapter, monkeypatch):
    eid, event = first(adapter)
    sport = event['desc']['sport']
    await accept(adapter, monkeypatch, {'sports': {sport: {'slug': 'not-a-configured-game'}}}, NOW + timedelta(seconds=1))
    assert not adapter.normalize({'id': eid})
    await transport(adapter, snapshot_responses([], NOW - timedelta(seconds=60)))
    await adapter.poll_once()
    assert adapter.normalize({'id': eid})
