"""Persistence: history filters/CSV, overrides and settings across restarts, shutdown flush."""

import time

import pytest
from fastapi.testclient import TestClient

from backend.adapters import apply_mock_mode
from backend.adapters.mock import reset_worlds
from backend.api.server import create_app
from backend.config import load_settings
from backend.engine.scanner import Scanner
from backend.models import ArbLeg, ArbOpportunity, ClosedArb
from backend.storage.db import Database
from tests.conftest import at


def closed(arb_id: str, game: str, profit: float, confirmed: bool, start_offset: float) -> ClosedArb:
    leg = ArbLeg(platform="polymarket", platform_name="Polymarket", market_id="m", outcome="A", ask=0.4, size=10)
    arb = ArbOpportunity(
        arb_id=arb_id, pair_key="p", direction="A", game=game, event_title="A vs B", team_a="A", team_b="B",
        leg1=leg, leg2=leg.model_copy(update={"platform": "kalshi", "outcome": "B"}), sum_ask=0.9, fees_usd=0.1,
        cost_per_contract=0.95, profit_pct=profit, contracts=10, volume_usd=9.5, profit_usd=0.5,
    )
    return ClosedArb(
        arb_id=arb_id, first_seen=at(start_offset), last_seen=at(start_offset + 6), lifetime_sec=6.0,
        confirmed=confirmed, max_profit_pct=profit, max_volume_usd=9.5, max_profit_usd=0.5, last=arb,
    )


async def test_history_cursor_paging_is_not_shifted_by_new_rows(tmp_path):
    db = Database(tmp_path / "cursor.db")
    await db.connect()
    await db.add_history([closed(name, "cs2", 1.0, True, offset) for name, offset in (("a", 0), ("b", 10), ("c", 20), ("d", 30))])
    first = (await db.list_history(limit=2))["items"]
    assert [i["arb_id"] for i in first] == ["d", "c"]
    # A newer row is written before the user clicks "Показать ещё": an offset would return "c" again.
    await db.add_history([closed("e", "cs2", 1.0, True, 40)])
    last = first[-1]
    page = await db.list_history(limit=2, before=(last["first_seen"], last["id"]))
    assert [i["arb_id"] for i in page["items"]] == ["b", "a"] and page["total"] == 5
    # Rows with the same first_seen are split by id, without repeats or gaps.
    await db.add_history([closed("f", "cs2", 1.0, True, 0)])
    rest = await db.list_history(limit=10, before=(page["items"][0]["first_seen"], page["items"][0]["id"]))
    assert sorted(i["arb_id"] for i in rest["items"]) == ["a", "f"]
    await db.close()


async def test_history_filters_and_csv(tmp_path):
    db = Database(tmp_path / "h.db")
    await db.connect()
    await db.add_history([
        closed("a", "cs2", 1.0, True, 0),
        closed("b", "cs2", 3.0, False, 10),
        closed("c", "dota2", 5.0, True, 20),
    ])
    assert (await db.list_history())["total"] == 3
    newest_first = [i["arb_id"] for i in (await db.list_history())["items"]]
    assert newest_first == ["c", "b", "a"]
    assert [i["arb_id"] for i in (await db.list_history(game="cs2"))["items"]] == ["b", "a"]
    assert [i["arb_id"] for i in (await db.list_history(confirmed_only=True))["items"]] == ["c", "a"]
    assert [i["arb_id"] for i in (await db.list_history(min_profit_pct=2.5))["items"]] == ["c", "b"]
    page = await db.list_history(limit=1, offset=1)
    assert page["total"] == 3 and [i["arb_id"] for i in page["items"]] == ["b"]
    csv_text = await db.history_csv(game="cs2", confirmed_only=True)
    lines = csv_text.strip().splitlines()
    assert len(lines) == 2 and lines[0].startswith("id,first_seen")
    await db.close()


def _app(db_path):
    reset_worlds()
    settings = apply_mock_mode(load_settings())
    settings.storage.path = str(db_path)
    settings.logging.file = ""
    return create_app(settings)


def test_overrides_and_settings_survive_restart(tmp_path):
    db_path = tmp_path / "persist.db"
    with TestClient(_app(db_path), base_url="http://localhost") as client:
        assert client.put("/api/settings", json={"engine.confirm_seconds": 12, "engine.depth_mode": "walk_book"}).status_code == 200
        key = "kalshi:KXMOCKCS2-000|polymarket:polymarket-000"
        assert client.post("/api/pairs/override", json={"pair_key": key, "status": "blocked"}).status_code == 200
    with TestClient(_app(db_path), base_url="http://localhost") as client:
        settings = client.get("/api/settings").json()
        assert settings["engine.confirm_seconds"] == 12
        assert settings["engine.depth_mode"] == "walk_book"
        deadline = time.time() + 5
        state = client.get("/api/state").json()
        while time.time() < deadline and not state["blocked"]:
            time.sleep(0.1)
            state = client.get("/api/state").json()
        assert [p["pair_key"] for p in state["blocked"]] == [key]


async def test_active_arbs_are_written_on_shutdown(settings, tmp_path):
    db = Database(tmp_path / "s.db")
    await db.connect()
    scanner = Scanner(settings, {}, db)
    opp = closed("x", "cs2", 2.0, True, 0).last
    scanner.tracker.update([opp], at(0))
    scanner.tracker.update([opp], at(3))
    await scanner.stop()
    items = (await db.list_history())["items"]
    assert [i["arb_id"] for i in items] == ["x"]
    assert items[0]["lifetime_sec"] == pytest.approx(3.0)
    assert items[0]["confirmed"] is False
    await db.close()
