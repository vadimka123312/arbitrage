"""HTTP retries/backoff and freshness bookkeeping (no real network)."""

from datetime import timedelta
from types import SimpleNamespace

import httpx
import pytest

from backend.adapters.kalshi import KalshiAdapter
from backend.engine.scanner import Scanner
from backend.net import HttpClient, HttpError
from backend.storage.db import Database
from backend.models import Level, utcnow
from tests.conftest import load_fixture, make_market
from tests.test_adapters import KALSHI_SERIES_META


async def test_retry_on_429_then_success():
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] < 3:
            return httpx.Response(429, json={"error": "too many requests"})
        return httpx.Response(200, json={"ok": True})

    client = HttpClient("https://api.test", "test", rate_per_sec=1000, backoff_base=0.001,
                        transport=httpx.MockTransport(handler))
    assert await client.get_json("/x") == {"ok": True}
    assert calls["n"] == 3
    await client.aclose()


async def test_non_retryable_error_raises_immediately():
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(404, json={"error": "not found"})

    client = HttpClient("https://api.test", "test", rate_per_sec=1000, transport=httpx.MockTransport(handler))
    with pytest.raises(HttpError) as exc:
        await client.get_json("/missing")
    assert exc.value.status == 404 and calls["n"] == 1
    await client.aclose()


async def test_retries_exhausted():
    client = HttpClient("https://api.test", "test", rate_per_sec=1000, max_retries=2, backoff_base=0.001,
                        transport=httpx.MockTransport(lambda r: httpx.Response(503)))
    with pytest.raises(HttpError):
        await client.get_json("/down")
    await client.aclose()


async def test_kalshi_partial_poll_keeps_last_good_until_a_complete_response(settings):
    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    market = adapter._normalize_event(load_fixture("kalshi_event.json"), "cs2", "KXCS2GAME", KALSHI_SERIES_META)[0]
    market.updated_at = None
    books = load_fixture("kalshi_orderbooks.json")["orderbooks"]
    returned = {"items": books[:1]}

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path.endswith("/markets/orderbooks")
        assert len(request.url.params.get_list("tickers")) == 2
        return httpx.Response(200, json={"orderbooks": returned["items"]})

    await adapter.http.aclose()
    adapter.http = HttpClient("https://api.test", "kalshi", rate_per_sec=1000, transport=httpx.MockTransport(handler))
    adapter._subscribed = {market.key: market}
    with pytest.raises(ValueError, match="incomplete orderbooks response"):
        await adapter.poll_once()
    assert market.updated_at is None  # only one of the two books came back
    assert adapter.books == {} and adapter.book_ts == {}  # no half-snapshot is published to the cache
    returned["items"] = books
    await adapter.poll_once()
    assert market.updated_at is not None
    assert market.outcome_a_ask is not None and market.outcome_b_ask is not None
    await adapter.http.aclose()


def test_scanner_merge_keeps_fresher_book(settings, tmp_path):
    scanner = Scanner(settings, {}, Database(tmp_path / "x.db"))
    live = make_market("polymarket", "m1", asks_a=[(0.40, 10)], asks_b=[(0.61, 10)])
    scanner._merge("polymarket", [live])
    # Discovery returns the same market with new metadata and an older (indicative) book.
    rediscovered = make_market("polymarket", "m1", asks_a=[(0.55, 0)], asks_b=[(0.50, 0)])
    rediscovered.updated_at = None
    rediscovered.event_title = "renamed"
    scanner._merge("polymarket", [rediscovered])
    kept = scanner.markets["polymarket"]["polymarket:m1"]
    assert kept is live  # same object (adapters hold references to it)
    assert kept.event_title == "renamed"
    assert kept.outcome_a_ask == pytest.approx(0.40)
    # A market that disappears from discovery is removed.
    scanner._merge("polymarket", [])
    assert scanner.markets["polymarket"] == {}


def test_scanner_merge_takes_newer_book(settings, tmp_path):
    scanner = Scanner(settings, {}, Database(tmp_path / "x.db"))
    old = make_market("kalshi", "k1", asks_a=[(0.40, 10)], asks_b=[(0.61, 10)], updated_at=utcnow() - timedelta(seconds=30))
    scanner._merge("kalshi", [old])
    new = make_market("kalshi", "k1", asks_a=[(0.45, 10)], asks_b=[(0.56, 10)])
    scanner._merge("kalshi", [new])
    assert scanner.markets["kalshi"]["kalshi:k1"].outcome_a_ask == pytest.approx(0.45)


def test_pair_warnings_include_draw_and_start_time(settings, tmp_path):
    from backend.models import MatchedPair

    scanner = Scanner(settings, {}, Database(tmp_path / "w.db"))
    left = make_market("polymarket", "p1", best_of=2)
    right = make_market("kalshi", "k1", best_of=None)
    scanner._merge("polymarket", [left])
    scanner._merge("kalshi", [right])
    pair = MatchedPair(pair_key="x", game="cs2", left_key=left.key, right_key=right.key, left_platform="polymarket",
                       right_platform="kalshi", time_diff_minutes=120)
    fields = {w.field: w.severity for w in scanner._rule_warnings(pair)}
    assert fields["draw"] == "high"
    assert fields["start_time"] == "medium"


async def test_per_call_retries_override():
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(503)

    client = HttpClient("https://api.test", "t", rate_per_sec=1000, backoff_base=0.001, transport=httpx.MockTransport(handler))
    with pytest.raises(HttpError):
        await client.get_json("/x", retries=1)
    assert calls["n"] == 2  # one try + one retry, not max_retries (5)
    await client.aclose()


async def _kalshi_with_mock_http(settings, handler):
    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    market = adapter._normalize_event(load_fixture("kalshi_event.json"), "cs2", "KXCS2GAME", KALSHI_SERIES_META)[0]
    adapter._subscribed = {market.key: market}
    await adapter.http.aclose()
    adapter.http = HttpClient("https://api.test", "kalshi", rate_per_sec=1000, transport=httpx.MockTransport(handler))
    return adapter, market


async def test_kalshi_poll_never_overwrites_books_owned_by_the_stream(settings):
    books = load_fixture("kalshi_orderbooks.json")["orderbooks"]
    tickers = [ob["ticker"] for ob in books]
    state = {"adapter": None, "requested": []}

    def handler(request: httpx.Request) -> httpx.Response:
        asked = request.url.params.get_list("tickers")
        state["requested"].append(asked)
        if len(state["requested"]) == 2:
            # A stream snapshot for the first ticker lands while this request is in flight.
            state["adapter"].books[tickers[0]] = {"yes": [(0.30, 7.0)], "no": [(0.65, 9.0)]}
            state["adapter"]._ws_owned.add(tickers[0])
        return httpx.Response(200, json={"orderbooks": [ob for ob in books if ob["ticker"] in asked]})

    adapter, market = await _kalshi_with_mock_http(settings, handler)
    state["adapter"] = adapter
    assert await adapter.poll_once() is True  # first poll: nothing is owned by the stream yet
    assert await adapter.poll_once() is True  # the in-flight response for tickers[0] must be dropped
    assert adapter.books[tickers[0]] == {"yes": [(0.30, 7.0)], "no": [(0.65, 9.0)]}
    assert await adapter.poll_once() is True  # later polls do not even ask for the stream's ticker
    assert state["requested"][-1] == [tickers[1]]
    adapter._ws_owned.add(tickers[1])
    assert await adapter.poll_once() is False  # the stream owns every book: no request at all
    assert len(state["requested"]) == 3
    await adapter.http.aclose()


async def test_kalshi_exchange_status_failure_is_not_retried_before_every_poll(settings):
    calls = {"status": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/exchange/status"):
            calls["status"] += 1
            return httpx.Response(200, json=["not", "an", "object"])
        return httpx.Response(200, json={"orderbooks": []})

    adapter, market = await _kalshi_with_mock_http(settings, handler)
    await adapter.refresh_exchange_status()  # malformed JSON must not raise
    assert adapter._status_checked > 0 and market.accepting_orders is True
    await adapter.http.aclose()


def test_kalshi_ws_sequence_gap_before_a_snapshot_resyncs(settings):
    import json as _json

    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    snapshotted: set[str] = set()
    seqs: dict[int, int] = {}
    snap = {"type": "orderbook_snapshot", "sid": 1, "msg": {"market_ticker": "T-A", "yes_dollars_fp": [], "no_dollars_fp": []}}
    assert adapter._on_ws_message(_json.dumps({**snap, "seq": 1}), snapshotted, seqs) == "data"
    other = {**snap, "seq": 3, "msg": {**snap["msg"], "market_ticker": "T-B"}}  # seq 2 was lost
    assert adapter._on_ws_message(_json.dumps(other), snapshotted, seqs) == "resync"


# ---------------------------------------------------------------- log messages (user's Windows log, session 3)


def test_describe_error_names_exceptions_without_text():
    from backend.net import describe_error

    assert describe_error(httpx.ReadTimeout("")) == "ReadTimeout"
    assert describe_error(OSError("network is down")) == "OSError: network is down"
    assert describe_error(HttpError("kalshi: GET /x failed: ReadTimeout")) == "kalshi: GET /x failed: ReadTimeout"


async def test_network_error_log_names_the_error_and_the_recovery(caplog):
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] == 1:
            raise httpx.ReadTimeout("", request=request)  # httpx timeouts carry no text
        return httpx.Response(200, json={"ok": True})

    client = HttpClient("https://api.test", "test", rate_per_sec=1000, backoff_base=0.001,
                        transport=httpx.MockTransport(handler))
    with caplog.at_level("INFO", logger="backend.net"):
        assert await client.get_json("/books") == {"ok": True}
    messages = [r.getMessage() for r in caplog.records]
    assert any("network error on /books (ReadTimeout)" in m for m in messages)
    assert any("GET /books succeeded after 1 retry" in m for m in messages)
    await client.aclose()


async def test_rate_limit_retry_logs_no_recovery_line(caplog):
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(429) if calls["n"] == 1 else httpx.Response(200, json={"ok": True})

    client = HttpClient("https://api.test", "test", rate_per_sec=1000, backoff_base=0.001,
                        transport=httpx.MockTransport(handler))
    with caplog.at_level("INFO", logger="backend.net"):
        assert await client.get_json("/events") == {"ok": True}
    messages = [r.getMessage() for r in caplog.records]
    assert any("HTTP 429 on /events" in m for m in messages)
    assert not any("succeeded after" in m for m in messages)  # throttling is routine: one line is enough
    await client.aclose()


async def test_polymarket_ws_logs_connects_closes_and_reconnects(settings, monkeypatch, caplog):
    import backend.adapters.polymarket as pm_module
    from backend.adapters.polymarket import PolymarketAdapter

    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    outcomes = ["fail", "ok", "fail", "ok"]  # first attempt fails, then a clean close, a failure and a reconnect
    connects = {"n": 0}

    class FakeWs:
        close_code = 1000

        async def send(self, data):
            return None

        async def close(self):
            return None

        def __aiter__(self):
            return self

        async def __anext__(self):
            if connects["n"] == len(outcomes):
                adapter._running = False  # end the test after the last connection
            raise StopAsyncIteration

    class FakeConnect:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            connects["n"] += 1
            if outcomes[connects["n"] - 1] == "fail":
                raise OSError("")  # dropped network, no message
            return FakeWs()

        async def __aexit__(self, *exc):
            return False

    monkeypatch.setattr(pm_module.websockets, "connect", FakeConnect)
    monkeypatch.setattr(pm_module, "backoff_delay", lambda *args, **kwargs: 0.0)
    adapter._running = True
    with caplog.at_level("INFO", logger="adapter.polymarket"):
        await adapter._ws_loop(0, ["t1", "t2"], adapter._ws_generation)
    messages = [r.getMessage() for r in caplog.records]
    assert messages[0] == "ws 0 error: OSError"
    # Never connected before: not a "reconnect".
    assert messages[1].startswith("ws 0 connected after ") and messages[1].endswith(" s of failed attempts")
    assert messages[2] == "ws 0 closed (code 1000), reconnecting"
    assert messages[3] == "ws 0 error: OSError"
    assert messages[4].startswith("ws 0 reconnected, no data for ")
    assert connects["n"] == 4
    await adapter.gamma.aclose()
    await adapter.clob.aclose()


async def test_kalshi_poll_logs_recovery_only_after_a_real_poll(settings, monkeypatch, caplog):
    import backend.adapters.kalshi as kalshi_module

    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    adapter.poll_sec = 0.0
    clock = {"t": 0.0}
    monkeypatch.setattr(kalshi_module, "time", SimpleNamespace(monotonic=lambda: clock["t"]))
    # (time, result): a failure, a recovery, a failure that ends with nothing to poll, a failure and a recovery.
    steps = iter([(10.0, "fail"), (12.0, True), (20.0, "fail"), (30.0, False), (40.0, "fail"), (45.0, True)])

    async def fake_poll_once():
        step = next(steps, None)
        if step is None:
            adapter._running = False
            return True
        clock["t"] = step[0]
        if step[1] == "fail":
            raise httpx.ConnectError("")
        return step[1]

    async def no_status_check():
        return None

    monkeypatch.setattr(adapter, "poll_once", fake_poll_once)
    monkeypatch.setattr(adapter, "refresh_exchange_status", no_status_check)
    adapter._running = True
    with caplog.at_level("INFO", logger="adapter.kalshi"):
        await adapter._poll_loop()
    messages = [r.getMessage() for r in caplog.records]
    assert messages.count("orderbook poll failed: ConnectError") == 3
    recovered = [m for m in messages if m.startswith("orderbook polling recovered")]
    # Measured from the last successful poll; nothing to poll ends the second outage without a line.
    assert recovered == ["orderbook polling recovered, no data for 12.0 s", "orderbook polling recovered, no data for 15.0 s"]
    await adapter.http.aclose()


async def test_scanner_logs_why_a_confirmed_arb_ended(settings, tmp_path, caplog):
    from tests.conftest import make_pair

    db = Database(tmp_path / "ended.db")
    await db.connect()
    scanner = Scanner(settings, {}, db)
    settings.engine.confirm_seconds = 0  # confirmed at first sight
    left = make_market("polymarket", "pm1", asks_a=[(0.40, 100)], asks_b=[(0.62, 100)])
    right = make_market("kalshi", "k1", asks_a=[(0.62, 80)], asks_b=[(0.50, 50)])
    scanner._merge("polymarket", [left])
    scanner._merge("kalshi", [right])
    scanner.pairs = [make_pair(left, right)]
    with caplog.at_level("INFO", logger="backend.engine.scanner"):
        await scanner.evaluate()
        assert len(scanner.active) == 1
        left.updated_at = utcnow() - timedelta(seconds=settings.engine.stale_seconds + 5)  # the feed went silent
        await scanner.evaluate()
        left.updated_at = utcnow()
        await scanner.evaluate()
        right.asks_b = [right.asks_b[0].model_copy(update={"price": 0.70})]  # the price moved away
        await scanner.evaluate()
    ended = [r.getMessage() for r in caplog.records if r.getMessage().startswith("ARB ended")]
    assert len(ended) == 2
    assert ended[0].endswith("| stale data (polymarket)")
    assert ended[1].endswith("| prices, depth or filters changed")
    await db.close()


def test_end_reason_names_the_cause(settings, tmp_path):
    from tests.conftest import make_pair

    scanner = Scanner(settings, {}, Database(tmp_path / "reason.db"))
    left = make_market("polymarket", "pm1")
    right = make_market("kalshi", "k1")
    scanner._merge("polymarket", [left])
    scanner._merge("kalshi", [right])
    pair = make_pair(left, right)
    names = {"polymarket": "Polymarket", "kalshi": "Kalshi"}
    now = utcnow()
    assert scanner._end_reason(pair.pair_key, now, names) == "pair no longer matched"
    scanner.pairs = [pair]
    assert scanner._end_reason(pair.pair_key, now, names) == "prices, depth or filters changed"
    right.accepting_orders = False
    assert scanner._end_reason(pair.pair_key, now, names) == "trading paused (Kalshi)"
    right.updated_at = now - timedelta(seconds=settings.engine.stale_seconds + 1)
    assert scanner._end_reason(pair.pair_key, now, names) == "stale data (Kalshi)"
    scanner._merge("kalshi", [])
    assert scanner._end_reason(pair.pair_key, now, names) == "market gone (Kalshi)"


async def test_arb_ended_line_has_the_legs_and_is_logged_on_shutdown(settings, tmp_path, caplog):
    from tests.conftest import make_pair

    db = Database(tmp_path / "stop.db")
    await db.connect()
    scanner = Scanner(settings, {}, db)
    settings.engine.confirm_seconds = 0
    left = make_market("polymarket", "pm1", asks_a=[(0.40, 100)], asks_b=[(0.62, 100)])
    right = make_market("kalshi", "k1", asks_a=[(0.62, 80)], asks_b=[(0.50, 50)])
    scanner._merge("polymarket", [left])
    scanner._merge("kalshi", [right])
    scanner.pairs = [make_pair(left, right)]
    with caplog.at_level("INFO", logger="backend.engine.scanner"):
        await scanner.evaluate()
        await scanner.stop()
    ended = [r.getMessage() for r in caplog.records if r.getMessage().startswith("ARB ended")]
    assert len(ended) == 1
    assert "| polymarket NIP + kalshi Liquid | lasted " in ended[0]
    assert ended[0].endswith("| scanner stopped")
    await db.close()


@pytest.mark.parametrize(
    ("use_ws", "first_ok", "line"),
    [
        # With the WebSocket, REST is only the backup: the time since its last success is not a data gap.
        (True, True, "REST book refresh recovered, last success 105.0 s ago"),
        (False, True, "REST book refresh recovered, no data for 105.0 s"),
        # The very first refresh failed: there was no earlier success to speak of.
        (True, False, "REST book refresh recovered, first success 105.0 s after start"),
        (False, False, "REST book refresh recovered, no data for 105.0 s"),
    ],
)
async def test_polymarket_rest_refresh_recovery_line(settings, monkeypatch, caplog, use_ws, first_ok, line):
    import backend.adapters.polymarket as pm_module
    from backend.adapters.polymarket import PolymarketAdapter

    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    adapter.use_ws = use_ws
    adapter.resync_sec = adapter.poll_sec = 0.0
    clock = {"t": 0.0}
    monkeypatch.setattr(pm_module, "time", SimpleNamespace(monotonic=lambda: clock["t"]))
    steps = iter([(0.0, "ok" if first_ok else "fail"), (100.0, "fail"), (104.0, "fail"), (105.0, "ok")])

    async def fake_refresh():
        step = next(steps, None)
        if step is None:
            adapter._running = False
            return
        clock["t"] = step[0]
        if step[1] == "fail":
            raise httpx.ReadTimeout("")

    monkeypatch.setattr(adapter, "_rest_refresh", fake_refresh)
    adapter._running = True
    with caplog.at_level("INFO", logger="adapter.polymarket"):
        await adapter._resync_loop()
    messages = [r.getMessage() for r in caplog.records]
    assert messages == ["REST book refresh failed: ReadTimeout"] * (2 if first_ok else 3) + [line]
    await adapter.gamma.aclose()
    await adapter.clob.aclose()


async def test_polymarket_missing_pong_log_names_the_connection(settings, caplog):
    from backend.adapters.polymarket import PolymarketAdapter, WsConn

    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    adapter.ping_interval = 0.001
    closed = {"n": 0}

    class FakeWs:
        async def close(self):
            closed["n"] += 1

        async def send(self, data):
            return None

    conn = WsConn()
    conn.last_pong = 0.0  # no PONG for a long time
    with caplog.at_level("WARNING", logger="adapter.polymarket"):
        await adapter._ping_loop(FakeWs(), conn, 3)
    assert closed["n"] == 1
    assert caplog.records[-1].getMessage().startswith("ws 3: no PONG for ")
    await adapter.gamma.aclose()
    await adapter.clob.aclose()


def test_pair_quotes_carry_the_prices_the_engine_uses(settings, tmp_path):
    from tests.conftest import make_pair

    scanner = Scanner(settings, {}, Database(tmp_path / "quotes.db"))
    left = make_market("polymarket", "pm1", asks_a=[(0.50, 100)], asks_b=[(0.62, 100)], min_order_size=5)
    right = make_market("kalshi", "k1", asks_a=[(0.62, 80)], asks_b=[(0.40, 1)], min_order_size=1)
    # Kalshi's raw top for "Liquid" is a 0.5-contract leftover at 0.40 that cannot be an order on its own.
    right.set_books(right.asks_a, [Level(price=0.40, size=0.5, instrument="YES «Liquid»"),
                                   Level(price=0.42, size=100, instrument="NO «NIP»")], None, None, utcnow())
    scanner._merge("polymarket", [left])
    scanner._merge("kalshi", [right])
    view = scanner._pair_view(make_pair(left, right), utcnow())
    quote = view["quotes"]["A"]  # buy NIP on Polymarket + Liquid on Kalshi
    assert view["right"]["ask_b"] == pytest.approx(0.40)  # the market view still shows the raw top of the book
    assert quote["right_price"] == pytest.approx(0.42) and quote["right_instrument"] == "NO «NIP»"
    assert quote["left_price"] == pytest.approx(0.50) and quote["left_instrument"] is None
    assert quote["sum_ask"] == pytest.approx(0.92)


async def test_discovery_network_failure_logs_one_line_without_traceback(settings, tmp_path, monkeypatch, caplog):
    import asyncio
    import contextlib

    import backend.engine.scanner as scanner_module

    calls = {"n": 0}

    class FakeAdapter:
        platform = "fake"
        name = "Fake"

        async def fetch_markets(self):
            calls["n"] += 1
            if calls["n"] == 1:
                raise HttpError("fake: GET /events failed: ConnectTimeout")
            if calls["n"] == 2:
                raise ValueError("unexpected bug")
            return []

        async def subscribe_prices(self, markets, on_update):
            return None

    monkeypatch.setattr(scanner_module, "backoff_delay", lambda *args, **kwargs: 0.0)
    settings.discovery.refresh_seconds = 0.01
    scanner = Scanner(settings, {"fake": FakeAdapter()}, Database(tmp_path / "disc.db"))
    with caplog.at_level("INFO", logger="backend.engine.scanner"):
        task = asyncio.create_task(scanner._discovery_loop(scanner.adapters["fake"]))
        for _ in range(200):
            await asyncio.sleep(0.01)
            if calls["n"] >= 3:
                break
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
    failed = [r for r in caplog.records if "discovery failed" in r.getMessage()]
    assert failed[0].levelname == "WARNING" and failed[0].exc_info is None  # network trouble: one line
    assert failed[0].getMessage() == "fake: discovery failed: fake: GET /events failed: ConnectTimeout (retry in 0 s)"
    assert failed[1].levelname == "ERROR" and failed[1].exc_info is not None  # a real bug keeps its traceback
    assert any(r.getMessage() == "fake: 0 markets" for r in caplog.records)


async def _run_ws_script(adapter, monkeypatch, caplog, script, link=None, start=10.0):
    """Run ``_ws_loop`` against scripted connections on a fake clock; return the log messages.

    ``script``: (result, time of the handshake or of the failure, times of the frames, time of the close).
    """
    import backend.adapters.polymarket as pm_module

    clock = {"t": start}
    monkeypatch.setattr(pm_module, "time", SimpleNamespace(monotonic=lambda: clock["t"]))
    connects = {"n": 0}

    class FakeWs:
        close_code = 1000

        def __init__(self, frames, close_at):
            self.frames, self.close_at = list(frames), close_at

        async def send(self, data):
            return None

        async def close(self):
            return None

        def __aiter__(self):
            return self

        async def __anext__(self):
            if self.frames:
                clock["t"] = self.frames.pop(0)
                return "PONG"
            clock["t"] = self.close_at
            if connects["n"] == len(script):
                adapter._running = False  # end the test after the last connection
            raise StopAsyncIteration

    class FakeConnect:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            if connects["n"] >= len(script):  # a script that ends with a failure must not loop forever
                adapter._running = False
                raise TimeoutError("script exhausted")
            result, at, frames, close_at = script[connects["n"]]
            connects["n"] += 1
            clock["t"] = at
            if result == "fail":
                raise TimeoutError("timed out during opening handshake")
            return FakeWs(frames, close_at)

        async def __aexit__(self, *exc):
            return False

    monkeypatch.setattr(pm_module.websockets, "connect", FakeConnect)
    monkeypatch.setattr(pm_module, "backoff_delay", lambda *args, **kwargs: 0.0)
    adapter._running = True
    caplog.clear()
    with caplog.at_level("INFO", logger="adapter.polymarket"):
        await adapter._ws_loop(0, ["t1", "t2"], adapter._ws_generation, link)
    return [r.getMessage() for r in caplog.records]


async def test_polymarket_ws_data_gap_counts_from_the_last_frame(settings, monkeypatch, caplog):
    from backend.adapters.polymarket import PolymarketAdapter

    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    messages = await _run_ws_script(adapter, monkeypatch, caplog, [
        ("fail", 25.0, [], None),  # the first attempt started at 10 s and timed out at 25 s
        ("ok", 40.0, [50.0], 70.0),  # one frame at 50 s, closed at 70 s
        ("ok", 100.0, [], 101.0),  # opens, sends nothing, closes
        ("ok", 130.0, [], 131.0),
    ])
    assert messages == [
        "ws 0 error: TimeoutError: timed out during opening handshake",
        "ws 0 connected after 30.0 s of failed attempts",  # from the start of the first attempt
        "ws 0 closed (code 1000), reconnecting",
        "ws 0 reconnected, no data for 50.0 s",  # since the frame at 50 s, not since the handshake at 40 s
        "ws 0 closed (code 1000), reconnecting",
        "ws 0 reconnected, no data for 80.0 s",  # the connection without frames did not reset the gap
        "ws 0 closed (code 1000), reconnecting",
    ]
    await adapter.gamma.aclose()
    await adapter.clob.aclose()


async def test_polymarket_ws_outage_survives_a_new_subscription(settings, monkeypatch, caplog):
    import asyncio

    from backend.adapters.polymarket import PolymarketAdapter, WsLink

    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    started = []

    async def fake_loop(conn_id, assets, generation, link=None):
        started.append(link)

    monkeypatch.setattr(adapter, "_ws_loop", fake_loop)
    market = make_market("polymarket", "pm1")
    market.extra.update(token_a="t1", token_b="t2")
    adapter._subscribed = {market.key: market}

    def resubscribe(tokens):  # discovery found another set of markets: new connections
        adapter.token_index = {t: (market.key, "a") for t in tokens}
        adapter._ensure_ws()

    resubscribe(["t1", "t2"])
    await asyncio.sleep(0)
    first = started[-1]
    assert (first.last_data, first.failed_since) == (None, None)
    first.last_data = 50.0  # the link is down: its last frame came at 50 s
    resubscribe(["t1", "t2", "t3"])
    await asyncio.sleep(0)
    second = started[-1]
    assert second is not first and (second.last_data, second.connected) == (50.0, False)
    second.connected, second.last_data = True, 90.0  # a link that is up: a routine re-subscription
    resubscribe(["t1", "t2", "t4"])
    await asyncio.sleep(0)
    assert started[-1].last_data is None  # no "reconnected" line for it
    await adapter.stop()

    # The successor logs the recovery with the whole gap, although its own first connection opens normally.
    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    messages = await _run_ws_script(adapter, monkeypatch, caplog, [("ok", 100.0, [], 101.0)], link=WsLink(50.0))
    assert messages[0] == "ws 0 reconnected, no data for 50.0 s"
    await adapter.gamma.aclose()
    await adapter.clob.aclose()


async def test_polymarket_ws_real_loops_hand_an_outage_over_on_resubscription(settings, monkeypatch, caplog):
    import asyncio

    import backend.adapters.polymarket as pm_module
    from backend.adapters.polymarket import PolymarketAdapter

    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    adapter.ping_interval = 1000.0  # no PONG timeouts in this test
    clock = {"t": 100.0}
    monkeypatch.setattr(pm_module, "time", SimpleNamespace(monotonic=lambda: clock["t"]))
    monkeypatch.setattr(pm_module, "backoff_delay", lambda *args, **kwargs: 0.005)
    net = {"down": False}

    class FakeWs:
        close_code = 1000

        async def send(self, data):
            return None

        async def close(self):
            return None

        def __aiter__(self):
            return self

        async def __anext__(self):
            await asyncio.sleep(0.005)
            if net["down"]:
                raise ConnectionError("network down")
            return "PONG"

    class FakeConnect:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            await asyncio.sleep(0)
            if net["down"]:
                raise OSError("network down")
            return FakeWs()

        async def __aexit__(self, *exc):
            return False

    monkeypatch.setattr(pm_module.websockets, "connect", FakeConnect)
    market = make_market("polymarket", "pm1")
    market.extra.update(token_a="t1", token_b="t2")
    adapter._subscribed = {market.key: market}
    adapter._running = True

    def resubscribe(tokens):  # discovery found another set of markets: new connections replace the old ones
        adapter.token_index = {t: (market.key, "a") for t in tokens}
        adapter._ensure_ws()

    def recovery_lines():
        return [r.getMessage() for r in caplog.records if "connected after" in r.getMessage() or "reconnected" in r.getMessage()]

    with caplog.at_level("INFO", logger="adapter.polymarket"):
        resubscribe(["t1", "t2"])
        await asyncio.sleep(0.05)  # streaming; the last frame comes at 100 s
        assert adapter._ws_links[0].connected is True
        # A routine re-subscription while the link is up: the new loop starts afresh, no recovery line.
        resubscribe(["t1", "t2", "t3"])
        await asyncio.sleep(0.05)
        assert recovery_lines() == [] and adapter._ws_links[0].connected is True
        # Outage at 150 s; a discovery at 160 s replaces the failing loop; the network is back at 200 s.
        clock["t"] = 150.0
        net["down"] = True
        await asyncio.sleep(0.05)
        assert adapter._ws_links[0].connected is False
        clock["t"] = 160.0
        resubscribe(["t1", "t2", "t4"])
        await asyncio.sleep(0.05)
        clock["t"] = 200.0
        net["down"] = False
        await asyncio.sleep(0.05)
        assert recovery_lines() == ["ws 0 reconnected, no data for 100.0 s"]  # once, by the new loop, the whole gap
        await adapter.stop()


async def test_discovery_rejected_request_logs_an_error_without_traceback(settings, tmp_path, monkeypatch, caplog):
    import asyncio
    import contextlib

    import backend.engine.scanner as scanner_module

    errors = [
        HttpError("fake: GET /events -> 404: not found", 404),  # rejected: likely an API change or our bug
        HttpError("fake: GET /events -> 429", 429),  # rate limit after all retries: temporary
        HttpError("fake: GET /events failed: ConnectError: refused"),  # network
    ]
    calls = {"n": 0}

    class FakeAdapter:
        platform = "fake"
        name = "Fake"

        async def fetch_markets(self):
            calls["n"] += 1
            if calls["n"] <= len(errors):
                raise errors[calls["n"] - 1]
            return []

        async def subscribe_prices(self, markets, on_update):
            return None

    monkeypatch.setattr(scanner_module, "backoff_delay", lambda *args, **kwargs: 0.0)
    settings.discovery.refresh_seconds = 0.01
    scanner = Scanner(settings, {"fake": FakeAdapter()}, Database(tmp_path / "rejected.db"))
    with caplog.at_level("INFO", logger="backend.engine.scanner"):
        task = asyncio.create_task(scanner._discovery_loop(scanner.adapters["fake"]))
        for _ in range(200):
            await asyncio.sleep(0.01)
            if calls["n"] > len(errors):
                break
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
    failed = [r for r in caplog.records if "discovery failed" in r.getMessage()]
    assert [(r.levelname, r.exc_info) for r in failed] == [("ERROR", None), ("WARNING", None), ("WARNING", None)]
    assert failed[0].getMessage() == "fake: discovery failed: fake: GET /events -> 404: not found (retry in 0 s)"
