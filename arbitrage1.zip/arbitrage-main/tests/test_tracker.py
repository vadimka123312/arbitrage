"""The N-second confirmation rule, resets and history records."""

import pytest

from backend.engine.tracker import ArbTracker
from backend.models import ArbLeg, ArbOpportunity
from tests.conftest import at


def opp(arb_id="pair|A", profit_pct=2.0, volume=100.0, profit_usd=2.0):
    leg = ArbLeg(platform="p", platform_name="P", market_id="m", outcome="X", ask=0.5, size=10)
    return ArbOpportunity(
        arb_id=arb_id, pair_key="pair", direction="A", game="cs2", event_title="X vs Y", team_a="X", team_b="Y",
        leg1=leg, leg2=leg, sum_ask=0.96, fees_usd=0.1, cost_per_contract=0.98, profit_pct=profit_pct,
        contracts=10, volume_usd=volume, profit_usd=profit_usd,
    )


def test_confirmed_only_after_five_seconds():
    tracker = ArbTracker(confirm_seconds=5)
    assert tracker.update([opp()], at(0)).active[0].confirmed is False
    assert tracker.update([opp()], at(4.9)).active[0].confirmed is False
    update = tracker.update([opp()], at(5.0))
    assert update.active[0].confirmed is True
    assert [t.arb_id for t in update.newly_confirmed] == ["pair|A"]
    # Not reported as "new" twice.
    assert tracker.update([opp()], at(5.5)).newly_confirmed == []


def test_disappearance_closes_and_resets_timer():
    tracker = ArbTracker(confirm_seconds=5)
    tracker.update([opp()], at(0))
    tracker.update([opp()], at(3))
    closed = tracker.update([], at(3.5)).closed
    assert len(closed) == 1
    assert closed[0].lifetime_sec == pytest.approx(3.0)
    assert closed[0].confirmed is False
    # It comes back: the timer starts again from zero.
    tracker.update([opp()], at(4))
    assert tracker.update([opp()], at(8.9)).active[0].confirmed is False
    assert tracker.update([opp()], at(9.0)).active[0].confirmed is True


def test_history_record_keeps_max_values():
    tracker = ArbTracker(confirm_seconds=5)
    tracker.update([opp(profit_pct=2.0, volume=100, profit_usd=2)], at(0))
    tracker.update([opp(profit_pct=3.5, volume=80, profit_usd=2.8)], at(3))
    tracker.update([opp(profit_pct=1.0, volume=150, profit_usd=1.5)], at(6))
    closed = tracker.update([], at(7)).closed[0]
    assert closed.lifetime_sec == pytest.approx(6.0)
    assert closed.confirmed is True
    assert closed.max_profit_pct == pytest.approx(3.5)
    assert closed.max_volume_usd == pytest.approx(150)
    assert closed.max_profit_usd == pytest.approx(2.8)
    assert closed.last.profit_pct == pytest.approx(1.0)


def test_threshold_can_change_at_runtime():
    tracker = ArbTracker(confirm_seconds=5)
    tracker.update([opp()], at(0))
    tracker.confirm_seconds = 2
    assert tracker.update([opp()], at(2.0)).active[0].confirmed is True
    tracker.confirm_seconds = 10
    assert tracker.update([opp()], at(3.0)).active[0].confirmed is False


def test_directions_are_tracked_independently():
    tracker = ArbTracker(confirm_seconds=5)
    tracker.update([opp("pair|A"), opp("pair|B")], at(0))
    update = tracker.update([opp("pair|B")], at(1))
    assert [c.arb_id for c in update.closed] == ["pair|A"]
    assert [t.arb_id for t in update.active] == ["pair|B"]


def test_close_all_on_shutdown():
    tracker = ArbTracker(confirm_seconds=5)
    tracker.update([opp()], at(0))
    assert len(tracker.close_all(at(0))) == 1
    assert tracker.active == {}
