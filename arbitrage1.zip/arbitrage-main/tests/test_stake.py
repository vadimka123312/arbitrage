"""Stake adapter on responses recorded from the live API on 2026-10-16 16:43 UTC (no network).

Recorded: the R6 fixture list, tournaments and categories, the odds of "Cloud9 - M80" (start 18:00 UTC), and the same
match on Polymarket (Gamma event) and Kalshi (event with nested markets) at the same minute.
"""

from __future__ import annotations

import copy
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import httpx
import pytest

import backend.adapters.stake as stake_module
from backend.adapters.kalshi import KalshiAdapter
from backend.adapters.polymarket import PolymarketAdapter
from backend.adapters.stake import (
    API_KEY_ENV, StakeAdapter, find_match_winner, fmt_odds, iter_markets, ms_to_dt, odds_level, parse_best_of,
)
from backend.config import PlatformConfig, PlatformFeeConfig
from backend.engine.arb import evaluate_pair, quote_direction
from backend.engine.fees import effective_fee_spec, fee_usd
from backend.engine.scanner import Scanner
from backend.matching.rules import STAKE_RULES
from backend.models import FeeSpec, utcnow
from backend.net import HttpClient, HttpError
from backend.storage.db import Database
from tests.conftest import PM_FEE, load_fixture, make_market, make_pair

SLUG = "883116-cloud9-m80"
START = datetime(2026, 10, 16, 18, 0, tzinfo=timezone.utc)
URL = "https://stake.com/sports/rainbow-six/international-16/north-america-league-2026-stage-2-t10/883116-cloud9-m80"
KALSHI_R6_META = {"title": "R6 Game", "fee_multiplier": 1, "fee_type": "quadratic"}


def recorded_api(requests: list | None = None, odds: dict | None = None):
    """Answers like the API did on 2026-10-16 (R6 lists; other games list nothing; unknown fixtures -> HTTP 500)."""
    odds = {SLUG: load_fixture("stake_fixture_cloud9_m80.json")} if odds is None else odds
    lists = {
        "/sport/rainbow-six/fixture": "stake_r6_fixture_list.json",
        "/sport/rainbow-six/tournament": "stake_r6_tournaments.json",
        "/sport/rainbow-six/category": "stake_r6_categories.json",
    }

    def handler(request: httpx.Request) -> httpx.Response:
        if requests is not None:
            requests.append(request)
        path = request.url.path
        if path in lists:
            return httpx.Response(200, json=load_fixture(lists[path]))
        if path.startswith("/sport/"):
            return httpx.Response(200, json={"sport": {}, path.rsplit("/", 1)[1]: []})
        if path.startswith("/fixtures/"):
            slug = path.removeprefix("/fixtures/")
            if slug in odds:
                return httpx.Response(200, json=odds[slug])
            return httpx.Response(500, json={"message": "error"})
        return httpx.Response(404)

    return handler


def make_adapter(settings, monkeypatch, handler) -> StakeAdapter:
    """A Stake adapter whose HTTP client talks to ``handler`` (the adapter still builds its own headers)."""
    monkeypatch.setattr(
        stake_module, "HttpClient",
        lambda *a, **kw: HttpClient(*a, transport=httpx.MockTransport(handler), backoff_base=0.001, **kw),
    )
    cfg = PlatformConfig.model_validate({**settings.platforms["stake"].model_dump(), "rate_limit_per_sec": 1000})
    return StakeAdapter("stake", cfg, settings)


def fixture_with(**changes) -> dict:
    """The recorded Cloud9 - M80 response with some fixture fields changed."""
    data = copy.deepcopy(load_fixture("stake_fixture_cloud9_m80.json"))
    data["fixture"].update(changes)
    return data


def winner_of(data: dict) -> dict:
    """The two-way market object inside ``data`` (the one the adapter reads), for in-place changes."""
    return find_match_winner(list(iter_markets(data["groups"])))


# ---- conversions and parsing ---------------------------------------------------------------------------------------


def test_odds_become_one_level_of_one_max_stake_bet():
    level = odds_level(2.5, 50, "Cloud9")
    assert level.price == pytest.approx(0.4) and level.size == pytest.approx(125)
    assert level.price * level.size == pytest.approx(50)  # the whole level is one bet of max_stake_usd
    assert level.instrument == "Ставка «Cloud9», коэф. 2,5"
    m80 = odds_level(1.42, 50, "M80")
    assert m80.price == pytest.approx(1 / 1.42) and m80.size == pytest.approx(71)
    assert odds_level("2.70", 50, "A").size == pytest.approx(135)  # numbers as strings are read too
    for odds in (None, "", 0, 1.0, 0.5, "x"):  # 0 = not offered (inactive outcome); 1.0 can never win anything
        assert odds_level(odds, 50, "A") is None
    assert odds_level(2.0, 0, "A") is None
    assert (fmt_odds(10.0), fmt_odds(1.78), fmt_odds(2.0)) == ("10", "1,78", "2")
    assert ms_to_dt(1792173600000) == START and ms_to_dt(0) is None and ms_to_dt(None) is None


@pytest.mark.parametrize("odds,max_stake", [
    (float("nan"), 50), (float("inf"), 50), (float("-inf"), 50),
    ("NaN", 50), ("Infinity", 50),
    (2.5, float("nan")), (2.5, float("inf")), (2.5, float("-inf")),
    (1e308, 50), (2.5, 1e308),
])
def test_nonfinite_odds_stakes_and_overflow_do_not_create_levels(odds, max_stake):
    """Некорректное значение не превращается в ask с NaN/Infinity; обычные формулы не меняются."""
    assert odds_level(odds, max_stake, "A") is None


def test_recorded_fixture_markets_format_and_winner():
    data = load_fixture("stake_fixture_cloud9_m80.json")
    markets = list(iter_markets(data["groups"]))
    ids = [m["id"] for m in markets]
    # Groups hold lists of market lists; the two-way market is listed in "main" and "winner" and is kept once.
    assert len(ids) == len(set(ids)) == 10
    winner = find_match_winner(markets)
    assert (winner["name"], winner["specifiers"], winner["status"]) == (
        "Match Winner - Twoway", "variant=way:two|way=two", "active")
    assert [(o["name"], o["odds"]) for o in winner["outcomes"]] == [("Cloud9", 2.7), ("M80", 1.42)]
    assert parse_best_of(markets) == 3  # from "Correct Score" (best_of=3)
    assert [m["id"] for m in iter_markets([{"name": "flat", "markets": markets}])] == ids  # the shape of the spec


def test_only_the_match_level_two_way_market_is_used():
    def market(name: str, specifiers: str, outcomes: int = 2) -> dict:
        return {"id": f"{name}|{specifiers}", "name": name, "specifiers": specifiers, "status": "active",
                "outcomes": [{"name": f"T{i}", "odds": 2.0, "active": True} for i in range(outcomes)]}

    others = [
        market("Map 1 Winner - Twoway", "map=1|variant=way:two|way=two"),
        market("Match Winner - Threeway", "variant=way:three|way=three", 3),
        market("Match Winner / Map 1 Winner", "map=1", 4),
        market("Match Winner - Twoway", "map=2|way=two"),
        market("Match Winner - Twoway", "variant=way:two|way=two", 3),
    ]
    assert find_match_winner(others) is None
    match = market("Match Winner - twoway", "variant=way:two|way=two")  # the spelling of the spec example
    assert find_match_winner(others + [match]) is match
    assert parse_best_of([{"specifiers": "map=1|best_of=3"}, {"specifiers": "threshold=2.5"}]) is None


# ---- discovery -----------------------------------------------------------------------------------------------------


async def test_discovery_on_recorded_responses(settings, monkeypatch):
    monkeypatch.delenv(API_KEY_ENV, raising=False)
    requests: list[httpx.Request] = []
    adapter = make_adapter(settings, monkeypatch, recorded_api(requests))
    markets = await adapter.fetch_markets()
    # 13 R6 fixtures are listed; only Cloud9 - M80 has recorded odds (the others answer 500 here).
    assert [m.market_id for m in markets] == [SLUG]
    m = markets[0]
    assert (m.platform, m.game, m.team_a, m.team_b, m.event_title) == ("stake", "r6", "Cloud9", "M80", "Cloud9 - M80")
    assert m.tournament == "North America League 2026 - Stage 2"
    assert m.start_time == START and m.best_of == 3 and not m.is_live and m.accepting_orders
    assert m.url == URL
    assert m.fee == FeeSpec(model="none") and m.min_order_size == 0 and m.resolution_rules == STAKE_RULES
    assert m.outcome_a_ask == pytest.approx(1 / 2.7) and m.outcome_a_ask_size == pytest.approx(135)
    assert m.outcome_b_ask == pytest.approx(1 / 1.42) and m.outcome_b_ask_size == pytest.approx(71)
    assert m.outcome_a_bid is None and m.outcome_b_bid is None
    assert m.liquidity_at_best == pytest.approx(100)  # two bets of max_stake_usd
    assert [lv.instrument for lv in m.asks_a + m.asks_b] == ["Ставка «Cloud9», коэф. 2,7", "Ставка «M80», коэф. 1,42"]
    assert m.updated_at is not None
    listing = [r for r in requests if r.url.path == "/sport/rainbow-six/fixture"]
    assert len(listing) == 1 and dict(listing[0].url.params) == {"limit": "50", "offset": "0"}
    assert all("x-api-key" not in r.headers for r in requests)
    assert adapter.status.markets == 1

    # The next discovery asks again only for the 12 fixtures without an answer; the poll loop keeps Cloud9 fresh.
    requests.clear()
    assert [m.market_id for m in await adapter.fetch_markets()] == [SLUG]
    asked = {r.url.path.removeprefix("/fixtures/") for r in requests if r.url.path.startswith("/fixtures/")}
    assert len(asked) == 12 and SLUG not in asked
    await adapter.stop()


async def test_fixture_without_a_two_way_market_is_checked_again_only_after_the_slow_interval(settings, monkeypatch):
    requests: list[httpx.Request] = []
    no_market = fixture_with()
    no_market["groups"] = []
    adapter = make_adapter(settings, monkeypatch, recorded_api(requests, {SLUG: no_market}))

    def asked() -> bool:
        found = any(r.url.path == f"/fixtures/{SLUG}" for r in requests)
        requests.clear()
        return found

    assert await adapter.fetch_markets() == [] and asked()
    assert await adapter.fetch_markets() == [] and not asked()
    adapter._fetched[SLUG] -= adapter.slow_poll_sec
    assert await adapter.fetch_markets() == [] and asked()
    await adapter.stop()


async def test_api_key_from_the_environment_is_sent_as_header(settings, monkeypatch):
    monkeypatch.setenv(API_KEY_ENV, "test-key-123")
    requests: list[httpx.Request] = []
    adapter = make_adapter(settings, monkeypatch, recorded_api(requests))
    await adapter.fetch_markets()
    assert requests and all(r.headers.get("x-api-key") == "test-key-123" for r in requests)
    await adapter.stop()


async def test_a_failing_game_list_keeps_its_last_list_and_the_other_games(settings, monkeypatch, caplog):
    down = {"rainbow-six": False, "counter-strike": True}
    base = recorded_api()

    def handler(request: httpx.Request) -> httpx.Response:
        sport = request.url.path.split("/")[2] if request.url.path.startswith("/sport/") else ""
        if down.get(sport):
            return httpx.Response(400, text="notFound")  # what the API answers for an unknown sport slug
        return base(request)

    adapter = make_adapter(settings, monkeypatch, handler)
    with caplog.at_level("INFO", logger="adapter.stake"):
        assert [m.market_id for m in await adapter.fetch_markets()] == [SLUG]  # cs2 failed, r6 still found
        down["rainbow-six"] = True  # now r6 fails too, after one good list: its last list is used
        down["counter-strike"] = False
        assert [m.market_id for m in await adapter.fetch_markets()] == [SLUG]
        down["rainbow-six"] = False
        await adapter.fetch_markets()
    messages = [r.getMessage() for r in caplog.records if r.name == "adapter.stake"]
    assert [m for m in messages if "fixture list" in m] == [
        "counter-strike: fixture list unavailable (stake: GET /sport/counter-strike/fixture -> 400: notFound), "
        "its last list is used",
        "rainbow-six: fixture list unavailable (stake: GET /sport/rainbow-six/fixture -> 400: notFound), "
        "its last list is used",
        "counter-strike: fixture list available again",
        "rainbow-six: fixture list available again",
    ]
    down.update({sport: True for sport in adapter.sport_game})  # every list fails: the discovery fails
    with pytest.raises(HttpError):
        await adapter.fetch_markets()
    await adapter.stop()


async def test_discovery_forgets_fixtures_that_are_no_longer_listed(settings, monkeypatch):
    listing = load_fixture("stake_r6_fixture_list.json")
    lists = {"/sport/rainbow-six/fixture": listing}
    base = recorded_api()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path in lists:
            return httpx.Response(200, json=lists[request.url.path])
        return base(request)

    adapter = make_adapter(settings, monkeypatch, handler)
    await adapter.fetch_markets()
    other = "883527-loud-faze"
    assert SLUG in adapter.odds and other in adapter._fetched
    adapter._failing.add(other)
    lists["/sport/rainbow-six/fixture"] = {**listing, "fixture": [f for f in listing["fixture"] if f["slug"] == SLUG]}
    await adapter.fetch_markets()
    assert set(adapter.odds) == {SLUG} and set(adapter._fetched) == {SLUG} and not adapter._failing
    await adapter.stop()


async def test_links_fall_back_to_the_sport_page_without_the_tournament_list(settings, monkeypatch, caplog):
    base = recorded_api()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/sport/rainbow-six/tournament":
            return httpx.Response(503)
        return base(request)

    adapter = make_adapter(settings, monkeypatch, handler)
    with caplog.at_level("WARNING", logger="adapter.stake"):
        market = (await adapter.fetch_markets())[0]
    assert market.url == "https://stake.com/sports/rainbow-six"
    assert any(r.getMessage().startswith("rainbow-six: tournament list unavailable") for r in caplog.records)
    await adapter.stop()


async def test_list_endpoints_are_read_page_by_page(settings, monkeypatch):
    items = [{"slug": f"{i}-a-b"} for i in range(120)]
    offsets = []

    def handler(request: httpx.Request) -> httpx.Response:
        limit, offset = int(request.url.params["limit"]), int(request.url.params["offset"])
        offsets.append(offset)
        return httpx.Response(200, json={"fixture": items[offset: offset + limit]})

    adapter = make_adapter(settings, monkeypatch, handler)
    assert [f["slug"] for f in await adapter._list("/sport/x/fixture", "fixture")] == [f["slug"] for f in items]
    assert offsets == [0, 50, 100]  # the third page is short: the last one
    offsets.clear()
    same = make_adapter(settings, monkeypatch, lambda request: httpx.Response(200, json={"fixture": items[:50]}))
    assert len(await same._list("/sport/x/fixture", "fixture")) == 50  # an ignored offset does not loop
    await adapter.stop()
    await same.stop()


async def test_the_key_never_leaves_for_another_host_and_is_never_logged(settings, monkeypatch, caplog):
    secret = "test-key-123"
    monkeypatch.setenv(API_KEY_ENV, secret)
    hosts = []

    def handler(request: httpx.Request) -> httpx.Response:
        hosts.append(request.url.host)
        if request.url.host != "odds-data.stake.com":
            return httpx.Response(200, json={})
        if request.url.path == "/sport/rainbow-six/fixture":
            return httpx.Response(302, headers={"Location": "https://collector.example/steal"})
        return httpx.Response(401, text="unauthorized")

    adapter = make_adapter(settings, monkeypatch, handler)
    with caplog.at_level("DEBUG"):
        with pytest.raises(HttpError) as exc:
            await adapter.fetch_markets()
    assert set(hosts) == {"odds-data.stake.com"}  # the redirect was not followed
    texts = [r.getMessage() for r in caplog.records] + [str(exc.value), str(adapter.status.model_dump())]
    assert not [t for t in texts if secret in t]
    await adapter.stop()


def test_discovery_window_and_status_filter(settings, monkeypatch):
    adapter = make_adapter(settings, monkeypatch, recorded_api())
    now = utcnow()
    base = {"slug": "1-a-b", "type": "match", "enabled": True, "blacklisted": False, "status": "active",
            "preMatchEnabled": True, "inPlayEnabled": True,
            "startTime": int((now + timedelta(hours=2)).timestamp() * 1000)}
    assert adapter._wanted(base, now)
    assert not adapter._wanted({**base, "status": "live"}, now)  # pre-match only by default
    adapter.include_live = True
    assert adapter._wanted({**base, "status": "live"}, now)
    assert not adapter._wanted({**base, "status": "live", "inPlayEnabled": False}, now)
    adapter.include_live = False
    for change in ({"status": "ended"}, {"status": "inactive"}, {"enabled": False}, {"blacklisted": True},
                   {"preMatchEnabled": False}, {"type": "outright"}, {"slug": ""}):
        assert not adapter._wanted({**base, **change}, now), change
    settings.discovery.horizon_hours = 1
    assert not adapter._wanted(base, now)  # starts in 2 h
    assert adapter._wanted({**base, "startTime": None}, now)  # no start time: kept


def test_live_suspended_and_closed_fixtures_take_no_bets(settings, monkeypatch):
    adapter = make_adapter(settings, monkeypatch, recorded_api())
    market = adapter.normalize({**load_fixture("stake_fixture_cloud9_m80.json"), "sport": "rainbow-six"})[0]
    assert market.accepting_orders and market.asks_a and market.asks_b

    def apply(data: dict) -> None:
        adapter._apply(market, adapter._parse(data, utcnow()))

    apply(fixture_with(status="live"))
    assert market.is_live and not market.accepting_orders and market.asks_a  # prices are shown, no arbs
    adapter.include_live = True
    apply(fixture_with(status="live"))
    assert market.accepting_orders
    adapter.include_live = False
    for changes in ({"status": "ended"}, {"status": "inactive"}, {"enabled": False}, {"blacklisted": True},
                    {"preMatchEnabled": False}):
        apply(fixture_with(**changes))
        assert not market.accepting_orders, changes
    suspended = fixture_with()
    winner_of(suspended)["status"] = "suspended"
    apply(suspended)
    assert not market.accepting_orders and market.asks_a == [] and market.asks_b == []
    one_side = fixture_with()
    winner_of(one_side)["outcomes"][1].update(active=False, odds=0)
    apply(one_side)
    assert market.accepting_orders and len(market.asks_a) == 1 and market.asks_b == []
    renamed = fixture_with()
    winner_of(renamed)["outcomes"][0]["name"] = "Cloud9 Academy"  # another opponent: another match
    apply(renamed)
    assert market.asks_a == [] and market.asks_b == [] and not market.accepting_orders  # neither side is priced
    flipped = fixture_with()
    winner_of(flipped)["outcomes"].reverse()  # the same teams in the other order: priced by name
    apply(flipped)
    assert market.accepting_orders and market.outcome_a_ask == pytest.approx(1 / 2.7)
    gone = fixture_with()
    gone["groups"] = []
    apply(gone)
    assert not market.accepting_orders and market.asks_a == [] and market.asks_b == []


def test_bo2_fixtures_and_odd_markets_are_skipped(settings, monkeypatch):
    adapter = make_adapter(settings, monkeypatch, recorded_api())
    bo2 = fixture_with()
    next(m for m in iter_markets(bo2["groups"]) if m["name"] == "Correct Score")["specifiers"] = "best_of=2|variant=best_of:2"
    assert adapter.normalize({**bo2, "sport": "rainbow-six"}) == []  # a draw would void the two-way bet
    same = fixture_with()
    winner_of(same)["outcomes"][1]["name"] = "Cloud9"
    assert adapter.normalize({**same, "sport": "rainbow-six"}) == []
    assert adapter.normalize({**fixture_with(), "sport": "dota-2-duels"}) == []  # not a configured game
    assert adapter.normalize({"groups": []}) == []
    three_way = fixture_with()  # no "Correct Score", but a match-level 1X2 market: a draw is possible
    three_way["groups"].append({"name": "threeway", "markets": [[{
        "id": "x", "name": "Match Winner - Threeway", "specifiers": "variant=way:three|way=three", "status": "active",
        "outcomes": [{"name": "Cloud9", "odds": 2.9}, {"name": "draw", "odds": 4.0}, {"name": "M80", "odds": 1.9}]}]]})
    assert adapter.normalize({**three_way, "sport": "rainbow-six"}) == []
    map_three_way = fixture_with()  # a three-way market of one map does not make a match draw possible
    map_three_way["groups"].append({"name": "maps", "markets": [[{
        "id": "y", "name": "Map 3 Winner - Threeway", "specifiers": "map=3|variant=way:three|way=three"}]]})
    assert len(adapter.normalize({**map_three_way, "sport": "rainbow-six"})) == 1


# ---- polling -------------------------------------------------------------------------------------------------------


def stake_markets(adapter: StakeAdapter, count: int) -> list:
    """``count`` subscribed-style markets made from the recorded response (slugs 1-x-y, 2-x-y, ...)."""
    return [adapter.normalize({**fixture_with(slug=f"{i}-x-y"), "sport": "rainbow-six"})[0] for i in range(1, count + 1)]


async def test_paired_fixtures_are_polled_every_pass_the_others_slowly(settings, monkeypatch):
    requests: list[httpx.Request] = []
    first = load_fixture("stake_fixture_cloud9_m80.json")
    second = fixture_with(slug="2-x-y")
    adapter = make_adapter(settings, monkeypatch, recorded_api(requests, {SLUG: first, "2-x-y": second}))
    a = adapter.normalize({**first, "sport": "rainbow-six"})[0]
    b = adapter.normalize({**second, "sport": "rainbow-six"})[0]
    updates = []
    await adapter.subscribe_prices([a, b], updates.append)  # not started: the loop itself does not run here

    def polled() -> list[str]:
        paths = sorted(r.url.path.removeprefix("/fixtures/") for r in requests)
        requests.clear()
        return paths

    old = utcnow() - timedelta(minutes=10)
    a.updated_at = old
    assert await adapter.poll_once() == (2, 0, None, False)  # before the first matching run every fixture is fast
    assert polled() == ["2-x-y", SLUG] and a.updated_at > old and {m.key for m in updates} == {a.key, b.key}
    adapter.set_paired({a.key})
    assert await adapter.poll_once() == (1, 0, None, False)
    assert polled() == [SLUG]  # b was asked a moment ago: not again before slow_poll_interval_sec
    adapter._fetched["2-x-y"] -= adapter.slow_poll_sec
    await adapter.poll_once()
    assert polled() == ["2-x-y", SLUG]
    adapter.set_paired(set())
    assert await adapter.poll_once() == (0, 0, None, False) and polled() == []
    await adapter.stop()


async def test_other_fixtures_only_get_the_requests_left_in_a_pass(settings, monkeypatch):
    adapter = make_adapter(settings, monkeypatch, recorded_api())
    adapter.rate, adapter.poll_sec = 2.0, 5.0  # 8 requests fit into a pass (80 % of 2 req/s x 5 s)
    markets = stake_markets(adapter, 12)
    await adapter.subscribe_prices(markets, lambda m: None)
    now = 1000.0
    for i, market in enumerate(markets):
        adapter._fetched[market.market_id] = now - adapter.slow_poll_sec - i  # every one is due, 12-x-y waited longest
    adapter.set_paired({markets[0].key, markets[1].key, markets[2].key})
    due = [m.market_id for m in adapter._due(now)]
    assert due[:3] == ["1-x-y", "2-x-y", "3-x-y"]  # the paired ones first
    assert due[3:] == ["12-x-y", "11-x-y", "10-x-y", "9-x-y", "8-x-y"]  # 5 others, the longest waiting first
    adapter.set_paired({m.key for m in markets[:10]})  # the paired ones need the whole pass: still one other
    assert [m.market_id for m in adapter._due(now)][10:] == ["12-x-y"]
    await adapter.stop()


async def test_each_answer_is_applied_at_once_not_at_the_end_of_the_pass(settings, monkeypatch):
    import asyncio

    release = asyncio.Event()
    fast, slow = fixture_with(slug="1-x-y"), fixture_with(slug="2-x-y")

    async def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/2-x-y"):
            await release.wait()  # a slow answer
            return httpx.Response(200, json=slow)
        return httpx.Response(200, json=fast)

    adapter = make_adapter(settings, monkeypatch, handler)
    a, b = stake_markets(adapter, 2)
    old = utcnow() - timedelta(minutes=10)
    a.updated_at = b.updated_at = old
    await adapter.subscribe_prices([a, b], lambda m: None)
    a.updated_at = b.updated_at = old
    task = asyncio.create_task(adapter.poll_once())
    for _ in range(100):
        await asyncio.sleep(0.01)
        if a.updated_at > old:
            break
    assert a.updated_at > old and b.updated_at == old and not task.done()  # a is fresh while b is still asked
    release.set()
    assert await task == (2, 0, None, False) and b.updated_at > old
    await adapter.stop()


async def test_a_failing_fixture_does_not_stop_the_others(settings, monkeypatch, caplog):
    first = load_fixture("stake_fixture_cloud9_m80.json")
    adapter = make_adapter(settings, monkeypatch, recorded_api(odds={SLUG: first}))
    a = adapter.normalize({**first, "sport": "rainbow-six"})[0]
    b = adapter.normalize({**fixture_with(slug="2-x-y"), "sport": "rainbow-six"})[0]
    b_time = b.updated_at
    await adapter.subscribe_prices([a, b], lambda m: None)
    with caplog.at_level("INFO", logger="adapter.stake"):
        answered, failed, error, limited = await adapter.poll_once()
        await adapter.poll_once()
    assert (answered, failed, limited) == (1, 1, False) and "500" in error
    assert b.updated_at == b_time  # its quote ages and turns stale; nothing is invented
    lines = [r.getMessage() for r in caplog.records if "2-x-y" in r.getMessage()]
    assert len(lines) == 1 and lines[0].startswith("no odds for 2-x-y")  # once per streak, not every pass
    await adapter.stop()


async def test_a_malformed_answer_only_affects_its_fixture(settings, monkeypatch, caplog):
    odd_value, broken = fixture_with(slug="1-x-y"), fixture_with(slug="2-x-y")
    winner_of(odd_value)["outcomes"][0]["odds"] = {"unexpected": "object"}
    winner_of(broken)["outcomes"] = "xy"  # not a list of outcomes: no usable market
    good = load_fixture("stake_fixture_cloud9_m80.json")
    adapter = make_adapter(settings, monkeypatch, recorded_api(odds={"1-x-y": odd_value, "2-x-y": broken, SLUG: good}))
    a, b = stake_markets(adapter, 2)
    c = adapter.normalize({**good, "sport": "rainbow-six"})[0]
    await adapter.subscribe_prices([a, b, c], lambda m: None)
    assert await adapter.poll_once() == (3, 0, None, False)
    assert a.asks_a == [] and len(a.asks_b) == 1  # the odd odds value is not priced, the other outcome is
    assert b.asks_a == b.asks_b == [] and not b.accepting_orders  # treated as a market that is not offered
    assert len(c.asks_a) == len(c.asks_b) == 1
    # A bug while applying one answer is that fixture's failure only.
    real_apply = adapter._apply

    def apply(market, state):
        if market.market_id == "1-x-y":
            raise RuntimeError("boom")
        real_apply(market, state)

    monkeypatch.setattr(adapter, "_apply", apply)
    c.updated_at = utcnow() - timedelta(minutes=10)
    with caplog.at_level("INFO", logger="adapter.stake"):
        assert await adapter.poll_once() == (3, 0, None, False)  # a bug, not an API failure: no outage, no backoff
        await adapter.poll_once()
    assert c.updated_at > utcnow() - timedelta(minutes=1)
    bug = [r for r in caplog.records if r.getMessage() == "could not apply the odds of 1-x-y"]
    assert len(bug) == 1 and bug[0].exc_info  # with its traceback, once
    await adapter.stop()


async def test_a_full_outage_is_one_line_and_leaves_no_fixture_marked(settings, monkeypatch, caplog):
    adapter = make_adapter(settings, monkeypatch, lambda request: httpx.Response(503))
    markets = stake_markets(adapter, 3)
    await adapter.subscribe_prices(markets, lambda m: None)
    with caplog.at_level("INFO", logger="adapter.stake"):
        assert (await adapter.poll_once())[:2] == (0, 3)
    assert not [r for r in caplog.records if r.name == "adapter.stake"] and not adapter._failing
    await adapter.stop()


async def test_poll_loop_status_lines_and_backoff(settings, monkeypatch, caplog):
    adapter = make_adapter(settings, monkeypatch, recorded_api())
    clock = {"t": 0.0}  # passes take no time; the clock moves while the loop sleeps
    monkeypatch.setattr(stake_module, "time", SimpleNamespace(monotonic=lambda: clock["t"]))
    steps = iter([  # (answered, failed, error, rate-limited)
        (0, 1, "ReadTimeout", False),  # one bad pass (a timeout): nothing changes yet
        (1, 0, None, False),           # fine again
        (1, 1, "HTTP 500", False),     # half failed (e.g. a removed fixture): not a bad pass
        (0, 3, "HTTP 503", False),     # bad
        (0, 3, "HTTP 503", False),     # bad twice in a row: down, back off 10 s
        (0, 0, None, False),           # nothing asked: still down, back off 20 s
        (1, 2, "HTTP 500", False),     # most failed: still down (the first line was enough), 40 s
        (2, 1, "HTTP 500", False),     # most answered: up again
        (3, 1, "HTTP 429", True),      # one 429: no pause
        (3, 1, "HTTP 429", True),      # a second 429 in a row: up, but back off 10 s
        (2, 0, None, False),
    ])
    seen, sleeps = [], []

    async def fake_poll_once():
        step = next(steps, None)
        if step is None:
            adapter._running = False
            return 0, 0, None, False
        seen.append((adapter.status.connected, adapter.status.error))
        return step

    async def fake_sleep(delay):
        sleeps.append(round(delay, 1))
        clock["t"] += delay

    monkeypatch.setattr(adapter, "poll_once", fake_poll_once)
    adapter._sleep = fake_sleep
    adapter._running = True
    with caplog.at_level("INFO", logger="adapter.stake"):
        await adapter._poll_loop()
    messages = [r.getMessage() for r in caplog.records if r.name == "adapter.stake"]
    assert messages == ["odds polling failed for all 3 fixtures: HTTP 503", "odds polling recovered after 80.0 s"]
    # Status seen by the next pass.
    assert seen[1] == (False, None)  # the state before the first good pass: one bad pass changes nothing
    assert seen[3] == seen[4] == (True, None)  # single bad passes do not mark Stake down
    assert seen[5] == (False, "poll: 3 of 3 failed: HTTP 503")
    assert seen[6] == (False, "poll: 3 of 3 failed: HTTP 503")  # an empty pass is no recovery
    assert seen[7] == (True, "poll: 2 of 3 failed: HTTP 500")  # some answers: connected, but not healthy
    assert seen[8] == seen[9] == seen[10] == (True, None)
    assert sleeps == [5.0, 5.0, 5.0, 5.0, 10.0, 20.0, 40.0, 5.0, 5.0, 10.0, 5.0, 5.0]
    assert adapter.status.connected and adapter.status.last_update is not None
    await adapter.stop()


async def test_a_slow_pass_is_reported_once(settings, monkeypatch, caplog):
    adapter = make_adapter(settings, monkeypatch, recorded_api())
    clock = {"t": 0.0}
    monkeypatch.setattr(stake_module, "time", SimpleNamespace(monotonic=lambda: clock["t"]))
    durations = iter([8.0, 9.0, 1.0, 8.0])

    async def fake_poll_once():
        took = next(durations, None)
        if took is None:
            adapter._running = False
            return 0, 0, None, False
        clock["t"] += took
        return 40, 0, None, False

    async def no_sleep(delay):
        return None

    monkeypatch.setattr(adapter, "poll_once", fake_poll_once)
    adapter._sleep = no_sleep
    adapter._running = True
    with caplog.at_level("INFO", logger="adapter.stake"):
        await adapter._poll_loop()
    slow = [r.getMessage() for r in caplog.records if "pass took" in r.getMessage()]
    assert slow == ["odds polling pass took 8.0 s for 40 fixtures: Stake quotes can turn stale "
                    "(raise rate_limit_per_sec or poll fewer games)"] * 2  # once per streak
    await adapter.stop()


async def test_reordered_outcomes_never_mislabel_the_odds(settings, monkeypatch, tmp_path):
    """Stake lists the outcomes the other way round: Scanner._merge keeps the book but takes the new team order."""
    data = load_fixture("stake_fixture_cloud9_m80.json")
    adapter = make_adapter(settings, monkeypatch, recorded_api())
    listing = next(f for f in load_fixture("stake_r6_fixture_list.json")["fixture"] if f["slug"] == SLUG)
    scanner = Scanner(settings, {"stake": adapter}, Database(tmp_path / "flip.db"))
    adapter.odds[SLUG] = adapter._parse(data, utcnow())
    scanner._merge("stake", [adapter._build_market(listing, "rainbow-six", "r6")])
    await adapter.subscribe_prices(list(scanner.markets["stake"].values()), lambda m: None)
    market = scanner.markets["stake"][f"stake:{SLUG}"]
    assert (market.team_a, market.outcome_a_ask) == ("Cloud9", pytest.approx(1 / 2.7))

    flipped = copy.deepcopy(data)
    winner_of(flipped)["outcomes"].reverse()
    adapter.odds[SLUG] = adapter._parse(flipped, utcnow())
    adapter._apply_subscribed(SLUG)  # the poll applies it to the scanner's market (teams still Cloud9, M80)
    scanner._merge("stake", [adapter._build_market(listing, "rainbow-six", "r6")])  # equal time: the book is kept
    assert market.team_a == "M80"
    await adapter.subscribe_prices(list(scanner.markets["stake"].values()), lambda m: None)
    assert market.outcome_a_ask == pytest.approx(1 / 1.42) and market.asks_a[0].instrument.startswith("Ставка «M80»")
    assert market.outcome_b_ask == pytest.approx(1 / 2.7) and market.asks_b[0].instrument.startswith("Ставка «Cloud9»")
    pm = make_market("polymarket", "p1", "Cloud9", "M80", asks_a=[(0.33, 100)], asks_b=[(0.68, 100)], fee=PM_FEE)
    assert evaluate_pair(make_pair(pm, market, swapped=True), pm, market, settings, utcnow()) == []  # no false arb
    await adapter.stop()


async def test_quotes_are_stamped_with_the_request_time_and_429_is_reported(settings, monkeypatch):
    import asyncio

    status = {"code": 200}

    async def handler(request: httpx.Request) -> httpx.Response:
        await asyncio.sleep(0.3)  # a slow answer
        if status["code"] == 429:
            return httpx.Response(429, json={"message": "too many requests"})
        return httpx.Response(200, json=fixture_with(slug="1-x-y"))

    adapter = make_adapter(settings, monkeypatch, handler)
    (a,) = stake_markets(adapter, 1)
    await adapter.subscribe_prices([a], lambda m: None)
    asked = utcnow()
    await adapter.poll_once()
    answered = utcnow()
    assert asked <= a.updated_at < answered - timedelta(seconds=0.25)  # not the receive time: never fresher than it is
    status["code"] = 429
    assert await adapter.poll_once() == (0, 1, "stake: GET /fixtures/1-x-y -> 429", True)
    await adapter.stop()


async def test_a_total_odds_outage_at_discovery_is_never_silent(settings, monkeypatch, caplog):
    other = "883527-loud-faze"
    base = recorded_api(odds={SLUG: load_fixture("stake_fixture_cloud9_m80.json"), other: fixture_with(slug=other)})
    blocked = {"on": True}

    def handler(request: httpx.Request) -> httpx.Response:
        if blocked["on"] and request.url.path.startswith("/fixtures/"):
            return httpx.Response(403, text="forbidden")
        return base(request)

    adapter = make_adapter(settings, monkeypatch, handler)
    with pytest.raises(HttpError) as exc:  # no odds at all: the scanner logs a failed discovery, Stake is unhealthy
        await adapter.fetch_markets()
    assert exc.value.status == 403
    blocked["on"] = False
    assert sorted(m.market_id for m in await adapter.fetch_markets()) == sorted([SLUG, other])
    blocked["on"] = True
    adapter.odds = {SLUG: adapter.odds[SLUG]}  # the other fixtures are new again, and all their requests fail
    with caplog.at_level("INFO", logger="adapter.stake"):
        assert [m.market_id for m in await adapter.fetch_markets()] == [SLUG]  # the known market stays
        await adapter.fetch_markets()
        blocked["on"] = False
        await adapter.fetch_markets()
    messages = [r.getMessage() for r in caplog.records if r.name == "adapter.stake"]
    assert len(messages) == 2 and messages[1] == "odds of new fixtures available again"
    assert messages[0].startswith("odds unavailable for all 12 new fixtures: stake: GET /fixtures/")
    assert messages[0].endswith("-> 403: forbidden")  # once, not every discovery
    await adapter.stop()


async def test_a_redirect_is_an_error_and_the_game_keeps_its_last_list(settings, monkeypatch, caplog):
    base = recorded_api()
    moved = {"on": False}

    def handler(request: httpx.Request) -> httpx.Response:
        if moved["on"] and request.url.path == "/sport/rainbow-six/fixture":
            return httpx.Response(301, headers={"Location": "https://mirror.example/fixtures"}, json={"fixture": []})
        return base(request)

    adapter = make_adapter(settings, monkeypatch, handler)
    assert [m.market_id for m in await adapter.fetch_markets()] == [SLUG]
    moved["on"] = True
    with caplog.at_level("WARNING", logger="adapter.stake"):
        assert [m.market_id for m in await adapter.fetch_markets()] == [SLUG]  # the last list, not an empty one
    assert any("redirect to mirror.example not followed" in r.getMessage() for r in caplog.records)
    await adapter.stop()


async def test_a_fixture_with_unusable_team_names_is_checked_again_later(settings, monkeypatch):
    same_names = fixture_with()
    winner_of(same_names)["outcomes"][1]["name"] = "Cloud9"
    odds = {SLUG: same_names}
    adapter = make_adapter(settings, monkeypatch, recorded_api(odds=odds))
    assert await adapter.fetch_markets() == []
    odds[SLUG] = load_fixture("stake_fixture_cloud9_m80.json")  # the feed fixes the names
    assert await adapter.fetch_markets() == []  # not asked again before slow_poll_interval_sec
    adapter._fetched[SLUG] -= adapter.slow_poll_sec
    assert [m.market_id for m in await adapter.fetch_markets()] == [SLUG]
    await adapter.stop()


async def test_a_malformed_list_answer_keeps_the_last_list(settings, monkeypatch, caplog):
    base = recorded_api()
    broken = {"on": False}

    def handler(request: httpx.Request) -> httpx.Response:
        if broken["on"] and request.url.path == "/sport/rainbow-six/fixture":
            return httpx.Response(200, json={"message": "error"})  # 200, but no fixture list
        return base(request)

    adapter = make_adapter(settings, monkeypatch, handler)
    assert [m.market_id for m in await adapter.fetch_markets()] == [SLUG]
    broken["on"] = True
    with caplog.at_level("WARNING", logger="adapter.stake"):
        assert [m.market_id for m in await adapter.fetch_markets()] == [SLUG]  # not an empty list
    assert any("no 'fixture' list" in r.getMessage() for r in caplog.records)
    await adapter.stop()


async def test_an_older_answer_never_replaces_a_newer_one(settings, monkeypatch):
    import asyncio

    first_asked = asyncio.Event()
    old_odds, new_odds = fixture_with(slug="1-x-y"), fixture_with(slug="1-x-y")
    winner_of(old_odds)["status"] = "suspended"
    calls = {"n": 0}

    async def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] == 1:  # asked first, answers last (e.g. a discovery request next to a poll)
            first_asked.set()
            await asyncio.sleep(0.2)
            return httpx.Response(200, json=old_odds)
        return httpx.Response(200, json=new_odds)

    adapter = make_adapter(settings, monkeypatch, handler)
    slow = asyncio.create_task(adapter._fetch("1-x-y"))
    await first_asked.wait()
    await asyncio.sleep(0.01)
    await adapter._fetch("1-x-y")
    newer = adapter.odds["1-x-y"]
    await slow
    assert adapter.odds["1-x-y"] is newer and adapter.odds["1-x-y"].market["status"] == "active"
    await adapter.stop()


async def test_no_markets_at_all_is_still_a_healthy_stake(settings, monkeypatch):
    adapter = make_adapter(settings, monkeypatch, recorded_api())
    await adapter.subscribe_prices([], lambda m: None)  # discovery worked, nothing is open on Stake right now

    async def stop_after_one_pass(delay):
        adapter._running = False

    adapter._sleep = stop_after_one_pass
    adapter._running = True
    await adapter._poll_loop()
    assert adapter.status.connected and adapter.status.last_update is not None and adapter.status.error is None
    await adapter.stop()


# ---- fees and arbitrage maths with a Stake leg ---------------------------------------------------------------------


def test_stake_has_no_fee(settings):
    cfg = settings.fees.for_platform("stake")
    assert cfg.taker_rate is None and cfg.extra_cost_per_contract == 0 and cfg.fixed_cost_per_trade_usd == 0
    spec = effective_fee_spec(FeeSpec(model="none"), cfg)
    assert spec.model == "none" and fee_usd(spec, 0.4, 125) == 0
    # A number in fees.stake.taker_rate would switch on the Polymarket formula (the config comment says so).
    assert effective_fee_spec(FeeSpec(model="none"), PlatformFeeConfig(taker_rate=0.02)).model == "polymarket"


def test_arb_with_a_stake_leg_is_one_bet_of_max_stake_and_only_the_exchange_pays_fees(settings):
    stake = make_market("stake", "s1", "NIP", "Liquid", fee=FeeSpec(model="none"))
    stake.set_books([odds_level(2.5, 50, "NIP")], [odds_level(1.5, 50, "Liquid")], None, None, utcnow())
    pm = make_market("polymarket", "p1", "NIP", "Liquid", asks_a=[(0.62, 300)], asks_b=[(0.55, 200)], fee=PM_FEE)
    arbs = evaluate_pair(make_pair(pm, stake), pm, stake, settings, utcnow())
    # A: NIP on Polymarket 0.62 + Liquid on Stake 1/1.5 = 1.287 (no arb); B: Liquid 0.55 + NIP on Stake 1/2.5 = 0.95.
    assert [a.direction for a in arbs] == ["B"]
    arb = arbs[0]
    pm_fee = round(125 * 0.05 * 0.55 * 0.45, 5)  # Polymarket taker fee for 125 shares at 0.55
    assert arb.contracts == 125  # the Stake level: one bet of $50 at 2.5 pays $125
    assert arb.leg2.platform == "stake" and arb.leg2.fee_usd == 0 and arb.leg2.ask == pytest.approx(0.4)
    assert arb.leg2.instrument == "Ставка «NIP», коэф. 2,5"
    assert arb.fees_usd == pytest.approx(pm_fee, abs=1e-4)
    assert arb.volume_usd == pytest.approx(round(125 * 0.55 + 50 + pm_fee, 2))
    assert arb.profit_usd == pytest.approx(round(125 - (125 * 0.55 + 50 + pm_fee), 2))
    assert arb.sum_ask == pytest.approx(0.95)
    # The same pair in walk-book mode: the single Stake level limits the volume in the same way.
    settings.engine.depth_mode = "walk_book"
    assert evaluate_pair(make_pair(pm, stake), pm, stake, settings, utcnow())[0].contracts == 125


# ---- matching on three venues (recorded) ---------------------------------------------------------------------------


def three_venues(settings, monkeypatch, tmp_path):
    """A scanner holding the recorded Cloud9 - M80 market of each venue (not matched yet)."""
    pm = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    ks = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    st = make_adapter(settings, monkeypatch, recorded_api())
    listing = next(f for f in load_fixture("stake_r6_fixture_list.json")["fixture"] if f["slug"] == SLUG)
    st.odds[SLUG] = st._parse(load_fixture("stake_fixture_cloud9_m80.json"), utcnow())
    markets = {
        "polymarket": pm._normalize_event(load_fixture("polymarket_event_cloud9_m80.json"), "r6")[0],
        "kalshi": ks._normalize_event(load_fixture("kalshi_event_cloud9_m80.json"), "r6", "KXR6GAME", KALSHI_R6_META)[0],
        "stake": st._build_market(listing, "rainbow-six", "r6"),
    }
    scanner = Scanner(settings, {"polymarket": pm, "kalshi": ks, "stake": st}, Database(tmp_path / "three.db"))
    for market in markets.values():
        scanner.markets[market.platform][market.key] = market
    return scanner, markets


def test_scanner_pairs_stake_with_polymarket_and_kalshi_without_engine_changes(settings, monkeypatch, tmp_path):
    scanner, markets = three_venues(settings, monkeypatch, tmp_path)
    assert {p: (m.team_a, m.team_b, m.start_time) for p, m in markets.items()} == {
        "polymarket": ("Cloud9", "M80", START), "kalshi": ("Cloud9", "M80", START), "stake": ("Cloud9", "M80", START)}
    scanner.rematch()
    pairs = {(p.left_platform, p.right_platform): p for p in scanner.pairs}
    assert set(pairs) == {("polymarket", "kalshi"), ("polymarket", "stake"), ("kalshi", "stake")}
    assert not scanner.review and not scanner.blocked
    pm_stake, kalshi_stake = pairs[("polymarket", "stake")], pairs[("kalshi", "stake")]
    assert (pm_stake.status, pm_stake.confidence, pm_stake.swapped, pm_stake.format_check) == ("auto", 100.0, False, "match")
    # Kalshi publishes no best-of format: the same score as for Polymarket <-> Kalshi pairs.
    assert (kalshi_stake.status, kalshi_stake.confidence, kalshi_stake.format_check) == ("auto", 95.0, "unknown")
    severities = {w.field: w.severity for w in pm_stake.warnings}
    assert severities == {"cancel": "high", "postpone_window_hours": "medium", "postpone_fallback": "medium",
                          "forfeit_before_start": "high", "forfeit_after_start": "medium", "tie": "high"}
    assert {w.field: w.severity for w in kalshi_stake.warnings}["tie"] == "info"  # Kalshi has no tie clause
    # Polling hint: the Stake adapter learns which of its markets are paired; one match on three venues counts once.
    assert scanner.adapters["stake"]._paired == {markets["stake"].key}
    assert scanner.snapshot()["counts"]["matches"] == 1

    # Recorded prices: Kalshi top of book (YES Cloud9 0.33, YES M80 0.70; NO M80 = 1 - 0.68) and Stake 2.7 / 1.42.
    quote = quote_direction(kalshi_stake, markets["kalshi"], markets["stake"], "A", settings)
    assert quote.fills1[0][0] == pytest.approx(0.32) and quote.fills1[0][2] == "NO «M80»"
    assert quote.fills2[0][0] == pytest.approx(1 / 1.42)
    assert quote.profit < 0  # 0.32 + 0.704 + fee > 1: no arb at 16:43 UTC


def test_a_broken_polling_hint_never_stops_matching(settings, monkeypatch, tmp_path, caplog):
    scanner, markets = three_venues(settings, monkeypatch, tmp_path)

    def broken(keys):
        raise RuntimeError("boom")

    monkeypatch.setattr(scanner.adapters["kalshi"], "set_paired", broken)
    scanner.rematch()
    assert len(scanner.pairs) == 3 and scanner.adapters["stake"]._paired == {markets["stake"].key}
    assert any("kalshi: set_paired failed" in r.getMessage() for r in caplog.records)


def test_match_counter_counts_a_match_once_on_any_number_of_venues(settings, tmp_path):
    scanner = Scanner(settings, {}, Database(tmp_path / "count.db"))
    one = [make_market(p, f"{p}-1") for p in ("polymarket", "kalshi", "stake")]
    two = [make_market(p, f"{p}-2", team_a="G2", team_b="FaZe") for p in ("polymarket", "kalshi")]
    lone = make_market("stake", "stake-3", team_a="OG", team_b="Spirit")
    for market in (*one, *two, lone):
        scanner.markets.setdefault(market.platform, {})[market.key] = market
    scanner.pairs = [make_pair(one[0], one[1]), make_pair(one[0], one[2]), make_pair(one[1], one[2]),
                     make_pair(two[0], two[1])]
    assert scanner._match_count() == 3  # the triangle, the two-venue pair and the market on one venue
    scanner.pairs.append(make_pair(one[0], make_market("kalshi", "gone")))  # a market removed before the next match run
    assert scanner._match_count() == 3


def test_mock_bookmaker_quotes_like_the_real_adapter(settings):
    from backend.adapters import apply_mock_mode, build_adapters
    from backend.adapters.mock import MockWorld

    mock = apply_mock_mode(settings)
    adapter = build_adapters(mock)["stake"]
    adapter.world = MockWorld(seed=1, arb_rate_per_min=0, tick_ms=500)
    market = adapter.normalize(adapter.world.matches[0])[0]
    assert market.fee.model == "none" and market.resolution_rules == STAKE_RULES and market.outcome_a_bid is None
    for asks in (market.asks_a, market.asks_b):
        assert len(asks) == 1
        level = asks[0]
        odds = round(1 / level.price, 2)
        assert level.size == pytest.approx(50 * odds) and level.instrument.endswith(f"коэф. {fmt_odds(odds)}")
    games = {spec_game for m in adapter.world.matches for spec_game in [m.spec["game"]] if adapter.normalize(m)}
    assert "mlbb" not in games and games <= set(settings.platforms["stake"].games)  # only the games Stake has
