"""Диагностика BC.Game: только синтетический MockTransport, без .env и сети."""

from __future__ import annotations

import argparse
import asyncio
from datetime import datetime, timedelta, timezone
import gzip
import json
import logging
import os
import stat
import time

import httpx
import pytest

from backend.adapters import bcgame
from backend.adapters.bcgame import BcGameAdapter, FeedState, PROXY_ENV
from backend import config
from backend.config import PlatformConfig, Settings
from backend.engine.arb import is_fresh
from backend.net import HttpError
from backend.storage.db import Database
from tools import bcgame_observation_report as report
from tools import bcgame_observe as observe

NOW = datetime(2026, 10, 19, 15, tzinfo=timezone.utc)
PUBLIC_GENERATED = int((NOW - timedelta(seconds=2)).timestamp() * 1000)


@pytest.fixture(autouse=True)
def offline_only(monkeypatch):
    """Не читаем настоящий proxy env/.env; случайный живой запрос сразу ломает тест."""
    getenv = os.getenv
    monkeypatch.setattr(os, "getenv", lambda name, default=None: default if name == PROXY_ENV else getenv(name, default))

    def forbidden_dotenv():
        raise AssertionError("Tests must not read .env")

    async def forbidden_network(*args, **kwargs):
        raise AssertionError("Tests must use MockTransport")

    monkeypatch.setattr(config, "_load_dotenv", forbidden_dotenv)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden_network)
    monkeypatch.setattr(bcgame, "utcnow", lambda: NOW)
    monkeypatch.setattr(observe, "mark", lambda: {"utc": NOW.isoformat(), "mono_ns": time.monotonic_ns()})


def settings():
    cfg = PlatformConfig(adapter="backend.adapters.bcgame:BcGameAdapter", name="BC.Game", enabled=False,
                         games={"cs2": {"sport_slugs": ["counter-strike"]}}, rate_limit_per_sec=10000)
    return Settings(platforms={"bcgame": cfg}, games={"cs2": {"name": "Counter-Strike"}},
                    capture={"enabled": False}, paper={"enabled": False}, engine={"eval_interval_ms": 50})


def payload():
    return {"epoch": 17, "version": 501, "generated": PUBLIC_GENERATED, "snapshot_complete": True,
            "sports": {"1": {"slug": "counter-strike"}}, "categories": {}, "tournaments": {},
            "events": {"101": {"desc": {"type": "match", "sport": "1", "scheduled": (NOW + timedelta(hours=1)).timestamp(),
                                         "competitors": [{"name": "Alpha"}, {"name": "Beta"}]},
                                "state": {"status": 0}, "markets": {"186": {"": {"4": {"k": "2.0"}, "5": {"k": "1.9"}}}}}}}


def feed_handler(request):
    version = request.url.path.rsplit("/", 1)[-1]
    common = {"epoch": 17, "generated": PUBLIC_GENERATED}
    if version == "0":
        data = {**common, "version": 100, "top_events_versions": [101], "rest_events_versions": []}
    elif version == "101":
        data = payload()
    else:
        data = {**common, "version": 502, "events": {}}
    return httpx.Response(200, json=data)


async def install_transport(adapter, handler=feed_handler):
    await adapter.http.aclose()
    adapter.http = httpx.AsyncClient(base_url=adapter.api_url, timeout=adapter.http.timeout,
                                     transport=httpx.MockTransport(handler), follow_redirects=False, trust_env=False)
    if isinstance(adapter, observe.ObservationAdapter):
        adapter._attach_http_hooks()


@pytest.fixture
async def observed(tmp_path):
    s = settings()
    journal = observe.Journal(tmp_path / "capture", capture_packets=True)
    adapter = observe.ObservationAdapter("bcgame", s.platforms["bcgame"], s, journal=journal)
    await install_transport(adapter)
    yield adapter, journal, s
    await adapter.stop()
    journal.close()


def rows(journal):
    return [json.loads(line) for line in (journal.root / "events.jsonl").read_text(encoding="utf-8").splitlines()]


def at(ms=0):
    return {"utc": (NOW + timedelta(milliseconds=ms)).isoformat(), "mono_ns": 1_000_000_000 + int(ms * 1e6)}


def event(stage, ms=0, **values):
    return {"stage": stage, **at(ms), **values}


def write_rows(root, records):
    root.mkdir()
    (root / "events.jsonl").write_text("".join(json.dumps(r) + "\n" for r in records), encoding="utf-8")
    return root


def completed_checks(checks):
    return [event("run_started", stale_seconds=10), event("snapshot_accepted", 1, started=at()),
            event("normalized", 2, market="bcgame:101", duration_ms=.1), *checks,
            event("run_finished", 100, outcome="completed")]


def check(ms=10, age=2, **values):
    return event("engine_check", ms, market="bcgame:101", updated_at=(NOW - timedelta(seconds=age)).isoformat(),
                 age_sec=age, nonempty=True, fresh=True, **values)


def args(root, **changes):
    values = dict(output=root, allow_live_observe=True, duration=.15, fault_at=None, fault_duration=.01,
                  capture_packets=False, config=None, label="offline-test")
    return argparse.Namespace(**(values | changes))


def test_summary_percentiles_and_monotonic_units():
    assert report.summary([None, float("nan"), float("inf"), True]) == {"n": 0}
    assert report.summary([0, 10]) == {"n": 2, "median": 5, "p95": 9.5, "max": 10, "min": 0}
    assert report.elapsed_ms({"mono_ns": 10, "utc": "2099-01-01"}, {"mono_ns": 2_000_010, "utc": "1999-01-01"}) == 2
    assert report.elapsed_ms({"mono_ns": 10}, {"mono_ns": 9}) is None
    assert report.source_time(PUBLIC_GENERATED) == NOW - timedelta(seconds=2)
    assert report.dt("2026-10-19T15:00:00") is None


def test_unknown_timestamps_remain_blocked_in_denominators(tmp_path):
    fresh = check()
    stale = check(20, age=20)
    stale["fresh"] = False
    unknown = {**check(30), "updated_at": None, "age_sec": None, "fresh": False}
    empty = {**check(40), "nonempty": False, "updated_at": None, "age_sec": None, "fresh": False}
    result = report.analyze(write_rows(tmp_path / "report", completed_checks([fresh, stale, unknown, empty])))
    assert result["age_at_engine_sec"] == {"n": 2, "median": 11, "p95": 19.1, "min": 2, "max": 20}
    assert result["fresh_share"] == result["stale_share"] == result["unknown_share"] == pytest.approx(1 / 3)
    assert result["blocked_share"] == .75
    assert result["engine_samples"]["unknown_timestamp"] == 2
    assert result["engine_samples"]["unknown_timestamp_nonempty"] == 1
    assert result["engine_samples"]["empty"] == 1
    assert result["validation"]["ok"]
    assert result["timestamp_semantics"]["individual_quote_change_time"] == "unknown"


@pytest.mark.parametrize("kind", ["empty", "undated", "no_samples", "interrupted"])
def test_empty_or_undated_or_incomplete_is_not_success(tmp_path, kind):
    row = check()
    if kind == "empty":
        row["nonempty"] = False
    elif kind == "undated":
        row.update(updated_at=None, age_sec=None, fresh=False)
    records = completed_checks([] if kind == "no_samples" else [row])
    if kind == "interrupted":
        records[-1]["outcome"] = "interrupted"
    root = write_rows(tmp_path / kind, records)
    assert not report.analyze(root)["validation"]["ok"]
    assert report.main([str(root)]) == 2


def test_legacy_http_marks_keep_units_source_age_and_raw_timestamps(tmp_path):
    generated = int((NOW + timedelta(seconds=4)).timestamp() * 1000)
    http = event("http", 5001, request_id=1, channel="prematch", phase="delta", requested_version="501",
                 response={"generated": generated, "epoch": 17, "version": 502}, asked_at=NOW.isoformat(),
                 enqueued=at(), semaphore_acquired=at(100), token_acquired=at(200), headers_received=at(4200),
                 body_received=at(5000), parse_started=at(5000), parse_finished=at(5001), has_index_marker=False)
    result = report.analyze(write_rows(tmp_path / "legacy", completed_checks([http, check()])))
    durations = result["durations"]
    assert durations["http_ms"]["median"] == 4800
    assert durations["body_ms"]["median"] == 800
    assert durations["parse_ms"]["median"] == 1
    assert durations["source_age_at_body_sec"]["median"] == 1
    assert durations["request_start_clamp_would_lose_sec"]["median"] == 4
    assert result["delta_requests"] == 1 and result["index_markers_in_delta"] == 0
    assert set(result["measurement_boundaries"]["engine_book_timings"].values()) == {"not_measured"}
    assert result["engine_tick_coverage"]["zero_market_ticks"] is None


def test_legacy_optional_packets_count_deletes_suspends_resets(tmp_path):
    root = write_rows(tmp_path / "legacy-packets", completed_checks([
        event("http", 3, request_id=1, phase="delta", requested_version="501", response={},
              has_index_marker=True), check()]))
    body = {"events": {"1": None, "2": {"shouldResetEvent": True, "markets": {"186": {"": {
        "4": None, "5": {"b": 1}}}}}}}
    (root / "packet-000001.json.gz").write_bytes(gzip.compress(json.dumps(body).encode()))
    result = report.analyze(root)
    assert result["counts"]["event_deletes"] == 1
    assert result["counts"]["winner_deletes"] == 1
    assert result["counts"]["winner_suspends"] == 1
    assert result["counts"]["event_resets"] == 1
    assert result["counts"]["null_deletes"] == 2
    assert result["index_markers_in_delta"] == 1


def test_journal_is_private_exclusive_and_packets_are_opt_in(tmp_path, capsys):
    journal = observe.Journal(tmp_path / "private")
    journal.emit("run_started")
    journal.capture(1, payload())
    assert not list(journal.root.glob("*.gz"))
    secret = "synthetic-user:synthetic-password@proxy.invalid"
    original = logging.getLogger().handlers[:]
    with observe.private_logging(journal):
        try:
            raise RuntimeError(secret)
        except RuntimeError:
            logging.getLogger("httpx").exception("never log %s", secret)
    journal.close()
    assert logging.getLogger().handlers == original
    text = (journal.root / "events.jsonl").read_text()
    assert "RuntimeError" in text and secret not in text
    assert not capsys.readouterr().err
    if os.name != "nt":
        assert stat.S_IMODE(journal.root.stat().st_mode) == 0o700
        assert stat.S_IMODE((journal.root / "events.jsonl").stat().st_mode) == 0o600
    with pytest.raises(FileExistsError):
        observe.Journal(journal.root)
    report.write_summary(journal.root / "summary.json", {"ok": False})
    with pytest.raises(FileExistsError):
        report.write_summary(journal.root / "summary.json", {})


async def test_real_get_instrumentation_captures_only_public_body_and_headers(observed):
    adapter, journal, _ = observed
    requests = []

    class Chunks(httpx.AsyncByteStream):
        async def __aiter__(self):
            body = json.dumps(payload()).encode()
            yield body[:50]
            yield body[50:]

    def handler(request):
        requests.append(request)
        return httpx.Response(200, stream=Chunks(), headers={"date": "Mon, 19 Oct 2026 15:00:00 GMT",
                                                           "set-cookie": "private=value", "location": "secret-url"})

    await install_transport(adapter, handler)
    data, asked = await adapter._get("prematch", "101")
    assert data == payload() and asked == NOW
    row = next(r for r in rows(journal) if r["stage"] == "http")
    stages = ("enqueued", "semaphore_wait_started", "semaphore_acquired", "rate_wait_started", "token_acquired",
              "http_started", "headers_received", "body_received", "parse_started", "parse_finished", "parent_returned")
    assert [row[k]["mono_ns"] for k in stages] == sorted(row[k]["mono_ns"] for k in stages)
    assert all(report.dt(row[k]["utc"]).utcoffset() == timedelta(0) for k in stages)
    assert row["headers"] == {"date": "Mon, 19 Oct 2026 15:00:00 GMT"}
    assert row["response"]["generated"] == PUBLIC_GENERATED
    assert requests[0].method == "GET" and not requests[0].headers.get("Authorization")
    assert not requests[0].headers.get("Cookie")
    packet = journal.root / "packet-000001.json.gz"
    assert json.loads(gzip.decompress(packet.read_bytes())) == data
    assert "private=value" not in (journal.root / "events.jsonl").read_text()
    if os.name != "nt":
        assert stat.S_IMODE(packet.stat().st_mode) == 0o600


async def test_network_errors_log_type_not_credentialed_message(observed):
    adapter, journal, _ = observed
    secret = "synthetic-user:synthetic-password@proxy.invalid"

    def handler(request):
        raise httpx.ProxyError(secret)

    await install_transport(adapter, handler)
    with pytest.raises(HttpError):
        await adapter._get("prematch", "501")
    text = (journal.root / "events.jsonl").read_text()
    assert secret not in text and "HttpError" in text
    assert not list(journal.root.glob("*.gz"))
    assert adapter.failures == 1 and observe.CURRENT.get() is None


@pytest.mark.parametrize("status", [401, 403, 429])
async def test_observer_preserves_access_and_retry_guards(observed, status):
    adapter, journal, _ = observed
    requests = []

    def handler(request):
        requests.append(request)
        return httpx.Response(status, headers={"Retry-After": "60"})

    await install_transport(adapter, handler)
    for _ in range(2):
        with pytest.raises(HttpError) as error:
            await adapter._get("prematch", "501")
        assert error.value.status == status
    assert len(requests) == 1
    assert sum(r["stage"] == "http_error" for r in rows(journal)) == 2


async def test_merge_wrapper_is_scoped_and_does_not_change_adapter_results(observed):
    adapter, journal, s = observed
    native = BcGameAdapter("bcgame", s.platforms["bcgame"], s)
    await install_transport(native)
    merge = bcgame.merge_payload
    try:
        expected = await native.fetch_markets()
        with observe.observe_merges(adapter):
            assert bcgame.merge_payload({}, {"events": {}}) == {"sports": {}, "categories": {}, "tournaments": {}, "events": {}}
            assert not any(r["stage"] == "merged" for r in rows(journal))
            actual = await adapter.fetch_markets()
        assert [m.model_dump() for m in actual] == [m.model_dump() for m in expected]
        merged = [r for r in rows(journal) if r["stage"] == "merged"]
        assert len(merged) == 1 and merged[0]["request_id"] == 2
        assert len(merged[0]["winner_initialized"]) == 2
        assert bcgame.merge_payload is merge and observe.MERGING.get() is None
        with pytest.raises(RuntimeError), observe.observe_merges(adapter):
            raise RuntimeError("test restore")
        assert bcgame.merge_payload is merge
    finally:
        await native.stop()


async def test_snapshot_override_forwards_optional_previous_and_future_kwargs(observed, monkeypatch):
    adapter, _, _ = observed
    previous, result = FeedState(), FeedState(version="501")
    calls = []

    async def snapshot(self, channel, *args, **kwargs):
        calls.append((channel, args, kwargs))
        return result

    monkeypatch.setattr(BcGameAdapter, "_snapshot", snapshot)
    assert await adapter._snapshot("prematch", previous, diagnostic_test=True) is result
    assert calls == [("prematch", (previous,), {"diagnostic_test": True})]
    assert observe.MERGING.get() is None and adapter.phase.get() == "delta"


async def test_scanner_records_real_freshness_optional_provenance_and_no_pairs(observed):
    adapter, journal, s = observed
    with observe.observe_merges(adapter):
        markets = await adapter.fetch_markets()
    scanner = observe.ProbeScanner(s, {"bcgame": adapter}, Database(journal.root / "unused.db"), journal=journal)
    scanner._merge("bcgame", markets)
    market = markets[0]
    original_stamp = market.updated_at
    adapter._subscribed = {market.key: market}
    scanner.rematch()
    adapter._callback = scanner._on_price
    adapter.notify(market)
    await scanner.evaluate()
    market.updated_at = None
    market.extra.update(bcgame_quote_times={"4": None, "5": None},
                        timestamp_kind="source_message_of_last_observed_quote_change", actual_price_change_at=None)
    await scanner.evaluate()
    checks = [r for r in rows(journal) if r["stage"] == "engine_check"]
    assert checks[0]["fresh"] == is_fresh(market.model_copy(update={"updated_at": original_stamp}), NOW, s.engine.stale_seconds)
    assert checks[1]["fresh"] is False and checks[1]["age_sec"] is None and checks[1]["nonempty"]
    assert checks[1]["bcgame_quote_times"] == {"4": None, "5": None}
    assert checks[1]["actual_price_change_at"] is None
    assert adapter._paired == {market.key} and scanner.pairs == scanner.active == []
    assert s.platforms["bcgame"].enabled is False and s.engine.stale_seconds == 10
    with pytest.raises(ValueError):
        observe.ProbeScanner(s, {"bcgame": adapter, "fake": adapter}, scanner.db, journal=journal)


async def test_fault_really_closes_client_reopens_same_config_and_waits_for_install(observed, monkeypatch):
    adapter, journal, _ = observed
    markets = await adapter.fetch_markets()
    old_http, old_clock = adapter.http, markets[0].updated_at
    native_client = httpx.AsyncClient
    created = []

    def factory(**options):
        created.append(options.copy())
        return native_client(**options, transport=httpx.MockTransport(feed_handler))

    async def pause(seconds):
        assert old_http.is_closed and adapter.fault_active
        with pytest.raises(HttpError, match="client closed"):
            await adapter._get("prematch", "501")
        assert markets[0].updated_at == old_clock

    monkeypatch.setattr(httpx, "AsyncClient", factory)
    monkeypatch.setattr(observe.asyncio, "sleep", pause)
    # Изменение env не должно заменить зафиксированный маршрут после сбоя.
    getenv = os.getenv
    monkeypatch.setattr(os, "getenv", lambda name, default=None: "do-not-use-new-proxy" if name == PROXY_ENV else getenv(name, default))
    await adapter.inject_fault(.01)
    assert old_http.is_closed and not adapter.http.is_closed and adapter.generation == 1
    assert created == [adapter._http_options]
    assert created[0]["proxy"] is None and created[0]["trust_env"] is False and created[0]["follow_redirects"] is False
    assert adapter.http.base_url == old_http.base_url and adapter.http.timeout == old_http.timeout
    assert not any(r["stage"] == "fault_recovered" for r in rows(journal))
    await adapter._sync()
    await adapter._sync()
    records = rows(journal)
    assert sum(r["stage"] == "fault_injected" for r in records) == 1
    assert sum(r["stage"] == "fault_transport_reopened" for r in records) == 1
    assert sum(r["stage"] == "fault_recovered" for r in records) == 1
    error = next(r for r in records if r["stage"] == "http_error")
    assert error["injected"] and error["fault_id"] == 1
    assert error["in_fault_window"] and error["fault_error_basis"] == "fault_closed_client"
    recovered = next(r for r in records if r["stage"] == "fault_recovered")
    assert recovered["transport_generation"] == 1
    assert adapter._market("101", adapter.feeds["prematch"], "prematch").updated_at == old_clock


async def test_fault_cancellation_does_not_claim_recovery(observed, monkeypatch):
    adapter, journal, _ = observed
    closed = asyncio.Event()

    async def pause(seconds):
        closed.set()
        await asyncio.Event().wait()

    monkeypatch.setattr(observe.asyncio, "sleep", pause)
    task = asyncio.create_task(adapter.inject_fault(15))
    await closed.wait()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    journal.emit("run_started", fault_at_sec=0)
    journal.emit("run_finished", outcome="completed")
    result = report.analyze(journal.root)
    assert adapter.http.is_closed
    assert result["faults"]["injected"] == result["faults"]["cancelled"] == 1
    assert result["faults"]["recovered"] == result["faults"]["transport_reopened"] == 0
    assert "controlled_fault_not_recovered" in result["validation"]["reasons"]


async def test_malformed_post_fault_packet_is_not_recovery(observed, monkeypatch):
    adapter, journal, _ = observed
    await adapter.fetch_markets()

    async def pause(seconds):
        return None

    monkeypatch.setattr(observe.asyncio, "sleep", pause)
    def malformed_client():
        return httpx.AsyncClient(base_url=adapter.api_url, trust_env=False, transport=httpx.MockTransport(
            lambda request: httpx.Response(200, json={"epoch": 17, "version": 502})))

    monkeypatch.setattr(adapter, "_new_http", malformed_client)
    await adapter.inject_fault(.01)
    with pytest.raises(ValueError):
        await adapter._sync()
    assert not adapter.fault.get("recovered")
    assert not any(r["stage"] == "fault_recovered" for r in rows(journal))


@pytest.mark.parametrize("changes", [{"allow_live_observe": False}, {"duration": 0}, {"duration": float("nan")},
                                     {"duration": float("inf")}, {"fault_at": -1}, {"fault_at": float("nan")},
                                     {"fault_at": .14, "fault_duration": .02}, {"fault_duration": 0}])
async def test_invalid_args_or_missing_consent_stop_before_settings_or_output(tmp_path, monkeypatch, changes):
    def forbidden(*args, **kwargs):
        raise AssertionError("Settings must not load before consent/validation")

    monkeypatch.setattr(observe, "load_settings", forbidden)
    root = tmp_path / "not-created"
    with pytest.raises(ValueError):
        await observe.run(args(root, **changes))
    assert not root.exists()


def test_cli_requires_consent_and_defaults_to_30_minutes(tmp_path, monkeypatch, capsys):
    with pytest.raises(SystemExit) as stopped:
        observe.main(["--output", str(tmp_path / "blocked")])
    assert stopped.value.code == 2 and not (tmp_path / "blocked").exists()
    captured = []

    async def fake_run(arguments):
        captured.append(arguments)
        return {"validation": {"ok": False}}

    monkeypatch.setattr(observe, "run", fake_run)
    assert observe.main(["--allow-live-observe", "--output", str(tmp_path / "empty")]) == 2
    assert captured[0].duration == 1800 and captured[0].fault_at is None and not captured[0].capture_packets


@pytest.mark.parametrize("has_markets", [True, False])
async def test_run_uses_actual_scanner_with_private_db_and_never_empty_success(tmp_path, monkeypatch, has_markets):
    s = settings()
    monkeypatch.setattr(observe, "load_settings", lambda path: s)
    native_client = httpx.AsyncClient

    def handler(request):
        response = feed_handler(request)
        if not has_markets and request.url.path.endswith("/101"):
            return httpx.Response(200, json={**payload(), "events": {}})
        return response

    monkeypatch.setattr(httpx, "AsyncClient", lambda **options: native_client(**options, transport=httpx.MockTransport(handler)))
    merge = bcgame.merge_payload
    root = tmp_path / "run"
    result = await observe.run(args(root, duration=.4))
    assert result["run_finished"]["outcome"] == "completed"
    assert result["validation"]["ok"] is has_markets
    assert (root / "observer.db").is_file() and (root / "summary.json").is_file()
    assert result["run_finished"]["nonempty_checks"] > 0 if has_markets else result["run_finished"]["nonempty_checks"] == 0
    assert bcgame.merge_payload is merge
    assert not list(root.glob("*.gz")) and s.platforms["bcgame"].enabled is False
    if os.name != "nt":
        assert stat.S_IMODE((root / "observer.db").stat().st_mode) == 0o600


def test_report_uses_recorded_freshness_not_hardcoded_ten_seconds(tmp_path):
    records = completed_checks([check(age=20)])
    records[0]["stale_seconds"] = 30
    result = report.analyze(write_rows(tmp_path / "threshold", records))
    assert result["fresh_share"] == 1 and result["stale_seconds"] == 30


def captured_http(root, records, request_id, body, *, requested="501", phase="delta", channel="prematch"):
    """Публичный пакет и ссылка на него; установка состояния всегда отдельным событием."""
    (root / f"packet-{request_id:06d}.json.gz").write_bytes(gzip.compress(json.dumps(body).encode()))
    records.append(event("http", len(records), request_id=request_id, requested_version=requested, phase=phase,
                         channel=channel, response={k: body.get(k) for k in ("epoch", "version", "generated")},
                         packet_counts=report.packet_counts(body)))


def lifecycle_capture(tmp_path):
    root = write_rows(tmp_path / "lifecycle", [])
    records = [event("run_started", stale_seconds=10)]
    captured_http(root, records, 1, {"epoch": 17, "version": 100, "top_events_versions": [101],
                                   "rest_events_versions": []}, requested="0", phase="snapshot")
    captured_http(root, records, 2, payload(), requested="101", phase="snapshot")
    records.extend([event("snapshot_accepted", 3, started=at(1)),
                    event("state_installed", 4, request_ids=[1, 2], versions={"prematch": "501"}),
                    event("normalized", 5, market="bcgame:101", channel="prematch", duration_ms=.1), check()])
    return root, records


def lifecycle_report(root, records):
    records = [*records, event("run_finished", 100, outcome="completed")]
    (root / "events.jsonl").write_text("".join(json.dumps(r) + "\n" for r in records), encoding="utf-8")
    return report.analyze(root)


@pytest.mark.parametrize("kind,reason,marker", [
    ("event_delete", "event_missing", "event_deletes"),
    ("winner_delete", "winner_missing", "winner_deletes"),
    ("side_delete", "winner_missing", "winner_deletes"),
    ("suspend", "winner_suspended", "winner_suspends"),
    ("closed", "event_inactive", None),
    ("reset", "winner_missing", "event_resets"),
    ("quote_delete", "winner_quote_missing", "null_deletes"),
    ("rebind", "winner_missing", None),
    ("desc_delete", "winner_missing", "null_deletes"),
])
def test_installed_lifecycle_counts_invalid_fresh_reuse_not_clock_advances(tmp_path, kind, reason, marker):
    root, records = lifecycle_capture(tmp_path)
    changes = {
        "event_delete": None,
        "winner_delete": {"markets": {"186": None}},
        "side_delete": {"markets": {"186": {"": {"4": None}}}},
        "suspend": {"markets": {"186": {"": {"4": {"b": 1}}}}},
        "closed": {"state": {"status": 3}},
        "reset": {"shouldResetEvent": True, "state": {"status": 0}},
        "quote_delete": {"markets": {"186": {"": {"4": {"k": None}}}}},
        "rebind": {"desc": {"competitors": [{"name": "Beta"}, {"name": "Alpha"}]}},
        "desc_delete": {"desc": None},
    }
    # Тот же маркер в чужом событии не входит в пересечение наблюдаемых ID.
    captured_http(root, records, 3, {"epoch": 17, "version": 502,
                                   "events": {"101": changes[kind], "999": changes[kind]}})
    records.extend([event("state_installed", 20, request_ids=[3], versions={"prematch": "502"}), check(30), check(40)])
    result = lifecycle_report(root, records)
    lifecycle = result["lifecycle"]
    assert lifecycle["status"] == "measured"
    assert lifecycle["invalid_reused_markets"] == 1 and lifecycle["invalid_reused_samples"] == 2
    assert lifecycle["invalid_reused_market_keys"] == ["bcgame:101"]
    assert lifecycle["invalid_reused_samples_by_reason"] == {reason: 2}
    if marker:
        assert lifecycle["observed_installed_packet_markers"][marker] == 1
        assert result["counts"][marker] == 2
    assert lifecycle["observed_event_disappearances"] == (1 if kind == "event_delete" else 0)


def test_installed_lifecycle_does_not_count_safely_blocked_or_empty_books(tmp_path):
    root, records = lifecycle_capture(tmp_path)
    captured_http(root, records, 3, {"epoch": 17, "version": 502, "events": {"101": None}})
    records.extend([event("state_installed", 20, request_ids=[3], versions={"prematch": "502"}),
                    {**check(30), "fresh": False}, {**check(40), "nonempty": False},
                    {**check(50), "updated_at": None, "age_sec": None, "fresh": False}])
    result = lifecycle_report(root, records)["lifecycle"]
    assert result["status"] == "measured" and result["invalid_reused_samples"] == result["invalid_reused_markets"] == 0
    assert result["observed_installed_packet_markers"]["event_deletes"] == 1
    assert result["cross_reset_quote_chronology"] == "not_measured"
    assert result["clock_safety"] == "not_assessed_by_raw_availability_even_when_reuse_is_zero"


def test_installed_lifecycle_ignores_successful_but_uninstalled_deletion(tmp_path):
    root, records = lifecycle_capture(tmp_path)
    captured_http(root, records, 3, {"epoch": 17, "version": 502, "events": {"101": None}})
    records.append(check(20))
    # Следующий sync остаётся на старом cursor: HTTP #3 не был установлен.
    captured_http(root, records, 4, {"epoch": 17, "version": 502, "events": {}})
    records.extend([event("state_installed", 30, request_ids=[4], versions={"prematch": "502"}), check(40)])
    result = lifecycle_report(root, records)
    assert result["counts"]["event_deletes"] == 1
    assert result["lifecycle"]["status"] == "measured"
    assert result["lifecycle"]["invalid_reused_samples"] == 0
    assert result["lifecycle"]["observed_installed_packet_markers"]["event_deletes"] == 0


def test_installed_snapshot_is_atomic_and_disappearance_does_not_inherit_old_events(tmp_path):
    root, records = lifecycle_capture(tmp_path)
    # Trigger delta и сам index не сливаются в состояние snapshot.
    captured_http(root, records, 3, {"epoch": 18, "version": 0, "events": {"101": None}})
    captured_http(root, records, 4, {"epoch": 18, "version": 200, "top_events_versions": [201],
                                   "rest_events_versions": [202], "events": {"101": None}}, requested="0", phase="snapshot")
    records.append(check(20))
    captured_http(root, records, 5, {"epoch": 18, "version": 601, "events": {}, "snapshot_complete": False},
                  requested="201", phase="snapshot")
    records.append(check(30))
    captured_http(root, records, 6, {"epoch": 18, "version": 602, "events": {}, "snapshot_complete": True},
                  requested="202", phase="snapshot")
    records.extend([event("state_installed", 40, request_ids=[3, 4, 5, 6], versions={"prematch": "602"}), check(50)])
    lifecycle = lifecycle_report(root, records)["lifecycle"]
    assert lifecycle["status"] == "measured" and lifecycle["linked_installations"] == 2
    assert lifecycle["checked_samples"] == 4 and lifecycle["invalid_reused_samples"] == 1
    assert lifecycle["invalid_reused_samples_by_reason"] == {"event_missing": 1}
    assert lifecycle["observed_event_disappearances"] == lifecycle["observed_disappeared_markets"] == 1
    assert lifecycle["observed_installed_packet_markers"]["event_deletes"] == 0


def test_uninstalled_snapshot_parts_never_remove_or_suspend_current_state(tmp_path):
    root, records = lifecycle_capture(tmp_path)
    captured_http(root, records, 3, {"epoch": 18, "version": 200, "top_events_versions": [201],
                                   "rest_events_versions": [202]}, requested="0", phase="snapshot")
    captured_http(root, records, 4, {"epoch": 18, "version": 601, "events": {"101": None}, "snapshot_complete": False},
                  requested="201", phase="snapshot")
    records.extend([event("snapshot_error", 20, error_type="SnapshotExpired"), check(30)])
    lifecycle = lifecycle_report(root, records)["lifecycle"]
    assert lifecycle["status"] == "measured" and lifecycle["invalid_reused_samples"] == 0
    assert lifecycle["observed_installed_packet_markers"]["event_deletes"] == 0


@pytest.mark.parametrize("missing", ["request_ids", "packet", "snapshot_part"])
def test_lifecycle_missing_evidence_is_not_measured_not_a_false_zero(tmp_path, missing):
    root, records = lifecycle_capture(tmp_path)
    if missing == "request_ids":
        next(r for r in records if r["stage"] == "state_installed").pop("request_ids")
    elif missing == "packet":
        (root / "packet-000002.json.gz").unlink()
    else:
        index = {"epoch": 17, "version": 100, "top_events_versions": [101, 102], "rest_events_versions": []}
        (root / "packet-000001.json.gz").write_bytes(gzip.compress(json.dumps(index).encode()))
    lifecycle = lifecycle_report(root, records)["lifecycle"]
    assert lifecycle["status"] == "not_measured" and lifecycle["not_measured_reasons"]
    assert lifecycle["invalid_reused_markets"] is lifecycle["invalid_reused_samples"] is None
    assert lifecycle["observed_installed_packet_markers"] is None


async def test_lifecycle_replays_actual_adapter_install_links_and_scanner_checks(observed):
    """Реальный формат инструмента, но намеренно удерживаем старую книгу после удаления."""
    adapter, journal, s = observed
    markets = await adapter.fetch_markets()
    scanner = observe.ProbeScanner(s, {"bcgame": adapter}, Database(journal.root / "unused.db"), journal=journal)
    scanner._merge("bcgame", markets)
    await scanner.evaluate()
    await install_transport(adapter, lambda request: httpx.Response(200, json={
        "epoch": 17, "version": 502, "generated": PUBLIC_GENERATED, "events": {"101": None}}))
    await adapter._sync()
    await scanner.evaluate()
    result = report.analyze(journal.root)["lifecycle"]
    assert result["status"] == "measured" and result["linked_installations"] == 2
    assert result["invalid_reused_markets"] == result["invalid_reused_samples"] == 1
    assert result["observed_installed_packet_markers"]["event_deletes"] == 1


@pytest.mark.parametrize("patch", [{}, {"desc": None}, {"desc": {}}, {"desc": {"competitors": None}},
                                  {"shouldResetEvent": True, "state": {"status": 0}}])
def test_lifecycle_event_projection_matches_native_missing_and_null_desc(patch):
    old = payload()["events"]["101"]
    native = bcgame.merge_payload({"events": {"101": old}}, {"events": {"101": patch}})["events"]["101"]
    expected = {k: v for k, v in native.items() if k in ("desc", "state", "markets")}
    assert report._merge_observed_event(old, patch) == expected
    assert old == payload()["events"]["101"]  # обе функции не мутируют исходную запись


@pytest.mark.parametrize("failure", [401, 403, 429, "cooldown", "json"])
async def test_native_errors_inside_fault_window_are_not_causally_injected(observed, failure):
    adapter, journal, _ = observed
    await install_transport(adapter, lambda request: httpx.Response(200, content=b"{") if failure == "json" else
                            httpx.Response(failure if isinstance(failure, int) else 200, headers={"Retry-After": "60"}))
    adapter.fault = {"id": 1, "client": adapter.http, "injected": observe.mark()}
    adapter.fault_active = True
    if failure == "cooldown":
        adapter._retry_until = time.monotonic() + 60
    with pytest.raises((HttpError, ValueError)):
        await adapter._get("prematch", "501")
    error = next(r for r in rows(journal) if r["stage"] == "http_error")
    assert error["in_fault_window"] and error["injected"] is False and error["fault_error_basis"] is None
    counts = report.analyze(journal.root)["counts"]
    assert counts["injected_http_errors"] == 0 and counts["fault_window_http_errors"] == 1


async def test_fault_attributes_a_demonstrably_closed_inflight_transport(observed, monkeypatch):
    adapter, journal, _ = observed
    requested, closed = asyncio.Event(), asyncio.Event()

    class Transport(httpx.AsyncBaseTransport):
        async def handle_async_request(self, request):
            requested.set()
            await closed.wait()
            raise httpx.ReadError("synthetic closed transport")

        async def aclose(self):
            closed.set()

    await adapter.http.aclose()
    adapter.http = httpx.AsyncClient(base_url=adapter.api_url, trust_env=False, transport=Transport())
    adapter.request_retries = 0
    adapter._attach_http_hooks()
    request = asyncio.create_task(adapter._get("prematch", "501"))
    await requested.wait()

    async def pause(seconds):
        with pytest.raises(HttpError):
            await request

    monkeypatch.setattr(observe.asyncio, "sleep", pause)
    await adapter.inject_fault(.01)
    error = next(r for r in rows(journal) if r["stage"] == "http_error")
    assert error["injected"] and error["fault_error_basis"] == "inflight_transport_closed_by_fault"


async def test_engine_book_boundaries_ignore_normalization_temps_and_link_publish(observed):
    adapter, journal, s = observed
    markets = await adapter.fetch_markets()
    scanner = observe.ProbeScanner(s, {"bcgame": adapter}, Database(journal.root / "unused.db"), journal=journal)
    scanner._merge("bcgame", markets)
    market = markets[0]
    adapter._subscribed = {market.key: market}
    temporary = market.model_copy(deep=True)
    adapter._set_source_books(temporary, temporary.asks_a, temporary.asks_b, temporary.updated_at)
    assert not any(r["stage"] == "engine_book_installed" for r in rows(journal))
    assert any(r["stage"] == "engine_market_registered" for r in rows(journal))
    adapter._callback = scanner._on_price
    adapter._publish(force=True)
    records = rows(journal)
    installed = next(r for r in records if r["stage"] == "engine_book_installed")
    published = next(r for r in records if r["stage"] == "published")
    assert installed["duration_ms"] == report.elapsed_ms(installed["started"], installed)
    assert installed["normalized_finished"]["mono_ns"] <= installed["started"]["mono_ns"] <= installed["mono_ns"]
    assert published["book_installed"]["mono_ns"] == installed["mono_ns"] <= published["mono_ns"]
    adapter.feeds["prematch"].data["events"].clear()
    adapter._publish(force=True)
    invalidated = [r for r in rows(journal) if r["stage"] == "published"][-1]
    assert invalidated["book_installed"] is None and invalidated["accepting_orders"] is False
    result = report.analyze(journal.root)
    assert set(result["measurement_boundaries"]["engine_book_timings"].values()) == {"measured"}
    assert result["measurement_boundaries"]["invalidation_book_install_duration"].startswith("not_measured")


async def test_discovery_merge_distinguishes_kept_books_from_merge_envelope(observed):
    adapter, journal, s = observed
    markets = await adapter.fetch_markets()
    scanner = observe.ProbeScanner(s, {"bcgame": adapter}, Database(journal.root / "unused.db"), journal=journal)
    scanner._merge("bcgame", markets)
    market = markets[0]
    adapter._subscribed = {market.key: market}
    adapter._set_source_books(market, market.asks_a, market.asks_b, market.updated_at)
    kept = adapter.book_installed[market.key]
    incoming = market.model_copy(deep=True)
    incoming.asks_a[0].price = incoming.outcome_a_ask = .7
    scanner._merge("bcgame", [incoming])
    assert adapter.book_installed[market.key] is kept
    assert not any(r["stage"] == "engine_discovery_books_merged" for r in rows(journal))
    incoming.updated_at = NOW + timedelta(seconds=1)
    scanner._merge("bcgame", [incoming])
    event_row = next(r for r in rows(journal) if r["stage"] == "engine_discovery_books_merged")
    assert event_row["boundary"] == "scanner_merge_call_envelope" and event_row["book_install_duration"] == "not_measured"
    assert market.key not in adapter.book_installed


def test_report_separates_feed_install_book_install_and_zero_market_coverage(tmp_path):
    records = completed_checks([
        event("engine_tick", 3, markets=0), event("engine_tick", 4, markets=1),
        event("state_installed", 15, started=at(10)),
        event("engine_book_installed", 30, started=at(25), normalized_finished=at(20), duration_ms=5, market="bcgame:101"),
        event("published", 40, market="bcgame:101", installed=at(15), book_installed=at(30), asks=[.5, .6]),
        check(50), {**check(60), "nonempty": False},
    ])
    result = report.analyze(write_rows(tmp_path / "book-timing", records))
    durations = result["durations"]
    assert "install_ms" not in durations and "install_to_publish_ms" not in durations
    assert durations["feed_state_install_ms"]["median"] == durations["engine_book_install_duration_ms"]["median"] == 5
    assert durations["normalize_to_engine_book_install_ms"]["median"] == durations["engine_book_install_to_publish_ms"]["median"] == 10
    assert durations["feed_state_to_publish_ms"]["median"] == 25
    assert result["engine_tick_coverage"]["zero_market_ticks"] == 1
    assert result["engine_tick_coverage"]["with_markets_share"] == .5
    assert result["fresh_share"] == 1 and result["fresh_share_all_engine_samples"] == .5
