"""Честные метрики отчёта: процентили, прибыль при ставке, банкролл с блокировкой денег, выбросы, фазы, бумажная
проверка, турниры и флаги; старые строки без новых данных; отчёт по копии реальной истории arb_copy.db."""

from __future__ import annotations

import json
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest

from backend import honest_stats as hs
from backend.stats import HonestSettings, build_report, collect, format_text, period_days
from backend.storage.db import Database

MSK = ZoneInfo("Europe/Moscow")
NOW = datetime(2026, 10, 16, 12, 0, tzinfo=timezone.utc)
T0 = datetime(2026, 10, 16, 6, 0, tzinfo=timezone.utc)
NAMES = {"polymarket": "Polymarket", "kalshi": "Kalshi", "stake": "Stake"}
ARB_COPY = Path(__file__).resolve().parent.parent / "arb_copy.db"


def iso(minutes: float) -> str:
    return (T0 + timedelta(minutes=minutes)).isoformat()


def row(minute: float, rid: int, *, arb_id: str = "pm:1|k:1|A", start: float | None = 60, profit: float = 1.0,
        pct: float = 2.0, volume: float = 50.0, lifetime: float = 20.0, tournament: str = "Major",
        capture: dict | None = None, teams: tuple[str, str] = ("NAVI", "FaZe")) -> dict:
    """Строка истории; без ``capture`` — как у строк до этой версии сканера (новых колонок нет совсем)."""
    out = {
        "id": rid, "arb_id": arb_id, "pair_key": arb_id.rsplit("|", 1)[0], "game": "cs2",
        "event_title": f"{teams[0]} vs {teams[1]}", "tournament": tournament, "team_a": teams[0], "team_b": teams[1],
        "leg1_platform": "polymarket", "leg2_platform": "kalshi", "start_time": iso(start) if start is not None else None,
        "first_seen": iso(minute), "lifetime_sec": lifetime, "max_profit_pct": pct, "max_volume_usd": volume,
        "max_profit_usd": profit, "minute_healthy": None,
    }
    if capture is not None:
        out.update({"capture_version": 1, **capture})
    return out


def captured(confirm_profit: float, confirm_volume: float, stakes: list[tuple[float, float, float]],
             optimal: tuple[float, float], flags: dict | None = None, phase: str = "prematch") -> dict:
    """Данные при подтверждении: таблица ставок [(ставка, потрачено, прибыль)] и оптимальный размер."""
    return {
        "phase": phase, "confirm_profit_usd": confirm_profit, "confirm_profit_pct": confirm_profit / confirm_volume * 100,
        "confirm_volume_usd": confirm_volume,
        "stake_profits": json.dumps([{"stake_usd": s, "cost_usd": c, "profit_usd": p,
                                      "filled": c is not None and c >= s - 0.01} for s, c, p in stakes]),
        "optimal_stake_usd": optimal[0], "optimal_profit_usd": optimal[1],
        "liquidity_flags": json.dumps(flags or {}),
    }


def build(rows, paper=None, **honest) -> dict:
    period = period_days(MSK, 1, NOW)
    return build_report(
        rows, {}, {}, period, tracking_since=None, tz_name="Europe/Moscow", now=NOW, platform_names=NAMES,
        game_names={"cs2": "CS2"}, confirm_seconds=5.0, paper=paper, honest=HonestSettings(**honest),
    )


def record(r: dict, large: float = 1000.0) -> hs.ArbRecord:
    return hs.make_record(r, rid=r["id"], day=T0.date(), venue=("polymarket", "kalshi"), healthy=False,
                          confirm_seconds=5.0, large_volume_usd=large)


# ---- функции ----------------------------------------------------------------------------------------


def test_percentiles_interpolate_between_neighbours():
    assert hs.percentile([1, 2, 3, 4], 50) == 2.5
    assert hs.percentile([1, 2, 3, 4], 90) == pytest.approx(3.7)
    assert hs.percentile([5], 25) == 5 and hs.percentile([], 50) is None
    assert hs.spread([4, 1, 3, 2]) == {"p25": 1.75, "p50": 2.5, "p75": 3.25, "p90": 3.7, "max": 4, "count": 4}
    assert hs.spread([]) is None


def test_profit_curve_and_profit_at_a_stake():
    stakes = [{"stake_usd": 10, "cost_usd": 10, "profit_usd": 0.4}, {"stake_usd": 25, "cost_usd": 25, "profit_usd": 0.9},
              {"stake_usd": 50, "cost_usd": 40, "profit_usd": 1.2}, {"stake_usd": 100, "cost_usd": None, "profit_usd": None}]
    curve = hs.profit_curve(stakes, 40, 1.2)
    assert curve == [(0.0, 0.0), (10, 0.4), (25, 0.9), (40, 1.2)]
    assert hs.profit_curve([], None, None) is None and hs.profit_curve("garbage", None, None) is None
    new = record(row(0, 1, capture=captured(1.0, 40, [(10, 10, 0.4), (25, 25, 0.9), (50, 40, 1.2)], (40, 1.2))))
    assert hs.profit_at(new, 10) == (10, 0.4, True)
    used, profit, exact = hs.profit_at(new, 30)
    assert (used, exact) == (30, True) and profit == pytest.approx(0.9 + 0.3 * 5 / 15)
    assert hs.profit_at(new, 100) == (40, 1.2, True) and hs.profit_at(new, None) == (40, 1.2, True)
    # Старая строка: оценка по максимумам, как в проверке пользователя: min(прибыль, ставка × процент / 100).
    old = record(row(0, 2, profit=5.0, pct=4.0, volume=300))
    assert hs.profit_at(old, 100) == (100, 4.0, False)
    assert hs.profit_at(old, 1000) == (300, 5.0, False) and hs.profit_at(old, None) == (300, 5.0, False)


def test_old_rows_get_a_derived_phase_and_no_data_marks():
    old = record(row(0, 1, start=60, volume=1500))  # появилась за час до старта
    assert (old.phase, old.phase_derived, old.captured, old.flags, old.large) == ("prematch", True, False, None, True)
    assert old.confirmed_at == T0 + timedelta(seconds=5)  # подтверждение = появление + порог
    assert record(row(90, 2, start=60)).phase == "live"
    assert record(row(0, 3, start=None)).phase == "unknown"
    new = record(row(0, 4, start=None, capture=captured(1, 50, [], (50, 1), phase="live")))
    assert (new.phase, new.phase_derived, new.flags) == ("live", False, {})  # фаза из колонки, не из времени


def test_bankroll_locks_money_until_the_match_is_settled():
    def arb(minute, rid, start, volume=1000.0):
        return record(row(minute, rid, arb_id=f"p{rid}|k|A", start=start, profit=20, pct=2.0, volume=volume))

    arbs = [
        arb(0, 1, start=60),      # берёт 60 $; деньги вернутся в 60 + 180 мин
        arb(10, 2, start=60),     # свободно 40 $: берёт 40 $
        arb(20, 3, start=60),     # денег нет
        arb(30, 4, start=60, volume=0),  # объёма нет (но и денег нет: считается как «денег нет»)
        arb(241, 5, start=200),   # первые две вилки рассчитаны (старт 60 + 3 ч = 240): берёт 60 $
    ]
    result = hs.simulate_bankroll(arbs, bankroll=100, cap=60, settle_hours=3)
    assert (result["taken"], result["skipped_no_money"], result["skipped_no_depth"]) == (3, 2, 0)
    assert result["profit_usd"] == pytest.approx(60 * 0.02 + 40 * 0.02 + 60 * 0.02)
    assert result["turnover_usd"] == 160 and result["peak_locked_usd"] == 100
    assert (result["exact_arbs"], result["estimated_arbs"]) == (0, 3)
    assert result["return_pct"] == pytest.approx(result["profit_usd"] / 100 * 100, abs=0.01)
    # После старта: деньги заняты на settle_hours от подтверждения.
    live = [arb(0, 6, start=-30), arb(100, 7, start=-30), arb(181, 8, start=-30)]
    result = hs.simulate_bankroll(live, bankroll=60, cap=60, settle_hours=3)
    assert (result["taken"], result["skipped_no_money"]) == (2, 1)
    # Без лимита на вилку: весь свободный капитал, но не больше объёма вилки.
    result = hs.simulate_bankroll([arb(0, 9, start=60, volume=30)], bankroll=100, cap=0, settle_hours=3)
    assert result["turnover_usd"] == 30
    zero = record(row(0, 10, profit=0.0, volume=10))
    assert hs.simulate_bankroll([zero], 100, 50, 3)["skipped_no_depth"] == 1
    assert hs.simulate_bankroll(arbs, bankroll=0, cap=60, settle_hours=3) is None


def test_outliers_are_excluded_from_every_group():
    rows = [row(i, i, arb_id=f"p{i}|k|A", profit=p, tournament=t)
            for i, (p, t) in enumerate([(100, "A"), (50, "B"), (1, "A"), (2, "B"), (3, "A")], start=1)]
    rep = build(rows, exclude_top_n=2)
    h = rep["totals"]["honest"]
    assert (h["profit_usd"], h["profit_trimmed_usd"], h["outliers"], h["outliers_profit_usd"]) == (156, 6, 2, 150)
    assert [o["profit_usd"] for o in rep["outliers"]] == [100, 50]
    trimmed = {t["tournament"]: t["profit_trimmed_usd"] for t in rep["by_tournament"]}
    assert trimmed == {"A": 4, "B": 2}
    assert sum(p["profit_trimmed_usd"] for p in rep["phases"]) == 6
    assert rep["by_day"][0]["profit_trimmed_usd"] == 6
    assert build(rows, exclude_top_n=0)["totals"]["honest"]["profit_trimmed_usd"] == 156


def test_report_with_old_and_new_rows_phases_paper_and_flags():
    new_capture = captured(1.5, 60, [(10, 10, 0.3), (25, 25, 0.7), (50, 50, 1.3), (100, 60, 1.5)], (60, 1.5),
                           flags={"size_jump": {"added_usd": 900}})
    rows = [
        row(0, 1, arb_id="pm:1|k:1|A", start=60, profit=9.0, pct=3.0, volume=2000),  # старая, до старта
        row(100, 2, arb_id="pm:2|k:2|B", start=60, profit=2.0, pct=1.5, volume=70, lifetime=8,
            capture={**new_capture, "phase": "live"}, teams=("OG", "Liquid"), tournament="Cup"),
    ]
    paper = [
        {"arb_id": "pm:2|k:2|B", "first_seen": iso(100), "delay_sec": 5.0, "status": "ok", "arb_exists": 1,
         "profit_usd": 1.1, "volume_usd": 55, "stake_profits": json.dumps([{"cost_usd": 50, "profit_usd": 0.9}]),
         "optimal_stake_usd": 55, "optimal_profit_usd": 1.1, "books_match": 0},
        {"arb_id": "pm:2|k:2|B", "first_seen": iso(100), "delay_sec": 15.0, "status": "ok", "arb_exists": 0,
         "profit_usd": None, "volume_usd": None, "stake_profits": None, "optimal_stake_usd": None,
         "optimal_profit_usd": None, "books_match": 1},
        {"arb_id": "pm:2|k:2|B", "first_seen": iso(100), "delay_sec": 60.0, "status": "error", "arb_exists": None,
         "profit_usd": None, "volume_usd": None, "stake_profits": None, "optimal_stake_usd": None,
         "optimal_profit_usd": None, "books_match": None},
        {"arb_id": "other|A", "first_seen": iso(5), "delay_sec": 5.0, "status": "ok", "arb_exists": 1,
         "profit_usd": 50, "volume_usd": 1, "stake_profits": None, "optimal_stake_usd": None,
         "optimal_profit_usd": None, "books_match": 1},  # появление не из этого периода/истории: не считается
    ]
    rep = build(rows, paper=paper, exclude_top_n=0, max_stake_per_arb_usd=50)
    t, h = rep["totals"], rep["totals"]["honest"]
    assert (t["captured_arbs"], t["derived_phase_arbs"]) == (1, 1)
    assert (h["confirm_arbs"], h["no_data_arbs"], h["confirm_profit_usd"]) == (1, 1, 1.5)
    assert h["capped"] == {"max_stake_usd": 50, "profit_usd": 2.8, "exact_arbs": 1, "exact_profit_usd": 1.3,
                           "estimated_arbs": 1, "estimated_profit_usd": 1.5}
    five, fifteen, sixty = h["paper"]
    assert (five["checked"], five["left"], five["share_left"], five["profit_usd"]) == (1, 1, 1.0, 1.1)
    assert (five["capped_profit_usd"], five["books_mismatch"], five["no_data"]) == (0.9, 1, 1)  # старая: без проверки
    assert (fifteen["left"], fifteen["share_left"]) == (0, 0.0)
    assert (sixty["checked"], sixty["errors"]) == (0, 1)  # ошибка запроса — «данных нет», а не «вилка исчезла»
    phases = {p["phase"]: p for p in rep["phases"]}
    assert set(phases) == {"prematch", "live"}  # «старт неизвестен» без вилок не показывается
    assert (phases["prematch"]["arbs"], phases["prematch"]["confirm_profit_usd"]) == (1, None)
    assert phases["live"]["paper"][0]["left"] == 1 and phases["prematch"]["paper"][0]["checked"] == 0
    assert phases["prematch"]["flags"] == {"large_volume": 1, "size_jump": 0, "stale_data": 0, "no_data": 1}
    assert phases["live"]["flags"]["size_jump"] == 1
    top = {p["pair_key"]: p for p in rep["top_pairs"]}
    assert top["pm:1|k:1"]["flags"]["large_volume"] == 1 and top["pm:1|k:1"]["max_volume_usd"] == 2000
    assert top["pm:2|k:2"]["confirm_profit_usd"] == 1.5 and top["pm:2|k:2"]["phases"]["live"] == 1
    tournaments = {x["tournament"]: x for x in rep["by_tournament"]}
    assert tournaments["Major"]["share_of_profit"] == pytest.approx(9 / 11, abs=1e-4)
    assert (tournaments["Cup"]["live_arbs"], tournaments["Major"]["large_volume_arbs"]) == (1, 1)

    text = format_text(rep)
    assert "Прибыль при подтверждении: 1,50 $ (у 1 из 2 вилок есть данные при подтверждении)" in text
    assert "Ставка до 50 $ на вилку, без учёта банкролла: 2,80 $*; из них 1,50 $ — оценка по максимумам" in text
    assert "Бумажная проверка (стаканы перечитаны отдельным запросом), осталось: +5 с — 1 из 1 (100 %); " \
           "+15 с — 0 из 1 (0 %); +60 с — без данных у 1" in text
    assert "По фазам" in text and "Фаза 1 из 2 вилок вычислена по времени старта из истории" in text
    assert "большой объём ×1, нет снимков" in text and "скачок размера ×1" in text
    assert "По турнирам (показано 2 из 2)" in text


def test_empty_period_has_no_phase_rows_and_no_errors():
    rep = build([])
    assert rep["totals"]["honest"]["bankroll"]["taken"] == 0 and rep["outliers"] == []
    assert [p["phase"] for p in rep["phases"]] == ["prematch", "live"] and rep["phases"][0]["arbs"] == 0
    assert "подтверждённых вилок нет" in format_text(rep)


async def test_api_returns_the_honest_report(tmp_path, settings):
    db = Database(tmp_path / "api.db")
    await db.connect()
    rep = await collect(db, settings, days=1)
    assert {"phases", "outliers", "by_tournament", "settings"} <= rep.keys()
    assert rep["settings"]["exclude_top_n"] == settings.stats.exclude_top_n
    assert rep["settings"]["paper_delays_sec"] == settings.paper.delays_sec
    await db.close()


@pytest.mark.skipif(not ARB_COPY.is_file(), reason="arb_copy.db is not in the repository")
async def test_report_on_a_copy_of_the_real_history_matches_the_checked_numbers(tmp_path, settings):
    """Числа, сверенные с пользователем по arb_copy.db (сам файл только копируется)."""
    copy = tmp_path / "arb_copy.db"
    shutil.copyfile(ARB_COPY, copy)
    db = Database(copy, read_only=True)
    await db.connect()
    settings.stats.exclude_top_n, settings.stats.max_stake_per_arb_usd = 10, 100
    rep = await collect(db, settings, days=7, now=datetime(2026, 10, 18, 21, 0, tzinfo=timezone.utc))
    await db.close()
    t, h = rep["totals"], rep["totals"]["honest"]
    assert (t["arbs"], t["distinct_arbs"], h["profit_usd"], t["captured_arbs"]) == (374, 134, 1250.72, 0)
    phases = {p["phase"]: p for p in rep["phases"]}
    pre, live = phases["prematch"], phases["live"]
    assert (pre["arbs"], pre["profit_usd"], live["arbs"], live["profit_usd"]) == (220, 876.49, 154, 374.23)
    assert pre["lifetime_spread"]["p50"] == pytest.approx(93.5, abs=0.1)
    assert pre["volume_spread"]["p50"] == pytest.approx(27.7, abs=0.05)
    assert live["lifetime_spread"]["p50"] == pytest.approx(13.4, abs=0.1)
    assert h["large_volume_arbs"] == 15 and h["capped"]["profit_usd"] == pytest.approx(256.37, abs=0.01)
    assert h["confirm_profit_usd"] is None and all(p["checked"] == 0 for p in h["paper"])
    large = [o for o in rep["outliers"] if o["large_volume"]]
    assert rep["outliers"][0]["team_a"] == "RED Canids Academy" and rep["outliers"][0]["profit_usd"] == 635.87
    assert len(large) == 8 and h["profit_trimmed_usd"] == pytest.approx(1250.72 - 952.32, abs=0.01)
    cct = rep["by_tournament"][0]
    assert cct["tournament"] == "CCT South America Series 7 Group Stage" and cct["profit_usd"] == 850.94
    # Банкролл по фазам — доли одной симуляции: в сумме равны итогу.
    bank = h["bankroll"]
    assert sum(p["bankroll"]["profit_usd"] for p in rep["phases"]) == pytest.approx(bank["profit_usd"], abs=0.02)
    assert bank["taken"] + bank["skipped_no_money"] + bank["skipped_no_depth"] == 374


# ---- поправки по ревью ------------------------------------------------------------------------------------


def test_bankroll_by_phase_is_a_share_of_one_pool_and_rows_add_up():
    rows = [
        row(0, 1, arb_id="p1|k|A", start=600, profit=20, pct=2.0, volume=1000),   # до старта: деньги заняты до 600+180
        row(30, 2, arb_id="p2|k|A", start=10, profit=20, pct=2.0, volume=1000),   # после старта: денег уже нет
        row(40, 3, arb_id="p3|k|A", start=None, profit=20, pct=2.0, volume=1000),  # старт неизвестен
    ]
    rep = build(rows, exclude_top_n=0, bankroll_usd=100, max_stake_per_arb_usd=100, settle_hours=3)
    total = rep["totals"]["honest"]["bankroll"]
    shares = {p["phase"]: p["bankroll"] for p in rep["phases"]}
    assert (total["taken"], total["skipped_no_money"]) == (1, 2)
    assert sum(s["profit_usd"] for s in shares.values()) == pytest.approx(total["profit_usd"])
    assert sum(s["arbs"] for s in shares.values()) == total["arbs"] == 3
    assert shares["prematch"]["taken"] == 1 and shares["live"]["skipped_no_money"] == 1
    assert shares["unknown"]["skipped_no_money"] == 1 and all(s["shared_pool"] for s in shares.values())
    # Отдельная симуляция только фазы «после старта» дала бы прибыль (своя полная касса) — в отчёте её нет.
    assert hs.simulate_bankroll([record(rows[1])], 100, 100, 3)["profit_usd"] > shares["live"]["profit_usd"] == 0
    text = format_text(rep)
    assert "Банкролл (доля)" in text and "суммы фаз равны итогу" in text


def test_exact_bankroll_path_settle_without_start_and_empty_curves():
    stakes = [(10, 10, 0.3), (25, 25, 0.7), (50, 50, 1.3), (100, 60, 1.5)]
    exact = record(row(0, 1, start=None, capture=captured(1.5, 60, stakes, (60, 1.5), phase="live")))
    # Без времени старта деньги заняты от подтверждения (появление + 5 с) на settle_hours.
    again = record(row(179, 2, arb_id="p2|k|A", start=None, capture=captured(1.5, 60, stakes, (60, 1.5))))
    later = record(row(181, 3, arb_id="p3|k|A", start=None, capture=captured(1.5, 60, stakes, (60, 1.5))))
    result = hs.simulate_bankroll([exact, again, later], bankroll=40, cap=0, settle_hours=3)
    assert (result["taken"], result["skipped_no_money"], result["exact_arbs"], result["estimated_arbs"]) == (2, 1, 2, 0)
    assert result["profit_usd"] == pytest.approx(2 * (0.7 + (1.3 - 0.7) * 15 / 25))  # 40 $ по кривой 25…50 $
    # Строка с данными, у которой при подтверждении не было выгодной ставки: ноль, а не оценка по максимумам.
    empty = record(row(0, 4, profit=9.0, pct=3.0, volume=300,
                       capture=captured(0.5, 20, [(10, None, None)], (None, None))))
    assert empty.curve is None and hs.profit_at(empty, 100) == (0.0, 0.0, True)
    assert hs.capped_profit([empty], 100)["profit_usd"] == 0 and hs.capped_profit([empty], 100)["exact_arbs"] == 1


def test_naive_timestamps_are_utc_and_do_not_break_the_report():
    rows = [row(0, 1, start=60), row(5, 2, arb_id="p2|k|A", start=60)]
    rows[0]["first_seen"] = rows[0]["first_seen"].replace("+00:00", "")  # время без часового пояса
    rows[1]["start_time"] = rows[1]["start_time"].replace("+00:00", "")
    rows[1]["confirmed_at"] = (T0 + timedelta(minutes=5, seconds=5)).replace(tzinfo=None).isoformat()
    rows[1]["capture_version"] = 1
    rep = build(rows, exclude_top_n=0)
    assert rep["totals"]["arbs"] == 2 and {p["phase"]: p["arbs"] for p in rep["phases"]}["prematch"] == 2
    assert rep["totals"]["honest"]["bankroll"]["arbs"] == 2


def test_paper_delays_from_history_and_tournament_cap(settings):
    rows = [row(i, i, arb_id=f"p{i}|k|A", tournament=f"T{i:02d}") for i in range(1, 61)]
    paper = [{"arb_id": "p1|k|A", "first_seen": iso(1), "delay_sec": 30.0, "status": "ok", "arb_exists": 1,
              "profit_usd": 0.5, "volume_usd": 10, "stake_profits": None, "optimal_stake_usd": None,
              "optimal_profit_usd": None, "books_match": 1}]
    rep = build(rows, paper=paper, paper_delays_sec=(5.0, 15.0))  # +30 с больше нет в настройке
    assert rep["settings"]["paper_delays_sec"] == [5.0, 15.0, 30.0]
    thirty = rep["totals"]["honest"]["paper"][-1]
    assert (thirty["delay_sec"], thirty["checked"], thirty["left"]) == (30.0, 1, 1)
    assert len(rep["by_tournament"]) == 50 and rep["tournaments_total"] == 60
    assert "По турнирам (показано 15 из 60)" in format_text(rep)


def test_console_cells_show_partly_known_values_and_derived_phase_only_for_old_rows():
    new_capture = captured(1.5, 60, [(10, 10, 0.3)], (60, 1.5))
    rows = [
        row(0, 1),  # до этой версии: данных нет, фаза по времени старта
        row(1, 2, arb_id="p2|k|A", capture=new_capture),
        row(2, 3, arb_id="p3|k|A", start=None, capture={**new_capture, "phase": None}),  # новая, старт неизвестен
    ]
    rep = build(rows, exclude_top_n=0)
    assert rep["totals"]["derived_phase_arbs"] == 1  # только старая строка
    day = rep["by_day"][0]
    assert (day["arbs"], day["confirm_arbs"], day["confirm_profit_usd"]) == (3, 2, 3.0)
    text = format_text(rep)
    assert "3,00 $ (у 2 из 3)" in text  # по дням, по играм, по площадкам, по турнирам
    assert "Сумма макс. $" in text and "Без топ-0" not in text
    old = build([row(0, 1)], exclude_top_n=0)
    assert "данных нет" in format_text(old).split("По дням")[1]
