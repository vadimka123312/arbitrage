"""Данные для честной статистики: ставки с обходом стакана, фаза, снимки при подтверждении и на пике, флаги
подозрительной ликвидности, миграция базы старой версии, страницы истории и API."""

from __future__ import annotations

import asyncio
import json
import random
import shutil
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend.adapters import apply_mock_mode
from backend.adapters.kalshi import KalshiAdapter, parse_book
from backend.adapters.mock import reset_worlds
from backend.api.server import create_app
from backend.config import PlatformFeeConfig, Settings, load_settings
from backend.engine import scanner as scanner_module
from backend.engine.arb import (
    EPS, LegInput, cap_levels, direction_inputs, evaluate_pair, execute_budget, execute_walk_book,
)
from backend.engine.capture import Capture, optimal, phase_of, stake_table
from backend.engine.scanner import Scanner
from backend.engine.tracker import ArbTracker
from backend.models import FeeSpec, Level, utcnow
from backend.stats import collect
from backend.storage.db import CAPTURE_COLUMNS, SCHEMA, Database
from tests.conftest import KALSHI_FEE, PM_FEE, at, load_fixture, make_market, make_pair
from tests.test_adapters import KALSHI_SERIES_META

NAMES = {"polymarket": "Polymarket", "kalshi": "Kalshi"}
ARB_COPY = Path(__file__).resolve().parent.parent / "arb_copy.db"


def columns_of(path: Path) -> set[str]:
    conn = sqlite3.connect(path)
    try:
        return {r[1] for r in conn.execute("PRAGMA table_info(arb_history)")}
    finally:
        conn.close()


def leg(asks, fee: FeeSpec | None = None, min_size: float = 0.0) -> LegInput:
    return LegInput(
        asks=[Level(price=p, size=s) for p, s in asks], fee=fee or FeeSpec(), fee_cfg=PlatformFeeConfig(),
        min_order_size=min_size,
    )


# ---- ставки с обходом стакана -------------------------------------------------------------------


def test_cap_levels_keeps_the_first_contracts_of_a_book():
    levels = [Level(price=0.40, size=10, instrument="x"), Level(price=0.41, size=5), Level(price=0.45, size=100)]
    capped = cap_levels(levels, 12.5)
    assert [(lv.price, lv.size, lv.instrument) for lv in capped] == [(0.40, 10, "x"), (0.41, 2.5, None)]
    assert levels[1].size == 5  # сам стакан не меняется
    assert cap_levels(levels, 0) == [] and len(cap_levels(levels, 1e9)) == 3


def test_budget_buys_the_cheapest_pairs_first():
    leg1 = leg([(0.40, 100), (0.45, 100)])
    leg2 = leg([(0.50, 50), (0.52, 200)])
    # Пары: 50 по 0,90, затем 50 по 0,92, затем 100 по 0,97; дальше первая нога кончается.
    full = execute_walk_book(leg1, leg2)
    assert (full.contracts, round(full.total_cost, 6), round(full.profit, 6)) == (200, 188, 12)
    ten = execute_budget(leg1, leg2, 10)  # бюджет подбирается с точностью до десятой доли цента
    assert ten.total_cost == pytest.approx(10, abs=1e-3) and ten.contracts == pytest.approx(10 / 0.90, abs=1e-3)
    sixty = execute_budget(leg1, leg2, 60)
    assert sixty.total_cost == pytest.approx(60, abs=1e-3)
    assert sixty.contracts == pytest.approx(50 + 15 / 0.92, abs=1e-3)
    assert sixty.profit == pytest.approx(sixty.contracts - sixty.total_cost)
    assert sixty.profit_pct == pytest.approx(sixty.profit / sixty.total_cost * 100)
    # Бюджет больше стакана: весь выгодный объём, как у walk_book.
    assert execute_budget(leg1, leg2, 500).total_cost == pytest.approx(188)
    assert execute_budget(leg1, leg2, 0) is None
    assert execute_budget(leg([(0.60, 100)]), leg([(0.50, 100)]), 50) is None  # вилки нет


def test_budget_counts_fees_kalshi_rounding_and_minimum_orders():
    pm = leg([(0.45, 1000)], fee=PM_FEE, min_size=5)
    kalshi = leg([(0.48, 1000)], fee=KALSHI_FEE, min_size=1)
    for budget in (10, 25, 100, 250):
        result = execute_budget(pm, kalshi, budget)
        assert budget - 0.05 < result.total_cost <= budget + EPS  # Kalshi округляет комиссию вверх до цента
        assert result.fee1 > 0 and result.fee2 > 0
        assert result.profit == pytest.approx(result.contracts - result.total_cost)
    # 3 $ не хватает на 5 акций Polymarket (минимальный ордер): покупки нет.
    assert execute_budget(pm, kalshi, 3.0) is None


def test_stake_table_respects_the_stake_limit_and_optimal_is_the_whole_walk():
    # Stake: один уровень на исход, размер = max_stake_usd × коэф. (50 $ при коэф. 2,5 = 125 контрактов по 0,4).
    stake_leg = leg([(1 / 2.5, 50 * 2.5)])
    pm = leg([(0.55, 10_000)], fee=PM_FEE, min_size=5)
    small, big = stake_table(pm, stake_leg, [10, 250])
    assert small["filled"] is True and small["cost_usd"] == pytest.approx(10, abs=0.01)
    assert small["profit_pct"] == pytest.approx(small["profit_usd"] / small["cost_usd"] * 100, abs=0.05)
    assert big["filled"] is False and big["contracts"] == pytest.approx(125)
    result = execute_budget(pm, stake_leg, 250)
    assert sum(p * q for p, q, _ in result.fills2) == pytest.approx(50)  # на Stake не больше 50 $
    best = optimal(pm, stake_leg)
    full = execute_walk_book(pm, stake_leg)
    assert best == {"stake_usd": round(full.total_cost, 2), "contracts": 125.0, "profit_usd": round(full.profit, 2),
                    "profit_pct": round(full.profit_pct, 3)}
    assert optimal(leg([(0.60, 10)]), leg([(0.50, 10)])) is None
    assert stake_table(leg([(0.60, 10)]), leg([(0.50, 10)]), [10])[0]["profit_usd"] is None


def test_phase_is_taken_from_the_start_time_at_first_seen():
    assert phase_of(at(0), at(600)) == ("prematch", 10.0)
    assert phase_of(at(600), at(0)) == ("live", -10.0)
    assert phase_of(at(0), at(0)) == ("live", 0.0)  # матч начался в этот момент
    assert phase_of(at(0), None) == (None, None)


# ---- снимки и флаги через трекер ------------------------------------------------------------------


class World:
    """Два рынка, одна пара, движок, трекер и сбор данных; время задаётся тестом."""

    def __init__(self, settings: Settings, start: datetime | None = None, suffix: str = "1"):
        self.settings = settings
        self.left = make_market("polymarket", f"pm{suffix}", asks_a=[(0.40, 100), (0.42, 300)], asks_b=[(0.62, 100)],
                                fee=PM_FEE, start=start, updated_at=at(0), min_order_size=5)
        self.right = make_market("kalshi", f"k{suffix}", asks_a=[(0.62, 80)], asks_b=[(0.50, 50), (0.52, 500)],
                                 fee=KALSHI_FEE, start=start, updated_at=at(0), min_order_size=1)
        self.pair = make_pair(self.left, self.right)
        self.markets = {self.left.key: self.left, self.right.key: self.right}
        self.tracker = ArbTracker(settings.engine.confirm_seconds)
        self.capture = Capture(settings)
        self.closed = []

    def books(self, now: datetime, right_b=None, left_a=None, left_age: float = 0.0) -> None:
        """Новые стаканы (то, что прислала площадка) с отметкой времени ``now``."""
        if left_a is not None:
            self.left.set_books([Level(price=p, size=s) for p, s in left_a], self.left.asks_b, None, None, now)
        self.left.updated_at = now - timedelta(seconds=left_age)
        if right_b is not None:
            self.right.set_books(self.right.asks_a, [Level(price=p, size=s) for p, s in right_b], None, None, now)
        self.right.updated_at = now

    def step(self, now: datetime):
        found = evaluate_pair(self.pair, self.left, self.right, self.settings, now, NAMES)
        update = self.tracker.update(found, now)
        self.capture.observe(now, [self.pair], self.markets.get, update)
        self.closed += update.closed
        return found


def test_snapshots_at_confirmation_and_peak_phase_stakes_and_optimal(settings):
    w = World(settings, start=at(3600))
    w.books(at(0))
    first = w.step(at(0))
    assert [o.direction for o in first] == ["A"]  # NIP @0,40 на Polymarket + Liquid @0,50 на Kalshi
    w.books(at(2), right_b=[(0.50, 90), (0.52, 500)])  # глубже на лучшей цене: прибыль растёт — новый пик
    peak = w.step(at(2))[0]
    w.books(at(5), right_b=[(0.50, 60), (0.52, 100)])  # подтверждение на меньшем объёме, стакан мельче 250 $
    confirm = w.step(at(5))[0]
    assert w.tracker.active[confirm.arb_id].confirmed
    confirm_inputs = direction_inputs(w.pair, w.left, w.right, "A", settings)
    expected_optimal = execute_walk_book(*confirm_inputs)
    w.books(at(7), right_b=[(0.70, 500)])  # вилка исчезла
    assert w.step(at(7)) == []
    (item,) = w.closed
    rec = item.capture
    assert rec["capture_version"] == 1 and rec["phase"] == "prematch" and rec["minutes_to_start"] == 60.0
    assert rec["confirmed_at"] == at(5).isoformat()
    assert (rec["confirm_profit_usd"], rec["confirm_profit_pct"], rec["confirm_volume_usd"]) == (
        confirm.profit_usd, confirm.profit_pct, confirm.volume_usd)
    # Пик — один момент: прибыль, процент и объём согласованы, прибыль равна максимуму трекера.
    assert rec["peak_at"] == at(2).isoformat() and item.max_profit_usd == peak.profit_usd
    assert (rec["peak_profit_pct"], rec["peak_volume_usd"]) == (peak.profit_pct, peak.volume_usd)
    assert rec["optimal_stake_usd"] == round(expected_optimal.total_cost, 2)
    assert rec["optimal_profit_usd"] == round(expected_optimal.profit, 2)
    stakes = json.loads(rec["stake_profits"])
    assert [s["stake_usd"] for s in stakes] == [10, 25, 50, 100, 250]
    assert [s["filled"] for s in stakes] == [True, True, True, True, False]  # 250 $ больше всего стакана
    assert stakes[-1]["cost_usd"] == rec["optimal_stake_usd"]
    profits = [s["profit_usd"] for s in stakes]
    assert profits == sorted(profits)
    assert json.loads(rec["liquidity_flags"]) == {}

    snap = json.loads(rec["confirm_snapshot"])
    assert (snap["kind"], snap["at"], snap["depth_mode"]) == ("confirm", at(5).isoformat(), "best_level")
    assert snap["quote"]["profit_usd"] == confirm.profit_usd and snap["stakes"] == stakes
    pm_leg, kalshi_leg = snap["legs"]
    assert (pm_leg["platform"], pm_leg["buy"], pm_leg["outcome"]) == ("polymarket", "a", "NIP")
    assert pm_leg["asks_a"] == [[0.40, 100.0, None], [0.42, 300.0, None]] and pm_leg["age_sec"] == 0.0
    assert pm_leg["fee"]["model"] == "polymarket" and pm_leg["fee"]["rate"] == 0.05
    assert pm_leg["min_order_size"] == 5 and pm_leg["start_time"] == at(3600).isoformat()
    assert (kalshi_leg["platform"], kalshi_leg["buy"], kalshi_leg["outcome"]) == ("kalshi", "b", "Liquid")
    assert kalshi_leg["asks_b"] == [[0.50, 60.0, None], [0.52, 100.0, None]]
    assert kalshi_leg["fee"]["round_up_cents"] is True and kalshi_leg["contracts"] == confirm.contracts
    peak_snap = json.loads(rec["peak_snapshot"])
    assert peak_snap["kind"] == "peak" and peak_snap["legs"][1]["asks_b"][0] == [0.50, 90.0, None]
    assert w.capture.active == {}


def test_unconfirmed_appearance_gets_only_the_phase(settings):
    w = World(settings)  # без времени старта
    w.books(at(0))
    w.step(at(0))
    w.books(at(2), right_b=[(0.70, 500)])
    w.step(at(2))
    (item,) = w.closed
    assert item.confirmed is False
    assert item.capture == {"capture_version": 1, "phase": None, "minutes_to_start": None}


def test_live_phase_and_same_tick_confirmation_reuses_the_snapshot(settings):
    settings.engine.confirm_seconds = 0  # подтверждена при первом же наблюдении
    w = World(settings, start=at(-600))
    w.tracker.confirm_seconds = 0
    w.books(at(0))
    w.step(at(0))
    w.books(at(1), right_b=[(0.70, 500)])
    w.step(at(1))
    rec = w.closed[0].capture
    assert rec["phase"] == "live" and rec["minutes_to_start"] == -10.0
    assert rec["confirmed_at"] == rec["peak_at"] == at(0).isoformat()
    assert json.loads(rec["confirm_snapshot"])["kind"] == "confirm"
    assert json.loads(rec["peak_snapshot"])["kind"] == "peak"


def test_size_jump_on_a_leg_is_flagged(settings):
    w = World(settings)
    w.books(at(0), right_b=[(0.70, 50)])  # вилки нет
    assert w.step(at(0)) == []
    # Следующий опрос: на лучшей цене появились 5000 контрактов (было 50) — и с ними вилка.
    w.books(at(1), right_b=[(0.50, 5000)])
    assert w.step(at(1))
    w.books(at(6.5))
    w.step(at(6.5))
    w.books(at(8), right_b=[(0.70, 50)])
    w.step(at(8))
    flags = json.loads(w.closed[0].capture["liquidity_flags"])
    jump = flags["size_jump"]
    assert (jump["platform"], jump["market_id"], jump["outcome"]) == ("kalshi", "k1", "Liquid")
    assert (jump["prev_price"], jump["prev_size"], jump["price"], jump["size"]) == (0.70, 50.0, 0.50, 5000.0)
    assert jump["ratio"] == 100.0 and jump["added_usd"] == 2475.0 and jump["at"] == at(1).isoformat()
    assert "large_volume" not in flags  # объём ограничен первой ногой (100 контрактов NIP)


def test_small_changes_and_jumps_on_other_books_are_not_flagged(settings):
    w = World(settings)
    w.books(at(0))
    w.step(at(0))
    w.books(at(1), right_b=[(0.50, 200), (0.52, 500)])  # в 4 раза: меньше порога size_jump_ratio = 5
    w.step(at(1))
    w.books(at(2))
    # Скачок на рынке, который нога не покупает (Liquid на Polymarket), и маленький скачок в долларах.
    w.left.set_books(w.left.asks_a, [Level(price=0.62, size=100_000)], None, None, at(3))
    w.right.set_books([Level(price=0.62, size=80 * 6)], w.right.asks_b, None, None, at(3))  # +49,6 $ < 500 $
    w.step(at(3))
    w.books(at(6))
    w.step(at(6))
    w.books(at(7), right_b=[(0.70, 50)])
    w.step(at(7))
    assert json.loads(w.closed[0].capture["liquidity_flags"]) == {}


def test_stale_data_and_large_volume_flags(settings):
    settings.capture.large_volume_usd = 20
    w = World(settings)
    w.books(at(0), left_age=8)  # данные Polymarket 8 с: свежие для движка (10 с), но старше порога флага (7 с)
    w.step(at(0))
    w.books(at(5), left_age=8)
    w.step(at(5))
    w.books(at(6), right_b=[(0.70, 50)])
    w.step(at(6))
    flags = json.loads(w.closed[0].capture["liquidity_flags"])
    assert flags["stale_data"] == {"moment": "confirm", "platform": "polymarket", "age_sec": 8.0, "threshold_sec": 7.0}
    assert flags["large_volume"]["threshold_usd"] == 20 and flags["large_volume"]["volume_usd"] >= 20

    settings.capture.large_volume_usd = 0  # 0 — флаг выключен
    w = World(settings)
    w.books(at(0))
    w.step(at(0))
    w.books(at(5))
    w.step(at(5))
    w.books(at(6), right_b=[(0.70, 50)])
    w.step(at(6))
    assert "large_volume" not in json.loads(w.closed[0].capture["liquidity_flags"])


def test_capture_can_be_switched_off(settings):
    settings.capture.enabled = False
    w = World(settings, start=at(60))
    for t in (0, 5):
        w.books(at(t))
        w.step(at(t))
    w.books(at(6), right_b=[(0.70, 50)])
    w.step(at(6))
    item = w.closed[0]
    assert item.confirmed and item.capture == {"capture_version": 1, "phase": "prematch", "minutes_to_start": 1.0}


def test_kalshi_instrument_ids_name_the_ticker_of_every_level(settings):
    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    market = adapter._normalize_event(load_fixture("kalshi_event.json"), "cs2", "KXCS2GAME", KALSHI_SERIES_META)[0]
    raw_books = load_fixture("kalshi_orderbooks.json")["orderbooks"]
    books = {ob["ticker"]: parse_book(ob["orderbook_fp"]) for ob in raw_books}
    adapter.books.update(books)
    adapter.book_ts.update({ticker: utcnow() for ticker in books})
    assert adapter._apply_books(market)
    ids = adapter.instrument_ids(market)
    ticker_tl, ticker_nip = market.extra["ticker_a"], market.extra["ticker_b"]
    assert ids["YES «Liquid»"] == f"{ticker_tl} YES" and ids["NO «NIP»"] == f"{ticker_nip} NO"
    # Каждый уровень стакана «Liquid выиграет» — это YES на рынке Liquid или NO на рынке NIP.
    assert {ids[lv.instrument] for lv in market.asks_a} == {f"{ticker_tl} YES", f"{ticker_nip} NO"}


# ---- сканер, база, API --------------------------------------------------------------------------


async def test_scanner_writes_the_data_and_survives_a_capture_failure(settings, tmp_path, monkeypatch, caplog):
    clock = {"now": at(0)}
    monkeypatch.setattr(scanner_module, "utcnow", lambda: clock["now"])
    db = Database(tmp_path / "scan.db")
    await db.connect()
    scanner = Scanner(settings, {}, db)
    w = World(settings, start=at(120))
    scanner._merge("polymarket", [w.left])
    scanner._merge("kalshi", [w.right])
    scanner.pairs = [w.pair]
    for t in (0, 3, 6):
        clock["now"] = at(t)
        w.books(at(t))
        await scanner.evaluate()
    clock["now"] = at(7)
    w.books(at(7), right_b=[(0.70, 50)])
    await scanner.evaluate()
    (row,) = (await db.list_history())["items"]
    assert row["confirmed"] and row["phase"] == "prematch" and row["minutes_to_start"] == 2.0
    assert row["capture_version"] == 1 and row["confirm_profit_usd"] is not None
    assert isinstance(row["stake_profits"], list) and row["liquidity_flags"] == {}
    assert "confirm_snapshot" not in row  # снимки — только в одной строке, не в страницах истории
    full = await db.get_history_item(row["id"])
    assert full["confirm_snapshot"]["legs"][0]["platform"] == "polymarket"
    assert full["peak_snapshot"]["kind"] == "peak"
    assert await db.get_history_item(row["id"] + 100) is None

    def broken(*args, **kwargs):
        raise RuntimeError("boom")

    monkeypatch.setattr(scanner.capture, "observe", broken)
    w.books(at(10), right_b=[(0.50, 50), (0.52, 500)])  # вилка появляется снова
    with caplog.at_level("ERROR", logger="backend.engine.scanner"):
        for t in (10, 11, 16):
            clock["now"] = at(t)
            w.books(at(t))
            await scanner.evaluate()
        clock["now"] = at(17)
        w.books(at(17), right_b=[(0.70, 50)])
        await scanner.evaluate()
    # Поиск и история работают дальше, без новых данных; ошибка в логе один раз за серию.
    rows = (await db.list_history())["items"]
    assert len(rows) == 2 and rows[0]["confirmed"] and rows[0]["capture_version"] == 0
    assert sum("capture failed" in r.getMessage() for r in caplog.records) == 1
    csv_text = await db.history_csv()
    assert "phase,minutes_to_start" in csv_text.splitlines()[0] and "confirm_snapshot" not in csv_text
    await db.close()


async def test_old_database_gets_the_new_columns_without_losing_rows(tmp_path, settings):
    path = tmp_path / "old.db"
    old = sqlite3.connect(path)
    old.executescript(SCHEMA)  # таблица первой версии: новых колонок ещё нет
    old.execute(
        "INSERT INTO arb_history (arb_id, pair_key, game, team_a, team_b, start_time, direction, leg1_platform, "
        "leg2_platform, first_seen, last_seen, lifetime_sec, confirmed, max_profit_pct, max_volume_usd, "
        "max_profit_usd, created_at) VALUES ('p|A', 'p', 'cs2', 'A', 'B', ?, 'A', 'polymarket', 'kalshi', ?, ?, "
        "20, 1, 2.5, 40, 1.0, ?)",
        (at(600).isoformat(), at(0).isoformat(), at(20).isoformat(), at(20).isoformat()),
    )
    old.commit()
    old.close()
    # Только чтение (отчёт до первого запуска новой версии): база не меняется, отчёт работает.
    reader = Database(path, read_only=True)
    await reader.connect()
    report = await collect(reader, settings, days=1, now=at(3600))
    assert report["totals"]["arbs"] == 1 and report["totals"]["captured_arbs"] == 0
    await reader.close()
    assert "phase" not in columns_of(path)

    db = Database(path)
    await db.connect()
    assert set(CAPTURE_COLUMNS) <= columns_of(path)
    (item,) = (await db.list_history())["items"]
    assert (item["arb_id"], item["max_profit_usd"], item["capture_version"]) == ("p|A", 1.0, 0)
    assert item["phase"] is None and item["stake_profits"] is None and item["liquidity_flags"] is None
    await db.close()
    db = Database(path)  # повторное открытие: колонки уже есть, ничего не добавляется
    await db.connect()
    assert (await db.list_history())["total"] == 1
    await db.close()


@pytest.mark.skipif(not ARB_COPY.is_file(), reason="arb_copy.db is not in the repository")
async def test_migration_on_a_copy_of_the_real_history(tmp_path, settings):
    """Копия arb_copy.db (сам файл только читается): строки после миграции те же, отчёт тот же."""
    copy = tmp_path / "arb_copy.db"
    shutil.copyfile(ARB_COPY, copy)
    raw = sqlite3.connect(copy)
    old_columns = [r[1] for r in raw.execute("PRAGMA table_info(arb_history)")]
    before = raw.execute(f"SELECT {', '.join(old_columns)} FROM arb_history ORDER BY id").fetchall()
    raw.close()
    now = datetime(2026, 10, 18, 21, 0, tzinfo=timezone.utc)
    reader = Database(copy, read_only=True)
    await reader.connect()
    old_report = await collect(reader, settings, days=7, now=now)
    await reader.close()

    db = Database(copy)
    await db.connect()
    await db.close()
    raw = sqlite3.connect(copy)
    after = raw.execute(f"SELECT {', '.join(old_columns)} FROM arb_history ORDER BY id").fetchall()
    assert after == before and raw.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    touched = raw.execute("SELECT COUNT(*) FROM arb_history WHERE capture_version != 0 OR phase IS NOT NULL")
    assert touched.fetchone()[0] == 0
    raw.close()
    reader = Database(copy, read_only=True)
    await reader.connect()
    new_report = await collect(reader, settings, days=7, now=now)
    await reader.close()
    for key in ("generated_at",):
        old_report.pop(key)
        new_report.pop(key)
    assert new_report == old_report and new_report["totals"]["captured_arbs"] == 0


def test_history_item_endpoint_returns_the_snapshots(tmp_path, settings):
    w = World(settings, start=at(600))
    for t in (0, 5):
        w.books(at(t))
        w.step(at(t))
    w.books(at(6), right_b=[(0.70, 50)])
    w.step(at(6))
    path = tmp_path / "api.db"

    async def write() -> None:
        db = Database(path)
        await db.connect()
        await db.add_history(w.closed)
        await db.close()

    asyncio.run(write())
    reset_worlds()
    app_settings = apply_mock_mode(load_settings())
    app_settings.storage.path = str(path)
    app_settings.logging.file = ""
    with TestClient(create_app(app_settings), base_url="http://localhost") as client:
        item = client.get("/api/history/1").json()
        assert item["phase"] == "prematch" and item["confirm_snapshot"]["kind"] == "confirm"
        assert item["peak_snapshot"]["legs"][0]["asks_a"][0] == [0.40, 100.0, None]
        assert item["liquidity_flags"] == {} and len(item["stake_profits"]) == 5
        page = client.get("/api/history", params={"limit": 5}).json()
        assert all("confirm_snapshot" not in row for row in page["items"])
        assert client.get("/api/history/999999").status_code == 404
        assert client.get("/api/history/abc").status_code == 422


# ---- поправки по ревью ------------------------------------------------------------------------------------


def lifecycle(w: World, times=(0, 5), close_at: float = 6) -> None:
    """Вилка появляется, подтверждается и исчезает."""
    for t in times:
        w.books(at(t))
        w.step(at(t))
    w.books(at(close_at), right_b=[(0.70, 50)])
    w.step(at(close_at))


def test_bought_out_levels_data_gaps_and_late_jumps_are_not_size_jumps(settings):
    # Лучший уровень выкупили: лучшей стала цена хуже с большим размером. Новой заявки нет.
    w = World(settings)
    w.books(at(0), right_b=[(0.50, 10), (0.51, 3000)])
    assert w.step(at(0))
    w.books(at(1), right_b=[(0.51, 3000)])
    assert w.step(at(1))
    lifecycle(w, times=(5,), close_at=7)
    assert "size_jump" not in json.loads(w.closed[0].capture["liquidity_flags"])

    # Перерыв в данных 31 с: первый свежий опрос не сравнивается со стаканом до перерыва.
    w = World(settings)
    w.books(at(0))
    w.step(at(0))
    w.books(at(31), right_b=[(0.50, 5000), (0.52, 500)])
    w.step(at(31))
    w.books(at(32), right_b=[(0.70, 50)])
    w.step(at(32))
    assert "size_jump" not in json.loads(w.closed[0].capture["liquidity_flags"])

    # Скачок после подтверждения и пика (прибыль не выросла: объём ограничен другой ногой) — не флаг этой вилки.
    w = World(settings)
    for t in (0, 5):
        w.books(at(t), right_b=[(0.50, 200), (0.52, 500)])
        w.step(at(t))
    w.books(at(6), right_b=[(0.50, 2000), (0.52, 500)])  # ×10 и +900 $ на лучшей цене
    w.step(at(6))
    w.books(at(7), right_b=[(0.70, 50)])
    w.step(at(7))
    rec = w.closed[0].capture
    assert rec["peak_at"] == at(0).isoformat() and rec["confirmed_at"] == at(5).isoformat()
    assert "size_jump" not in json.loads(rec["liquidity_flags"])


def test_budget_on_split_kalshi_legs_matches_a_brute_force_search():
    """Нога Kalshi из двух инструментов (YES «A» и NO «B»), минимальные ордера и фиксированные расходы: подбор под
    бюджет не хуже перебора по сетке числа контрактов больше чем на цент."""
    rng = random.Random(7)
    for case in range(30):
        pm = LegInput(
            asks=[Level(price=round(0.40 + 0.01 * i, 2), size=rng.choice([3, 8, 20, 60])) for i in range(4)],
            fee=PM_FEE, fee_cfg=PlatformFeeConfig(), min_order_size=5,
        )
        kalshi = LegInput(
            asks=[Level(price=round(0.48 + 0.01 * (i // 2), 2), size=rng.choice([1, 2, 6, 15, 40]),
                        instrument="YES «A»" if i % 2 else "NO «B»") for i in range(6)],
            fee=KALSHI_FEE, fee_cfg=PlatformFeeConfig(fixed_cost_per_trade_usd=0.02 if case % 2 else 0.0),
            min_order_size=rng.choice([1, 5]),
        )
        full = execute_walk_book(pm, kalshi)
        if full is None or full.profit <= EPS:
            continue
        for budget in (5, 10, 25, 50):
            result = execute_budget(pm, kalshi, budget)
            best = 0.0
            for step in range(1, int(full.contracts * 4) + 1):
                n = step / 4
                probe = execute_walk_book(
                    LegInput(cap_levels(pm.asks, n), pm.fee, pm.fee_cfg, pm.min_order_size),
                    LegInput(cap_levels(kalshi.asks, n), kalshi.fee, kalshi.fee_cfg, kalshi.min_order_size),
                )
                if probe is not None and probe.total_cost <= budget + EPS:
                    best = max(best, probe.profit)
            got = result.profit if result is not None else 0.0
            assert got >= best - 0.01, (case, budget, got, best)
            assert result is None or result.total_cost <= budget + EPS


def test_one_failing_arb_does_not_stop_capture_of_the_others(settings, monkeypatch, caplog):
    w1, w2 = World(settings), World(settings, suffix="2")
    capture, tracker = Capture(settings), ArbTracker(settings.engine.confirm_seconds)
    markets, pairs, closed = {**w1.markets, **w2.markets}, [w1.pair, w2.pair], []
    real = capture._moment

    def flaky(now, kind, opp, *rest):
        if opp.pair_key == w1.pair.pair_key:
            raise RuntimeError("boom")
        return real(now, kind, opp, *rest)

    monkeypatch.setattr(capture, "_moment", flaky)

    def step(t: float, **books) -> None:
        for w in (w1, w2):
            w.books(at(t), **books)
        found = [o for w in (w1, w2) for o in evaluate_pair(w.pair, w.left, w.right, settings, at(t), NAMES)]
        update = tracker.update(found, at(t))
        capture.observe(at(t), pairs, markets.get, update)
        closed.extend(update.closed)

    with caplog.at_level("ERROR", logger="backend.engine.capture"):
        step(0)
        step(5)
        step(6, right_b=[(0.70, 50)])
    by_pair = {c.last.pair_key: c.capture for c in closed}
    assert by_pair[w2.pair.pair_key]["confirm_profit_usd"] is not None  # вторая вилка собрана полностью
    failed = by_pair[w1.pair.pair_key]
    assert "confirm_profit_usd" not in failed and failed["capture_version"] == 1  # строка пишется, без снимков
    assert sum("could not observe" in r.getMessage() for r in caplog.records) == 1  # одна строка за серию


def test_a_reappearance_starts_with_a_clean_state(settings):
    w = World(settings, start=at(3600))
    lifecycle(w)
    w.books(at(10), right_b=[(0.50, 30), (0.52, 500)])  # вернулась с меньшим объёмом
    w.step(at(10))
    lifecycle(w, times=(15,), close_at=16)
    first, second = w.closed
    rec = second.capture
    assert (rec["peak_at"], rec["confirmed_at"]) == (at(10).isoformat(), at(15).isoformat())
    assert rec["peak_profit_usd"] == second.max_profit_usd < first.max_profit_usd
    assert rec["minutes_to_start"] == round((3600 - 10) / 60, 2)


def test_capture_does_not_change_the_arbs_found(settings):
    """Регрессия «поиск не меняется»: со сбором данных и без него — те же вилки и те же строки истории."""

    def run(enabled: bool):
        settings.capture.enabled = enabled
        w, seen = World(settings, start=at(60)), []
        for t, books in ((0, {}), (2, {"right_b": [(0.50, 90), (0.52, 500)]}), (5, {}), (6, {"left_a": [(0.41, 50)]}),
                         (8, {"right_b": [(0.70, 50)]})):
            w.books(at(t), **books)
            seen.append([o.model_dump() for o in w.step(at(t))])
        return seen, [c.model_dump(exclude={"capture"}) for c in w.closed]

    assert run(True) == run(False)


async def test_scanner_stop_writes_the_data_of_active_arbs(settings, tmp_path, monkeypatch):
    clock = {"now": at(0)}
    monkeypatch.setattr(scanner_module, "utcnow", lambda: clock["now"])
    db = Database(tmp_path / "stop.db")
    await db.connect()
    scanner = Scanner(settings, {}, db)
    w = World(settings, start=at(600))
    scanner._merge("polymarket", [w.left])
    scanner._merge("kalshi", [w.right])
    scanner.pairs = [w.pair]
    for t in (0, 6):
        clock["now"] = at(t)
        w.books(at(t))
        await scanner.evaluate()
    await scanner.stop()  # вилка ещё жива: пишется при остановке вместе с данными
    (row,) = (await db.list_history())["items"]
    assert row["confirmed"] and row["phase"] == "prematch" and row["confirm_profit_usd"] is not None
    await db.close()
