"""Resolution-rule parsing and comparison on real rule texts."""

from backend.matching.rules import STAKE_PROFILE, STAKE_RULES, compare_rules, parse_rules
from tests.conftest import load_fixture


def _texts():
    pm_event = load_fixture("polymarket_event.json")
    pm_rules = next(m["description"] for m in pm_event["markets"] if m["sportsMarketType"] == "moneyline")
    k_event = load_fixture("kalshi_event.json")
    market = k_event["markets"][0]
    k_rules = f"{market['rules_primary']}\n{market['rules_secondary']}"
    return pm_rules, k_rules


def test_parse_polymarket_rules():
    profile = parse_rules(_texts()[0])
    assert profile.cancel == "50-50"
    assert profile.tie == "50-50"
    assert profile.postpone_window_hours == 14 * 24
    assert profile.postpone_fallback == "50-50"
    assert profile.forfeit_before_start == "50-50"
    assert profile.forfeit_after_start == "official"


def test_parse_kalshi_rules():
    profile = parse_rules(_texts()[1])
    assert profile.cancel == "fair_price"
    assert profile.postpone_window_hours == 48
    assert profile.postpone_fallback == "fair_price"
    assert profile.forfeit_before_start == "fair_price"
    assert profile.forfeit_after_start == "official"
    assert profile.tie is None


def test_compare_reports_real_differences():
    pm_rules, k_rules = _texts()
    warnings = compare_rules(parse_rules(pm_rules), parse_rules(k_rules), "Polymarket", "Kalshi")
    by_field = {w.field: w for w in warnings}
    assert by_field["cancel"].severity == "high"
    assert by_field["forfeit_before_start"].severity == "high"
    assert by_field["postpone_window_hours"].severity == "medium"
    assert "14 дн." in by_field["postpone_window_hours"].message
    assert "48 ч" in by_field["postpone_window_hours"].message
    assert by_field["tie"].severity == "info"
    assert "forfeit_after_start" not in by_field  # same on both platforms


def test_identical_or_empty_rules_give_no_warnings():
    pm_rules, _ = _texts()
    assert compare_rules(parse_rules(pm_rules), parse_rules(pm_rules), "A", "B") == []
    assert compare_rules(parse_rules(""), parse_rules(""), "A", "B") == []


def test_alternative_wordings():
    after = parse_rules("If a team forfeits after the match has started, the market resolves per the official result.")
    assert after.forfeit_after_start == "official" and after.forfeit_before_start is None
    during = parse_rules("If the match is forfeited during play, the official result applies.")
    assert during.forfeit_after_start == "official"
    both = parse_rules("If the match is cancelled or forfeited before play begins, the market will resolve to the fair market price.")
    assert both.cancel == "fair_price" and both.forfeit_before_start == "fair_price"
    no = parse_rules("If the match is cancelled, this market resolves to No.")
    assert no.cancel == "no"


def test_stake_profile_voids_where_polymarket_and_kalshi_settle():
    # Stake's summary text is parsed like any rules text and gives exactly the Stake profile.
    assert parse_rules(STAKE_RULES) == STAKE_PROFILE
    assert STAKE_PROFILE.postpone_window_hours == 24
    pm_rules, k_rules = _texts()
    vs_pm = {w.field: w for w in compare_rules(parse_rules(pm_rules), STAKE_PROFILE, "Polymarket", "Stake")}
    assert {f: w.severity for f, w in vs_pm.items()} == {
        "cancel": "high", "postpone_window_hours": "medium", "postpone_fallback": "medium",
        "forfeit_before_start": "high", "forfeit_after_start": "medium", "tie": "high",
    }
    assert vs_pm["cancel"].message == "Отмена матча: Polymarket — 50/50, Stake — возврат/аннулирование"
    assert "14 дн." in vs_pm["postpone_window_hours"].message and "24 ч" in vs_pm["postpone_window_hours"].message
    assert vs_pm["forfeit_after_start"].left == "официальный результат"
    vs_k = {w.field: w.severity for w in compare_rules(parse_rules(k_rules), STAKE_PROFILE, "Kalshi", "Stake")}
    assert vs_k == {
        "cancel": "high", "postpone_window_hours": "medium", "postpone_fallback": "medium",
        "forfeit_before_start": "high", "forfeit_after_start": "medium", "tie": "info",  # Kalshi: no tie clause
    }
    assert compare_rules(STAKE_PROFILE, parse_rules(STAKE_RULES), "Stake", "Stake") == []
