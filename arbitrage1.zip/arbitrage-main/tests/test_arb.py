"""Arbitrage maths: directions, fees, volume, freshness, depth modes."""

from datetime import timedelta

import pytest

from backend.engine.arb import direction_legs, evaluate_pair, execute_best_level, execute_walk_book, LegInput
from backend.config import PlatformFeeConfig
from backend.models import FeeSpec, Level, utcnow
from tests.conftest import KALSHI_FEE, PM_FEE, make_market, make_pair


def _markets(left_fee=PM_FEE, right_fee=KALSHI_FEE, swapped=False, **kw):
    left = make_market(
        "polymarket", "pm1", "NIP", "Liquid", asks_a=[(0.40, 100)], asks_b=[(0.62, 100)], fee=left_fee, **kw
    )
    if swapped:
        right = make_market(
            "kalshi", "k1", "Liquid", "NIP", asks_a=[(0.50, 50)], asks_b=[(0.62, 80)], fee=right_fee, best_of=None
        )
    else:
        right = make_market(
            "kalshi", "k1", "NIP", "Liquid", asks_a=[(0.62, 80)], asks_b=[(0.50, 50)], fee=right_fee, best_of=None
        )
    return left, right, make_pair(left, right, swapped=swapped)


def test_direction_legs_mapping():
    left, right, pair = _markets()
    assert direction_legs(pair, "A") == ("a", "b")
    assert direction_legs(pair, "B") == ("b", "a")
    pair.swapped = True
    assert direction_legs(pair, "A") == ("a", "a")
    assert direction_legs(pair, "B") == ("b", "b")


def test_arb_with_fees_and_volume(settings):
    left, right, pair = _markets()
    arbs = evaluate_pair(pair, left, right, settings, utcnow())
    assert len(arbs) == 1  # only "buy NIP on Polymarket + buy Liquid on Kalshi"
    arb = arbs[0]
    assert arb.direction == "A"
    assert arb.leg1.outcome == "NIP" and arb.leg2.outcome == "Liquid"
    assert arb.sum_ask == pytest.approx(0.90)
    assert arb.contracts == pytest.approx(50)  # min of the two best-level sizes
    # Polymarket fee 50*0.05*0.4*0.6 = 0.6; Kalshi fee ceil_cent(50*0.07*0.25) = 0.88
    assert arb.fees_usd == pytest.approx(1.48)
    assert arb.volume_usd == pytest.approx(46.48)
    assert arb.profit_usd == pytest.approx(3.52)
    assert arb.profit_pct == pytest.approx(3.52 / 46.48 * 100, abs=1e-3)
    assert arb.cost_per_contract == pytest.approx(46.48 / 50)


def test_swapped_orientation_gives_same_result(settings):
    left, right, pair = _markets(swapped=True)
    arbs = evaluate_pair(pair, left, right, settings, utcnow())
    assert len(arbs) == 1
    assert arbs[0].leg2.outcome == "Liquid"
    assert arbs[0].profit_usd == pytest.approx(3.52)


def test_profit_formula_without_fees(settings):
    left, right, pair = _markets(left_fee=FeeSpec(), right_fee=FeeSpec())
    arb = evaluate_pair(pair, left, right, settings, utcnow())[0]
    cost = 0.90
    assert arb.cost_per_contract == pytest.approx(cost)
    assert arb.profit_pct == pytest.approx((1 - cost) / cost * 100, abs=1e-3)


def test_no_arb_when_cost_at_least_one(settings):
    left = make_market("polymarket", "pm1", asks_a=[(0.50, 100)], asks_b=[(0.51, 100)])
    right = make_market("kalshi", "k1", asks_a=[(0.50, 100)], asks_b=[(0.50, 100)])
    assert evaluate_pair(make_pair(left, right), left, right, settings, utcnow()) == []


def test_fees_can_kill_a_gross_arb(settings):
    left = make_market("polymarket", "pm1", asks_a=[(0.49, 100)], asks_b=[(0.60, 100)], fee=PM_FEE)
    right = make_market("kalshi", "k1", asks_a=[(0.60, 100)], asks_b=[(0.50, 100)], fee=KALSHI_FEE)
    # gross 0.99 < 1, but fees (~0.0125 + 0.0175 per contract) make it a loss
    assert evaluate_pair(make_pair(left, right), left, right, settings, utcnow()) == []


def test_stale_side_blocks_arb(settings):
    old = utcnow() - timedelta(seconds=settings.engine.stale_seconds + 1)
    left, right, pair = _markets()
    right.updated_at = old
    assert evaluate_pair(pair, left, right, settings, utcnow()) == []
    right.updated_at = None
    assert evaluate_pair(pair, left, right, settings, utcnow()) == []


def test_min_order_size_blocks_tiny_size(settings):
    left = make_market("polymarket", "pm1", asks_a=[(0.40, 3)], asks_b=[(0.62, 100)], min_order_size=5)
    right = make_market("kalshi", "k1", asks_a=[(0.62, 80)], asks_b=[(0.50, 50)])
    assert evaluate_pair(make_pair(left, right), left, right, settings, utcnow()) == []


def test_min_profit_and_volume_filters(settings):
    left, right, pair = _markets()
    settings.engine.min_profit_pct = 50
    assert evaluate_pair(pair, left, right, settings, utcnow()) == []
    settings.engine.min_profit_pct = 0
    settings.engine.min_volume_usd = 1000
    assert evaluate_pair(pair, left, right, settings, utcnow()) == []


def test_extra_costs_are_included(settings):
    left, right, pair = _markets(left_fee=FeeSpec(), right_fee=FeeSpec())
    settings.fees.model_extra["polymarket"] = {"extra_cost_per_contract": 0.01, "fixed_cost_per_trade_usd": 0.5}
    arb = evaluate_pair(pair, left, right, settings, utcnow())[0]
    assert arb.extra_costs_usd == pytest.approx(50 * 0.01 + 0.5)
    assert arb.profit_usd == pytest.approx(50 * 0.10 - 1.0)


def test_walk_book_takes_deeper_levels_while_profitable():
    leg1 = LegInput(
        asks=[Level(price=0.40, size=10), Level(price=0.45, size=10), Level(price=0.55, size=100)],
        fee=FeeSpec(), fee_cfg=PlatformFeeConfig(),
    )
    leg2 = LegInput(asks=[Level(price=0.50, size=15), Level(price=0.52, size=100)], fee=FeeSpec(), fee_cfg=PlatformFeeConfig())
    execution = execute_walk_book(leg1, leg2)
    # pairs: 10 @ (0.40+0.50), 5 @ (0.45+0.50), 5 @ (0.45+0.52); next 0.55+0.52 > 1 stops
    assert execution.contracts == pytest.approx(20)
    assert execution.gross == pytest.approx(10 * 0.90 + 5 * 0.95 + 5 * 0.97)
    assert execution.profit == pytest.approx(20 - execution.gross)


def test_walk_book_mode_in_evaluate(settings):
    settings.engine.depth_mode = "walk_book"
    left = make_market("polymarket", "pm1", asks_a=[(0.40, 10), (0.42, 40)], asks_b=[(0.62, 100)])
    right = make_market("kalshi", "k1", asks_a=[(0.62, 80)], asks_b=[(0.50, 100)])
    arb = evaluate_pair(make_pair(left, right), left, right, settings, utcnow())[0]
    assert arb.contracts == pytest.approx(50)
    assert arb.leg1.avg_price == pytest.approx((10 * 0.40 + 40 * 0.42) / 50)


def test_best_level_aggregates_instruments_at_same_price(settings):
    left = make_market("polymarket", "pm1", asks_a=[(0.40, 100)], asks_b=[(0.62, 100)])
    right = make_market("kalshi", "k1", asks_a=[(0.62, 80)], asks_b=[(0.50, 3)], fee=KALSHI_FEE)
    right.asks_b = [Level(price=0.50, size=3, instrument="YES «Liquid»"), Level(price=0.50, size=4, instrument="NO «NIP»")]
    arb = evaluate_pair(make_pair(left, right), left, right, settings, utcnow())[0]
    assert arb.contracts == pytest.approx(7)  # 3 + 4 at the same price
    assert arb.leg2.instrument == "YES «Liquid» ×3 + NO «NIP» ×4"
    # Two separate Kalshi orders: each fee is rounded up on its own (0.0525 -> 0.06, 0.07 -> 0.07).
    assert arb.leg2.fee_usd == pytest.approx(0.06 + 0.07)


def test_fixed_cost_is_charged_per_order(settings):
    settings.fees.model_extra["kalshi"] = {"fixed_cost_per_trade_usd": 0.10}
    left = make_market("polymarket", "pm1", asks_a=[(0.40, 100)], asks_b=[(0.62, 100)])
    right = make_market("kalshi", "k1", asks_a=[(0.62, 80)], asks_b=[(0.50, 3)])
    right.asks_b = [Level(price=0.50, size=3, instrument="YES «Liquid»"), Level(price=0.50, size=4, instrument="NO «NIP»")]
    arb = evaluate_pair(make_pair(left, right), left, right, settings, utcnow())[0]
    assert arb.extra_costs_usd == pytest.approx(0.20)


def _kalshi_leg(levels, min_order_size=1.0):
    """A Kalshi-style leg: (price, size, instrument) levels, one order per instrument."""
    return LegInput(
        asks=[Level(price=p, size=q, instrument=inst) for p, q, inst in levels],
        fee=FeeSpec(),
        fee_cfg=PlatformFeeConfig(),
        min_order_size=min_order_size,
    )


def _pm_leg(levels, min_order_size=0.0):
    return LegInput(
        asks=[Level(price=p, size=q) for p, q in levels], fee=FeeSpec(), fee_cfg=PlatformFeeConfig(),
        min_order_size=min_order_size,
    )


def test_split_order_below_minimum_is_dropped_at_best_level():
    # 0.5 contracts of YES «Liquid» cannot be an order on its own (Kalshi minimum 1): only NO «NIP» is used.
    kalshi = _kalshi_leg([(0.50, 0.5, "YES «Liquid»"), (0.50, 4, "NO «NIP»")])
    execution = execute_best_level(_pm_leg([(0.40, 100)]), kalshi)
    assert execution.contracts == pytest.approx(4)
    assert {inst for _, _, inst in execution.fills2} == {"NO «NIP»"}


def test_split_order_trailing_part_below_minimum_is_dropped():
    # The other leg allows 3.5 contracts: YES ×3 + NO ×0.5 would make a 0.5-contract NO order. The result is
    # conservative (NO alone could cover 3.5): split parts are dropped, never rebalanced.
    kalshi = _kalshi_leg([(0.50, 3, "YES «Liquid»"), (0.50, 4, "NO «NIP»")])
    execution = execute_best_level(_pm_leg([(0.40, 3.5)]), kalshi)
    assert execution.contracts == pytest.approx(3)
    assert execution.fills2 == [(0.50, 3, "YES «Liquid»")]
    assert execution.fills1 == [(0.40, 3, None)]


def test_split_orders_all_below_minimum_give_no_execution():
    kalshi = _kalshi_leg([(0.50, 0.6, "YES «Liquid»"), (0.50, 0.7, "NO «NIP»")])
    assert execute_best_level(_pm_leg([(0.40, 100)]), kalshi) is None
    assert execute_walk_book(_pm_leg([(0.40, 100)]), kalshi) is None


def test_walk_book_drops_small_instrument_and_uses_the_next_one():
    # The cheapest Kalshi level is a 0.5-contract YES order (below the minimum): walk the NO book instead.
    kalshi = _kalshi_leg([(0.40, 0.5, "YES «Liquid»"), (0.42, 10, "NO «NIP»"), (0.47, 10, "NO «NIP»")])
    execution = execute_walk_book(_pm_leg([(0.50, 15)]), kalshi)
    assert execution.contracts == pytest.approx(15)
    assert {inst for _, _, inst in execution.fills2} == {"NO «NIP»"}
    assert execution.gross == pytest.approx(15 * 0.50 + 10 * 0.42 + 5 * 0.47)


def test_small_kalshi_leftover_does_not_empty_the_polymarket_leg():
    # Taking the 0.5-contract leftover would also make the Polymarket order (minimum 5 shares) too small;
    # only the leftover must be dropped, in both depth modes.
    kalshi = _kalshi_leg([(0.40, 0.5, "YES «Liquid»"), (0.42, 100, "NO «NIP»")])
    pm = _pm_leg([(0.50, 100)], min_order_size=5)
    for execute in (execute_best_level, execute_walk_book):
        execution = execute(pm, kalshi)
        assert execution.contracts == pytest.approx(100)
        assert {inst for _, _, inst in execution.fills2} == {"NO «NIP»"}


def test_polymarket_minimum_still_applies_after_dropping_a_leftover():
    kalshi = _kalshi_leg([(0.40, 0.5, "YES «Liquid»"), (0.42, 4, "NO «NIP»")])
    assert execute_best_level(_pm_leg([(0.50, 100)], min_order_size=5), kalshi) is None  # 4 contracts < 5 shares
    assert execute_best_level(_pm_leg([(0.50, 3)], min_order_size=5), kalshi) is None  # Polymarket depth 3 < 5


def test_split_order_minimum_in_evaluate_pair(settings):
    left = make_market("polymarket", "pm1", asks_a=[(0.40, 100)], asks_b=[(0.62, 100)], min_order_size=5)
    right = make_market("kalshi", "k1", asks_a=[(0.62, 80)], asks_b=[(0.50, 3)], fee=KALSHI_FEE, min_order_size=1)
    right.asks_b = [Level(price=0.50, size=0.4, instrument="YES «Liquid»"), Level(price=0.51, size=6, instrument="NO «NIP»")]
    arb = evaluate_pair(make_pair(left, right), left, right, settings, utcnow())[0]
    assert arb.contracts == pytest.approx(6)
    assert arb.leg2.instrument == "NO «NIP»"
    assert arb.leg2.ask == pytest.approx(0.51)
