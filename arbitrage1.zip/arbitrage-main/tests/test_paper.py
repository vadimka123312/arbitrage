"""Бумажная проверка: отдельный REST-запрос стаканов через N секунд после подтверждения, сравнение со стаканом сканера,
очередь проверок, запись в базу, запросы адаптеров на записанных ответах API."""

from __future__ import annotations

import asyncio
import json
import sqlite3
from datetime import timedelta

import httpx
import pytest

from backend.adapters.base import MarketAdapter
from backend.adapters.kalshi import KalshiAdapter
from backend.adapters.mock import MockAdapter, reset_worlds
from backend.adapters.polymarket import PolymarketAdapter
from backend.engine.arb import evaluate_pair
from backend.engine.paper import PaperChecker, PaperJob
from backend.engine.scanner import Scanner
from backend.engine.tracker import ArbTracker
from backend.models import Level, NormalizedMarket, utcnow
from backend.net import HttpClient, HttpError
from backend.stats import collect
from backend.storage.db import SCHEMA, Database
from tests.conftest import KALSHI_FEE, PM_FEE, load_fixture, make_market, make_pair
from tests.test_adapters import KALSHI_SERIES_META
from tests.test_stake import SLUG, make_adapter, recorded_api


class FakeAdapter(MarketAdapter):
    """Площадка, у которой «отдельный запрос» возвращает заданный тестом стакан или ошибку."""

    def __init__(self, platform: str, settings, books=None, error: Exception | None = None, supported: bool = True):
        from backend.config import PlatformConfig

        super().__init__(platform, PlatformConfig(adapter="x", name=platform.title()), settings)
        self.books = books  # (asks_a, asks_b) для ответа
        self.error = error
        self.supported = supported
        self.requests = 0

    async def fetch_book(self, market: NormalizedMarket) -> NormalizedMarket | None:
        self.requests += 1
        if not self.supported:
            return None
        if self.error is not None:
            raise self.error
        copy = market.model_copy(deep=True)
        if self.books is not None:
            asks_a, asks_b = self.books
            copy.set_books([Level(price=p, size=s) for p, s in asks_a], [Level(price=p, size=s) for p, s in asks_b],
                           None, None, utcnow())
        else:
            copy.updated_at = utcnow()
        return copy

    async def fetch_markets(self):
        return []

    async def subscribe_prices(self, markets, on_update):
        return None

    def normalize(self, raw):
        return []


class MemoryDb:
    def __init__(self):
        self.rows: list[dict] = []

    async def add_paper_checks(self, rows):
        self.rows.extend(rows)


def world(settings):
    """Пара с вилкой NIP @0,40 (Polymarket) + Liquid @0,50 (Kalshi), подтверждённая сейчас."""
    now = utcnow()
    left = make_market("polymarket", "pm1", asks_a=[(0.40, 100), (0.42, 300)], asks_b=[(0.62, 100)], fee=PM_FEE,
                       updated_at=now, min_order_size=5)
    right = make_market("kalshi", "k1", asks_a=[(0.62, 80)], asks_b=[(0.50, 50), (0.52, 500)], fee=KALSHI_FEE,
                        updated_at=now, min_order_size=1)
    pair = make_pair(left, right)
    settings.engine.confirm_seconds = 0
    tracker = ArbTracker(0)
    update = tracker.update(evaluate_pair(pair, left, right, settings, now), now)
    (tracked,) = update.newly_confirmed
    return left, right, pair, tracked


def job_of(tracked, pair, left, right, delay=0.0) -> PaperJob:
    """Проверка, срок которой уже наступил (по умолчанию — сразу после подтверждения)."""
    return PaperJob(
        arb_id=tracked.arb_id, direction=tracked.current.direction, first_seen=tracked.first_seen,
        confirmed_at=tracked.confirmed_at, delay_sec=delay, pair=pair, left=left, right=right,
        left_team=tracked.current.leg1.outcome, right_team=tracked.current.leg2.outcome,
        confirm_profit_usd=tracked.current.profit_usd, confirm_volume_usd=tracked.current.volume_usd,
    )


async def test_arb_left_in_the_rest_books_and_the_scanner_book_matches(settings):
    left, right, pair, tracked = world(settings)
    adapters = {"polymarket": FakeAdapter("polymarket", settings), "kalshi": FakeAdapter("kalshi", settings)}
    markets = {left.key: left, right.key: right}
    checker = PaperChecker(settings, adapters, MemoryDb(), markets.get)
    row = await checker.check(job_of(tracked, pair, left, right))
    assert (row["status"], row["arb_exists"], row["reason"]) == ("ok", 1, None)
    assert row["profit_usd"] == tracked.current.profit_usd and row["volume_usd"] == tracked.current.volume_usd
    assert (row["scanner_exists"], row["scanner_profit_usd"], row["books_match"]) == (1, row["profit_usd"], 1)
    assert row["first_seen"] == tracked.first_seen.isoformat() and row["delay_sec"] == 0.0
    assert 0 <= row["actual_delay_sec"] < 5
    stakes = json.loads(row["stake_profits"])
    assert [s["stake_usd"] for s in stakes] == [10, 25, 50, 100, 250] and stakes[0]["profit_usd"] > 0
    assert row["optimal_stake_usd"] > 0 and row["optimal_profit_usd"] > 0
    details = json.loads(row["details"])
    pm_leg, kalshi_leg = details["legs"]
    assert (pm_leg["platform"], pm_leg["rest"]["buy"], pm_leg["outcome"]) == ("polymarket", "a", "NIP")
    assert pm_leg["rest"]["best"] == [0.40, 100.0] and pm_leg["scanner"]["best"] == [0.40, 100.0]
    assert (kalshi_leg["rest"]["buy"], kalshi_leg["rest"]["asks"][1]) == ("b", [0.52, 500.0, None])
    assert details["rest_quote"]["profit_usd"] == row["profit_usd"]
    # Стаканы сканера не тронуты.
    assert left.asks_a[0].size == 100 and right.asks_b[0].size == 50


async def test_arb_gone_in_the_rest_books_while_the_scanner_still_shows_it(settings):
    left, right, pair, tracked = world(settings)
    adapters = {
        "polymarket": FakeAdapter("polymarket", settings),
        # Отдельный запрос видит, что заявка Liquid @0,50 ушла: лучшая цена 0,61.
        "kalshi": FakeAdapter("kalshi", settings, books=([(0.62, 80)], [(0.61, 500)])),
    }
    markets = {left.key: left, right.key: right}
    row = await PaperChecker(settings, adapters, MemoryDb(), markets.get).check(job_of(tracked, pair, left, right))
    assert (row["status"], row["arb_exists"], row["reason"]) == ("ok", 0, "prices, depth or filters changed")
    assert row.get("profit_usd") is None and row.get("volume_usd") is None
    assert row.get("stake_profits") is None  # у исчезнувшей вилки прибыли при ставках нет
    assert row["scanner_exists"] == 1 and row["books_match"] == 0  # стакан сканера отстал от площадки
    assert json.loads(row["details"])["legs"][1]["rest"]["best"] == [0.61, 500.0]


async def test_paused_trading_and_a_market_gone_from_the_scanner(settings):
    left, right, pair, tracked = world(settings)

    class Paused(FakeAdapter):
        async def fetch_book(self, market):
            copy = await super().fetch_book(market)
            copy.accepting_orders = False
            return copy

    adapters = {"polymarket": FakeAdapter("polymarket", settings), "kalshi": Paused("kalshi", settings)}
    # Сканер уже убрал рынок Kalshi: запрос идёт по копии из момента подтверждения, сравнения нет.
    markets = {left.key: left}
    row = await PaperChecker(settings, adapters, MemoryDb(), markets.get).check(job_of(tracked, pair, left, right))
    assert (row["arb_exists"], row["reason"]) == (0, "trading paused (kalshi)")
    assert row["scanner_exists"] is None and row["books_match"] is None


async def test_a_failed_request_is_no_data_not_a_gone_arb(settings):
    left, right, pair, tracked = world(settings)
    adapters = {
        "polymarket": FakeAdapter("polymarket", settings),
        "kalshi": FakeAdapter("kalshi", settings, error=HttpError("kalshi: GET /markets/orderbooks -> 503", 503)),
    }
    row = await PaperChecker(settings, adapters, MemoryDb(), {}.get).check(job_of(tracked, pair, left, right))
    assert (row["status"], row["arb_exists"]) == ("error", None)
    assert row["reason"] == "kalshi: GET /markets/orderbooks -> 503"  # площадка не повторяется
    assert json.loads(row["details"])["legs"][1]["error"].endswith("503")

    adapters["kalshi"] = FakeAdapter("kalshi", settings, supported=False)
    row = await PaperChecker(settings, adapters, MemoryDb(), {}.get).check(job_of(tracked, pair, left, right))
    assert (row["status"], row["arb_exists"], row["reason"]) == ("unsupported", None, "fetch not supported")


async def test_checks_run_at_their_delays_and_are_written(settings):
    left, right, pair, tracked = world(settings)
    settings.paper.delays_sec = [0.05, 0.15]
    adapters = {"polymarket": FakeAdapter("polymarket", settings), "kalshi": FakeAdapter("kalshi", settings)}
    db = MemoryDb()
    checker = PaperChecker(settings, adapters, db, {left.key: left, right.key: right}.get)
    task = asyncio.create_task(checker.run())
    tracked.confirmed_at = utcnow()
    checker.schedule(tracked, pair, left, right)
    assert checker.pending == 2
    await asyncio.sleep(0.02)
    assert db.rows == []  # раньше срока ничего не проверяется
    for _ in range(100):
        if len(db.rows) == 2:
            break
        await asyncio.sleep(0.01)
    assert [r["delay_sec"] for r in db.rows] == [0.05, 0.15] and checker.written == 2
    for row in db.rows:
        checked = utcnow().fromisoformat(row["checked_at"])
        assert checked >= tracked.confirmed_at + timedelta(seconds=row["delay_sec"])
    assert adapters["kalshi"].requests == 2 and checker.pending == 0
    # Отмена (остановка сканера) снимает ждущие проверки.
    tracked.confirmed_at = utcnow()
    settings.paper.delays_sec = [30.0]
    checker.schedule(tracked, pair, left, right)
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert checker.pending == 0


async def test_the_queue_is_bounded_and_paper_checks_can_be_off(settings, caplog):
    left, right, pair, tracked = world(settings)
    settings.paper.max_pending = 4
    checker = PaperChecker(settings, {}, MemoryDb(), {}.get)
    others = [tracked.model_copy(update={"first_seen": tracked.first_seen + timedelta(seconds=i)}) for i in (1, 2)]
    with caplog.at_level("WARNING", logger="backend.engine.paper"):
        checker.schedule(tracked, pair, left, right)  # 3 проверки
        checker.schedule(tracked, pair, left, right)  # то же появление ещё раз (порог подняли на лету): не ставится
        checker.schedule(others[0], pair, left, right)  # ещё 3 не помещаются
        checker.schedule(others[1], pair, left, right)
    assert checker.pending == 3 and checker.dropped == 6
    assert sum("paper.max_pending" in r.getMessage() for r in caplog.records) == 1  # одна строка за серию
    settings.paper.enabled = False
    off = PaperChecker(settings, {}, MemoryDb(), {}.get)
    off.schedule(tracked, pair, left, right)
    assert off.pending == 0


async def test_scanner_schedules_checks_and_the_history_item_shows_them(settings, tmp_path):
    settings.engine.confirm_seconds = 0
    settings.engine.history_min_lifetime_sec = 0  # одно наблюдение тоже попадает в историю
    settings.paper.delays_sec = [0.05]
    db = Database(tmp_path / "paper.db")
    await db.connect()
    adapters = {"polymarket": FakeAdapter("polymarket", settings), "kalshi": FakeAdapter("kalshi", settings)}
    scanner = Scanner(settings, adapters, db)
    left, right, pair, _ = world(settings)
    scanner._merge("polymarket", [left])
    scanner._merge("kalshi", [right])
    scanner.pairs = [pair]
    task = asyncio.create_task(scanner.paper.run())
    left.updated_at = right.updated_at = utcnow()
    await scanner.evaluate()
    assert scanner.paper.pending == 1
    for _ in range(100):
        if scanner.paper.written:
            break
        await asyncio.sleep(0.01)
    right.asks_b = [Level(price=0.70, size=10)]  # вилка исчезла: строка истории пишется
    await scanner.evaluate()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    (row,) = (await db.list_history())["items"]
    item = await db.get_history_item(row["id"])
    (check,) = item["paper_checks"]
    assert (check["status"], check["arb_exists"], check["delay_sec"]) == ("ok", 1, 0.05)
    assert check["first_seen"] == item["first_seen"] and isinstance(check["details"], dict)
    report = await collect(db, settings, days=1)
    (paper,) = report["totals"]["honest"]["paper"]
    assert (paper["delay_sec"], paper["checked"], paper["left"], paper["share_left"]) == (0.05, 1, 1, 1.0)
    await db.close()


async def test_old_database_gets_the_paper_table_and_reports_without_it(tmp_path, settings):
    path = tmp_path / "old.db"
    old = sqlite3.connect(path)
    old.executescript(SCHEMA.split("-- Бумажная проверка")[0])  # таблицы до этой версии
    old.close()
    reader = Database(path, read_only=True)
    await reader.connect()
    paper = (await collect(reader, settings, days=1))["totals"]["honest"]["paper"]
    assert [p["checked"] for p in paper] == [0, 0, 0]  # таблицы нет: «данных нет»
    await reader.close()
    db = Database(path)
    await db.connect()
    await db.close()
    names = {r[0] for r in sqlite3.connect(path).execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    assert "paper_checks" in names


# ---- запросы адаптеров на записанных ответах -------------------------------------------------------------


async def test_kalshi_fetch_book_reads_both_tickers_without_touching_the_cache(settings):
    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    market = adapter._normalize_event(load_fixture("kalshi_event.json"), "cs2", "KXCS2GAME", KALSHI_SERIES_META)[0]
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json=load_fixture("kalshi_orderbooks.json"))

    adapter.http = HttpClient("https://api.test", "kalshi", rate_per_sec=1000, transport=httpx.MockTransport(handler))
    before = (market.asks_a, market.updated_at)
    fresh = await adapter.fetch_book(market)
    assert requests[0].url.path == "/markets/orderbooks"
    assert requests[0].url.params.get_list("tickers") == [market.extra["ticker_a"], market.extra["ticker_b"]]
    assert (market.asks_a, market.updated_at) == before and adapter.books == {}  # ни рынок, ни кэш не изменились
    assert len(fresh.asks_a) > 1 and {lv.instrument.split(" ")[0] for lv in fresh.asks_a} == {"YES", "NO"}
    assert (utcnow() - fresh.updated_at).total_seconds() < 5

    def missing(request: httpx.Request) -> httpx.Response:
        data = load_fixture("kalshi_orderbooks.json")
        data["orderbooks"] = data["orderbooks"][:1]
        return httpx.Response(200, json=data)

    adapter.http = HttpClient("https://api.test", "kalshi", rate_per_sec=1000, transport=httpx.MockTransport(missing))
    with pytest.raises(ValueError, match="no orderbook"):
        await adapter.fetch_book(market)
    await adapter.http.aclose()


async def test_polymarket_fetch_book_posts_both_tokens(settings):
    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    market = adapter._normalize_event(load_fixture("polymarket_event.json"), "cs2")[0]
    token_a, token_b = market.extra["token_a"], market.extra["token_b"]
    payloads = []

    def handler(request: httpx.Request) -> httpx.Response:
        payloads.append(json.loads(request.content))
        return httpx.Response(200, json=[
            {"asset_id": token_b, "timestamp": "1792170000000", "bids": [{"price": "0.40", "size": "50"}],
             "asks": [{"price": "0.62", "size": "70"}, {"price": "0.61", "size": "30"}]},
            {"asset_id": token_a, "timestamp": "1792170001000", "bids": [{"price": "0.36", "size": "10"}],
             "asks": [{"price": "0.40", "size": "120"}]},
        ])

    adapter.clob = HttpClient("https://clob.test", "pm", rate_per_sec=1000, transport=httpx.MockTransport(handler))
    fresh = await adapter.fetch_book(market)
    assert payloads == [[{"token_id": token_a}, {"token_id": token_b}]]
    assert [(lv.price, lv.size) for lv in fresh.asks_b] == [(0.61, 30.0), (0.62, 70.0)]  # лучшая цена первой
    assert fresh.outcome_a_ask == 0.40 and fresh.outcome_a_bid == 0.36
    assert fresh.extra["book_exchange_ts"] == {"a": 1792170001000, "b": 1792170000000}
    assert "book_exchange_ts" not in market.extra and adapter.books == {}
    await adapter.clob.aclose()
    await adapter.gamma.aclose()


async def test_stake_fetch_book_reads_the_fixture_odds(settings, monkeypatch):
    requests: list[httpx.Request] = []
    adapter = make_adapter(settings, monkeypatch, recorded_api(requests))
    market = adapter.normalize({**load_fixture("stake_fixture_cloud9_m80.json"), "sport": "rainbow-six"})[0]
    cached = adapter.odds[SLUG]
    requests.clear()
    fresh = await adapter.fetch_book(market)
    assert [r.url.path for r in requests] == [f"/fixtures/{SLUG}"]
    assert fresh.outcome_a_ask == pytest.approx(1 / 2.7) and fresh.asks_a[0].size == pytest.approx(50 * 2.7)
    assert adapter.odds[SLUG] is cached  # кэш адаптера не заменён
    assert fresh.updated_at > cached.asked_at
    await adapter.stop()


async def test_mock_fetch_book_reads_the_mock_world(settings):
    reset_worlds()
    from backend.adapters import apply_mock_mode

    mock_settings = apply_mock_mode(settings)
    adapter = MockAdapter("kalshi", mock_settings.platforms["kalshi"], mock_settings)
    market = (await adapter.fetch_markets())[0]
    fresh = await adapter.fetch_book(market)
    assert fresh is not market and fresh.key == market.key and fresh.asks_a
    market.extra["mock_idx"] = -1
    with pytest.raises(ValueError):
        await adapter.fetch_book(market)


# ---- поправки по ревью: порядок команд, опоздания, тайм-аут, параллельность, ошибки ---------------------------


def reordered(market: NormalizedMarket) -> NormalizedMarket:
    """Та же площадка перечислила команды в другом порядке (как Stake): исходы и стаканы меняются местами."""
    copy = market.model_copy(deep=True)
    copy.team_a, copy.team_b = market.team_b, market.team_a
    copy.set_books(list(market.asks_b), list(market.asks_a), None, None, market.updated_at)
    return copy


async def test_reordered_teams_are_priced_by_name_not_by_the_old_swapped_flag(settings):
    """Регрессия: пара с флагом swapped из момента подтверждения и рынок с новым порядком команд дали бы ложную
    вилку (одна и та же команда на обеих ногах). Нога определяется по имени команды."""
    left, right, pair, tracked = world(settings)
    expected = tracked.current.profit_usd
    flipped = reordered(right)  # Kalshi теперь Liquid / NIP

    class Flipping(FakeAdapter):
        async def fetch_book(self, market):
            copy = reordered(market) if market.team_a == "NIP" else market.model_copy(deep=True)
            copy.updated_at = utcnow()
            return copy

    adapters = {"polymarket": FakeAdapter("polymarket", settings), "kalshi": Flipping("kalshi", settings)}
    flipped.updated_at = utcnow()
    markets = {left.key: left, right.key: flipped}  # сканер уже взял новый порядок, пара ещё старая
    row = await PaperChecker(settings, adapters, MemoryDb(), markets.get).check(job_of(tracked, pair, left, right))
    assert (row["status"], row["arb_exists"], row["profit_usd"]) == ("ok", 1, expected)
    assert (row["scanner_exists"], row["scanner_profit_usd"], row["books_match"]) == (1, expected, 1)
    legs = json.loads(row["details"])["legs"]
    assert (legs[1]["outcome"], legs[1]["rest"]["buy"], legs[1]["scanner"]["buy"]) == ("Liquid", "a", "a")
    # Команда сменилась (другой матч): «данных нет», а не вилка.
    renamed = right.model_copy(deep=True)
    renamed.team_b = "Spirit"
    adapters["kalshi"] = FakeAdapter("kalshi", settings)
    row = await PaperChecker(settings, adapters, MemoryDb(), {left.key: left, right.key: renamed}.get).check(
        job_of(tracked, pair, left, renamed))
    assert (row["status"], row["arb_exists"], row["reason"]) == ("error", None, "teams changed (kalshi)")


async def test_late_and_slow_checks_are_no_data(settings):
    left, right, pair, tracked = world(settings)
    adapters = {"polymarket": FakeAdapter("polymarket", settings), "kalshi": FakeAdapter("kalshi", settings)}
    checker = PaperChecker(settings, adapters, MemoryDb(), {}.get)
    late = job_of(tracked, pair, left, right)
    late.confirmed_at = utcnow() - timedelta(seconds=settings.paper.max_late_sec + 3)
    row = await checker.check(late)
    assert (row["status"], row["arb_exists"]) == ("late", None) and row["reason"].startswith("started 8.")
    assert row["actual_delay_sec"] >= 8 and adapters["kalshi"].requests == 0  # без запроса

    class Slow(FakeAdapter):
        async def fetch_book(self, market):
            copy = await super().fetch_book(market)
            copy.updated_at = utcnow() - timedelta(seconds=settings.engine.stale_seconds + 1)  # ответ шёл дольше 10 с
            return copy

    adapters["kalshi"] = Slow("kalshi", settings)
    row = await PaperChecker(settings, adapters, MemoryDb(), {}.get).check(job_of(tracked, pair, left, right))
    assert (row["status"], row["arb_exists"], row["reason"]) == ("error", None, "slow answer (kalshi)")


async def test_concurrency_timeout_and_failures_are_bounded_and_logged_once(settings, caplog):
    left, right, pair, tracked = world(settings)
    settings.paper.delays_sec = [0.01]
    settings.paper.max_concurrency = 2
    settings.paper.check_timeout_sec = 0.2
    active = {"now": 0, "max": 0}

    class Hanging(FakeAdapter):
        async def fetch_book(self, market):
            active["now"] += 1
            active["max"] = max(active["max"], active["now"])
            try:
                await asyncio.sleep(10)  # ответа нет
            finally:
                active["now"] -= 1

    adapters = {"polymarket": Hanging("polymarket", settings), "kalshi": Hanging("kalshi", settings)}

    class FailingDb(MemoryDb):
        async def add_paper_checks(self, rows):
            await super().add_paper_checks(rows)
            if len(self.rows) > 2:
                raise sqlite3.OperationalError("disk full")

    db = FailingDb()
    checker = PaperChecker(settings, adapters, db, {}.get)
    task = asyncio.create_task(checker.run())
    with caplog.at_level("INFO", logger="backend.engine.paper"):
        for i in range(5):
            checker.schedule(tracked.model_copy(update={"first_seen": tracked.first_seen + timedelta(seconds=i),
                                                        "confirmed_at": utcnow()}), pair, left, right)
        for _ in range(300):
            if len(db.rows) == 5:
                break
            await asyncio.sleep(0.01)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
    assert active["max"] <= 2 * 2  # не больше 2 проверок одновременно, по запросу на каждую ногу
    assert any(r["reason"] == "timeout after 0.2 s" for r in db.rows)
    assert all(r["status"] in ("error", "late") for r in db.rows)  # зависший запрос — «данных нет», слот свободен
    messages = [r.getMessage() for r in caplog.records]
    assert sum(m.startswith("could not write a paper check") for m in messages) == 1  # одна строка за серию


async def test_a_failing_venue_is_logged_once_per_streak(settings, caplog):
    left, right, pair, tracked = world(settings)
    broken = FakeAdapter("kalshi", settings, error=HttpError("kalshi: GET /markets/orderbooks -> 404", 404))
    adapters = {"polymarket": FakeAdapter("polymarket", settings), "kalshi": broken}
    checker = PaperChecker(settings, adapters, MemoryDb(), {}.get)
    with caplog.at_level("INFO", logger="backend.engine.paper"):
        for _ in range(3):
            await checker.check(job_of(tracked, pair, left, right))
        broken.error = None
        await checker.check(job_of(tracked, pair, left, right))
    messages = [r.getMessage() for r in caplog.records]
    assert messages == ["paper checks: kalshi book request failed: kalshi: GET /markets/orderbooks -> 404",
                        "paper checks: kalshi book requests work again"]


async def test_kalshi_fetch_book_does_not_retry(settings):
    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    market = adapter._normalize_event(load_fixture("kalshi_event.json"), "cs2", "KXCS2GAME", KALSHI_SERIES_META)[0]
    calls = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(request)
        return httpx.Response(503)

    adapter.http = HttpClient("https://api.test", "kalshi", rate_per_sec=1000, backoff_base=0.001,
                              transport=httpx.MockTransport(handler))
    with pytest.raises(HttpError):
        await adapter.fetch_book(market)
    assert len(calls) == 1  # без повторов: следующая проверка всё равно будет
    await adapter.http.aclose()


async def test_stake_fetch_book_reports_changed_teams(settings, monkeypatch):
    data = load_fixture("stake_fixture_cloud9_m80.json")
    adapter = make_adapter(settings, monkeypatch, recorded_api())
    market = adapter.normalize({**data, "sport": "rainbow-six"})[0]
    other = market.model_copy(update={"team_b": "FURIA"})  # у рынка сканера другой соперник
    with pytest.raises(ValueError, match="teams changed"):
        await adapter.fetch_book(other)
    swapped = market.model_copy(update={"team_a": market.team_b, "team_b": market.team_a})
    fresh = await adapter.fetch_book(swapped)  # тот же матч, другой порядок: цены по именам
    assert fresh.team_a == "M80" and fresh.outcome_a_ask == pytest.approx(1 / 1.42)
    await adapter.stop()
