"""Cross-platform matching: orientation, time/format constraints, review bucket, overrides."""

from datetime import timedelta

import pytest

from backend.config import load_settings
from backend.matching.matcher import Matcher, make_pair_key
from backend.matching.normalizer import TeamNormalizer
from tests.conftest import T0, make_market


@pytest.fixture
def matcher():
    s = load_settings()
    return Matcher(s.matching, TeamNormalizer.from_file(s.resolve_path(s.matching.aliases_file)))


def pm(market_id, a, b, start=T0, bo=3, game="cs2"):
    return make_market("polymarket", market_id, a, b, start=start, best_of=bo, game=game)


def ks(market_id, a, b, start=T0, game="cs2"):
    return make_market("kalshi", market_id, a, b, start=start, best_of=None, game=game)


def test_reversed_team_order_is_detected(matcher):
    result = matcher.match([pm("p1", "NIP", "Liquid")], [ks("k1", "Liquid", "NIP")])
    assert len(result.pairs) == 1
    pair = result.pairs[0]
    assert pair.swapped is True
    assert pair.status == "auto"
    # team 100 %, time 100 %, format unknown (Kalshi) -> 0.7 + 0.2 + 0.1 * 0.5
    assert pair.confidence == pytest.approx(95.0)
    assert pair.format_check == "unknown"


def test_aliases_are_used(matcher):
    result = matcher.match([pm("p1", "Natus Vincere", "FaZe")], [ks("k1", "FaZe Clan", "NAVI")])
    assert len(result.pairs) == 1 and result.pairs[0].swapped


def test_different_game_never_matches(matcher):
    result = matcher.match([pm("p1", "Team Liquid", "G2", game="cs2")], [ks("k1", "Team Liquid", "G2", game="valorant")])
    assert result.pairs == [] and result.review == []


def test_format_mismatch_is_rejected(matcher):
    left = pm("p1", "NIP", "Liquid", bo=1)
    right = make_market("other", "o1", "NIP", "Liquid", start=T0, best_of=3)
    assert matcher.match([left], [right]).pairs == []
    right.best_of = 1
    pair = matcher.match([left], [right]).pairs[0]
    assert pair.format_check == "match" and pair.confidence == pytest.approx(100.0)


def test_time_tolerance(matcher):
    tol = matcher.cfg.time_tolerance_hours
    far = ks("k1", "NIP", "Liquid", start=T0 + timedelta(hours=tol + 0.5))
    assert matcher.match([pm("p1", "NIP", "Liquid")], [far]).pairs == []
    # 4.5 h apart: names identical but the schedule disagrees -> manual review
    mid = ks("k1", "NIP", "Liquid", start=T0 + timedelta(hours=4.5))
    result = matcher.match([pm("p1", "NIP", "Liquid")], [mid])
    assert result.pairs == []
    assert len(result.review) == 1 and result.review[0].status == "review"


def test_partial_name_goes_to_review(matcher):
    result = matcher.match([pm("p1", "ONIC PH", "Team Liquid PH", game="mlbb")], [ks("k1", "ONIC", "Team Liquid PH", game="mlbb")])
    assert result.pairs == []
    assert len(result.review) == 1


def test_academy_is_not_matched_with_main_team(matcher):
    left = [pm("p1", "Team Spirit", "MOUZ"), pm("p2", "Spirit Academy", "MOUZ NXT", start=T0 + timedelta(minutes=30))]
    right = [ks("k1", "Spirit Academy", "MOUZ NXT", start=T0 + timedelta(minutes=30)), ks("k2", "Spirit", "MOUZ")]
    result = matcher.match(left, right)
    got = {(p.left_key, p.right_key) for p in result.pairs}
    assert got == {("polymarket:p1", "kalshi:k2"), ("polymarket:p2", "kalshi:k1")}


def test_one_to_one_assignment_prefers_closest_time(matcher):
    left = [pm("p1", "HAVU", "Voca", start=T0)]
    right = [ks("k1", "HAVU", "Voca", start=T0 + timedelta(hours=3)), ks("k2", "Voca", "HAVU", start=T0)]
    result = matcher.match(left, right)
    assert len(result.pairs) == 1 and result.pairs[0].right_key == "kalshi:k2"


def test_overrides(matcher):
    left = [pm("p1", "NIP", "Liquid")]
    right = [ks("k1", "Liquid", "NIP")]
    key = make_pair_key("polymarket:p1", "kalshi:k1")
    blocked = matcher.match(left, right, {key: "blocked"})
    assert blocked.pairs == [] and len(blocked.blocked) == 1

    # A review pair becomes a confirmed pair.
    far = [ks("k1", "Liquid", "NIP", start=T0 + timedelta(hours=4.5))]
    confirmed = matcher.match(left, far, {key: "confirmed"})
    assert len(confirmed.pairs) == 1 and confirmed.pairs[0].status == "confirmed"

    # A confirmed pair is kept even when a hard constraint rejects it now.
    very_far = [ks("k1", "Liquid", "NIP", start=T0 + timedelta(hours=30))]
    kept = matcher.match(left, very_far, {key: "confirmed"})
    assert len(kept.pairs) == 1 and kept.pairs[0].status == "confirmed"


def test_pair_key_is_order_independent():
    assert make_pair_key("b:1", "a:2") == make_pair_key("a:2", "b:1") == "a:2|b:1"


def test_unknown_start_time_never_auto_matches(matcher):
    result = matcher.match([pm("p1", "NIP", "Liquid", start=None)], [ks("k1", "Liquid", "NIP")])
    assert result.pairs == []
    assert len(result.review) == 1 and result.review[0].auto_eligible is False


def test_large_start_time_gap_goes_to_review(matcher):
    # 2 h apart: names identical, confidence would pass, but a human must check the schedule.
    result = matcher.match([pm("p1", "NIP", "Liquid")], [ks("k1", "Liquid", "NIP", start=T0 + timedelta(hours=2))])
    assert result.pairs == [] and len(result.review) == 1
    # 1 h apart is still automatic.
    result = matcher.match([pm("p1", "NIP", "Liquid")], [ks("k1", "Liquid", "NIP", start=T0 + timedelta(hours=1))])
    assert len(result.pairs) == 1


def test_postponed_match_beyond_tolerance_goes_to_review(matcher):
    day_later = ks("k1", "Liquid", "NIP", start=T0 + timedelta(hours=24))
    result = matcher.match([pm("p1", "NIP", "Liquid")], [day_later])
    assert result.pairs == [] and len(result.review) == 1
    assert any("перенос" in r for r in result.review[0].reasons)
    # Similar (not identical) names that far apart are not suggested at all.
    assert matcher.match([pm("p1", "ONIC PH", "Liquid")], [ks("k1", "ONIC", "Liquid", start=T0 + timedelta(hours=24))]).review == []
    # Beyond review_max_hours nothing is suggested.
    far = ks("k1", "Liquid", "NIP", start=T0 + timedelta(hours=72))
    assert matcher.match([pm("p1", "NIP", "Liquid")], [far]).review == []


def test_strong_pair_held_for_review_is_not_replaced_by_a_weaker_auto_pair(matcher):
    # Same names but 2 h apart (only the time rule blocks it: 89.5 %) vs an alias at the same time (88 %).
    left = [pm("p1", "Gaimin Gladiators", "Tundra")]
    right = [
        ks("k1", "Gaimin Gladiators", "Tundra", start=T0 + timedelta(hours=2)),
        ks("k2", "GG", "Tundra"),
    ]
    result = matcher.match(left, right)
    assert result.pairs == []  # ambiguous: no automatic pair for p1
    assert [p.right_key for p in result.review] == ["kalshi:k1"]
    # Once the user blocks the held pair, the weaker candidate pairs automatically again.
    blocked = matcher.match(left, right, {make_pair_key("polymarket:p1", "kalshi:k1"): "blocked"})
    assert [p.right_key for p in blocked.pairs] == ["kalshi:k2"]
