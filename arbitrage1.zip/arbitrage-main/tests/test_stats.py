"""Statistics report: days in the configured time zone, totals, groups, uptime, database queries, CLI, API."""

from __future__ import annotations

import asyncio
import json
import sqlite3
import time
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import pytest
from pydantic import ValidationError

from backend.config import Settings, validate_timezone
from backend.engine.scanner import Scanner
from backend.models import ArbLeg, ArbOpportunity, ClosedArb, PlatformStatus
from backend.report import main as report_main
from backend.stats import build_report, collect, fmt_duration, fmt_hours, fmt_minutes, fmt_num, format_text, period_days
from backend.storage.db import Database

MSK = ZoneInfo("Europe/Moscow")
NOW = datetime(2026, 10, 16, 12, 0, tzinfo=timezone.utc)  # 15:00 in Moscow
NAMES = {"polymarket": "Polymarket", "kalshi": "Kalshi"}
GAMES = {"cs2": "CS2", "dota2": "Dota 2"}


def utc(text: str) -> datetime:
    return datetime.fromisoformat(text).replace(tzinfo=timezone.utc)


def row(
    first_seen: str,
    arb_id: str = "pm:1|k:1|A",
    pair_key: str = "pm:1|k:1",
    game: str = "cs2",
    lifetime: float = 20.0,
    profit_usd: float = 0.5,
    profit_pct: float = 2.0,
    volume: float = 10.0,
    legs: tuple[str, str] = ("polymarket", "kalshi"),
    teams: tuple[str, str] = ("NAVI", "FaZe"),
    healthy: int | None = None,
) -> dict:
    """A confirmed history row as returned by ``Database.stats_arbs`` (``healthy``: its minute's uptime row)."""
    return {
        "arb_id": arb_id, "pair_key": pair_key, "game": game, "event_title": f"{teams[0]} vs {teams[1]}",
        "tournament": "Major", "team_a": teams[0], "team_b": teams[1], "leg1_platform": legs[0],
        "leg2_platform": legs[1], "first_seen": utc(first_seen).isoformat(), "lifetime_sec": lifetime,
        "max_profit_pct": profit_pct, "max_volume_usd": volume, "max_profit_usd": profit_usd,
        "minute_healthy": healthy,
    }


def report(rows, days=3, candidates=None, uptime=None, top=10, now=NOW, tracking_since=None):
    period = period_days(MSK, days, now)
    return build_report(
        rows, candidates or {}, uptime or {}, period, tracking_since=tracking_since, tz_name="Europe/Moscow", now=now,
        platform_names=NAMES, game_names=GAMES, confirm_seconds=5.0, top=top,
    )


def test_days_are_moscow_calendar_days():
    days = period_days(MSK, 3, NOW)
    assert [d.day.isoformat() for d in days] == ["2026-10-14", "2026-10-15", "2026-10-16"]
    assert days[0].start == utc("2026-10-13T21:00:00") and days[-1].end == utc("2026-10-16T21:00:00")
    rep = report([
        row("2026-10-15T20:30:00"),  # 23:30 Moscow time, 15 October
        row("2026-10-15T21:30:00"),  # 00:30 Moscow time, already 16 October
        row("2026-10-13T20:59:59"),  # 23:59:59 on 13 October: outside the period
    ])
    assert [(d["date"], d["arbs"]) for d in rep["by_day"]] == [("2026-10-14", 0), ("2026-10-15", 1), ("2026-10-16", 1)]
    assert rep["by_day"][1]["weekday"] == "чт"
    assert rep["period"] == {
        "from": "2026-10-14", "to": "2026-10-16",
        "since": "2026-10-13T21:00:00+00:00", "until": "2026-10-16T21:00:00+00:00",
    }
    assert rep["timezone"] == "Europe/Moscow" and rep["totals"]["arbs"] == 2


def test_day_bounds_follow_daylight_saving_time():
    # Berlin leaves summer time on 25 October 2026: that day has 25 hours.
    (day,) = period_days(ZoneInfo("Europe/Berlin"), 1, utc("2026-10-25T12:00:00"))
    assert day.start == utc("2026-10-24T22:00:00") and day.end == utc("2026-10-25T23:00:00")
    with pytest.raises(ValueError):
        period_days(MSK, 0, NOW)


def test_totals_groups_and_repeated_appearances():
    rows = [
        # The same arb appears twice on 16 October: two arbs, one distinct, its best appearance counts once.
        row("2026-10-16T06:00:00", lifetime=10, profit_usd=0.30, profit_pct=3.0, volume=10),
        row("2026-10-16T07:00:00", lifetime=40, profit_usd=0.50, profit_pct=5.0, volume=20),
        # The other direction of the same match, legs in the other order: same match, same venues.
        row("2026-10-16T08:00:00", arb_id="pm:1|k:1|B", lifetime=90, profit_usd=0.20, profit_pct=1.0, volume=30,
            legs=("kalshi", "polymarket")),
        row("2026-10-15T08:00:00", arb_id="pm:2|k:2|A", pair_key="pm:2|k:2", game="dota2", lifetime=400,
            profit_usd=1.00, profit_pct=4.0, volume=40, teams=("OG", "Tundra")),
    ]
    rep = report(rows, candidates={date(2026, 10, 16): 7, date(2026, 10, 14): 2})
    t = rep["totals"]
    assert (t["arbs"], t["distinct_arbs"], t["matches"], t["candidates"]) == (4, 3, 2, 9)
    assert t["profit_usd"] == 2.0 and t["profit_usd_distinct"] == 1.7  # 0.30 of the repeat is not counted
    assert (t["best_profit_usd"], t["best_profit_usd_pct"], t["best_profit_pct"]) == (1.0, 4.0, 5.0)
    assert t["median_profit_pct"] == 3.5 and t["median_volume_usd"] == 25.0
    assert (t["median_lifetime_sec"], t["max_lifetime_sec"]) == (65.0, 400.0)
    assert (t["share_30s"], t["share_60s"]) == (0.75, 0.5)
    assert [b["count"] for b in rep["lifetime_buckets"]] == [1, 0, 1, 1, 1]

    day16 = rep["by_day"][2]
    assert (day16["arbs"], day16["distinct_arbs"], day16["profit_usd"], day16["profit_usd_distinct"]) == (3, 2, 1.0, 0.7)
    assert day16["candidates"] == 7 and rep["by_day"][0]["candidates"] == 2

    # Sorted by profit; equal profit: more arbs first.
    assert [(g["name"], g["arbs"], g["profit_usd"]) for g in rep["by_game"]] == [("CS2", 3, 1.0), ("Dota 2", 1, 1.0)]
    # One pair of venues whatever the leg order, named in config order.
    assert [(v["label"], v["arbs"]) for v in rep["by_platforms"]] == [("Polymarket ↔ Kalshi", 4)]
    tops = [(p["team_a"], p["arbs"], p["profit_usd"], p["total_lifetime_sec"]) for p in rep["top_pairs"]]
    assert tops == [("NAVI", 3, 1.0, 140.0), ("OG", 1, 1.0, 400.0)]  # equal profit: more arbs first
    assert rep["pairs_total"] == 2 and len(report(rows, top=1)["top_pairs"]) == 1


def test_empty_period():
    rep = report([])
    t = rep["totals"]
    assert t["arbs"] == 0 and t["profit_usd"] == 0 and t["median_lifetime_sec"] is None and t["share_30s"] is None
    assert rep["by_game"] == [] and rep["top_pairs"] == [] and len(rep["by_day"]) == 3
    assert "подтверждённых вилок нет" in format_text(rep)


def test_uptime_hours_and_rate_per_24_hours():
    rows = [
        row("2026-10-14T09:00:00"),  # before uptime tracking started: the hours of that day are unknown, not 0
        row("2026-10-15T09:00:00", profit_usd=0.4, healthy=1),
        row("2026-10-15T10:00:00", arb_id="x|B", profit_usd=0.6, healthy=1),
        row("2026-10-16T09:00:00", profit_usd=1.0, healthy=1),
        # Found in a minute without fresh data on every platform: those minutes are not in the divisor either.
        row("2026-10-16T10:00:00", arb_id="y|A", profit_usd=5.0, healthy=0),
    ]
    uptime = {date(2026, 10, 15): (1440, 1380), date(2026, 10, 16): (600, 600)}
    since = utc("2026-10-14T21:00:00")  # the first uptime row: 15 October 00:00 in Moscow
    rep = report(rows, uptime=uptime, tracking_since=since)
    assert rep["uptime_tracked"] is True and rep["uptime_since"] == "2026-10-14T21:00:00+00:00"
    assert [(d["run_hours"], d["data_hours"]) for d in rep["by_day"]] == [(None, None), (24.0, 23.0), (10.0, 10.0)]
    t = rep["totals"]
    assert (t["run_hours"], t["data_hours"], t["run_minutes"], t["data_minutes"]) == (34.0, 33.0, 2040, 1980)
    assert [d["run_minutes"] for d in rep["by_day"]] == [None, 1440, 600]
    # 3 arbs and $2.00 in the 1980 minutes with fresh data: like with like (minutes with fresh data on both sides).
    assert t["per_24h"] == {"arbs": round(3 / 1980 * 1440, 2), "profit_usd": round(2.0 / 1980 * 1440, 2),
                            "distinct_arbs": round(3 / 1980 * 1440, 2)}  # 3 разные вилки-дня в свежие минуты
    assert t["arbs"] == 5 and t["rate_min_data_hours"] == 24
    text = format_text(rep)
    assert "Работа сканера: 34 ч 00 мин, из них со свежими данными всех площадок: 33 ч 00 мин" in text
    assert "На 24 ч со свежими данными: вилок 2,2, уникальных 2,2" in text
    assert "Время работы записывается с 15.10.2026 00:00: до этого часы неизвестны («—») или неполные." in text

    # After tracking started, a day without uptime rows and without arbs is a day the scanner did not run: 0 hours.
    early = utc("2026-10-13T12:00:00")
    assert report([], uptime=uptime, tracking_since=early)["by_day"][0]["run_hours"] == 0.0
    # Less than 24 hours of fresh data: no rate (matches are not spread evenly over a day).
    short = report(rows, uptime={date(2026, 10, 15): (690, 690), date(2026, 10, 16): (600, 600)}, tracking_since=since)
    assert short["totals"]["per_24h"] is None
    assert "На 24 ч: нужно хотя бы 24 ч со свежими данными" in format_text(short)
    # No uptime rows at all (an older database): hours unknown everywhere.
    old = report(rows, uptime=None)
    assert old["uptime_tracked"] is False and old["totals"]["run_hours"] is None and old["totals"]["per_24h"] is None
    assert all(d["run_hours"] is None for d in old["by_day"])
    assert "Работа сканера: нет данных" in format_text(old)


def test_text_report():
    rows = [row("2026-10-16T06:00:00", lifetime=75, profit_usd=1234.5)]
    rep = report(rows, uptime={date(2026, 10, 16): (120, 90)}, tracking_since=utc("2026-10-16T05:00:00"))
    rep["confirm_seconds"] = 2.5  # a threshold set in the UI can have a fraction
    text = format_text(rep, db_path="data/arb_history.db")
    assert "Отчёт по истории вилок: 14.10.2026 – 16.10.2026 (3 дн., часовой пояс Europe/Moscow)" in text
    assert "База: data/arb_history.db" in text
    # Вместо суммы максимумов: при подтверждении (у старых строк данных нет), медианы, итог без крупнейших.
    assert "Прибыль при подтверждении: данных нет (у всех 1 вилок: записаны до этой версии сканера)" in text
    assert "Прибыль за жизнь на вилку, $: медиана 1 234,50" in text
    # Вилка одна: исключена она одна (топ-1), а не «топ-10».
    assert "Итог без топ-1 (сумма максимумов без 1 крупнейшей вилки): 0,00 $; топ-1 дали 1 234,50 $ — 100 %" in text
    assert "Работа сканера: 2 ч 00 мин, из них со свежими данными всех площадок: 1 ч 30 мин" in text
    assert "(сейчас 2,5 с)" in text and "Время жизни (вместе с порогом подтверждения): медиана 1 мин 15 с" in text
    assert "16.10 пт" in text and "NAVI vs FaZe" in text and "Polymarket ↔ Kalshi" in text
    assert fmt_num(None) == "—" and fmt_num(0.5, 1) == "0,5"
    assert (fmt_duration(45), fmt_duration(185), fmt_duration(7620)) == ("45 с", "3 мин 05 с", "2 ч 07 мин")
    assert (fmt_minutes(None), fmt_minutes(2), fmt_minutes(2045)) == ("—", "2 мин", "34 ч 05 мин")
    assert (fmt_hours(None), fmt_hours(0.0), fmt_hours(0.03), fmt_hours(23.96)) == ("—", "0,0", "<0,1", "24,0")


def test_timezone_setting_is_validated():
    assert Settings().stats.timezone == "Europe/Moscow"
    assert validate_timezone("Asia/Almaty") == "Asia/Almaty"
    with pytest.raises(ValueError):
        validate_timezone("Mars/Olympus")
    with pytest.raises(ValidationError):
        Settings.model_validate({"stats": {"timezone": "Mars/Olympus"}})


# ---- database --------------------------------------------------------------------------------------


def closed(arb_id: str, first_seen: datetime, lifetime: float, confirmed: bool, profit_usd: float = 0.5) -> ClosedArb:
    leg = ArbLeg(platform="polymarket", platform_name="Polymarket", market_id="m", outcome="NAVI", ask=0.4, size=10)
    arb = ArbOpportunity(
        arb_id=arb_id, pair_key=arb_id.rsplit("|", 1)[0], direction="A", game="cs2", event_title="NAVI vs FaZe",
        team_a="NAVI", team_b="FaZe", leg1=leg, leg2=leg.model_copy(update={"platform": "kalshi", "outcome": "FaZe"}),
        sum_ask=0.9, fees_usd=0.1, cost_per_contract=0.95, profit_pct=2.0, contracts=10, volume_usd=9.5,
        profit_usd=profit_usd,
    )
    return ClosedArb(
        arb_id=arb_id, first_seen=first_seen, last_seen=first_seen + timedelta(seconds=lifetime),
        lifetime_sec=lifetime, confirmed=confirmed, max_profit_pct=2.0, max_volume_usd=9.5,
        max_profit_usd=profit_usd, last=arb,
    )


async def fill(db: Database) -> None:
    await db.add_history([
        closed("pm:1|k:1|A", utc("2026-10-15T20:30:00"), 30, True, 0.4),  # 15 Oct, Moscow time
        closed("pm:1|k:1|A", utc("2026-10-15T21:30:00"), 12, True, 0.6),  # 16 Oct, Moscow time
        closed("pm:1|k:1|B", utc("2026-10-15T21:40:00"), 2, False),  # candidate, 16 Oct
        closed("pm:2|k:2|A", utc("2026-10-16T11:00:00"), 3, False),  # candidate, 16 Oct
        closed("pm:3|k:3|A", utc("2026-10-10T10:00:00"), 50, True),  # outside the period
    ])
    # Minutes 20:58 and 20:59 UTC on 15 Oct belong to 15 Oct in Moscow, 21:00 and 21:01 to 16 Oct.
    for minute, healthy in (("20:58", True), ("20:59", False), ("21:00", True), ("21:01", True)):
        await db.mark_uptime(utc(f"2026-10-15T{minute}:10"), healthy)
    # Two checks in one minute: the minute has fresh data only if every check had it.
    await db.mark_uptime(utc("2026-10-15T21:01:40"), False)
    await db.mark_uptime(utc("2026-10-15T21:00:40"), True)


async def test_database_queries_and_collect(tmp_path, settings):
    db = Database(tmp_path / "stats.db")
    await db.connect()
    await fill(db)
    period = period_days(MSK, 2, NOW)
    bounds = [(d.day.isoformat(), d.start.isoformat(), d.end.isoformat()) for d in period]
    assert await db.stats_candidates(bounds) == {"2026-10-15": 0, "2026-10-16": 2}
    minutes = [(d.day.isoformat(), d.start_minute, d.end_minute) for d in period]
    assert await db.stats_uptime(minutes) == {"2026-10-15": (2, 1), "2026-10-16": (2, 1)}
    assert await db.uptime_first_minute() == int(utc("2026-10-15T20:58:00").timestamp() // 60)
    arbs = await db.stats_arbs(period[0].start.isoformat(), period[-1].end.isoformat())
    assert sorted(r["first_seen"] for r in arbs) == ["2026-10-15T20:30:00+00:00", "2026-10-15T21:30:00+00:00"]

    rep = await collect(db, settings, days=2, now=NOW)
    assert rep["timezone"] == "Europe/Moscow"
    assert [(d["date"], d["arbs"], d["candidates"], d["run_hours"]) for d in rep["by_day"]] == [
        ("2026-10-15", 1, 0, round(2 / 60, 2)), ("2026-10-16", 1, 2, round(2 / 60, 2)),
    ]
    assert rep["totals"]["profit_usd"] == 1.0 and rep["totals"]["distinct_arbs"] == 1
    await db.close()


async def test_read_only_database(tmp_path, settings):
    missing = tmp_path / "missing.db"
    with pytest.raises(FileNotFoundError):
        await Database(missing, read_only=True).connect()
    assert not missing.exists()

    # A database of an older version: history, no uptime table. The report reads it; read-only access must not add it.
    old = tmp_path / "old.db"
    db = Database(old)
    await db.connect()
    await fill(db)
    await db.close()
    conn = sqlite3.connect(old)
    conn.execute("DROP TABLE scanner_uptime")
    conn.commit()
    conn.close()
    db = Database(old, read_only=True)
    await db.connect()
    assert await db.uptime_first_minute() is None
    rep = await collect(db, settings, days=2, now=NOW)
    assert rep["uptime_tracked"] is False and rep["totals"]["arbs"] == 2 and rep["totals"]["run_hours"] is None
    with pytest.raises(sqlite3.OperationalError):
        await db.mark_uptime(NOW, True)
    await db.close()
    tables = {r[0] for r in sqlite3.connect(old).execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    assert "scanner_uptime" not in tables


async def test_scanner_records_uptime(settings, tmp_path):
    class FakeAdapter:
        def __init__(self, platform: str):
            self.platform = platform
            self.name = platform.title()
            self.status = PlatformStatus(platform=platform, name=self.name, connected=True)

    db = Database(tmp_path / "uptime.db")
    await db.connect()
    adapters = {"polymarket": FakeAdapter("polymarket"), "kalshi": FakeAdapter("kalshi")}
    scanner = Scanner(settings, adapters, db)
    t0 = utc("2026-10-16T09:00:05")
    for adapter in adapters.values():
        adapter.status.last_update = t0
    await scanner.record_uptime(t0)  # both platforms fresh
    adapters["kalshi"].status.last_update = t0 - timedelta(seconds=60)
    await scanner.record_uptime(t0 + timedelta(seconds=60))  # Kalshi data is 2 minutes old
    assert await db.stats_uptime([("d", int(t0.timestamp() // 60), int(t0.timestamp() // 60) + 2)]) == {"d": (2, 1)}
    await db.close()


# ---- command line and API ----------------------------------------------------------------------------


def test_report_command(tmp_path, capsys):
    path = tmp_path / "cli.db"

    async def prepare() -> None:
        db = Database(path)
        await db.connect()
        now = datetime.now(timezone.utc)
        await db.add_history([closed("pm:1|k:1|A", now - timedelta(hours=1), 42, True, 0.36)])
        await db.mark_uptime(now, True)
        await db.close()

    asyncio.run(prepare())
    assert report_main(["--db", str(path), "--days", "3"]) == 0
    text = capsys.readouterr().out
    assert "часовой пояс Europe/Moscow" in text and "NAVI vs FaZe" in text and "медиана 0,36" in text
    assert "Банкролл 1 000 $ (один на все площадки), до 100 $ на вилку" in text

    assert report_main(["--db", str(path), "--json", "--bankroll", "50", "--max-stake", "0", "--exclude-top", "0"]) == 0
    data = json.loads(capsys.readouterr().out)
    assert data["settings"]["bankroll_usd"] == 50 and data["settings"]["max_stake_per_arb_usd"] == 0
    assert data["totals"]["honest"]["outliers"] == 0 and data["totals"]["honest"]["profit_trimmed_usd"] == 0.36
    assert report_main(["--db", str(path), "--bankroll", "-1"]) == 2
    assert "--bankroll: нужно число не меньше 0" in capsys.readouterr().err

    assert report_main(["--db", str(path), "--json", "--tz", "Asia/Almaty"]) == 0
    data = json.loads(capsys.readouterr().out)
    assert data["timezone"] == "Asia/Almaty" and data["days"] == 7 and data["totals"]["arbs"] == 1

    assert report_main(["--db", str(tmp_path / "nope.db")]) == 1
    assert "Файл истории не найден" in capsys.readouterr().err
    not_db = tmp_path / "notes.txt"
    not_db.write_text("not a database", encoding="utf-8")
    assert report_main(["--db", str(not_db)]) == 1
    assert "Не удалось прочитать историю" in capsys.readouterr().err
    assert report_main(["--db", str(path), "--tz", "Mars/Olympus"]) == 2
    assert report_main(["--db", str(path), "--days", "0"]) == 2
    assert not (tmp_path / "nope.db").exists()


def test_stats_endpoint(tmp_path):
    from fastapi.testclient import TestClient

    from backend.adapters import apply_mock_mode
    from backend.adapters.mock import reset_worlds
    from backend.api.server import create_app
    from backend.config import load_settings

    reset_worlds()
    settings = apply_mock_mode(load_settings())
    settings.storage.path = str(tmp_path / "api.db")
    settings.logging.file = ""
    with TestClient(create_app(settings), base_url="http://localhost") as client:
        # The scanner writes its first uptime row right after the start, in the background; the API reads through a
        # connection of its own, so wait for that row.
        deadline = time.time() + 5
        data = client.get("/api/stats?days=3&top=5").json()
        while not data["uptime_tracked"] and time.time() < deadline:
            time.sleep(0.05)
            data = client.get("/api/stats?days=3&top=5").json()
        assert data["timezone"] == "Europe/Moscow" and data["days"] == 3 and len(data["by_day"]) == 3
        assert {"totals", "lifetime_buckets", "by_game", "by_platforms", "top_pairs"} <= set(data)
        assert data["uptime_tracked"] is True

        async def busy(fn):  # the scanner's connection must not be needed for the report
            raise AssertionError("the report used the scanner's database connection")

        client.app.state.db.read = busy
        assert client.get("/api/stats?days=7").json()["days"] == 7
        assert client.get("/api/stats").json()["days"] == 7
        for bad in ("days=0", "days=367", "top=0", "days=x"):
            assert client.get(f"/api/stats?{bad}").status_code == 422


def test_missing_values_and_unknown_hours_after_tracking_started():
    odd = row("2026-10-16T08:00:00", arb_id="odd|A", pair_key="odd", game=None, legs=(None, None), healthy=1)
    for key in ("max_profit_usd", "max_profit_pct", "max_volume_usd", "lifetime_sec", "team_a", "tournament"):
        odd[key] = None
    rep = report([odd, row("2026-10-15T08:00:00")], uptime={date(2026, 10, 16): (100, 100)},
                 tracking_since=utc("2026-10-13T12:00:00"))
    assert [(g["game"], g["name"]) for g in rep["by_game"]] == [("cs2", "CS2"), (None, "—")]
    assert {v["label"] for v in rep["by_platforms"]} == {"—", "Polymarket ↔ Kalshi"}
    assert rep["totals"]["profit_usd"] == 0.5
    assert {p["pair_key"]: p["team_a"] for p in rep["top_pairs"]} == {"pm:1|k:1": "NAVI", "odd": None}
    assert "? vs FaZe" in format_text(rep)
    # 15 October has an arb but no uptime row although tracking had started: unknown, not 0.
    assert [d["run_hours"] for d in rep["by_day"]] == [0.0, None, round(100 / 60, 2)]
    assert "Для дней с «—» время работы неизвестно" in format_text(rep)


async def test_arbs_carry_the_health_of_their_minute_and_day_bounds_are_exact(tmp_path, settings):
    db = Database(tmp_path / "health.db")
    await db.connect()
    await fill(db)
    await db.add_history([
        closed("pm:5|k:5|A", utc("2026-10-15T21:00:20.5"), 8, True),  # minute 21:00: fresh data at both checks
        closed("pm:6|k:6|A", utc("2026-10-15T21:01:59.999999"), 8, True),  # minute 21:01: one check without
        closed("pm:7|k:7|A", utc("2026-10-15T20:59:59.999999"), 8, True),  # the last microsecond of 15 Oct (Moscow)
    ])
    arbs = await db.stats_arbs("2026-10-15T00:00:00+00:00", "2026-10-17T00:00:00+00:00")
    health = {r["arb_id"]: r["minute_healthy"] for r in arbs}
    assert (health["pm:5|k:5|A"], health["pm:6|k:6|A"], health["pm:7|k:7|A"]) == (1, 0, 0)
    assert health["pm:1|k:1|A"] is None  # no uptime row for that minute
    rep = await collect(db, settings, days=2, now=NOW)
    assert [(d["date"], d["arbs"]) for d in rep["by_day"]] == [("2026-10-15", 2), ("2026-10-16", 3)]
    await db.close()


async def test_read_only_access_cannot_write_and_sees_a_running_writer(tmp_path):
    path = tmp_path / "live.db"
    writer = Database(path)
    await writer.connect()
    await writer.add_history([closed("pm:1|k:1|A", utc("2026-10-16T08:00:00"), 9, True)])
    reader = Database(path, read_only=True)
    await reader.connect()
    with pytest.raises(sqlite3.OperationalError, match="readonly"):
        await reader.mark_uptime(NOW, True)
    assert len(await reader.stats_arbs("2026-10-16", "2026-10-17")) == 1
    await writer.add_history([closed("pm:2|k:2|A", utc("2026-10-16T09:00:00"), 9, True)])  # the scanner goes on
    assert len(await reader.stats_arbs("2026-10-16", "2026-10-17")) == 2
    await reader.close()
    await writer.close()


async def test_uptime_write_failures_never_stop_the_scanner(settings, tmp_path, monkeypatch, caplog):
    import backend.engine.scanner as scanner_module

    db = Database(tmp_path / "fail.db")
    await db.connect()
    scanner = Scanner(settings, {}, db)
    calls = {"n": 0}
    real = scanner.record_uptime

    async def flaky(now):
        calls["n"] += 1
        if calls["n"] <= 2:
            raise sqlite3.OperationalError("disk I/O error")
        if calls["n"] == 4:
            raise RuntimeError("bug in the check")
        await real(now)

    monkeypatch.setattr(scanner, "record_uptime", flaky)
    monkeypatch.setattr(scanner_module, "UPTIME_CHECK_SECONDS", 0.005)
    with caplog.at_level("INFO", logger="backend.engine.scanner"):
        task = asyncio.create_task(scanner._uptime_loop())
        for _ in range(200):
            await asyncio.sleep(0.005)
            if calls["n"] >= 6:
                break
        assert not task.done()  # still running
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
    lines = [(r.levelname, r.getMessage(), r.exc_info is not None) for r in caplog.records]
    assert lines[:4] == [
        ("WARNING", "could not write the scanner uptime: OperationalError: disk I/O error", False),  # once per streak
        ("INFO", "scanner uptime is written again", False),
        ("ERROR", "scanner uptime check failed", True),  # a bug keeps its traceback
        ("INFO", "scanner uptime is written again", False),
    ]
    await db.close()


def test_report_command_output_file_saved_settings_and_folder(tmp_path, capsys):
    path = tmp_path / "cli2.db"

    async def prepare() -> None:
        db = Database(path)
        await db.connect()
        await db.add_history([closed("pm:1|k:1|A", datetime.now(timezone.utc) - timedelta(hours=1), 42, True, 0.36)])
        await db.save_settings({"engine.confirm_seconds": 2.5})  # changed in the UI
        await db.close()

    asyncio.run(prepare())
    out = tmp_path / "отчёт.txt"
    assert report_main(["--db", str(path), "-o", str(out)]) == 0
    assert "Отчёт сохранён" in capsys.readouterr().out
    text = out.read_text(encoding="utf-8")
    assert "Вилок: 1" in text and "(сейчас 2,5 с)" in text  # the saved threshold, not config.yaml
    assert report_main(["--db", str(path), "--json", "-o", str(tmp_path / "s.json")]) == 0
    assert json.loads((tmp_path / "s.json").read_text(encoding="utf-8"))["confirm_seconds"] == 2.5
    capsys.readouterr()
    assert report_main(["--db", str(tmp_path)]) == 1  # a folder, not a file
    assert "Файл истории не найден" in capsys.readouterr().err
    assert report_main(["--db", str(path), "-o", str(tmp_path / "missing" / "x.txt")]) == 1
    assert "Не удалось записать" in capsys.readouterr().err


async def test_stats_builds_run_one_at_a_time_and_share_identical_requests():
    from backend.api.server import StatsBuilds

    calls: list[tuple[int, int]] = []
    running = {"now": 0, "max": 0}

    async def build(days, top):
        calls.append((days, top))
        running["now"] += 1
        running["max"] = max(running["max"], running["now"])
        await asyncio.sleep(0.02)
        running["now"] -= 1
        return {"days": days, "top": top}

    builds = StatsBuilds(build)
    # A held arrow key or repeated refreshes: three identical requests, one build.
    same = await asyncio.gather(*(builds.get(7, 10) for _ in range(3)))
    assert same == [{"days": 7, "top": 10}] * 3 and calls == [(7, 10)]
    # Different periods queue up: never two builds at once.
    calls.clear()
    await asyncio.gather(builds.get(30, 10), builds.get(90, 10), builds.get(1, 10))
    assert sorted(calls) == [(1, 10), (30, 10), (90, 10)] and running["max"] == 1
    # A request that goes away does not cancel the build that another request waits for.
    first = asyncio.create_task(builds.get(7, 10))
    second = asyncio.create_task(builds.get(7, 10))
    await asyncio.sleep(0)
    first.cancel()
    assert await second == {"days": 7, "top": 10}


def test_stats_endpoint_falls_back_to_the_scanner_connection(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient

    import backend.api.server as server_module
    from backend.adapters import apply_mock_mode
    from backend.adapters.mock import reset_worlds
    from backend.config import load_settings

    reset_worlds()
    settings = apply_mock_mode(load_settings())
    settings.storage.path = str(tmp_path / "fallback.db")
    settings.logging.file = ""
    with TestClient(server_module.create_app(settings), base_url="http://localhost") as client:
        class NoReadOnly(Database):
            async def connect(self):
                if self.read_only:
                    raise OSError("read-only access refused")
                await super().connect()

        monkeypatch.setattr(server_module, "Database", NoReadOnly)
        resp = client.get("/api/stats?days=1")
        assert resp.status_code == 200 and resp.json()["days"] == 1


async def test_read_only_open_on_a_network_path_stays_read_only(tmp_path, monkeypatch):
    import backend.storage.db as db_module

    path = tmp_path / "share.db"
    writer = Database(path)
    await writer.connect()
    await writer.add_history([closed("pm:1|k:1|A", utc("2026-10-16T08:00:00"), 9, True)])
    await writer.close()
    real_connect = sqlite3.connect

    def no_uri(target, *args, **kwargs):  # what SQLite does with file://server/share/...: "invalid uri authority"
        if kwargs.get("uri"):
            raise sqlite3.OperationalError("invalid uri authority: server")
        return real_connect(target, *args, **kwargs)

    monkeypatch.setattr(db_module.sqlite3, "connect", no_uri)
    reader = Database(path, read_only=True)
    await reader.connect()
    assert len(await reader.stats_arbs("2026-10-16", "2026-10-17")) == 1
    with pytest.raises(sqlite3.OperationalError, match="readonly"):
        await reader.mark_uptime(NOW, True)
    await reader.close()


def test_report_output_never_overwrites_the_history(tmp_path, capsys):
    path = tmp_path / "keep.db"

    async def prepare() -> None:
        db = Database(path)
        await db.connect()
        await db.add_history([closed("pm:1|k:1|A", datetime.now(timezone.utc) - timedelta(hours=1), 42, True)])
        await db.close()

    asyncio.run(prepare())
    size = path.stat().st_size
    for target in (path, tmp_path / "keep.db-wal"):
        assert report_main(["--db", str(path), "-o", str(target)]) == 2
        assert "это файл истории сканера" in capsys.readouterr().err
    assert path.stat().st_size == size and sqlite3.connect(path).execute("SELECT COUNT(*) FROM arb_history").fetchone()[0] == 1


def test_pairs_with_stake_go_to_the_venue_pairs_without_changes():
    names = {"polymarket": "Polymarket", "kalshi": "Kalshi", "stake": "Stake"}  # config order
    rows = [
        row("2026-10-16T08:00:00", arb_id="pm:1|stake:1|A", pair_key="pm:1|stake:1", legs=("polymarket", "stake")),
        row("2026-10-16T08:10:00", arb_id="pm:1|stake:1|B", pair_key="pm:1|stake:1", legs=("stake", "polymarket")),
        row("2026-10-16T08:20:00", arb_id="k:1|stake:1|A", pair_key="k:1|stake:1", legs=("kalshi", "stake"),
            profit_usd=1.5),
        row("2026-10-16T08:30:00"),
    ]
    period = period_days(MSK, 3, NOW)
    rep = build_report(rows, {}, {}, period, tracking_since=None, tz_name="Europe/Moscow", now=NOW,
                       platform_names=names, game_names=GAMES, confirm_seconds=5.0)
    venues = {v["label"]: (v["platforms"], v["arbs"]) for v in rep["by_platforms"]}
    assert venues == {
        "Polymarket ↔ Stake": (["polymarket", "stake"], 2),  # the leg order does not matter
        "Kalshi ↔ Stake": (["kalshi", "stake"], 1),
        "Polymarket ↔ Kalshi": (["polymarket", "kalshi"], 1),
    }
    assert rep["by_platforms"][0]["label"] == "Kalshi ↔ Stake"  # sorted by profit
    text = format_text(rep)
    assert "Polymarket ↔ Stake" in text and "Kalshi ↔ Stake" in text
    # "pm:1", "k:1" and "stake:1" are one match on three venues: its three venue pairs count as one match.
    assert rep["totals"]["matches"] == 1 and "матчей 1" in text
    assert rep["pairs_total"] == 3  # the top list still has a row per venue pair


def test_count_matches_joins_pairs_that_share_a_market():
    from backend.stats import count_matches

    assert count_matches([]) == 0
    assert count_matches(["k:1|pm:1", "k:2|pm:2"]) == 2  # two platforms: one pair key per match
    assert count_matches(["k:1|pm:1", "pm:1|stake:1", "k:1|stake:1"]) == 1  # a triangle
    assert count_matches(["pm:1|stake:1", "k:1|stake:1"]) == 1  # joined through the Stake market
    assert count_matches(["pm:1|stake:1", "k:1|stake:2", "odd"]) == 3


async def test_report_from_the_database_names_stake_from_the_config(tmp_path, settings):
    db = Database(tmp_path / "stake.db")
    await db.connect()
    arb = closed("pm:1|stake:1|A", utc("2026-10-16T08:00:00"), 30, True)
    arb.last.leg2 = arb.last.leg2.model_copy(update={"platform": "stake", "platform_name": "Stake"})
    await db.add_history([arb])
    rep = await collect(db, settings, days=1, now=NOW)
    assert [(v["label"], v["arbs"]) for v in rep["by_platforms"]] == [("Polymarket ↔ Stake", 1)]
    assert rep["top_pairs"][0]["platforms_label"] == "Polymarket ↔ Stake"
    await db.close()
