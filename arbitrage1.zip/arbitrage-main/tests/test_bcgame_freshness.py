"""Время исходов: управляемые часы и синтетические ответы, без сети и текущего расписания."""

import copy
import json
from datetime import timedelta

import httpx
import pytest

import backend.adapters.bcgame as bcgame
from backend.adapters.bcgame import SnapshotExpired
from backend.engine.arb import evaluate_pair, is_fresh
from backend.net import HttpError
from tests.conftest import make_market, make_pair
from tests.test_bcgame import NOW, adapter, feed, first, markets, response_api, transport


def price_patch(event_id, event, outcomes=("4", "5")):
    selections = event["markets"]["186"][""]
    return {"events": {event_id: {"markets": {"186": {"": {
        oid: {"k": str(float(selections[oid]["k"]) + .03)} for oid in outcomes
    }}}}}}


async def accept(adapter, monkeypatch, patch, stamp, version=502):
    monkeypatch.setattr(bcgame, "utcnow", lambda: stamp)
    requests = []
    payload = {"epoch": 17, "version": version, "generated": int(stamp.timestamp()*1000), **patch}
    await transport(adapter, lambda req: (requests.append(req) or httpx.Response(200, json=payload)))
    await adapter.poll_once()
    return requests


def engine_result(adapter, market, now):
    peer = make_market(team_a=market.team_a, team_b=market.team_b, game=market.game, start=market.start_time,
                       asks_a=[(.001, 100)], asks_b=[(.001, 100)], updated_at=now)
    return evaluate_pair(make_pair(peer, market), peer, market, adapter.settings, now)


async def test_fresh_snapshot_reaches_engine_then_expires_without_new_quote(adapter, monkeypatch):
    adapter.feeds = {}
    await transport(adapter, response_api([]))
    found = await adapter.fetch_markets()
    assert found and engine_result(adapter, found[0], NOW)
    assert not engine_result(adapter, found[0], NOW + timedelta(seconds=11))
    assert found[0].updated_at == NOW


async def test_long_poll_uses_coherent_response_confirmation_time(adapter, monkeypatch):
    event_id, event = first(adapter)
    patch = price_patch(event_id, event)
    sent = NOW
    generated = NOW + timedelta(seconds=12)
    received = NOW + timedelta(seconds=13)
    clock = [sent]
    monkeypatch.setattr(bcgame, "utcnow", lambda: clock[0])
    async def handler(request):
        clock[0] = received
        return httpx.Response(200, json={"epoch": 17, "version": 502,
                                        "generated": int(generated.timestamp()*1000), **patch})
    await transport(adapter, handler)
    await adapter.poll_once()
    market = adapter.normalize({"id": event_id})[0]
    assert market.updated_at == received and market.updated_at != generated and market.updated_at != sent
    assert market.extra["source_generated_at"] == generated.isoformat()
    assert engine_result(adapter, market, received)


async def test_successful_delta_confirms_all_markets_in_coherent_state(adapter, monkeypatch):
    before = markets(adapter)
    eid, event = first(adapter)
    await accept(adapter, monkeypatch, price_patch(eid, event), NOW + timedelta(seconds=5))
    after = {m.key: m for m in markets(adapter)}
    assert after[before[0].key].updated_at == NOW + timedelta(seconds=5)
    for unchanged in before[1:]:
        assert after[unchanged.key].updated_at == NOW + timedelta(seconds=5)
        assert is_fresh(after[unchanged.key], NOW + timedelta(seconds=11), 10)
    assert is_fresh(after[before[0].key], NOW + timedelta(seconds=11), 10)


async def test_one_outcome_delta_keeps_other_outcome_time(adapter, monkeypatch):
    eid, event = first(adapter)
    later = NOW + timedelta(seconds=5)
    await accept(adapter, monkeypatch, price_patch(eid, event, ("4",)), later)
    market = adapter.normalize({"id": eid})[0]
    assert market.extra["bcgame_quote_times"] == {"4": later.isoformat(), "5": NOW.isoformat()}
    assert market.extra["bcgame_quote_sources"] == {"4": {"epoch": "17", "version": "502"},
                                                    "5": {"epoch": "17", "version": "501"}}
    assert market.updated_at == later
    assert engine_result(adapter, market, NOW + timedelta(seconds=11))


@pytest.mark.parametrize("kind", ["empty", "same_event_score", "other_event_score"])
async def test_successful_delta_confirms_state_even_without_price_change(adapter, monkeypatch, kind):
    ids = list(adapter.feeds["prematch"].data["events"])
    patch = {} if kind == "empty" else {"events": {ids[0 if kind == "same_event_score" else 1]: {"score": {"home_score": 9}}}}
    await accept(adapter, monkeypatch, patch, NOW + timedelta(seconds=20))
    assert all(m.updated_at == NOW + timedelta(seconds=20) for m in markets(adapter))
    assert all(is_fresh(m, NOW + timedelta(seconds=20), 10) for m in markets(adapter))


async def test_equal_decimal_spelling_still_confirms_coherent_state(adapter, monkeypatch):
    eid, event = first(adapter)
    original = float(event["markets"]["186"][""]["4"]["k"])
    patch = {"events": {eid: {"markets": {"186": {"": {"4": {"k": original}}}}}}}
    await accept(adapter, monkeypatch, patch, NOW + timedelta(seconds=20))
    assert adapter.normalize({"id": eid})[0].updated_at == NOW + timedelta(seconds=20)


async def test_duplicate_version_confirms_state_without_rewinding_data(adapter, monkeypatch):
    before = adapter.feeds["prematch"]
    await accept(adapter, monkeypatch, {}, NOW + timedelta(seconds=20), version=501)
    assert adapter.feeds["prematch"] is not before
    assert adapter.feeds["prematch"].data == before.data
    assert all(m.updated_at == NOW + timedelta(seconds=20) for m in markets(adapter))


async def test_duplicate_version_with_changed_data_is_rejected_atomically(adapter, monkeypatch):
    eid, event = first(adapter)
    before = copy.deepcopy(adapter.feeds)
    with pytest.raises(SnapshotExpired, match="duplicate"):
        await accept(adapter, monkeypatch, price_patch(eid, event), NOW + timedelta(seconds=5), version=501)
    assert adapter.feeds == before


async def test_replayed_known_version_with_new_timestamp_is_rejected(adapter, monkeypatch):
    await accept(adapter, monkeypatch, {}, NOW + timedelta(seconds=5), version=502)
    before = copy.deepcopy(adapter.feeds)
    with pytest.raises(SnapshotExpired, match="out of order"):
        await accept(adapter, monkeypatch, {}, NOW + timedelta(seconds=6), version=501)
    assert adapter.feeds == before


async def test_opaque_version_jump_is_not_invented_as_a_sequence_gap(adapter, monkeypatch):
    eid, event = first(adapter)
    await accept(adapter, monkeypatch, price_patch(eid, event), NOW + timedelta(seconds=5), version=987654321)
    assert adapter.feeds["prematch"].version == "987654321"
    assert adapter.normalize({"id": eid})[0].updated_at == NOW + timedelta(seconds=5)


async def test_out_of_order_source_time_does_not_rollback_data(adapter, monkeypatch):
    await accept(adapter, monkeypatch, {}, NOW + timedelta(seconds=5), version=502)
    before = copy.deepcopy(adapter.feeds)
    with pytest.raises(SnapshotExpired, match="time regressed"):
        await accept(adapter, monkeypatch, {}, NOW + timedelta(seconds=4), version=503)
    assert adapter.feeds == before


@pytest.mark.parametrize("reset", ["expired_cursor", "epoch_change"])
async def test_recovery_snapshot_confirms_current_full_state(adapter, reset):
    old = NOW - timedelta(seconds=60)
    adapter.feeds = {"prematch": feed(stamp=old)}
    requests = []
    await transport(adapter, response_api(requests, delta={"version": 0} if reset == "expired_cursor" else None,
                                          epoch=18 if reset == "epoch_change" else 17))
    found = await adapter.fetch_markets()
    assert len(found) == 7 and all(m.updated_at == NOW for m in found)
    assert engine_result(adapter, found[0], NOW)
    assert len(requests) == 4


@pytest.mark.parametrize("generated", [None, "", "NaN", "Infinity", True, -1,
                                         int(NOW.timestamp()), int(NOW.timestamp()*1_000_000)])
async def test_invalid_missing_or_wrong_unit_timestamps_cannot_make_fresh(adapter, generated):
    previous = copy.deepcopy(adapter.feeds)
    payload = {"epoch": 17, "version": 502, "generated": generated}
    await transport(adapter, lambda request: httpx.Response(200, content=json.dumps(payload),
                                                            headers={"content-type": "application/json"}))
    with pytest.raises(ValueError):
        await adapter.poll_once()
    assert adapter.feeds == previous


@pytest.mark.parametrize("kind", ["event", "winner", "outcome", "paused_outcome", "paused_event"])
async def test_removed_or_suspended_market_cannot_be_reused(adapter, monkeypatch, kind):
    market = markets(adapter)[0]
    await adapter.subscribe_prices([market], lambda m: None)
    eid = market.market_id
    if kind == "event": patch = {"events": {eid: None}}
    elif kind == "winner": patch = {"events": {eid: {"markets": {"186": None}}}}
    elif kind == "outcome": patch = {"events": {eid: {"markets": {"186": {"": {"4": None}}}}}}
    elif kind == "paused_outcome": patch = {"events": {eid: {"markets": {"186": {"": {"4": {"b": 1}}}}}}}
    else: patch = {"events": {eid: {"state": {"status": 2}}}}
    later = NOW + timedelta(seconds=5)
    await accept(adapter, monkeypatch, patch, later)
    assert not market.accepting_orders and not market.asks_a and not market.asks_b
    assert not engine_result(adapter, market, later)
    adapter._publish()
    assert not market.accepting_orders


async def test_disappeared_snapshot_event_is_not_restored_from_clock_history(adapter):
    market = markets(adapter)[0]
    await adapter.subscribe_prices([market], lambda m: None)
    requests = []
    native = response_api(requests, delta={"version": 0})
    def handler(request):
        payload = native(request).json()
        payload.get("events", {}).pop(market.market_id, None)
        return httpx.Response(200, json=payload)
    await transport(adapter, handler)
    await adapter.poll_once()
    assert not market.accepting_orders and not market.asks_a
    assert market.market_id not in adapter.feeds["prematch"].data["events"]


async def test_network_error_after_delay_does_not_refresh_quote_time(adapter, monkeypatch):
    market = markets(adapter)[0]
    clock = [NOW]
    monkeypatch.setattr(bcgame, "utcnow", lambda: clock[0])
    async def handler(request):
        clock[0] = NOW + timedelta(seconds=30)
        raise httpx.ReadTimeout("controlled timeout")
    await transport(adapter, handler)
    with pytest.raises(HttpError):
        await adapter.poll_once()
    assert market.updated_at == NOW
    assert not is_fresh(market, clock[0], 10)


async def test_source_quote_clock_is_diagnostic_not_required_for_synced_book(adapter):
    market = markets(adapter)[0]
    await adapter.subscribe_prices([market], lambda m: None)
    adapter.feeds["prematch"].quote_evidence.clear()
    adapter._publish(force=True)
    assert market.updated_at == NOW
    assert engine_result(adapter, market, NOW)
    await transport(adapter, response_api([]))
    book = await adapter.fetch_book(market)
    assert book.updated_at == NOW and book.asks_a and book.asks_b


async def test_metadata_only_delta_confirms_current_market_state(adapter, monkeypatch):
    eid, _ = first(adapter)
    later = NOW + timedelta(seconds=5)
    await accept(adapter, monkeypatch, {"events": {eid: {"desc": {"best_of": 5}}}}, later)
    normalized = adapter.normalize({"id": eid})[0]
    assert normalized.updated_at == later and normalized.best_of == 5
    assert engine_result(adapter, normalized, later)


async def test_snapshot_clock_regression_resets_diagnostics_without_blocking_state(adapter, monkeypatch):
    eid, _ = first(adapter)
    later = NOW + timedelta(seconds=5)
    await accept(adapter, monkeypatch, {"events": {eid: {"desc": {"best_of": 5}}}}, later)
    await transport(adapter, response_api([], delta={"version": 0}))
    await adapter.poll_once()
    assert adapter.normalize({"id": eid})[0].best_of is None


async def test_price_time_regression_resets_diagnostics_without_blocking_delta(adapter, monkeypatch):
    eid, event = first(adapter)
    await accept(adapter, monkeypatch, price_patch(eid, event), NOW - timedelta(seconds=1))
    assert adapter.normalize({"id": eid})[0].updated_at == NOW - timedelta(seconds=1)


async def test_failed_snapshot_does_not_publish_partial_quote_timestamps(adapter):
    previous = copy.deepcopy(adapter.feeds)
    await transport(adapter, response_api([], delta={"version": 0}, complete=False))
    with pytest.raises(SnapshotExpired, match="incomplete"):
        await adapter.poll_once()
    assert adapter.feeds == previous
