"""End-to-end API test in mock mode (FastAPI TestClient, no network)."""

import time

import pytest
from fastapi.testclient import TestClient

from backend.adapters import apply_mock_mode
from backend.adapters.mock import reset_worlds
from backend.api.server import create_app
from backend.config import load_settings


@pytest.fixture
def client(tmp_path):
    reset_worlds()
    settings = apply_mock_mode(load_settings())
    settings.storage.path = str(tmp_path / "test.db")
    settings.logging.file = ""
    settings.mock.tick_ms = 100
    settings.engine.eval_interval_ms = 100
    app = create_app(settings)
    with TestClient(app, base_url="http://localhost") as test_client:
        yield test_client


def wait_for(client, predicate, timeout=8.0):
    deadline = time.time() + timeout
    state = None
    while time.time() < deadline:
        state = client.get("/api/state").json()
        if predicate(state):
            return state
        time.sleep(0.1)
    raise AssertionError(f"condition not met; last counts: {state and state['counts']}")


def test_meta_and_state(client):
    meta = client.get("/api/meta").json()
    assert meta["mock_mode"] is True
    # Every enabled platform from config.yaml is exposed to the UI.
    assert {p["id"] for p in meta["platforms"]} == {"polymarket", "kalshi", "stake", "bcgame"}
    assert any(g["id"] == "cs2" for g in meta["games"])
    state = wait_for(client, lambda s: s["counts"]["pairs"] > 0)
    assert state["counts"]["review"] >= 1
    pair = state["pairs"][0]
    assert {"left", "right", "quotes", "best", "warnings"} <= set(pair)
    assert all(p["healthy"] for p in state["platforms"])


def test_settings_roundtrip_and_validation(client):
    assert client.put("/api/settings", json={"engine.confirm_seconds": 3}).json()["engine.confirm_seconds"] == 3
    assert client.get("/api/settings").json()["engine.confirm_seconds"] == 3
    assert client.put("/api/settings", json={"engine.confirm_seconds": -1}).status_code == 400
    assert client.put("/api/settings", json={"engine.depth_mode": "magic"}).status_code == 400
    assert client.put("/api/settings", json={"server.port": 1}).status_code == 400


def test_override_block_confirm_clear(client):
    state = wait_for(client, lambda s: s["counts"]["review"] > 0)
    key = state["review"][0]["pair_key"]
    assert client.post("/api/pairs/override", json={"pair_key": key, "status": "confirmed"}).json()["ok"]
    state = client.get("/api/state").json()
    assert any(p["pair_key"] == key and p["status"] == "confirmed" for p in state["pairs"])
    client.post("/api/pairs/override", json={"pair_key": key, "status": "blocked"})
    state = client.get("/api/state").json()
    assert any(p["pair_key"] == key for p in state["blocked"])
    assert not any(p["pair_key"] == key for p in state["pairs"])
    client.post("/api/pairs/override", json={"pair_key": key, "status": "clear"})
    state = client.get("/api/state").json()
    assert any(p["pair_key"] == key for p in state["review"])
    assert client.post("/api/pairs/override", json={"pair_key": key, "status": "nope"}).status_code == 400


def test_history_and_csv(client):
    data = client.get("/api/history?limit=5").json()
    assert set(data) == {"total", "items"}
    resp = client.get("/api/history.csv")
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/csv")
    assert "first_seen" in resp.text.splitlines()[0]


def test_websocket_pushes_meta_then_state(client):
    with client.websocket_connect("ws://localhost/ws") as ws:
        first = ws.receive_json()
        assert first["type"] == "meta"
        second = ws.receive_json()
        assert second["type"] == "state" and "counts" in second["data"]


def test_frontend_is_served(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "<html" in resp.text.lower() or "<!doctype" in resp.text.lower()


def test_settings_update_is_all_or_nothing(client):
    before = client.get("/api/settings").json()
    resp = client.put("/api/settings", json={"engine.stale_seconds": 20, "engine.confirm_seconds": -5})
    assert resp.status_code == 400
    assert client.get("/api/settings").json() == before  # the valid key was not applied either
    resp = client.put("/api/settings", json={"matching.review_threshold": 95})
    assert resp.status_code == 400  # review threshold above the auto threshold


def test_static_files_are_not_cached(client):
    assert client.get("/").headers.get("cache-control") == "no-cache"
    assert "cache-control" not in {k.lower() for k in client.get("/api/meta").headers}


def test_foreign_host_and_cross_site_writes_are_rejected(client):
    assert client.get("/api/state", headers={"Host": "attacker.example"}).status_code == 400
    bad_origin = {"Origin": "https://evil.example"}
    assert client.put("/api/settings", json={"engine.confirm_seconds": 7}, headers=bad_origin).status_code == 403
    assert client.post("/api/pairs/override", json={"pair_key": "a:1|b:2", "status": "blocked"}, headers=bad_origin).status_code == 403
    good_origin = {"Origin": "http://localhost:8000"}
    assert client.put("/api/settings", json={"engine.confirm_seconds": 7}, headers=good_origin).status_code == 200


def test_csv_cells_cannot_start_formulas():
    from backend.storage.db import _csv_cell

    assert _csv_cell("=HYPERLINK(\"http://x\")") == "'=HYPERLINK(\"http://x\")"
    assert _csv_cell("-1+2") == "'-1+2"
    assert _csv_cell("NAVI") == "NAVI"
    assert _csv_cell(-1.5) == -1.5


def test_websocket_rejects_foreign_origin(client):
    from starlette.websockets import WebSocketDisconnect

    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("ws://localhost/ws", headers={"Origin": "https://evil.example"}) as ws:
            ws.receive_json()


def test_websocket_sends_heartbeat_when_nothing_changes(tmp_path, monkeypatch):
    import backend.api.server as server_module

    monkeypatch.setattr(server_module, "HEARTBEAT_SECONDS", 0.3)
    settings = load_settings()
    settings.storage.path = str(tmp_path / "heartbeat.db")
    settings.logging.file = ""
    settings.engine.eval_interval_ms = 600_000  # no evaluation, so the state version never changes
    settings.engine.broadcast_interval_ms = 200
    app = create_app(settings, adapters={})
    with TestClient(app, base_url="http://localhost") as test_client:
        with test_client.websocket_connect("ws://localhost/ws") as ws:
            assert ws.receive_json()["type"] == "meta"
            state = ws.receive_json()
            assert state["type"] == "state"
            beat = ws.receive_json()
            assert beat["type"] == "heartbeat"
            assert set(beat["data"]) == {"version", "started_at", "server_time", "last_eval_at"}
            assert beat["data"]["version"] == state["data"]["version"]
            assert beat["data"]["started_at"] == state["data"]["started_at"]
            assert beat["data"]["last_eval_at"] is None  # the scanner has not evaluated yet


def test_ipv6_loopback_host_is_accepted(client):
    assert client.get("/api/health", headers={"Host": "[::1]:8000"}).status_code == 200
    assert client.get("/api/health", headers={"Host": "127.0.0.1:8000"}).status_code == 200
