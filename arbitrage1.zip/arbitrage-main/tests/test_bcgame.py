"""Контракт BC.Game: сокращённая реальная запись и отдельно синтетические ошибки/delta, без сети."""

from __future__ import annotations

import asyncio
import copy
from datetime import datetime, timedelta, timezone

import httpx
import pytest

import backend.adapters.bcgame as bcgame
from backend.adapters.bcgame import BcGameAdapter, FeedState, PROXY_ENV, SnapshotExpired, merge_payload
from backend.adapters.bcgame_clock import update_quote_times
from backend.config import PlatformConfig
from backend.matching.rules import BCGAME_PROFILE, BCGAME_RULES, RulesProfile, parse_rules
from backend.net import HttpError
from tests.conftest import load_fixture

NOW = datetime(2026, 10, 19, 13, 14, 50, tzinfo=timezone.utc)


def recording():
    return load_fixture("bcgame_prematch_esports.json")


def feed(data=None, version="501", stamp=NOW):
    data = recording() if data is None else data
    tables = {k: copy.deepcopy(data[k]) for k in ("sports", "categories", "tournaments", "events")}
    clocks = update_quote_times({}, tables, tables, stamp, "17", version)
    return FeedState(tables, "17", version, stamp, stamp, clocks, (version,))


@pytest.fixture
async def adapter(settings, monkeypatch):
    monkeypatch.delenv(PROXY_ENV, raising=False)
    monkeypatch.setattr(bcgame, "utcnow", lambda: NOW)
    cfg = PlatformConfig.model_validate({**settings.platforms["bcgame"].model_dump(), "rate_limit_per_sec": 10000})
    a = BcGameAdapter("bcgame", cfg, settings)
    a.feeds = {"prematch": feed()}
    yield a
    await a.stop()


async def transport(a, handler):
    await a.http.aclose()
    a.http = httpx.AsyncClient(base_url=a.api_url, transport=httpx.MockTransport(handler), follow_redirects=False)


def first(a):
    event_id = next(iter(a.feeds["prematch"].data["events"]))
    return event_id, a.feeds["prematch"].data["events"][event_id]


def markets(a):
    return [m for eid in a.feeds["prematch"].data["events"] for m in a.normalize({"id": eid})]


def response_api(requests, delta=None, complete=True, epoch=17):
    """Синтетическое разбиение сокращённой записи на две части, затем управляемый delta."""
    data = recording()
    events = list(data["events"].items())
    common = {"epoch": epoch, "generated": int(NOW.timestamp() * 1000)}
    index = {**common, "version": 100, "top_events_versions": [101], "rest_events_versions": [102]}
    one = {**common, **{k: data[k] for k in ("sports", "categories", "tournaments")},
           "events": dict(events[:4]), "version": 101, "snapshot_complete": False}
    two = {**common, "events": dict(events[4:]), "version": 501, "snapshot_complete": complete}

    def handler(request):
        requests.append(request)
        version = request.url.path.rsplit("/", 1)[1]
        value = {"0": index, "101": one, "102": two}.get(version)
        if value is None:
            value = {**common, "version": 502, "events": {}}
            value.update(delta or {})
        return httpx.Response(200, json=value)
    return handler


async def test_recorded_seven_games_have_only_one_ask_and_no_fee(adapter):
    actual = markets(adapter)
    assert {m.game for m in actual} == {"cs2", "dota2", "lol", "valorant", "overwatch", "r6", "mlbb"}
    assert len(actual) == 7
    for m in actual:
        assert len(m.asks_a) == len(m.asks_b) == 1
        assert m.outcome_a_bid is m.outcome_b_bid is None
        assert m.fee.model == "none" and m.fee.rate == 0
        assert m.asks_a[0].price * m.asks_a[0].size == pytest.approx(50, abs=1e-5)
        assert m.asks_b[0].price * m.asks_b[0].size == pytest.approx(50, abs=1e-5)
        assert m.best_of is None  # наличие трёх рынков карт не доказывает BO3
        assert m.updated_at == NOW and m.extra["stake_limit_assumed"] is True
        assert m.url.startswith("https://bc.game/sports/") and m.url.endswith(m.market_id)
        assert m.tournament and not m.is_live and m.accepting_orders


async def test_outcome_ids_not_json_order_choose_the_teams(adapter):
    eid, event = first(adapter)
    event["markets"]["186"][""] = {"5": {"k": "4.0"}, "4": {"k": "1.5"}}
    m = adapter.normalize({"id": eid})[0]
    assert m.team_a == event["desc"]["competitors"][0]["name"]
    assert m.outcome_a_ask == pytest.approx(1 / 1.5)
    assert m.outcome_b_ask == pytest.approx(0.25)


@pytest.mark.parametrize("bad", [None, "x", 0, 1, -1, float("nan"), float("inf"), 1e308])
async def test_invalid_decimal_odds_are_not_quotes(adapter, bad):
    eid, event = first(adapter)
    event["markets"]["186"][""]["4"]["k"] = bad
    assert adapter.normalize({"id": eid}) == []


@pytest.mark.parametrize("change", ["third", "missing", "blocked", "map", "threeway", "bo2", "tournament",
                                    "past", "no_time", "closed", "duplicate_teams"])
async def test_unsafe_or_non_match_markets_are_excluded(adapter, change):
    eid, event = first(adapter)
    winner = event["markets"]["186"][""]
    if change == "third": winner["draw"] = {"k": "3.0"}
    elif change == "missing": winner.pop("5")
    elif change == "blocked": winner["4"]["b"] = 1
    elif change == "map": event["markets"]["186"] = {"mapnr=1": winner}
    elif change == "threeway": event["markets"]["1"] = {"": {"1": {}, "2": {}, "3": {}}}
    elif change == "bo2": event["desc"]["best_of"] = 2
    elif change == "tournament": event["desc"]["type"] = "tournament"
    elif change == "past": event["desc"]["scheduled"] = int(NOW.timestamp())
    elif change == "no_time": event["desc"].pop("scheduled")
    elif change == "closed": event["state"]["status"] = 3
    elif change == "duplicate_teams": event["desc"]["competitors"][1]["name"] = event["desc"]["competitors"][0]["name"]
    assert adapter.normalize({"id": eid}) == []


async def test_unknown_rules_do_not_guess_a_settlement(adapter):
    assert parse_rules(BCGAME_RULES) == BCGAME_PROFILE == RulesProfile()
    assert "https://bc.game/help/terms-sports" in markets(adapter)[0].resolution_rules


async def test_atomic_snapshot_and_delta_without_authentication(adapter):
    requests = []
    adapter.feeds = {}
    await transport(adapter, response_api(requests))
    found = await adapter.fetch_markets()
    assert len(found) == 7 and adapter.feeds["prematch"].version == "501"
    await adapter.poll_once()
    assert adapter.feeds["prematch"].version == "502"
    assert [r.url.path.rsplit("/", 1)[1] for r in requests] == ["0", "101", "102", "501"]
    assert all(r.method == "GET" and not r.headers.get("Authorization") and not r.headers.get("Cookie") for r in requests)
    assert adapter.status.connected and not adapter.status.error


async def test_incomplete_snapshot_does_not_replace_a_working_feed(adapter):
    original = copy.deepcopy(adapter.feeds)
    requests = []
    await transport(adapter, response_api(requests, complete=False))
    with pytest.raises(SnapshotExpired):
        await adapter._snapshot("prematch")
    assert adapter.feeds == original


async def test_expired_delta_cursor_reloads_one_complete_snapshot(adapter):
    requests = []
    await transport(adapter, response_api(requests, delta={"version": 0}))
    await adapter.poll_once()
    assert [r.url.path.rsplit("/", 1)[1] for r in requests] == ["501", "0", "101", "102"]
    assert len(markets(adapter)) == 7


async def test_epoch_change_rebuilds_the_feed(adapter):
    requests = []
    await transport(adapter, response_api(requests, epoch=18))
    await adapter.poll_once()
    assert adapter.feeds["prematch"].epoch == "18"
    assert requests[1].url.path.endswith("/0")


def test_delta_null_and_event_reset_do_not_retain_removed_prices():
    old = recording()
    eid = next(iter(old["events"]))
    original = copy.deepcopy(old)
    changed = merge_payload(old, {"events": {eid: {"markets": {"186": None}}}})
    assert "186" not in changed["events"][eid]["markets"] and old == original
    reset = merge_payload(old, {"events": {eid: {"shouldResetEvent": True, "state": {"status": 3}}}})
    assert "markets" not in reset["events"][eid]
    gone = merge_payload(old, {"events": {eid: None}})
    assert eid not in gone["events"]


async def test_reordered_teams_without_new_prices_lose_the_old_winner(adapter):
    eid, event = first(adapter)
    delta = {"events": {eid: {"desc": {"competitors": list(reversed(event["desc"]["competitors"]))}}}}
    state = adapter.feeds["prematch"]
    state.data = merge_payload(state.data, delta)
    assert adapter.normalize({"id": eid}) == []


async def test_reordered_teams_with_prices_keep_subscribed_team_orientation(adapter):
    eid, event = first(adapter)
    market = adapter.normalize({"id": eid})[0]
    adapter._subscribed = {market.key: market}
    patch = {"events": {eid: {"desc": {"competitors": list(reversed(event["desc"]["competitors"]))},
                              "markets": {"186": {"": {"4": {"k": "4.0"}, "5": {"k": "1.5"}}}}}}}
    state = adapter.feeds["prematch"]
    state.data = merge_payload(state.data, patch)
    adapter._publish(force=True)
    assert market.outcome_a_ask == pytest.approx(1 / 1.5)
    assert market.outcome_b_ask == pytest.approx(0.25)


async def test_removed_market_is_disabled_without_a_fresh_old_quote(adapter):
    market = markets(adapter)[0]
    adapter._subscribed = {market.key: market}
    adapter.feeds["prematch"].data["events"].pop(market.market_id)
    adapter._publish()
    assert not market.accepting_orders and not market.asks_a and not market.asks_b


async def test_paired_markets_publish_each_delta_others_wait(adapter, monkeypatch):
    actual = markets(adapter)
    adapter._subscribed = {m.key: m for m in actual}
    adapter.set_paired({actual[0].key})
    adapter._publish(force=True)
    next_time = NOW + timedelta(seconds=1)
    monkeypatch.setattr(bcgame, "utcnow", lambda: next_time)
    state = adapter.feeds["prematch"]
    patch = {"events": {eid: {"markets": {"186": {"": {
        oid: {"k": str(float(value["k"]) + .01)} for oid, value in event["markets"]["186"][""].items()
    }}}} for eid, event in state.data["events"].items()}}
    changed = merge_payload(state.data, patch)
    clocks = update_quote_times(state.quote_evidence, changed, patch, next_time, "17", "502")
    adapter.feeds["prematch"] = FeedState(changed, "17", "502", next_time, next_time, clocks, ("501", "502"))
    adapter._publish()
    assert actual[0].updated_at == next_time
    assert all(m.updated_at == NOW for m in actual[1:])
    adapter._published[actual[1].key] = float("-inf")
    adapter._publish()
    assert actual[1].updated_at == next_time


async def test_independent_book_read_does_not_mutate_cache_or_scanner(adapter):
    market = markets(adapter)[0]
    before = copy.deepcopy(adapter.feeds)
    original = market.model_copy(deep=True)
    delta = {"events": {market.market_id: {"markets": {"186": {"": {"4": {"k": "2.5"}}}}}}}
    requests = []
    await transport(adapter, response_api(requests, delta=delta))
    checked = await adapter.fetch_book(market)
    assert checked.outcome_a_ask == pytest.approx(0.4)
    assert checked is not market and market == original and adapter.feeds == before
    assert len(requests) == 1


@pytest.mark.parametrize("status", [401, 403])
async def test_access_denied_stops_requests_without_bypassing(adapter, status):
    requests = []
    def denied(r):
        requests.append(r)
        return httpx.Response(status, text="Sensitive upstream content must not be logged")
    await transport(adapter, denied)
    adapter._running = True
    await adapter._poll_loop()
    assert not adapter.status.connected and str(status) in adapter.status.error
    with pytest.raises(HttpError):
        await adapter.poll_once()
    assert len(requests) == 1


async def test_429_obeys_retry_after_without_switching_proxy(adapter):
    requests = []
    def limited(r):
        requests.append(r)
        return httpx.Response(429, headers={"Retry-After": "120"})
    await transport(adapter, limited)
    before = bcgame.time.monotonic()
    with pytest.raises(HttpError):
        await adapter.poll_once()
    assert adapter._retry_until >= before + 119
    with pytest.raises(HttpError):
        await adapter.poll_once()
    assert len(requests) == 1


async def test_redirect_is_not_followed(adapter):
    requests = []
    def redirected(r):
        requests.append(r)
        return httpx.Response(302, headers={"Location": "https://other.example/collect"})
    await transport(adapter, redirected)
    with pytest.raises(HttpError, match="redirect not followed"):
        await adapter.poll_once()
    assert len(requests) == 1 and requests[0].url.host == "api-k-c7818b61-623.sptpub.com"


async def test_network_errors_do_not_expose_proxy_password(adapter, caplog):
    secret = "test-proxy-password-do-not-log"
    def failed(r):
        raise httpx.ProxyError(secret)
    await transport(adapter, failed)
    adapter._running = True
    async def stop(delay):
        adapter._running = False
    adapter._sleep = stop
    await adapter._poll_loop()
    assert not adapter.status.connected
    assert secret not in caplog.text and secret not in adapter.status.error
    assert "ProxyError" in adapter.status.error


async def test_polling_errors_back_off_and_recover(adapter, caplog):
    delays = []
    calls = 0
    async def poll():
        nonlocal calls
        calls += 1
        if calls <= 2:
            raise HttpError("BC.Game: HTTP 503", 503)
        adapter.status.connected = True
        adapter.status.error = None
        adapter._running = False
    async def pause(delay):
        delays.append(delay)
    adapter.poll_once = poll
    adapter._sleep = pause
    adapter._running = True
    await adapter._poll_loop()
    assert delays[:2] == [10, 20] and adapter._backoff == 0
    assert adapter.status.connected and adapter.status.error is None
    assert caplog.text.count("Гостевой фид BC.Game недоступен") == 1


async def test_failure_clears_stale_http_latency_but_keeps_last_successful_sync(adapter):
    adapter.status.connected = True
    adapter.status.latency_ms = 4157
    adapter.status.last_update = NOW
    adapter._failure(httpx.ReadTimeout("temporary failure"))
    assert adapter.status.connected is False
    assert adapter.status.latency_ms is None
    assert adapter.status.last_update == NOW
    assert "ReadTimeout" in adapter.status.error


async def test_latency_is_last_http_response_not_full_snapshot(adapter, monkeypatch):
    clock = [10.0]
    durations = iter((1.111, 2.222, 4.157))
    monkeypatch.setattr(bcgame.time, "monotonic", lambda: clock[0])
    requests = []
    native = response_api(requests)
    async def no_limit():
        return None
    adapter._limit.acquire = no_limit
    def delayed(request):
        clock[0] += next(durations)
        return native(request)
    await transport(adapter, delayed)
    await adapter._snapshot("prematch")
    assert len(requests) == 3
    assert adapter.status.latency_ms == 4157.0


async def test_successful_sync_confirms_state_at_request_time(adapter, monkeypatch):
    from backend.engine.arb import evaluate_pair
    from tests.conftest import make_market, make_pair

    old = NOW - timedelta(seconds=100)
    adapter.feeds = {"prematch": feed(stamp=old)}
    monkeypatch.setattr("backend.adapters.bcgame.utcnow", lambda: NOW)
    requests = []
    await transport(adapter, response_api(requests, delta={"generated": int(old.timestamp() * 1000)}))
    await adapter.poll_once()
    assert all(m.updated_at == NOW for m in markets(adapter))
    assert adapter.status.last_update == NOW
    stale = markets(adapter)[0]
    fresh = make_market(team_a=stale.team_a, team_b=stale.team_b, game=stale.game, start=stale.start_time,
                        asks_a=[(0.001, 100)], asks_b=[(0.001, 100)], updated_at=NOW)
    assert evaluate_pair(make_pair(fresh, stale), fresh, stale, adapter.settings, NOW)


async def test_future_timestamp_and_malformed_json_leave_last_feed_unchanged(adapter):
    previous = copy.deepcopy(adapter.feeds)
    requests = []
    await transport(adapter, response_api(requests, delta={"generated": int((NOW + timedelta(hours=1)).timestamp() * 1000)}))
    with pytest.raises(ValueError, match="future"):
        await adapter.poll_once()
    assert adapter.feeds == previous
    await transport(adapter, lambda r: httpx.Response(200, text="not json"))
    with pytest.raises(ValueError, match="JSON"):
        await adapter.poll_once()
    assert adapter.feeds == previous


async def test_too_many_snapshot_parts_fail_without_truncating(adapter):
    requests = []
    def many(r):
        requests.append(r)
        return httpx.Response(200, json={"epoch": 17, "version": 100, "generated": NOW.timestamp() * 1000,
                                        "top_events_versions": list(range(1, 30)), "rest_events_versions": []})
    await transport(adapter, many)
    with pytest.raises(ValueError, match="part count"):
        await adapter._snapshot("prematch")
    assert len(requests) == 1


async def test_configuration_and_proxy_initialization_do_not_expose_secrets(settings, monkeypatch):
    assert settings.platforms["bcgame"].enabled is True
    assert settings.platforms["bcgame"].opt("brand_id") == "2103509236163162112"
    assert settings.fees.for_platform("bcgame").taker_rate is None
    secret = "private-proxy-placeholder"
    monkeypatch.setenv(PROXY_ENV, f"socks5://user:{secret}@proxy.example:1080")
    def fail(**kwargs):
        raise ValueError(kwargs["proxy"])
    monkeypatch.setattr(bcgame.httpx, "AsyncClient", fail)
    with pytest.raises(ValueError) as caught:
        BcGameAdapter("bcgame", settings.platforms["bcgame"], settings)
    assert secret not in str(caught.value)


@pytest.mark.parametrize("proxy_url", [None, "http://proxy.example:10809"])
@pytest.mark.parametrize("reset", [False, True], ids=["delta", "reset"])
async def test_proxy_setting_is_used_for_snapshot_delta_and_reset(settings, monkeypatch, proxy_url, reset):
    if proxy_url is None:
        monkeypatch.delenv(PROXY_ENV, raising=False)
    else:
        monkeypatch.setenv(PROXY_ENV, proxy_url)

    requests = []
    handler = response_api(requests, delta={"version": 0} if reset else {"events": {}})
    clients = []

    class RecordingClient:
        def __init__(self, **kwargs):
            self.options = kwargs
            self.base_url = str(kwargs["base_url"])
            self.is_closed = False
            clients.append(self)

        async def get(self, path):
            request = httpx.Request("GET", f"{self.base_url}{path}")
            return handler(request)

        async def aclose(self):
            self.is_closed = True

    monkeypatch.setattr(bcgame.httpx, "AsyncClient", RecordingClient)
    adapter = BcGameAdapter("bcgame", settings.platforms["bcgame"], settings)
    async def no_limit():
        return None
    adapter._limit.acquire = no_limit
    try:
        state = await adapter._snapshot("prematch")
        state = await adapter._read("prematch", state)
    finally:
        await adapter.stop()

    assert len(clients) == 1
    assert clients[0].options["proxy"] == proxy_url
    assert clients[0].options["trust_env"] is False
    expected = ["0", "101", "102", "501"]
    if reset:
        expected += ["0", "101", "102"]
    assert [request.url.path.rsplit("/", 1)[1] for request in requests] == expected
    assert state.version == ("501" if reset else "502") and state.data["events"]


async def test_parallel_reads_obey_the_semaphore_and_rate_limiter(adapter):
    entered = asyncio.Event()
    release = asyncio.Event()
    active = peak = acquired = 0
    original_acquire = adapter._limit.acquire
    async def acquire():
        nonlocal acquired
        acquired += 1
        await original_acquire()
    adapter._limit.acquire = acquire
    async def handler(request):
        nonlocal active, peak
        active += 1
        peak = max(peak, active)
        if active == 2:
            entered.set()
        await release.wait()
        active -= 1
        return httpx.Response(200, json={"version": 502})
    await transport(adapter, handler)
    tasks = [asyncio.create_task(adapter._get("prematch", "501")) for _ in range(4)]
    try:
        await asyncio.wait_for(entered.wait(), 1)
        assert peak == active == 2 and acquired == 2
        release.set()
        await asyncio.gather(*tasks)
        assert peak == 2 and acquired == 4
    finally:
        release.set()
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


async def test_timeout_retries_without_refreshing_books(adapter):
    previous = copy.deepcopy(adapter.feeds)
    calls = []
    async def no_sleep(_delay):
        return None
    adapter._sleep = no_sleep
    def timeout(request):
        calls.append(request)
        raise httpx.ReadTimeout("temporary failure")
    await transport(adapter, timeout)
    with pytest.raises(HttpError, match="ReadTimeout"):
        await adapter.poll_once()
    assert len(calls) == 3 and adapter.feeds == previous


async def test_retryable_503_recovers_without_losing_feed(adapter):
    calls = []
    native = response_api([])
    async def no_sleep(_delay):
        return None
    adapter._sleep = no_sleep
    def handler(request):
        calls.append(request)
        return httpx.Response(503, json={"error": "temporary"}) if len(calls) < 3 else native(request)
    await transport(adapter, handler)
    await adapter.poll_once()
    assert len(calls) == 3 and adapter.status.connected


async def test_exhausted_503_keeps_previous_feed(adapter):
    previous = copy.deepcopy(adapter.feeds)
    calls = []
    async def no_sleep(_delay):
        return None
    adapter._sleep = no_sleep
    await transport(adapter, lambda request: (calls.append(request) or httpx.Response(503, json={"error": "temporary"})))
    with pytest.raises(HttpError, match="HTTP 503"):
        await adapter.poll_once()
    assert len(calls) == 3 and adapter.feeds == previous


async def test_cloudfront_access_block_is_exact_and_latched(adapter):
    calls = []
    await transport(adapter, lambda request: (calls.append(request) or httpx.Response(
        503, json={"error": "access blocked"}, headers={"bb-rsn": "bc"})))
    with pytest.raises(HttpError, match=r"access blocked by CloudFront \(bb-rsn: bc\)"):
        await adapter.poll_once()
    with pytest.raises(HttpError, match="access blocked by CloudFront"):
        await adapter.poll_once()
    assert len(calls) == 1


async def test_other_cloudfront_503_reason_is_retried(adapter):
    calls = []
    native = response_api([])
    async def no_sleep(_delay):
        return None
    adapter._sleep = no_sleep
    def handler(request):
        calls.append(request)
        return (httpx.Response(503, json={"error": "maintenance"}, headers={"bb-rsn": "maintenance"})
                if len(calls) == 1 else native(request))
    await transport(adapter, handler)
    await adapter.poll_once()
    assert len(calls) == 2 and adapter.status.connected


def test_small_source_clock_skew_is_tolerated_and_clamped(adapter, monkeypatch):
    monkeypatch.setattr(bcgame, "utcnow", lambda: NOW)
    payload = {"epoch": 17, "version": 502, "generated": int((NOW + timedelta(seconds=3)).timestamp() * 1000)}
    assert adapter._identity(payload) == ("17", "502", NOW)


def test_source_clock_skew_above_tolerance_is_rejected(adapter, monkeypatch):
    monkeypatch.setattr(bcgame, "utcnow", lambda: NOW)
    payload = {"epoch": 17, "version": 502, "generated": int((NOW + timedelta(seconds=6)).timestamp() * 1000)}
    with pytest.raises(ValueError, match="source timestamp is in the future"):
        adapter._identity(payload)


async def test_invalid_feed_error_explains_parser_stage(adapter):
    await transport(adapter, lambda request: httpx.Response(200, text="not json"))
    adapter.feeds = {}
    with pytest.raises(HttpError, match="invalid JSON response"):
        await adapter.fetch_markets()
    assert adapter.status.error == "BC.Game: feed unavailable (ValueError): BC.Game: invalid JSON response"


async def test_live_feed_is_opt_in_and_never_enters_prematch(adapter):
    eid, event = first(adapter)
    event["desc"]["scheduled"] = int((NOW - timedelta(minutes=1)).timestamp())
    event["state"]["status"] = 1
    assert adapter.normalize({"id": eid}) == []
    adapter.feeds["live"] = copy.deepcopy(adapter.feeds["prematch"])
    assert adapter.normalize({"id": eid, "channel": "live"}) == []
    adapter.include_live = True
    adapter.channels = ("prematch", "live")
    live = adapter.normalize({"id": eid, "channel": "live"})
    assert len(live) == 1 and live[0].is_live


async def test_declared_timeout_and_numeric_limits(settings, monkeypatch):
    monkeypatch.delenv(PROXY_ENV, raising=False)
    cfg = PlatformConfig.model_validate({**settings.platforms["bcgame"].model_dump(), "request_timeout_sec": 7})
    a = BcGameAdapter("bcgame", cfg, settings)
    try:
        assert a.http.timeout.connect == a.http.timeout.read == 7
    finally:
        await a.stop()
    for option in ("poll_interval_sec", "rate_limit_per_sec", "max_stake_usd"):
        cfg = PlatformConfig.model_validate({**settings.platforms["bcgame"].model_dump(), option: float("nan")})
        with pytest.raises(ValueError, match="positive finite"):
            BcGameAdapter("bcgame", cfg, settings)


@pytest.mark.parametrize("change", ["format", "start"])
async def test_metadata_change_blocks_old_pairs_until_rematching(adapter, tmp_path, change):
    from types import SimpleNamespace
    from backend.engine.arb import evaluate_pair
    from backend.engine.scanner import Scanner
    from backend.storage.db import Database
    from tests.conftest import make_market

    market = markets(adapter)[0]
    await adapter.subscribe_prices([market], lambda m: None)
    pm = make_market(platform="polymarket", team_a=market.team_a, team_b=market.team_b,
                     game=market.game, start=market.start_time, best_of=3,
                     asks_a=[(0.001, 100)], asks_b=[(0.001, 100)], updated_at=NOW)
    stub = SimpleNamespace(name="Polymarket", set_paired=lambda keys: None)
    scanner = Scanner(adapter.settings, {"polymarket": stub, "bcgame": adapter}, Database(tmp_path / "meta.db"))
    scanner.markets = {"polymarket": {pm.key: pm}, "bcgame": {market.key: market}}
    scanner.rematch()
    old_pair = scanner.pairs[0]
    assert evaluate_pair(old_pair, pm, market, adapter.settings, now=NOW)
    event = adapter.feeds["prematch"].data["events"][market.market_id]
    if change == "format":
        event["desc"]["best_of"] = 5
    else:
        event["desc"]["scheduled"] += 10 * 3600
    adapter._publish()
    assert not market.accepting_orders
    assert not evaluate_pair(old_pair, pm, market, adapter.settings, now=NOW)
    for _ in range(2):
        adapter._publish()
        assert not market.accepting_orders
    adapter.set_paired({market.key})  # другой discovery/rematch со старыми метаданными не снимает блокировку
    adapter._publish()
    assert not market.accepting_orders

    async def synced():
        pass
    adapter._sync = synced
    updated = await adapter.fetch_markets()
    scanner._merge("bcgame", updated)
    await adapter.subscribe_prices(list(scanner.markets["bcgame"].values()), lambda m: None)
    assert not market.accepting_orders
    scanner.rematch()
    assert scanner.pairs == []  # BO5 несовместим с BO3; перенос 10 ч не становится автоматической парой
    adapter._publish()
    assert market.accepting_orders


@pytest.mark.parametrize("status", [403, 429])
async def test_queued_request_rechecks_access_after_waiting_for_a_token(adapter, status):
    waiting = asyncio.Event()
    release = asyncio.Event()
    acquired = 0
    calls = []
    async def acquire():
        nonlocal acquired
        acquired += 1
        if acquired == 2:
            waiting.set()
            await release.wait()
    adapter._limit.acquire = acquire
    async def handler(request):
        calls.append(request)
        await waiting.wait()
        return httpx.Response(status, headers={"Retry-After": "120"} if status == 429 else {})
    await transport(adapter, handler)
    tasks = [asyncio.create_task(adapter._get("prematch", "501")) for _ in range(2)]
    try:
        with pytest.raises(HttpError):
            await asyncio.wait_for(tasks[0], 2)
        release.set()
        with pytest.raises(HttpError):
            await asyncio.wait_for(tasks[1], 2)
        assert len(calls) == 1
    finally:
        release.set()
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


async def test_paper_read_rejects_changed_matching_metadata(adapter):
    market = markets(adapter)[0]
    requests = []
    delta = {"events": {market.market_id: {"desc": {"best_of": 5}}}}
    await transport(adapter, response_api(requests, delta=delta))
    with pytest.raises(ValueError, match="metadata changed"):
        await adapter.fetch_book(market)


@pytest.mark.parametrize("swapped", [False, True])
def test_proven_mlbb_alias_matches_both_team_orders_without_other_games(settings, swapped):
    from backend.matching.matcher import Matcher
    from backend.matching.normalizer import TeamNormalizer
    from tests.conftest import make_market

    normalizer = TeamNormalizer.from_file(settings.resolve_path(settings.matching.aliases_file))
    left = make_market(platform="bcgame", game="mlbb", team_a="ONIC Philippines", team_b="TNC Pro Team",
                       start=NOW, best_of=None)
    names = ("TNC Pro Team", "ONIC PH") if swapped else ("ONIC PH", "TNC Pro Team")
    right = make_market(platform="polymarket", game="mlbb", team_a=names[0], team_b=names[1], start=NOW, best_of=5)
    result = Matcher(settings.matching, normalizer).match([left], [right])
    assert len(result.pairs) == 1 and not result.review and result.pairs[0].swapped is swapped
    assert normalizer.similarity("ONIC Philippines", "ONIC PH", game="mlbb") == 100
    assert normalizer.similarity("ONIC Philippines", "ONIC PH", game="cs2") < 100
    assert normalizer.similarity("ONIC Philippines", "ONIC Indonesia", game="mlbb") < 100


async def test_paper_read_pins_metadata_before_waiting(adapter):
    market = markets(adapter)[0]
    market.best_of = 3
    entered, release = asyncio.Event(), asyncio.Event()
    state = copy.deepcopy(adapter.feeds["prematch"])
    state.data["events"][market.market_id]["desc"]["best_of"] = 5
    async def read(channel, previous):
        entered.set()
        await release.wait()
        return state
    adapter._read = read
    task = asyncio.create_task(adapter.fetch_book(market))
    try:
        await asyncio.wait_for(entered.wait(), 1)
        market.best_of = 5  # discovery меняет живой объект, пока REST-запрос ожидает ответ
        release.set()
        with pytest.raises(ValueError, match="metadata changed"):
            await task
    finally:
        release.set()
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


async def test_paper_result_uses_the_original_team_order_during_input_mutation(adapter):
    market = markets(adapter)[0]
    original = market.model_copy(deep=True)
    entered, release = asyncio.Event(), asyncio.Event()
    state = copy.deepcopy(adapter.feeds["prematch"])
    async def read(channel, previous):
        entered.set()
        await release.wait()
        return state
    adapter._read = read
    task = asyncio.create_task(adapter.fetch_book(market))
    try:
        await asyncio.wait_for(entered.wait(), 1)
        market.team_a, market.team_b = market.team_b, market.team_a
        release.set()
        checked = await task
        assert (checked.team_a, checked.team_b) == (original.team_a, original.team_b)
        assert checked.outcome_a_ask == original.outcome_a_ask
        assert checked.outcome_b_ask == original.outcome_b_ask
    finally:
        release.set()
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
