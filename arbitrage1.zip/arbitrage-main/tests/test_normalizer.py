"""Team-name normalisation, aliases, qualifiers and fuzzy similarity."""

import pytest

from backend.config import load_settings
from backend.matching.normalizer import TeamNormalizer


@pytest.fixture(scope="module")
def norm():
    s = load_settings()
    return TeamNormalizer.from_file(s.resolve_path(s.matching.aliases_file))


@pytest.mark.parametrize(
    "a,b",
    [
        ("Los Niños", "Los Ninos"),
        ("QUINTESSÊNCIA", "QUINTESSENCIA"),
        ("Sökerorg", "Sokerorg"),
        ("VP.Future", "VP Future"),
        ("Team Liquid", "Liquid"),
        ("FaZe Clan", "FaZe"),
        ("ex-6666", "6666"),
        ("Bigetron by Vitality", "Bigetron"),
        ("KUUSAMO.gg", "KUUSAMO"),
        ("Fire Flux Esports", "Fire Flux"),
        ("ARK E-sports", "ARK"),
    ],
)
def test_spelling_variants_are_identical(norm, a, b):
    assert norm.similarity(a, b) == 100


@pytest.mark.parametrize(
    "a,b",
    [
        ("NAVI", "Natus Vincere"),
        ("Na'Vi", "Natus Vincere"),
        ("G2", "G2 Esports"),
        ("NIP", "Ninjas in Pyjamas"),
        ("TL", "Team Liquid"),
        ("Apogee Esports", "Betclic Apogee Esports"),
        ("PRX", "Paper Rex"),
        ("100T", "100 Thieves"),
    ],
)
def test_aliases(norm, a, b):
    assert norm.similarity(a, b) == 100


@pytest.mark.parametrize(
    "a,b",
    [
        ("Spirit", "Spirit Academy"),
        ("Team Spirit", "Spirit Academy"),
        ("MIBR", "MIBR Female"),
        ("ENCE", "ENCE Prospects"),
        ("Inner Circle", "Inner Circle Prospect"),
        ("NIP", "Young Ninjas"),
    ],
)
def test_different_squads_are_not_merged(norm, a, b):
    assert norm.similarity(a, b) <= 40


def test_qualifier_synonyms_are_equal(norm):
    assert norm.similarity("MIBR GC", "MIBR Female") == 100
    assert norm.similarity("FURIA fe", "FURIA Female") == 100
    assert norm.similarity("Spirit Academy", "Team Spirit Academy") == 100


def test_extra_token_is_penalised_not_rejected(norm):
    # Could be a sponsor name or a different team (G2 Ares is G2's academy): needs review.
    assert norm.similarity("G2 Ares", "G2") == 85
    assert norm.similarity("ONIC PH", "ONIC") == 85


def test_acronym_without_alias():
    bare = TeamNormalizer({})
    assert bare.similarity("NIP", "Ninjas in Pyjamas") == 90
    assert bare.similarity("EF", "Eternal Fire") == 90


def test_unrelated_teams(norm):
    assert norm.similarity("Natus Vincere", "Virtus.pro") < 50
    assert norm.similarity("Team Liquid ID", "Team Liquid PH") < 85


def test_game_specific_alias(norm):
    assert norm.similarity("RRQ", "RRQ Hoshi", game="mlbb") == 100
    assert norm.similarity("RRQ", "RRQ Hoshi", game="cs2") < 100


def test_normalize_output(norm):
    assert norm.normalize("Team Liquid") == "liquid"
    assert norm.normalize("MIBR GC") == "mibr female"
    assert norm.normalize("NAVI") == norm.normalize("Natus Vincere")
