"""Adapter parsing on fixtures captured from the real APIs (no network)."""

import json
from datetime import datetime, timedelta, timezone

import pytest

from backend.adapters.common import parse_best_of, parse_dt, slugify, split_teams
from backend.adapters.kalshi import KalshiAdapter, parse_book, parse_rules_time, parse_ticker_time
from backend.adapters.polymarket import PolymarketAdapter, TokenBook, WsConn
from backend.models import utcnow
from tests.conftest import load_fixture

KALSHI_SERIES_META = {"title": "Counter-Strike 2 Game", "fee_multiplier": 1, "fee_type": "quadratic"}


def test_common_helpers():
    assert parse_dt("2026-10-16 08:00:00+00") == datetime(2026, 10, 16, 8, tzinfo=timezone.utc)
    assert parse_dt("2026-10-16T08:00:00Z") == datetime(2026, 10, 16, 8, tzinfo=timezone.utc)
    assert parse_dt("garbage") is None
    assert parse_best_of("Counter-Strike: NIP vs Liquid (BO3) - X") == 3
    assert parse_best_of(None, "0-0|0-0|Bo5") == 5
    assert parse_best_of("no format here") is None
    assert slugify("Counter-Strike 2 Game") == "counterstrike-2-game"
    assert split_teams("Counter-Strike: NIP vs Liquid (BO3) - Stake Pulse") == ("NIP", "Liquid")
    assert split_teams("OCS Korea Stage 3 2026: SEIJI ESPORTS vs. Falcons") == ("SEIJI ESPORTS", "Falcons")
    assert split_teams("Liquid vs. NIP") == ("Liquid", "NIP")


def test_polymarket_event_to_market(settings):
    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    markets = adapter._normalize_event(load_fixture("polymarket_event.json"), "cs2")
    assert len(markets) == 1  # only the "moneyline" (match winner); maps and totals ignored
    m = markets[0]
    assert (m.team_a, m.team_b) == ("NIP", "Liquid")
    assert m.best_of == 3
    assert m.start_time == datetime(2026, 10, 16, 8, tzinfo=timezone.utc)
    assert m.url == "https://polymarket.com/event/cs2-nip-tl1-2026-10-16"
    assert m.fee.model == "polymarket" and m.fee.rate == pytest.approx(0.05)
    assert m.min_order_size == 5
    assert m.tournament == "Stake Pulse Beat III Playoffs"
    assert "50-50" in m.resolution_rules
    assert m.extra["token_a"].startswith("7032778262")
    # Indicative Gamma prices are present but never "fresh" (no sizes, no updated_at).
    assert m.updated_at is None
    assert adapter.normalize(load_fixture("polymarket_event.json"))[0].key == m.key


def test_polymarket_ws_messages_update_books(settings):
    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    market = adapter._normalize_event(load_fixture("polymarket_event.json"), "cs2")[0]
    ta, tb = market.extra["token_a"], market.extra["token_b"]
    adapter._subscribed = {market.key: market}
    adapter.token_index = {ta: (market.key, "a"), tb: (market.key, "b")}
    books = [
        {"event_type": "book", "asset_id": ta, "timestamp": "1000",
         "bids": [{"price": "0.53", "size": "10"}], "asks": [{"price": "0.60", "size": "100"}, {"price": "0.56", "size": "5"}]},
        {"event_type": "book", "asset_id": tb, "timestamp": "1000",
         "bids": [{"price": "0.40", "size": "100"}, {"price": "0.44", "size": "5"}], "asks": [{"price": "0.47", "size": "10"}]},
    ]
    conn = WsConn()
    assert adapter._on_ws_message(json.dumps(books), conn) is True
    assert conn.ready == {ta, tb}
    assert market.outcome_a_ask == pytest.approx(0.56) and market.outcome_a_ask_size == pytest.approx(5)
    assert market.outcome_b_ask == pytest.approx(0.47)
    assert market.outcome_a_bid == pytest.approx(0.53)
    assert market.updated_at is not None
    change = {"event_type": "price_change", "timestamp": "1001", "price_changes": [
        {"asset_id": ta, "price": "0.56", "size": "0", "side": "SELL"},
        {"asset_id": tb, "price": "0.44", "size": "0", "side": "BUY"},
    ]}
    adapter._on_ws_message(json.dumps(change), conn)
    assert market.outcome_a_ask == pytest.approx(0.60)
    assert market.outcome_b_bid == pytest.approx(0.40)
    # An older REST snapshot must not overwrite newer WebSocket state.
    assert adapter.books[ta].snapshot([], [{"price": "0.10", "size": "1"}], 900) is False


def test_kalshi_time_parsing():
    assert parse_ticker_time("KXCS2GAME-26OCT160400TLNIP") == datetime(2026, 10, 16, 8, tzinfo=timezone.utc)
    # Winter time (EST, UTC-5).
    assert parse_ticker_time("KXCS2GAME-27JAN150400ABCD") == datetime(2027, 1, 15, 9, tzinfo=timezone.utc)
    text = "match originally scheduled for Oct 15, 2026 at 2:00 PM EDT, then"
    assert parse_rules_time(text) == datetime(2026, 10, 15, 18, tzinfo=timezone.utc)
    assert parse_rules_time("originally scheduled for Oct 16, 2026, then") is None  # no time of day


def test_kalshi_event_to_market(settings):
    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    markets = adapter._normalize_event(load_fixture("kalshi_event.json"), "cs2", "KXCS2GAME", KALSHI_SERIES_META)
    assert len(markets) == 1
    m = markets[0]
    assert (m.team_a, m.team_b) == ("Liquid", "NIP")
    assert m.market_id == "KXCS2GAME-26OCT160400TLNIP"
    assert m.start_time == datetime(2026, 10, 16, 8, tzinfo=timezone.utc)
    assert m.best_of is None
    assert m.tournament == "Stake Pulse Beat III 2026"
    assert m.url == "https://kalshi.com/markets/kxcs2game/counterstrike-2-game/kxcs2game-26oct160400tlnip"
    assert m.fee.model == "kalshi" and m.fee.rate == pytest.approx(0.07) and m.fee.round_up_cents
    assert "fair market price" in m.resolution_rules
    assert m.extra["ticker_a"].endswith("-TL") and m.extra["ticker_b"].endswith("-NIP")


def test_kalshi_books_merge_yes_and_opponent_no(settings):
    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    market = adapter._normalize_event(load_fixture("kalshi_event.json"), "cs2", "KXCS2GAME", KALSHI_SERIES_META)[0]
    books = {ob["ticker"]: parse_book(ob["orderbook_fp"]) for ob in load_fixture("kalshi_orderbooks.json")["orderbooks"]}
    book_tl, book_nip = books[market.extra["ticker_a"]], books[market.extra["ticker_b"]]
    adapter.books.update(books)
    adapter.book_ts.update({ticker: utcnow() for ticker in books})
    assert adapter._apply_books(market)
    yes_tl = round(1 - book_tl["no"][0][0], 4)  # ask YES Liquid = 1 - best NO bid on Liquid
    no_nip = round(1 - book_nip["yes"][0][0], 4)  # ask NO NIP = 1 - best YES bid on NIP
    assert market.outcome_a_ask == pytest.approx(min(yes_tl, no_nip))
    instruments = {lv.instrument.split(" ")[0] for lv in market.asks_a}
    assert instruments <= {"YES", "NO"} and len(market.asks_a) > 1
    assert all(market.asks_a[i].price <= market.asks_a[i + 1].price for i in range(len(market.asks_a) - 1))

    adapter.use_no_side = False
    adapter._apply_books(market)
    assert market.outcome_a_ask == pytest.approx(yes_tl)
    assert all(lv.instrument.startswith("YES") for lv in market.asks_a)


def test_kalshi_parse_book_supports_legacy_cents():
    book = parse_book({"yes": [[42, 10], [40, 5]], "no": [[55, 3]]})
    assert book["yes"][0] == (0.42, 10) and book["no"][0] == (0.55, 3)


def test_polymarket_pong_refreshes_only_books_snapshotted_on_that_connection(settings):
    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    market = adapter._normalize_event(load_fixture("polymarket_event.json"), "cs2")[0]
    ta, tb = market.extra["token_a"], market.extra["token_b"]
    adapter._subscribed = {market.key: market}
    adapter.token_index = {ta: (market.key, "a"), tb: (market.key, "b")}
    old = utcnow() - timedelta(minutes=10)
    level = [{"price": "0.5", "size": "10"}]
    adapter.books[ta] = TokenBook()
    adapter.books[ta].snapshot(level, level, 1, old)
    adapter.books[tb] = TokenBook()
    adapter.books[tb].snapshot(level, level, 1, old)
    adapter._apply_book(market, notify=False)
    assert market.updated_at == old  # stamped with the real receive time, not "now"

    adapter._on_ws_message("PONG", WsConn())  # a connection that never snapshotted these tokens
    assert market.updated_at == old
    conn = WsConn()
    conn.ready = {ta, tb}
    adapter._on_ws_message("PONG", conn)
    assert market.updated_at > old


def test_rediscovery_does_not_make_stale_books_fresh(settings):
    # Polymarket: cached books received 10 minutes ago stay 10 minutes old after rediscovery.
    pm = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    event = load_fixture("polymarket_event.json")
    first = pm._normalize_event(event, "cs2")[0]
    old = utcnow() - timedelta(minutes=10)
    for token in (first.extra["token_a"], first.extra["token_b"]):
        pm.books[token] = TokenBook()
        pm.books[token].snapshot([{"price": "0.4", "size": "5"}], [{"price": "0.6", "size": "5"}], 1, old)
    again = pm._normalize_event(event, "cs2")[0]
    assert again.updated_at == old

    # Kalshi: old cached books are not re-stamped; the fresh top of book from the event is used instead.
    ks = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    kevent = load_fixture("kalshi_event.json")
    for ob in load_fixture("kalshi_orderbooks.json")["orderbooks"]:
        ks.books[ob["ticker"]] = parse_book(ob["orderbook_fp"])
        ks.book_ts[ob["ticker"]] = old
    market = ks._normalize_event(kevent, "cs2", "KXCS2GAME", KALSHI_SERIES_META)[0]
    assert market.updated_at > old
    assert len(market.asks_a) <= 2  # one level per instrument: the event's top of book, not the cached depth
    assert ks._apply_books(market) and market.updated_at == old


async def test_kalshi_exchange_pause_blocks_trading(settings):
    import httpx

    from backend.net import HttpClient

    ks = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    market = ks._normalize_event(load_fixture("kalshi_event.json"), "cs2", "KXCS2GAME", KALSHI_SERIES_META)[0]
    ks._subscribed = {market.key: market}
    payload = {"exchange_active": True, "trading_active": False, "exchange_index_statuses": [
        {"exchange_index": 0, "exchange_active": True, "trading_active": False}]}
    await ks.http.aclose()
    ks.http = HttpClient("https://api.test", "kalshi", rate_per_sec=1000,
                         transport=httpx.MockTransport(lambda r: httpx.Response(200, json=payload)))
    await ks.refresh_exchange_status()
    assert market.accepting_orders is False
    payload["trading_active"] = True
    payload["exchange_index_statuses"][0]["trading_active"] = True
    await ks.refresh_exchange_status()
    assert market.accepting_orders is True
    await ks.http.aclose()
