// Frontend logic without a browser: new-arb alerts and data liveness. Run: node --test tests/js/*.test.mjs
import assert from 'node:assert/strict';
import { test } from 'node:test';

import { createDetector } from '../../frontend/js/detector.js';
import { legCell, quoteCells } from '../../frontend/js/views/common.js';
import { acceptHeartbeat, acceptState, dataNow, isStale, scannerStalled, serverNow, store } from '../../frontend/js/store.js';

const arb = (id, profit, confirmed = true, firstSeen = '2026-10-15T20:00:00+00:00') => ({
  arb_id: id, first_seen: firstSeen, profit_pct: profit, confirmed,
});
const ids = (list) => list.map((a) => a.arb_id);

test('first call only records what is on screen', () => {
  const detect = createDetector(() => true);
  assert.deepEqual(detect([arb('a', 1)]), []);
  assert.deepEqual(ids(detect([arb('a', 1), arb('b', 2)])), ['b']);
  assert.deepEqual(detect([arb('a', 1), arb('b', 2)]), []); // announced once
});

test('an arb is announced when its own profit grows past the filter', () => {
  const filter = { min: 2 };
  const detect = createDetector((a) => a.profit_pct >= filter.min);
  detect([]);
  assert.deepEqual(detect([arb('x', 0.8)]), []); // confirmed but filtered out
  assert.deepEqual(ids(detect([arb('x', 4)])), ['x']);
});

test('arbs revealed only by a filter change are not announced', () => {
  const filter = { min: 2 };
  const detect = createDetector((a) => a.profit_pct >= filter.min);
  detect([]);
  detect([arb('x', 0.8)]);
  filter.min = 0.5; // the user loosens the filter; the arb itself did not change
  assert.deepEqual(detect([arb('x', 0.8)]), []);
});

test('intermediate filter values while typing do not mute a later alert', () => {
  const filter = { min: 2 };
  const detect = createDetector((a) => a.profit_pct >= filter.min);
  detect([]);
  detect([arb('x', 0.8)]);
  filter.min = -Infinity; // field cleared for a moment: everything is visible
  assert.deepEqual(detect([arb('x', 0.8)]), []);
  filter.min = 1.5; // the user finishes typing "1.5"
  assert.deepEqual(detect([arb('x', 0.9)]), []);
  assert.deepEqual(ids(detect([arb('x', 2.1)])), ['x']); // its own growth still alerts
});

test('re-confirmation after a threshold change is not announced twice', () => {
  const detect = createDetector(() => true);
  detect([]);
  assert.deepEqual(ids(detect([arb('a', 1)])), ['a']);
  assert.deepEqual(detect([arb('a', 1, false)]), []); // threshold raised: back to candidate
  assert.deepEqual(detect([arb('a', 1, true)]), []);
  // The same arb that disappears and comes back is a new occurrence.
  detect([]);
  assert.deepEqual(ids(detect([arb('a', 1, true, '2026-10-15T20:05:00+00:00')])), ['a']);
});

// ---------------------------------------------------------------- liveness

const iso = (ms) => new Date(ms).toISOString();
function state(version, { evalLagMs = 300, startedAt = 's1' } = {}) {
  const now = Date.now();
  return { version, started_at: startedAt, server_time: iso(now), last_eval_at: iso(now - evalLagMs), arbs: [] };
}
function reset() {
  Object.assign(store, { state: null, lastDataAt: 0, evalLagMs: null, evalLagSince: 0, clockOffset: 0 });
  Object.assign(store.conn, { ws: 'connecting', poll: 'idle', retryAt: 0, lastMessageAt: 0 });
}

test('fresh data is live; silence for more than 6 s makes it stale', () => {
  reset();
  assert.equal(isStale(), false); // still connecting: not stale yet
  store.conn.ws = 'open';
  acceptState(state(1));
  assert.equal(isStale(), false);
  assert.equal(scannerStalled(), false);
  store.lastDataAt = Date.now() - 7000; // frozen server / silent socket
  assert.equal(isStale(), true);
  assert.equal(scannerStalled(), false); // silence is never reported as a stuck scanner
  // Timers stop at the last data (server clock), not at the current time. No wall-clock tolerance: the
  // clock offset comes from a sample taken a moment after the STATE was built, so it is not exactly 0.
  assert.equal(dataNow(), store.lastDataAt + store.clockOffset);
  assert.ok(serverNow() - dataNow() >= 7000);
});

test('socket closed and REST failing is stale at once', () => {
  reset();
  store.conn.ws = 'open';
  acceptState(state(1));
  Object.assign(store.conn, { ws: 'closed', poll: 'fail' });
  assert.equal(isStale(), true);
  Object.assign(store.conn, { poll: 'ok' });
  assert.equal(isStale(), false); // REST fallback still delivers
});

test('a stuck scanner is detected from server timestamps (heartbeats)', () => {
  reset();
  store.conn.ws = 'open';
  acceptState(state(7));
  assert.equal(scannerStalled(), false);
  const now = Date.now();
  // Version unchanged, last evaluation 8 s ago on the server clock.
  assert.equal(acceptHeartbeat({ version: 7, started_at: 's1', server_time: iso(now), last_eval_at: iso(now - 8000) }), true);
  assert.equal(isStale(), false);
  assert.equal(scannerStalled(), false); // one lagging message is not enough (server resuming after a freeze)
  store.evalLagSince = Date.now() - 2000; // the lag persisted for 2 s
  assert.equal(scannerStalled(), true);
  // A heartbeat for another version means a STATE was missed.
  assert.equal(acceptHeartbeat({ version: 9, started_at: 's1', server_time: iso(now), last_eval_at: iso(now) }), false);
});

test('a cached snapshot from REST (same version) still updates the scanner age', () => {
  reset();
  store.conn.poll = 'ok';
  acceptState(state(3));
  assert.equal(acceptState(state(3, { evalLagMs: 9000 })), false); // not newer, but the server clock moved on
  store.evalLagSince = Date.now() - 2000;
  assert.equal(scannerStalled(), true);
});

test('a server resuming after a freeze is not reported as a stuck scanner', () => {
  reset();
  store.conn.ws = 'open';
  acceptState(state(4));
  acceptHeartbeat({ version: 4, started_at: 's1', server_time: iso(Date.now()), last_eval_at: iso(Date.now() - 15000) });
  assert.equal(scannerStalled(), false);
  acceptState(state(5)); // its first evaluation after the freeze, a fraction of a second later
  assert.equal(store.evalLagSince, 0);
  assert.equal(scannerStalled(), false);
});

// ---------------------------------------------------------------- pairs table quotes

test('quote cells show the prices the engine uses, in the left team order', () => {
  const pair = {
    swapped: true, // the right market lists the teams as B vs A
    left: { ask_a: 0.5, ask_b: 0.6, instrument_a: null, instrument_b: null, ask_a_size: 100, ask_b_size: 100 },
    right: { ask_a: 0.4, ask_b: 0.45, instrument_a: 'YES «B»', instrument_b: 'YES «A»', ask_a_size: 0.5, ask_b_size: 9 },
    quotes: {
      // Direction A = A on the left + B on the right; the 0.5-contract leftover at 0.40 was skipped.
      A: { left_price: 0.5, right_price: 0.42, left_instrument: null, right_instrument: 'NO «A»', contracts: 100 },
      B: null,
    },
  };
  const c = quoteCells(pair);
  assert.deepEqual(c.rightB, { ask: 0.42, instrument: 'NO «A»', size: 100, executed: true });
  assert.equal(c.leftA.ask, 0.5);
  // Direction B has no quote: the raw top of the book, aligned to the left team order.
  assert.deepEqual(c.leftB, { ask: 0.6, instrument: null, size: 100, executed: false });
  assert.deepEqual(c.rightA, { ask: 0.45, instrument: 'YES «A»', size: 9, executed: false });
});

test('a split order shows one instrument per line, escaped; a " + " inside a team name does not split', () => {
  const html = legCell({ platform: 'kalshi', ask: 0.42, outcome: 'B', instrument: 'YES «<b>» ×3 + NO «A + B» ×4' });
  const instr = html.match(/<div class="leg-instr"[^>]*>(.*?)<\/div>/)[1];
  assert.equal(instr, 'YES «&lt;b&gt;» ×3<br>+ NO «A + B» ×4');
  assert.ok(!html.includes('<b>'));
  assert.equal(legCell({ platform: 'kalshi', ask: 0.4, outcome: 'B', instrument: 'YES «B»' }).includes('<br>'), false);
});
