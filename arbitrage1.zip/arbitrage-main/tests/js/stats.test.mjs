// "Статистика" tab helpers without a browser. Run: node --test tests/js/*.test.mjs
import assert from 'node:assert/strict';
import { test } from 'node:test';

import {
  PHASE_LABELS, arbsWord, barPct, cappedText, flagsText, fmtDay, fmtHours, fmtMinutes, fmtShare, fmtZoned, paperCell,
  periodDays, statsKpis, uptimeNote, uptimeText, usdOrNoData,
} from '../../frontend/js/stats-format.js';

const NBSP = '\u00a0';

test('periods: only the offered ones, otherwise 7 days', () => {
  assert.equal(periodDays(30), 30);
  assert.equal(periodDays('1'), 1);
  assert.equal(periodDays(14), 7);
  assert.equal(periodDays(undefined), 7);
});

test('hours, minutes, days, shares and bars', () => {
  assert.equal(fmtHours(null), '—');
  assert.equal(fmtHours(0), '0,0');
  assert.equal(fmtHours(0.03), '<0,1'); // two minutes are not "0,0"
  assert.equal(fmtHours(23.96), '24,0');
  assert.equal(fmtMinutes(2), '2 мин');
  assert.equal(fmtMinutes(2045), '34 ч 05 мин');
  assert.equal(fmtMinutes(null), '—');
  assert.equal(fmtDay('2026-10-16', 'пт'), '16.10 пт');
  assert.equal(fmtDay(''), '—');
  assert.equal(fmtShare(0.583), `58${NBSP}%`);
  assert.equal(fmtShare(null), '—');
  assert.equal(barPct(0, 10), 0);
  assert.equal(barPct(1, 1000), 2); // a non-zero value stays visible
  assert.equal(barPct(5, 10), 50);
  assert.equal(barPct(3, 0), 0);
  assert.deepEqual([1, 2, 5, 21, 1.5].map(arbsWord), ['вилка', 'вилки', 'вилок', 'вилка', 'вилки']);
});

test('time in the report time zone (Moscow is UTC+3)', () => {
  assert.equal(fmtZoned('2026-10-16T13:40:00+00:00', 'Europe/Moscow'), '16.10.2026 16:40');
  assert.equal(fmtZoned('', 'Europe/Moscow'), '—');
});

const report = {
  days: 7,
  timezone: 'Europe/Moscow',
  period: { since: '2026-10-09T21:00:00+00:00' },
  uptime_tracked: true,
  uptime_since: '2026-10-14T21:00:00+00:00',
  settings: { exclude_top_n: 10, bankroll_usd: 1000, max_stake_per_arb_usd: 100, settle_hours: 3, paper_delays_sec: [5, 15, 60] },
  totals: {
    arbs: 12, distinct_arbs: 7, matches: 5, captured_arbs: 4, median_lifetime_sec: 45, share_30s: 0.58, share_60s: 0.33,
    run_minutes: 2040, data_minutes: 1980, per_24h: { arbs: 1.9, profit_usd: 0.56, distinct_arbs: 1.2 },
    honest: {
      profit_usd: 3.45, profit_trimmed_usd: 1.2, outliers: 10, confirm_profit_usd: 0.8, profit_spread: { p50: 0.21, p90: 3.3 },
      bankroll: { bankroll_usd: 1000, max_stake_usd: 100, taken: 9, arbs: 12, profit_usd: 2.5, exact_arbs: 4, estimated_arbs: 5 },
      paper: [{ delay_sec: 5, checked: 4, left: 1, share_left: 0.25, errors: 0 }, { delay_sec: 15, checked: 0, left: 0, errors: 2 }],
    },
  },
  by_day: [{ run_hours: null }, { run_hours: 24 }],
};

test('headline figures: values at confirmation, without outliers, medians, bankroll, paper checks', () => {
  const k = Object.fromEntries(statsKpis(report).map((x) => [x.id, x]));
  assert.deepEqual(Object.keys(k), ['arbs', 'confirm', 'trimmed', 'median', 'bankroll', 'paper', 'lifetime', 'rate']);
  assert.equal(k.arbs.value, '12');
  assert.equal(k.arbs.sub, 'уникальных 7 · матчей 5');
  assert.equal(k.confirm.value, `0,80${NBSP}$`);
  assert.equal(k.confirm.sub, 'у 4 из 12 вилок');
  assert.equal(k.trimmed.label, 'Без топ-10');
  assert.equal(k.trimmed.value, `1,20${NBSP}$`);
  assert.equal(k.trimmed.sub, `сумма максимумов без них; всего 3,45${NBSP}$`);
  assert.equal(k.median.label, 'Прибыль на вилку, медиана');
  assert.equal(k.median.value, `0,21${NBSP}$`);
  assert.equal(k.median.sub, `максимум за жизнь · p90 3,30${NBSP}$`);
  assert.equal(k.confirm.muted, false);
  assert.equal(k.bankroll.label, `Банкролл 1${NBSP}000${NBSP}$`);
  assert.equal(k.bankroll.value, `2,50${NBSP}$*`); // part of it is an estimate by the maxima
  assert.equal(k.bankroll.sub, `до 100${NBSP}$ на вилку · взято 9 из 12`);
  assert.equal(k.paper.label, 'Осталось через +5 с');
  assert.equal(k.paper.value, `25${NBSP}%`);
  assert.equal(k.paper.sub, '1 из 4 проверенных');
  assert.equal(k.lifetime.value, '45 с');
  assert.equal(k.rate.value, '1,9 вилки');
  assert.equal(k.rate.sub, 'уникальных 1,2');
  assert.equal(uptimeText(report), 'работа 34 ч 00 мин, со свежими данными 33 ч 00 мин');
  // Old rows only: no data at confirmation, no paper checks — said in words, not as zeros.
  const old = Object.fromEntries(statsKpis({ ...report, totals: { ...report.totals, captured_arbs: 0, honest: { ...report.totals.honest, paper: [{ delay_sec: 5, checked: 0, left: 0, errors: 0 }] } } }).map((x) => [x.id, x]));
  assert.equal(old.confirm.value, 'данных нет');
  assert.equal(old.confirm.sub, 'вилки записаны до этой версии');
  assert.equal(old.confirm.muted, true); // «данных нет» не зелёным
  assert.equal(old.paper.value, 'данных нет');
  // Исключено меньше вилок, чем в настройке (или ни одной): подпись по факту.
  const few = Object.fromEntries(statsKpis({ ...report, totals: { ...report.totals, honest: { ...report.totals.honest, outliers: 0 } } }).map((x) => [x.id, x]));
  assert.equal(few.trimmed.label, 'Сумма максимумов');
  const off = Object.fromEntries(statsKpis({ ...report, settings: { ...report.settings, paper_enabled: false }, totals: { ...report.totals, honest: { ...report.totals.honest, paper: [] } } }).map((x) => [x.id, x]));
  assert.equal(off.paper.sub, 'проверки выключены (paper.enabled)');
  // Nothing measured yet: dashes and explanations instead of zeros that look like data.
  const empty = Object.fromEntries(statsKpis({ totals: { arbs: 0, per_24h: null } }).map((x) => [x.id, x]));
  assert.equal(empty.median.value, '—');
  assert.equal(empty.confirm.sub, 'вилок нет');
  assert.equal(empty.bankroll.value, '—');
  assert.equal(empty.rate.sub, 'нужно хотя бы 24 ч со свежими данными');
  assert.equal(uptimeText({ totals: {} }), 'время работы не записано');
  // "Сегодня" can hardly collect 24 h of fresh data: point to a longer period instead of "wait".
  const today = Object.fromEntries(statsKpis({ days: 1, totals: { arbs: 0, per_24h: null, rate_min_data_hours: 24 } }).map((x) => [x.id, x]));
  assert.equal(today.rate.sub, 'для оценки выберите 7 дней или больше');
  // The word agrees with the rounded number that is shown; big counts are formatted.
  const rateOf = (arbs) => statsKpis({ totals: { per_24h: { arbs, profit_usd: 1 } } }).find((x) => x.id === 'rate').value;
  assert.deepEqual([4.97, 0.96, 20.98, 4.94].map(rateOf), ['5 вилок', '1 вилка', '21 вилка', '4,9 вилки']);
  const many = statsKpis({ totals: { arbs: 12345, distinct_arbs: 4321, matches: 1200 } })[0];
  assert.equal(many.value, `12${NBSP}345`);
  assert.equal(many.sub, `уникальных 4${NBSP}321 · матчей 1${NBSP}200`);
});

test('cells of the honest tables: estimates, paper checks, flags', () => {
  assert.equal(cappedText({ profit_usd: 10, exact_arbs: 2, estimated_arbs: 0 }), `10,00${NBSP}$`);
  assert.equal(cappedText({ profit_usd: 10, exact_arbs: 0, estimated_arbs: 3 }), `10,00${NBSP}$**`);
  assert.equal(cappedText(null), '—');
  const paper = report.totals.honest.paper;
  assert.equal(paperCell(paper, 5), `1 из 4 (25${NBSP}%)`);
  assert.equal(paperCell(paper, 15), 'без данных у 2');
  assert.equal(paperCell(paper, 60), 'данных нет');
  assert.equal(flagsText({ large_volume: 1, size_jump: 2, stale_data: 0, no_data: 3 }, 5), 'большой объём ×1, скачок размера ×2, нет снимков ×3');
  assert.equal(flagsText({ large_volume: 0, size_jump: 0, stale_data: 0, no_data: 3 }, 3), 'нет снимков');
  assert.equal(flagsText(undefined, 3), '');
  assert.equal(usdOrNoData(null), 'данных нет');
  assert.equal(PHASE_LABELS.prematch, 'до старта');
});

test('uptime note explains the dashes and partial hours', () => {
  // Tracking started inside the period: earlier hours are unknown or partial.
  assert.equal(uptimeNote(report), 'Время работы записывается с 15.10.2026 00:00: до этого часы неизвестны («—») или неполные.');
  assert.match(uptimeNote({ ...report, uptime_tracked: false }), /^Время работы сканера ещё не записано/);
  // Tracking started before the period, yet a day has arbs but no uptime rows.
  const before = { ...report, uptime_since: '2026-10-01T00:00:00+00:00' };
  assert.match(uptimeNote(before), /^Для дней с «—» время работы неизвестно/);
  assert.equal(uptimeNote({ ...before, by_day: [{ run_hours: 3 }] }), '');
});

test('server strings are escaped in the statistics tables', async () => {
  const { kpisHtml, topHtml, venuesHtml, gamesHtml } = await import('../../frontend/js/views/stats.js');
  const evil = '<img src=x onerror=alert(1)>';
  const top = topHtml({
    pairs_total: 1,
    top_pairs: [{ team_a: evil, team_b: 'B', event_title: '" onmouseover="x', tournament: evil, game: null,
      game_name: evil, platforms_label: evil, arbs: 1, total_lifetime_sec: 5, profit_usd: 1, best_profit_pct: 2,
      last_arb_at: '2026-10-16T08:00:00+00:00' }],
  });
  const venues = venuesHtml({ by_platforms: [{ label: evil, arbs: 1, distinct_arbs: 1, profit_usd: 1, best_profit_pct: 1 }] });
  const games = gamesHtml({ by_game: [{ game: null, name: evil, arbs: 1, distinct_arbs: 1, profit_usd: 1 }] });
  for (const html of [top, venues, games]) {
    assert.ok(!html.includes('<img'), html);
    assert.ok(html.includes('&lt;img src=x onerror=alert(1)&gt;'));
  }
  assert.ok(!top.includes('" onmouseover="x'));
  assert.ok(top.includes('title="&quot; onmouseover=&quot;x"'));
  const kpis = kpisHtml(report);
  assert.ok(kpis.includes('aria-label="Пояснение: Вилок"') && kpis.includes('role="button"'));
});

test('server strings are escaped in the honest tables', async () => {
  const { outliersHtml, paperHtml, phasesHtml, tournamentsHtml, topHtml } = await import('../../frontend/js/views/stats.js');
  const evil = '<img src=x onerror=alert(1)>';
  const rep = {
    settings: { exclude_top_n: 2, max_stake_per_arb_usd: 100, paper_delays_sec: [5] },
    totals: { derived_phase_arbs: 1, honest: { outliers: 2, paper: [{ delay_sec: 5, checked: 1, left: 1, share_left: 1, profit_usd: 1, capped_profit_usd: 1, books_mismatch: 0, errors: 0, no_data: 0 }] } },
    phases: [{ phase: 'prematch', label: evil, arbs: 1, distinct_arbs: 1, profit_trimmed_usd: 0, confirm_arbs: 0, paper: [] }],
    outliers: [{ team_a: evil, team_b: 'B', tournament: evil, phase: 'live', lifetime_sec: 5, volume_usd: 2000, profit_usd: 9, profit_pct: 1, large_volume: true, flags: null }],
    by_tournament: [{ tournament: evil, arbs: 1, prematch_arbs: 1, live_arbs: 0, profit_usd: 1, profit_trimmed_usd: 0, confirm_arbs: 0, large_volume_arbs: 1 }],
    pairs_total: 1,
    top_pairs: [{ team_a: evil, team_b: 'B', tournament: evil, game_name: evil, platforms_label: evil, arbs: 2, profit_usd: 1, flags: { large_volume: 1, no_data: 2 }, last_arb_at: '2026-10-16T08:00:00+00:00' }],
  };
  const htmls = [outliersHtml(rep), paperHtml(rep), phasesHtml(rep), tournamentsHtml(rep), topHtml(rep)];
  for (const html of htmls) assert.ok(!html.includes('<img'), html);
  assert.ok(htmls[0].includes('большой объём, нет снимков') && htmls[0].includes('исключены из «без топ-2»'));
  assert.ok(htmls[2].includes('до старта') && htmls[2].includes('данных нет')); // the label comes from the client
  assert.ok(htmls[4].includes('большой объём ×1, нет снимков'));
  // Partly known values at confirmation say for how many arbs they are known.
  const partly = phasesHtml({ ...rep, phases: [{ phase: 'live', arbs: 5, distinct_arbs: 5, profit_trimmed_usd: 0, confirm_arbs: 2, confirm_profit_usd: 1.5, paper: [] }] });
  assert.ok(partly.includes('(2 из 5)'));
  // No paper checks yet: one card that says so, not an empty table.
  assert.ok(paperHtml({ ...rep, totals: { honest: { paper: [{ delay_sec: 5, checked: 0, errors: 0 }] } } }).includes('данных нет'));
});
