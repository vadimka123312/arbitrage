// Метаданные и фильтры четвёртой площадки на вымышленных данных, без браузера и сети.
import assert from 'node:assert/strict';
import { beforeEach, test } from 'node:test';

import { acceptMeta, DEFAULT_FILTERS, gameInfo, platformInfo, platformTimingInfo, store } from '../../frontend/js/store.js';
import { fallbackColor } from '../../frontend/js/util.js';
import { passesFilters } from '../../frontend/js/views/arbs.js';
import { directionText, legCell, linkButton, quoteCells } from '../../frontend/js/views/common.js';
import { chipHtml } from '../../frontend/js/views/header.js';
import { freshnessText } from '../../frontend/js/views/pairs.js';

beforeEach(() => {
  store.state = null;
  acceptMeta({
    mock_mode: true,
    platforms: [
      { id: 'polymarket', name: 'Polymarket (mock)', color: '#3b82f6' },
      { id: 'kalshi', name: 'Kalshi (mock)', color: '#10b981' },
      { id: 'stake', name: 'Stake (mock)', color: '#f59e0b' },
      { id: 'bcgame', name: 'BC.Game (mock)', color: '#84cc16' },
    ],
    games: [
      { id: 'cs2', name: 'Counter-Strike 2', short: 'CS2' },
      { id: 'r6', name: 'Rainbow Six Siege', short: 'R6' },
    ],
  });
});

test('platformInfo читает все четыре площадки из метаданных, включая цвет BC.Game', () => {
  assert.deepEqual(store.meta.platforms.map((p) => platformInfo(p.id).short), [
    'Polymarket', 'Kalshi', 'Stake', 'BC.Game',
  ]);
  assert.deepEqual(platformInfo('bcgame'), {
    id: 'bcgame', name: 'BC.Game (mock)', short: 'BC.Game', color: '#84cc16',
  });
});

test('текущий статус BC.Game имеет приоритет, а недостающий цвет берётся из метаданных', () => {
  store.state = { platforms: [{ platform: 'bcgame', name: 'BC.Game' }] };
  assert.deepEqual(platformInfo('bcgame', 'другое имя'), {
    id: 'bcgame', name: 'BC.Game', short: 'BC.Game', color: '#84cc16',
  });
  store.state.platforms[0].color = ' #aabbcc ';
  assert.equal(platformInfo('bcgame').color, '#aabbcc');
});

test('метрики BC.Game называют HTTP-ответ и синхронизацию, а не возраст коэффициентов', () => {
  const timing = platformTimingInfo('bcgame');
  assert.equal(timing.latencyLabel, 'Последний HTTP-ответ');
  assert.equal(timing.updateLabel, 'Последняя успешная синхронизация');
  assert.match(timing.note, /не возраст коэффициентов/);
  const html = chipHtml({
    platform: 'bcgame', name: 'BC.Game', mode: 'rest', connected: true, healthy: true,
    latency_ms: 4157, last_update: '2026-10-20T14:00:00Z', markets: 33, error: null,
  });
  assert.match(html, /Последний HTTP-ответ/);
  assert.match(html, /Последняя успешная синхронизация/);
  assert.match(html, /data-prefix="синхр\. "/);
  assert.match(html, /HTTP .*4.*157.*мс/);
  assert.match(html, /BETBY не сообщает его отдельно/);
});

test('остальные площадки сохраняют прежние подписи метрик', () => {
  assert.deepEqual(platformTimingInfo('stake'), {
    latencyLabel: 'Задержка', latencyInline: 'задержка', latencyCompact: '',
    updateLabel: 'Обновлено', updateInline: 'обновлено', updatePrefix: 'обновлено ', note: '',
  });
});

test('свежесть BC.Game означает синхронизацию, а не доказанный возраст коэффициента', () => {
  assert.equal(
    freshnessText({ platform: 'bcgame', fresh: true }),
    'Состояние подтверждено недавней синхронизацией. Время изменения коэффициентов неизвестно.',
  );
  assert.equal(
    freshnessText({ platform: 'bcgame', fresh: false }),
    'Синхронизация устарела — пара не участвует в расчёте вилок.',
  );
  assert.equal(freshnessText({ platform: 'stake', fresh: true }), 'Котировки свежие.');
});

test('опасный цвет BC.Game заменяется безопасным запасным цветом', () => {
  for (const color of ['#84cc16; background:url(https://example.com)', 'url(javascript:alert(1))', '#84cc16" onclick="alert(1)']) {
    store.state = { platforms: [{ platform: 'bcgame', color }] };
    assert.equal(platformInfo('bcgame').color, fallbackColor('bcgame'));
    const html = legCell({ platform: 'bcgame', outcome: 'FaZe', ask: 0.5 });
    assert.ok(html.includes(`style="--pf:${fallbackColor('bcgame')}"`));
    assert.ok(!html.includes(color));
  }
});

test('без метаданных используется имя площадки из ноги, без жёсткого списка платформ', () => {
  store.meta = null;
  assert.deepEqual(platformInfo('bcgame', 'BC.Game'), {
    id: 'bcgame', name: 'BC.Game', short: 'BC.Game', color: fallbackColor('bcgame'),
  });
  assert.equal(platformInfo('bcgame').name, 'bcgame');
});

test('ссылка BC.Game сохраняет mock URL, а имена и запрещённые URL не попадают в HTML', () => {
  const url = 'https://bc.game/sports/mock/bcgame-000?mock=1&game=cs2';
  const html = linkButton('bcgame', null, url);
  assert.ok(html.includes('style="--pf:#84cc16"'));
  assert.ok(html.includes('href="https://bc.game/sports/mock/bcgame-000?mock=1&amp;game=cs2"'));
  assert.ok(html.includes('rel="noopener noreferrer"'));
  assert.ok(html.includes('BC.Game ↗'));
  const disabled = linkButton('bcgame', null, 'javascript:alert(1)');
  assert.ok(disabled.includes('pf-link disabled'));
  assert.ok(!disabled.includes('href=') && !disabled.includes('javascript:'));

  store.meta.platforms.find((p) => p.id === 'bcgame').name = 'BC.Game <img src=x onerror=alert(1)>';
  const escaped = legCell({ platform: 'bcgame', outcome: '<script>team</script>', ask: 0.5 });
  assert.ok(escaped.includes('BC.Game &lt;img'));
  assert.ok(escaped.includes('&lt;script&gt;team&lt;/script&gt;'));
  assert.ok(!escaped.includes('<img') && !escaped.includes('<script>'));
});

test('обратный порядок команд Stake и BC.Game сохраняется в котировках и описании ног', () => {
  const pair = {
    swapped: true,
    left: { platform: 'stake', team_a: 'NAVI', team_b: 'FaZe', ask_a: 0.4, ask_b: 0.7 },
    right: {
      platform: 'bcgame', team_a: 'FaZe', team_b: 'NAVI', ask_a: 0.5, ask_b: 0.7,
      ask_a_size: 50, ask_b_size: 35.75, instrument_a: 'Ставка «FaZe», коэф. 2',
    },
    quotes: {
      A: { left_price: 0.4, right_price: 0.5, contracts: 50, right_instrument: 'Ставка «FaZe», коэф. 2' },
    },
  };
  assert.equal(directionText(pair, 'A'), '«NAVI» на Stake + «FaZe» на BC.Game');
  assert.equal(directionText(pair, 'B'), '«FaZe» на Stake + «NAVI» на BC.Game');
  assert.deepEqual(quoteCells(pair).rightB, {
    ask: 0.5, instrument: 'Ставка «FaZe», коэф. 2', size: 50, executed: true,
  });
  assert.equal(quoteCells(pair).rightA.ask, 0.7);
});

test('метаданные игр и фильтры работают для синтетической вилки Stake ↔ BC.Game', () => {
  assert.deepEqual(gameInfo('r6'), { id: 'r6', name: 'Rainbow Six Siege', short: 'R6' });
  const arb = {
    game: 'r6', profit_pct: 11.111, volume_usd: 45, is_live: false,
    leg1: { platform: 'stake' }, leg2: { platform: 'bcgame' },
  };
  const filters = { ...DEFAULT_FILTERS, game: 'r6', minProfit: '2,5', minVolume: '45', live: 'upcoming' };
  assert.equal(passesFilters(arb, DEFAULT_FILTERS), true);
  assert.equal(passesFilters(arb, filters), true);
  assert.equal(passesFilters(arb, { ...filters, game: 'cs2' }), false);
  assert.equal(passesFilters(arb, { ...filters, minProfit: '12' }), false);
  assert.equal(passesFilters(arb, { ...filters, minVolume: '46' }), false);
  assert.equal(passesFilters(arb, { ...filters, live: 'live' }), false);
  assert.equal(passesFilters({ ...arb, is_live: true }, { ...filters, live: 'live' }), true);
});
