"""Fee formulas (Polymarket sports taker fee, Kalshi quadratic taker fee)."""

import pytest

from backend.config import PlatformFeeConfig
from backend.engine.fees import (
    effective_fee_spec,
    fee_usd,
    fee_usd_fills,
    marginal_fee_per_contract,
    round_up_cents,
)
from backend.models import FeeSpec
from tests.conftest import KALSHI_FEE, PM_FEE


@pytest.mark.parametrize(
    "price,expected",
    [(0.50, 1.25), (0.30, 1.05), (0.70, 1.05), (0.10, 0.45), (0.90, 0.45), (0.01, 0.0495)],
)
def test_polymarket_fee_matches_published_table(price, expected):
    # docs.polymarket.com/trading/fees, "Sports" tab, 100 shares.
    assert fee_usd(PM_FEE, price, 100) == pytest.approx(expected, abs=1e-5)


def test_polymarket_fee_is_rounded_to_5_decimals():
    fee = fee_usd(PM_FEE, 0.37, 3)  # 3 * 0.05 * 0.37 * 0.63 = 0.034965
    assert fee == pytest.approx(0.03497, abs=1e-9) or fee == pytest.approx(0.03496, abs=1e-9)
    assert round(fee, 5) == fee


@pytest.mark.parametrize("price,expected", [(0.50, 1.75), (0.40, 1.68), (0.20, 1.12)])
def test_kalshi_fee_examples(price, expected):
    assert fee_usd(KALSHI_FEE, price, 100) == pytest.approx(expected)


def test_kalshi_fee_rounds_up_to_the_cent():
    assert fee_usd(KALSHI_FEE, 0.50, 1) == pytest.approx(0.02)  # 0.0175 -> 0.02
    assert fee_usd(KALSHI_FEE, 0.99, 1) == pytest.approx(0.01)  # 0.000693 -> 0.01


def test_kalshi_fee_multiplier():
    spec = KALSHI_FEE.model_copy(update={"multiplier": 0.5})
    assert fee_usd(spec, 0.50, 100) == pytest.approx(0.88)  # 0.875 -> 0.88


def test_kalshi_sweep_is_rounded_once_per_order():
    fills = [(0.50, 1), (0.50, 1)]
    assert fee_usd_fills(KALSHI_FEE, fills) == pytest.approx(0.04)  # 0.035 -> 0.04, not 0.02 + 0.02


def test_polymarket_sweep_sums_fills():
    fills = [(0.50, 100), (0.30, 100)]
    assert fee_usd_fills(PM_FEE, fills) == pytest.approx(1.25 + 1.05)


def test_zero_fee_cases():
    assert fee_usd(FeeSpec(), 0.5, 100) == 0.0
    assert fee_usd(PM_FEE, 0.5, 0) == 0.0
    assert marginal_fee_per_contract(PM_FEE, 0.0) == 0.0
    assert marginal_fee_per_contract(KALSHI_FEE, 1.0) == 0.0


def test_round_up_cents_float_safety():
    assert round_up_cents(1.75) == 1.75  # 175.00000000000003 must not become 1.76
    assert round_up_cents(0.0001) == 0.01
    assert round_up_cents(0.0) == 0.0


def test_config_override_replaces_published_rate():
    override = PlatformFeeConfig(taker_rate=0.0)
    assert fee_usd(effective_fee_spec(PM_FEE, override), 0.5, 100) == 0.0
    override = PlatformFeeConfig(taker_rate=0.10, round_up_cents=False)
    spec = effective_fee_spec(KALSHI_FEE, override)
    assert fee_usd(spec, 0.5, 1) == pytest.approx(0.025)
