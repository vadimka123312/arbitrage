"""Shared test helpers."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pytest

from backend.config import load_settings
from backend.models import FeeSpec, Level, MatchedPair, NormalizedMarket

FIXTURES = Path(__file__).parent / "fixtures"
T0 = datetime(2026, 10, 16, 8, 0, tzinfo=timezone.utc)

PM_FEE = FeeSpec(model="polymarket", rate=0.05, exponent=1.0)
KALSHI_FEE = FeeSpec(model="kalshi", rate=0.07, multiplier=1.0, round_up_cents=True)


def load_fixture(name: str) -> Any:
    """Read a JSON fixture captured from the real APIs."""
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


@pytest.fixture
def settings():
    """Default settings with time filters wide open (fixtures have fixed dates)."""
    s = load_settings()
    s.discovery.horizon_hours = 1e6
    s.discovery.live_grace_hours = 1e6
    s.engine.min_profit_pct = 0.0
    s.engine.min_volume_usd = 0.0
    s.engine.depth_mode = "best_level"
    return s


def make_market(
    platform: str = "polymarket",
    market_id: str = "m1",
    team_a: str = "NIP",
    team_b: str = "Liquid",
    asks_a: list[tuple[float, float]] | None = None,
    asks_b: list[tuple[float, float]] | None = None,
    start: datetime | None = T0,
    game: str = "cs2",
    best_of: int | None = 3,
    fee: FeeSpec | None = None,
    updated_at: datetime | None = None,
    min_order_size: float = 0.0,
    rules: str = "",
) -> NormalizedMarket:
    """Build a market with explicit books."""
    market = NormalizedMarket(
        platform=platform,
        market_id=market_id,
        event_title=f"{team_a} vs {team_b}",
        game=game,
        team_a=team_a,
        team_b=team_b,
        start_time=start,
        best_of=best_of,
        fee=fee or FeeSpec(),
        min_order_size=min_order_size,
        url=f"https://example.com/{platform}/{market_id}",
        resolution_rules=rules,
    )
    market.set_books(
        [Level(price=p, size=s) for p, s in (asks_a or [])],
        [Level(price=p, size=s) for p, s in (asks_b or [])],
        None,
        None,
        updated_at or datetime.now(timezone.utc),
    )
    return market


def make_pair(left: NormalizedMarket, right: NormalizedMarket, swapped: bool = False) -> MatchedPair:
    """A matched pair between two markets."""
    return MatchedPair(
        pair_key=f"{left.key}|{right.key}",
        game=left.game,
        left_key=left.key,
        right_key=right.key,
        left_platform=left.platform,
        right_platform=right.platform,
        swapped=swapped,
        confidence=95.0,
    )


def at(seconds: float) -> datetime:
    """T0 + seconds."""
    return T0 + timedelta(seconds=seconds)
