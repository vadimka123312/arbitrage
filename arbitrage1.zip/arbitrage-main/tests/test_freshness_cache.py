"""Регрессии last-good cache и provenance времени котировок (без реальной сети)."""

from __future__ import annotations

from datetime import timedelta

import httpx
import pytest

from backend.adapters.kalshi import KalshiAdapter, parse_book
from backend.adapters.polymarket import PolymarketAdapter, TokenBook, WsConn
from backend.adapters.stake import StakeAdapter
from backend.engine.scanner import Scanner
from backend.net import HttpClient, HttpError
from backend.storage.db import Database
from backend.models import utcnow
from tests.conftest import load_fixture
from tests.test_adapters import KALSHI_SERIES_META


def _response(kind: str, payload) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        if kind == "timeout":
            raise httpx.ReadTimeout("temporary", request=request)
        if kind.startswith("http-"):
            return httpx.Response(int(kind.removeprefix("http-")))
        return httpx.Response(200, json=payload)

    return httpx.MockTransport(handler)


async def _polymarket(settings, transport: httpx.MockTransport):
    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    adapter.use_ws = False
    market = adapter._normalize_event(load_fixture("polymarket_event.json"), "cs2")[0]
    token_a, token_b = str(market.extra["token_a"]), str(market.extra["token_b"])
    adapter.token_index = {token_a: (market.key, "a"), token_b: (market.key, "b")}
    adapter._subscribed = {market.key: market}
    old = utcnow() - timedelta(minutes=5)
    for token, price in ((token_a, "0.41"), (token_b, "0.57")):
        book = adapter.books[token] = TokenBook()
        book.snapshot([], [{"price": price, "size": "12"}], 1000, old)
    adapter._apply_book(market, notify=False)
    adapter.status.last_update = old
    await adapter.clob.aclose()
    adapter.clob = HttpClient(
        "https://api.test", "polymarket", rate_per_sec=1000, max_retries=0, transport=transport
    )
    return adapter, market, (token_a, token_b), old


def _pm_row(token: str, *, asks=True) -> dict:
    row = {
        "asset_id": token,
        "timestamp": "2000",
        "bids": [{"price": "0.40", "size": "8"}],
    }
    if asks:
        row["asks"] = [{"price": "0.60", "size": "8"}]
    return row


@pytest.mark.parametrize("kind", ["http-500", "http-403", "http-429", "timeout"])
async def test_polymarket_http_failure_keeps_last_good_books(settings, kind):
    adapter, market, tokens, old = await _polymarket(settings, _response(kind, None))
    before = {token: (dict(adapter.books[token].bids), dict(adapter.books[token].asks), adapter.books[token].received_at)
              for token in tokens}
    with pytest.raises(HttpError):
        await adapter._rest_refresh()
    after = {token: (dict(adapter.books[token].bids), dict(adapter.books[token].asks), adapter.books[token].received_at)
             for token in tokens}
    assert after == before
    assert market.updated_at == old and adapter.status.last_update == old
    await adapter.clob.aclose()


@pytest.mark.parametrize("body_kind", ["empty", "partial", "missing-book", "malformed"])
async def test_polymarket_incomplete_success_keeps_last_good_books(settings, body_kind):
    placeholder = []
    adapter, market, tokens, old = await _polymarket(settings, _response("ok", placeholder))
    token_a, token_b = tokens
    bodies = {
        "empty": [],
        "partial": [_pm_row(token_a)],
        "missing-book": [_pm_row(token_a), _pm_row(token_b, asks=False)],
        "malformed": {"books": [_pm_row(token_a), _pm_row(token_b)]},
    }
    await adapter.clob.aclose()
    adapter.clob = HttpClient(
        "https://api.test", "polymarket", rate_per_sec=1000, max_retries=0,
        transport=_response("ok", bodies[body_kind]),
    )
    before = {token: (dict(adapter.books[token].bids), dict(adapter.books[token].asks), adapter.books[token].received_at)
              for token in tokens}
    with pytest.raises(ValueError):
        await adapter._rest_refresh()
    after = {token: (dict(adapter.books[token].bids), dict(adapter.books[token].asks), adapter.books[token].received_at)
             for token in tokens}
    assert after == before
    assert market.updated_at == old and adapter.status.last_update == old
    await adapter.clob.aclose()


async def test_polymarket_discovery_rejects_malformed_and_truncated_pages(settings):
    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    await adapter.gamma.aclose()
    adapter.gamma = HttpClient(
        "https://api.test", "polymarket-gamma", rate_per_sec=1000, max_retries=0,
        transport=_response("ok", {"events": []}),
    )
    with pytest.raises(ValueError, match="expected a list"):
        await adapter._fetch_events({"series_id": "x"})
    await adapter.gamma.aclose()
    adapter.page_size = adapter.max_pages = 1
    adapter.gamma = HttpClient(
        "https://api.test", "polymarket-gamma", rate_per_sec=1000, max_retries=0,
        transport=_response("ok", [{}]),
    )
    with pytest.raises(ValueError, match="pagination limit"):
        await adapter._fetch_events({"series_id": "x"})
    await adapter.gamma.aclose()
    await adapter.clob.aclose()


async def test_polymarket_multibatch_rest_does_not_undo_newer_pong_confirmation(settings):
    adapter = PolymarketAdapter("polymarket", settings.platforms["polymarket"], settings)
    adapter.use_ws = False
    adapter.ws_chunk = 2
    market = adapter._normalize_event(load_fixture("polymarket_event.json"), "cs2")[0]
    token_a, token_b = str(market.extra["token_a"]), str(market.extra["token_b"])
    adapter.token_index = {
        token_a: (market.key, "a"),
        **{f"unused-{idx}": ("", "") for idx in range(99)},
        token_b: (market.key, "b"),
    }
    adapter._subscribed = {market.key: market}
    adapter.books[token_a] = TokenBook()
    adapter.books[token_b] = TokenBook()
    old = utcnow() - timedelta(minutes=5)
    for book in adapter.books.values():
        book.snapshot([], [{"price": "0.50", "size": "10"}], 1000, old)
    adapter._apply_book(market, notify=False)
    pong_at = {"value": None}
    await adapter.clob.aclose()
    adapter.clob = HttpClient(
        "https://api.test", "polymarket", rate_per_sec=1000, max_retries=0,
        transport=_response("ok", []),
    )

    async def post_json(path, payload=None, retries=None):
        batch_tokens = [str(item["token_id"]) for item in payload]
        if token_b in batch_tokens:
            conn = WsConn()
            conn.ready = {token_a, token_b}
            adapter._on_ws_message("PONG", conn)
            pong_at["value"] = adapter.books[token_a].received_at
        now_rows = [{"asset_id": token, "timestamp": "1000", "bids": [],
                     "asks": [{"price": "0.50", "size": "10"}]} for token in batch_tokens]
        return now_rows

    adapter.clob.post_json = post_json
    await adapter._rest_refresh()
    assert pong_at["value"] is not None
    assert adapter.books[token_a].received_at == pong_at["value"]
    assert market.updated_at >= pong_at["value"]
    await adapter.clob.aclose()


async def _kalshi(settings, transport: httpx.MockTransport):
    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    market = adapter._normalize_event(
        load_fixture("kalshi_event.json"), "cs2", "KXCS2GAME", KALSHI_SERIES_META
    )[0]
    rows = load_fixture("kalshi_orderbooks.json")["orderbooks"]
    old = utcnow() - timedelta(minutes=5)
    for row in rows:
        ticker = str(row["ticker"])
        adapter.books[ticker] = parse_book(row["orderbook_fp"])
        adapter.book_ts[ticker] = old
    adapter._apply_books(market)
    adapter._subscribed = {market.key: market}
    adapter.status.last_update = old
    await adapter.http.aclose()
    adapter.http = HttpClient("https://api.test", "kalshi", rate_per_sec=1000, max_retries=0, transport=transport)
    return adapter, market, rows, old


@pytest.mark.parametrize("kind", ["http-500", "http-403", "http-429", "timeout"])
async def test_kalshi_http_failure_keeps_last_good_books(settings, kind):
    adapter, market, rows, old = await _kalshi(settings, _response(kind, None))
    before_books = {ticker: dict((side, list(levels)) for side, levels in book.items())
                    for ticker, book in adapter.books.items()}
    before_ts = adapter.book_ts.copy()
    with pytest.raises(HttpError):
        await adapter.poll_once()
    assert adapter.books == before_books and adapter.book_ts == before_ts
    assert market.updated_at == old and adapter.status.last_update == old
    await adapter.http.aclose()


@pytest.mark.parametrize("body_kind", ["empty", "partial", "missing-book", "malformed"])
async def test_kalshi_incomplete_success_keeps_last_good_books(settings, body_kind):
    adapter, market, rows, old = await _kalshi(settings, _response("ok", {}))
    bodies = {
        "empty": {"orderbooks": []},
        "partial": {"orderbooks": rows[:1]},
        "missing-book": {"orderbooks": [rows[0], {"ticker": rows[1]["ticker"]}]},
        "malformed": {"orderbooks": "not-a-list"},
    }
    await adapter.http.aclose()
    adapter.http = HttpClient(
        "https://api.test", "kalshi", rate_per_sec=1000, max_retries=0,
        transport=_response("ok", bodies[body_kind]),
    )
    before_books = {ticker: dict((side, list(levels)) for side, levels in book.items())
                    for ticker, book in adapter.books.items()}
    before_ts = adapter.book_ts.copy()
    with pytest.raises(ValueError):
        await adapter.poll_once()
    assert adapter.books == before_books and adapter.book_ts == before_ts
    assert market.updated_at == old and adapter.status.last_update == old
    await adapter.http.aclose()


async def test_kalshi_discovery_and_series_keep_last_good_on_malformed_200(settings):
    adapter = KalshiAdapter("kalshi", settings.platforms["kalshi"], settings)
    adapter.series_meta["KXCS2GAME"] = KALSHI_SERIES_META.copy()
    await adapter.http.aclose()
    adapter.http = HttpClient(
        "https://api.test", "kalshi", rate_per_sec=1000, max_retries=0,
        transport=_response("ok", {"message": "temporary"}),
    )
    with pytest.raises(ValueError, match="events list"):
        await adapter._fetch_events("KXCS2GAME")
    assert await adapter._series("KXCS2GAME") == KALSHI_SERIES_META
    assert "KXCS2GAME" not in adapter._series_checked
    await adapter.http.aclose()


async def test_kalshi_multibatch_rest_does_not_overwrite_a_newer_disconnected_ws_book(settings):
    adapter, market, rows, old = await _kalshi(settings, _response("ok", {}))
    adapter.batch = 1
    first, second = str(rows[0]["ticker"]), str(rows[1]["ticker"])
    ws_book = {"yes": [(0.91, 3.0)], "no": [(0.08, 4.0)]}
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        ticker = request.url.params.get_list("tickers")[0]
        if calls["n"] == 2:
            adapter.books[first] = ws_book
            adapter.book_ts[first] = utcnow()
            adapter._ws_owned.clear()  # the stream disconnected before the REST pass commits
        row = next(item for item in rows if item["ticker"] == ticker)
        return httpx.Response(200, json={"orderbooks": [row]})

    await adapter.http.aclose()
    adapter.http = HttpClient(
        "https://api.test", "kalshi", rate_per_sec=1000, max_retries=0,
        transport=httpx.MockTransport(handler),
    )
    await adapter.poll_once()
    assert calls["n"] == 2
    assert adapter.books[first] is ws_book
    assert adapter.book_ts[first] > old
    assert adapter.books[second] == parse_book(rows[1]["orderbook_fp"])
    await adapter.http.aclose()


async def test_stake_malformed_success_does_not_replace_last_good_odds(settings):
    adapter = StakeAdapter("stake", settings.platforms["stake"], settings)
    payload = load_fixture("stake_fixture_cloud9_m80.json")
    slug = str(payload["fixture"]["slug"])
    adapter.odds[slug] = adapter._parse(payload, utcnow() - timedelta(minutes=5))
    old = adapter.odds[slug]
    broken = {"fixture": payload["fixture"]}
    await adapter.http.aclose()
    adapter.http = HttpClient(
        "https://api.test", "stake", rate_per_sec=1000, max_retries=0,
        transport=_response("ok", broken), follow_redirects=False,
    )
    with pytest.raises(ValueError, match="groups"):
        await adapter._fetch(slug)
    assert adapter.odds[slug] is old
    await adapter.http.aclose()


async def test_stake_rejects_truncated_pagination(settings):
    adapter = StakeAdapter("stake", settings.platforms["stake"], settings)
    adapter.page_size = adapter.max_pages = 1
    await adapter.http.aclose()
    adapter.http = HttpClient(
        "https://api.test", "stake", rate_per_sec=1000, max_retries=0,
        transport=_response("ok", {"fixture": [{"slug": "still-more"}]}), follow_redirects=False,
    )
    with pytest.raises(ValueError, match="pagination limit"):
        await adapter._list("/sport/rainbow-six/fixture", "fixture")
    await adapter.http.aclose()


def test_market_timestamp_telemetry_distinguishes_confirmation_from_price_change(settings, tmp_path):
    stake = StakeAdapter("stake", settings.platforms["stake"], settings)
    payload = load_fixture("stake_fixture_cloud9_m80.json")
    market = stake.normalize({**payload, "sport": "rainbow-six"})[0]
    assert market.extra["timestamp_kind"] == "request_time_before_complete_fixture_response"
    assert market.extra["source_book_timestamp"] is None
    assert market.extra["actual_price_change_at"] is None
    view = Scanner(settings, {"stake": stake}, Database(tmp_path / "telemetry.db"))._market_view(market, utcnow())
    assert view["timestamp_kind"] == "request_time_before_complete_fixture_response"
    assert view["source_book_timestamp"] is None
    assert view["actual_price_change_at"] is None
