"""Интеграция четвёртой площадки на синтетических рынках, без сети и реальных ставок."""

from __future__ import annotations

import asyncio
from datetime import timedelta
from itertools import combinations
from zoneinfo import ZoneInfo

import httpx
import pytest

from backend.adapters import apply_mock_mode, build_adapters
from backend.adapters.mock import MockAdapter, MockWorld
from backend.adapters.stake import fmt_odds
from backend.api.server import create_app
from backend.engine.arb import evaluate_pair
from backend.engine.fees import effective_fee_spec, fee_usd
from backend.engine.scanner import Scanner
from backend.engine.tracker import ArbTracker
from backend.matching.rules import BCGAME_RULES, STAKE_RULES, compare_rules, parse_rules
from backend.models import FeeSpec, utcnow
from backend.stats import build_report, collect, format_text, period_days
from backend.storage.db import Database
from tests.conftest import T0

PLATFORMS = ("polymarket", "kalshi", "stake", "bcgame")


@pytest.fixture
def four_venues(settings, monkeypatch, tmp_path):
    """Один вымышленный матч на четырёх площадках; порядок BC.Game обратный Stake."""
    mock = apply_mock_mode(settings.model_copy(deep=True))
    mock.platforms["bcgame"] = mock.platforms["bcgame"].model_copy(
        update={"enabled": True, "max_stake_usd": 25.0}
    )
    mock.mock.arb_rate_per_min = 0
    mock.engine.confirm_seconds = 0
    mock.engine.eval_interval_ms = 50
    mock.capture.enabled = False
    mock.paper.enabled = False
    world = MockWorld(seed=1, arb_rate_per_min=0, tick_ms=500)
    world.matches = world.matches[:1]
    match = world.matches[0]
    match.prob = 0.5
    # Заданные цены, не наблюдение рынка: Stake 0,4/0,7; BC.Game 0,7/0,5 до перестановки команд.
    match.bias = {"stake": (-0.125, 0.175), "bcgame": (0.175, -0.025)}
    monkeypatch.setattr(world, "advance", lambda: None)
    adapters = build_adapters(mock)
    for adapter in adapters.values():
        adapter.world = world
    markets = {platform: adapter.normalize(match)[0] for platform, adapter in adapters.items()}
    scanner = Scanner(mock, adapters, Database(tmp_path / "four-venues.db"))
    for platform, market in markets.items():
        scanner.markets[platform][market.key] = market
    return scanner, markets


def test_four_platforms_are_configured_and_bcgame_is_enabled(settings):
    assert set(settings.platforms) == set(PLATFORMS)
    cfg = settings.platforms["bcgame"]
    assert cfg.enabled is True
    assert cfg.adapter == "backend.adapters.bcgame:BcGameAdapter"
    assert cfg.name == "BC.Game" and cfg.color == "#84cc16"
    assert {"cs2", "dota2"} <= set(cfg.games) <= set(settings.games)
    assert cfg.opt("max_stake_usd") > 0
    assert set(build_adapters(apply_mock_mode(settings))) == set(PLATFORMS)


def test_bcgame_can_be_disabled_without_enabling_or_disabling_other_platforms(settings):
    configured = settings.model_copy(deep=True)
    configured.platforms["bcgame"] = configured.platforms["bcgame"].model_copy(update={"enabled": False})
    assert set(build_adapters(apply_mock_mode(configured))) == {"polymarket", "kalshi", "stake"}


def test_bcgame_fee_config_keeps_the_bookmaker_fee_at_zero(settings):
    cfg = settings.fees.for_platform("bcgame")
    assert cfg.taker_rate is None
    assert cfg.extra_cost_per_contract == 0 and cfg.fixed_cost_per_trade_usd == 0
    fee = effective_fee_spec(FeeSpec(model="none"), cfg)
    assert fee.model == "none" and fee_usd(fee, 0.4, 125) == 0


@pytest.mark.parametrize("swapped", [False, True])
@pytest.mark.parametrize("max_stake", [12.5, 50.0])
def test_bcgame_mock_publishes_one_odds_level_per_outcome(four_venues, swapped, max_stake):
    scanner, _ = four_venues
    adapter = scanner.adapters["bcgame"]
    adapter.cfg = adapter.cfg.model_copy(update={"max_stake_usd": max_stake})
    match = adapter.world.matches[0]
    reverse = set(match.spec.get("swap", ())) - {"bcgame"}
    match.spec = {**match.spec, "swap": reverse | ({"bcgame"} if swapped else set())}
    market = adapter.normalize(match)[0]
    expected_odds = (2.0, 1.43) if swapped else (1.43, 2.0)
    assert market.extra["swapped"] is swapped
    assert market.fee.model == "none" and market.min_order_size == 0
    assert market.resolution_rules == BCGAME_RULES
    assert market.resolution_rules != STAKE_RULES
    assert market.url == "https://bc.game/sports/mock/bcgame-000"
    assert market.outcome_a_bid is None and market.outcome_b_bid is None
    for asks, team, odds in zip(
        (market.asks_a, market.asks_b), (market.team_a, market.team_b), expected_odds
    ):
        assert len(asks) == 1
        level = asks[0]
        assert level.price == pytest.approx(1 / odds)
        assert level.size == pytest.approx(max_stake * odds)
        assert level.instrument == f"Ставка «{team}», коэф. {fmt_odds(odds)}"
        assert level.price * level.size == pytest.approx(max_stake)


def test_bcgame_mock_only_lists_its_configured_games(four_venues):
    scanner, _ = four_venues
    cfg = scanner.settings.platforms["bcgame"].model_copy(update={"games": {"cs2": {}}})
    adapter = MockAdapter("bcgame", cfg, scanner.settings)
    adapter.world = MockWorld(seed=2, arb_rate_per_min=0, tick_ms=500)
    games = {market.game for match in adapter.world.matches for market in adapter.normalize(match)}
    assert games == {"cs2"}


def test_bcgame_mock_zero_stake_limit_does_not_invent_liquidity(four_venues):
    scanner, _ = four_venues
    adapter = scanner.adapters["bcgame"]
    adapter.cfg = adapter.cfg.model_copy(update={"max_stake_usd": 0})
    market = adapter.normalize(adapter.world.matches[0])[0]
    assert market.asks_a == market.asks_b == []
    assert market.outcome_a_ask is None and market.outcome_b_ask is None
    assert market.outcome_a_bid is None and market.outcome_b_bid is None


async def test_bcgame_mock_fetch_book_returns_an_independent_fresh_copy(four_venues):
    scanner, markets = four_venues
    adapter = scanner.adapters["bcgame"]
    original = markets["bcgame"]
    before = original.model_dump()
    adapter.world.matches[0].bias["bcgame"] = (0.1, -0.1)
    fresh = await adapter.fetch_book(original)
    assert original.model_dump() == before
    assert fresh is not original and fresh.key == original.key
    assert fresh.url == original.url and fresh.resolution_rules == BCGAME_RULES
    assert fresh.updated_at >= original.updated_at
    assert fresh.outcome_a_ask != original.outcome_a_ask
    assert len(fresh.asks_a) == len(fresh.asks_b) == 1
    assert fresh.outcome_a_bid is None and fresh.outcome_b_bid is None
    assert fresh.asks_a[0].instrument.startswith(f"Ставка «{fresh.team_a}»")


def test_scanner_matches_all_six_venue_pairs_and_counts_the_mock_match_once(four_venues):
    scanner, markets = four_venues
    scanner.rematch()
    pairs = {(p.left_platform, p.right_platform): p for p in scanner.pairs}
    assert set(pairs) == set(combinations(PLATFORMS, 2))
    assert not scanner.review and not scanner.blocked
    pair = pairs[("stake", "bcgame")]
    assert (pair.status, pair.confidence, pair.swapped, pair.format_check) == ("auto", 100.0, True, "match")
    assert (markets["stake"].team_a, markets["stake"].team_b) == (
        markets["bcgame"].team_b, markets["bcgame"].team_a
    )
    # Сравниваются собственные правила BC.Game, а не правила другого букмекера.
    assert pair.warnings == compare_rules(
        parse_rules(STAKE_RULES), parse_rules(BCGAME_RULES),
        scanner.adapters["stake"].name, scanner.adapters["bcgame"].name,
    )
    state = scanner.snapshot()
    assert state["counts"]["markets"] == 4 and state["counts"]["matches"] == 1
    assert state["counts"]["pairs"] == 6


@pytest.mark.parametrize("depth_mode", ["best_level", "walk_book"])
@pytest.mark.parametrize("platforms", [("stake", "bcgame"), ("bcgame", "stake")])
def test_reversed_bookmaker_pair_uses_opposite_teams_and_the_smaller_stake_limit(
    four_venues, depth_mode, platforms
):
    scanner, markets = four_venues
    scanner.settings.engine.depth_mode = depth_mode
    left, right = (markets[p] for p in platforms)
    pair = scanner.matcher.match([left], [right]).pairs[0]
    assert pair.swapped is True
    names = {p: adapter.name for p, adapter in scanner.adapters.items()}
    arbs = evaluate_pair(pair, left, right, scanner.settings, utcnow(), names)
    assert len(arbs) == 1
    arb = arbs[0]
    legs = {leg.platform: leg for leg in (arb.leg1, arb.leg2)}
    assert legs["stake"].outcome == "Natus Vincere" and legs["bcgame"].outcome == "FaZe Clan"
    assert legs["stake"].ask == pytest.approx(0.4) and legs["bcgame"].ask == pytest.approx(0.5)
    assert legs["bcgame"].platform_name == "BC.Game (mock)"
    # Лимит BC.Game: $25 при коэффициенте 2 даёт общий размер выплаты $50, не глубину биржевого стакана.
    assert arb.contracts == 50 and arb.volume_usd == 45 and arb.profit_usd == 5
    assert arb.sum_ask == pytest.approx(0.9) and arb.fees_usd == arb.extra_costs_usd == 0
    assert all(leg.fee_usd == 0 and leg.size == 50 for leg in legs.values())
    assert arb.contracts * legs["bcgame"].ask == 25
    assert arb.contracts * legs["stake"].ask == 20
    wrong_orientation = pair.model_copy(update={"swapped": False})
    assert evaluate_pair(wrong_orientation, left, right, scanner.settings, utcnow()) == []


async def test_mock_api_exposes_four_platforms_health_and_bcgame_market_urls(four_venues):
    scanner, markets = four_venues
    app = create_app(scanner.settings, adapters=scanner.adapters)
    # ASGITransport вызывает приложение в памяти: ни сервер, ни внешние API не используются.
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://localhost") as client:
            meta_response = await client.get("/api/meta")
            assert meta_response.status_code == 200
            meta = meta_response.json()
            assert meta["mock_mode"] is True
            assert {p["id"] for p in meta["platforms"]} == set(PLATFORMS)
            bcgame = next(p for p in meta["platforms"] if p["id"] == "bcgame")
            assert bcgame == {"id": "bcgame", "name": "BC.Game (mock)", "color": "#84cc16"}
            assert {"cs2", "dota2"} <= {g["id"] for g in meta["games"]}

            async def ready_state():
                while True:
                    response = await client.get("/api/state")
                    assert response.status_code == 200
                    state = response.json()
                    if state["counts"]["pairs"] == 6 and state["counts"]["active_arbs"] > 0:
                        return state
                    await app.state.scanner.wait_update(1.0)

            state = await asyncio.wait_for(ready_state(), timeout=5.0)
            assert state["mock_mode"] is True
            assert state["counts"]["markets_by_platform"] == {p: 1 for p in PLATFORMS}
            assert state["counts"]["matches"] == 1
            assert all(p["healthy"] and p["mode"] == "mock" and p["error"] is None for p in state["platforms"])
            status = next(p for p in state["platforms"] if p["platform"] == "bcgame")
            assert status["name"] == "BC.Game (mock)" and status["color"] == "#84cc16"
            assert status["markets"] == 1 and status["connected"] is True
            views = [m for pair in state["pairs"] for m in (pair["left"], pair["right"]) if m["platform"] == "bcgame"]
            assert len(views) == 3
            for market in views:
                assert market["url"] == markets["bcgame"].url
                assert market["platform_name"] == "BC.Game (mock)" and market["fee_model"] == "none"
                assert market["fresh"] is True and market["bid_a"] is None and market["bid_b"] is None
            arb = next(a for a in state["arbs"] if {a["leg1"]["platform"], a["leg2"]["platform"]} == {"stake", "bcgame"})
            assert arb["confirmed"] is True
            for leg in (arb["leg1"], arb["leg2"]):
                assert leg["url"] == markets[leg["platform"]].url
                assert leg["platform_name"].endswith(" (mock)") and leg["fee_usd"] == 0


def test_report_labels_all_six_configured_venue_pairs_and_reversed_legs(settings):
    """Строки истории вымышленные: проверяются группировка и подписи, не реальные вилки."""
    rows = []
    for left, right in combinations(PLATFORMS, 2):
        pair_key = f"{left}:mock|{right}:mock"
        rows.append({
            "arb_id": f"{pair_key}|A", "pair_key": pair_key, "game": "cs2", "event_title": "NAVI vs FaZe",
            "tournament": "Mock", "team_a": "NAVI", "team_b": "FaZe", "leg1_platform": left,
            "leg2_platform": right, "first_seen": T0.isoformat(), "lifetime_sec": 20,
            "max_profit_pct": 5, "max_volume_usd": 10, "max_profit_usd": 0.5, "minute_healthy": None,
        })
    duplicate = next(r for r in rows if r["leg1_platform"] == "stake" and r["leg2_platform"] == "bcgame")
    rows.append({**duplicate, "arb_id": f"{duplicate['pair_key']}|B", "leg1_platform": "bcgame", "leg2_platform": "stake"})
    now = T0 + timedelta(minutes=5)
    report = build_report(
        rows, {}, {}, period_days(ZoneInfo(settings.stats.timezone), 1, now), tracking_since=None,
        tz_name=settings.stats.timezone, now=now, platform_names={p: cfg.name for p, cfg in settings.platforms.items()},
        game_names={"cs2": "CS2"}, confirm_seconds=settings.engine.confirm_seconds,
    )
    venues = {v["label"]: (v["platforms"], v["arbs"]) for v in report["by_platforms"]}
    assert venues == {
        " ↔ ".join(settings.platforms[p].name for p in pair): (list(pair), 2 if pair == ("stake", "bcgame") else 1)
        for pair in combinations(PLATFORMS, 2)
    }
    assert report["totals"]["matches"] == 1 and report["pairs_total"] == 6
    text = format_text(report)
    assert all(label in text for label in ("Polymarket ↔ BC.Game", "Kalshi ↔ BC.Game", "Stake ↔ BC.Game"))


async def test_database_report_uses_config_names_for_a_synthetic_bcgame_arb(four_venues, settings, tmp_path):
    scanner, markets = four_venues
    scanner.rematch()
    pair = next(p for p in scanner.pairs if (p.left_platform, p.right_platform) == ("stake", "bcgame"))
    names = {p: adapter.name for p, adapter in scanner.adapters.items()}
    arb = evaluate_pair(pair, markets["stake"], markets["bcgame"], scanner.settings, utcnow(), names)[0]
    tracker = ArbTracker(confirm_seconds=0)
    tracker.update([arb], T0)
    tracker.update([arb], T0 + timedelta(seconds=20))
    db = Database(tmp_path / "bcgame-report.db")
    await db.connect()
    try:
        await db.add_history(tracker.close_all(T0 + timedelta(seconds=21)))
        report = await collect(db, settings, days=1, now=T0 + timedelta(minutes=5))
    finally:
        await db.close()
    assert [(v["label"], v["arbs"]) for v in report["by_platforms"]] == [("Stake ↔ BC.Game", 1)]
    assert report["top_pairs"][0]["platforms_label"] == "Stake ↔ BC.Game"
    assert "Stake ↔ BC.Game" in format_text(report)
