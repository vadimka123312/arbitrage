// Esports Arb Scanner — dashboard entry point (vanilla ES modules, no build step).

import { postJSON } from './js/api.js';
import { audioReady, beep, notifyPermission, requestNotifyPermission, showNotification, unlockAudio } from './js/alerts.js';
import { refreshState, startConnection } from './js/connection.js';
import { hydrateIcons } from './js/icons.js';
import { isStale, on, prefs, savePrefs, scannerStalled, store } from './js/store.js';
import { hidePopover, initPopover, refreshPopover, runTicks, setHTML, toast, watchScrollEdges } from './js/ui.js';
import { esc, parseTs } from './js/util.js';
import { createArbsView } from './js/views/arbs.js';
import { renderConn, renderHeader } from './js/views/header.js';
import { createHistoryView } from './js/views/history.js';
import { createPairsView } from './js/views/pairs.js';
import { createReviewView } from './js/views/review.js';
import { createSettingsView } from './js/views/settings.js';
import { createStatsView } from './js/views/stats.js';

const TABS = ['arbs', 'history', 'stats', 'pairs', 'review', 'settings'];
let activeTab = null;

/** Fill a game <select> from META (keeps an unknown saved value visible instead of hiding it). */
function fillGameSelect(select, value) {
  const games = store.meta?.games || [];
  const current = value || '';
  let html = '<option value="">Все игры</option>';
  html += games.map((g) => `<option value="${esc(g.id)}">${esc(g.name)}</option>`).join('');
  if (current && store.meta && !games.some((g) => g.id === current)) html += `<option value="${esc(current)}">${esc(current)}</option>`;
  setHTML(select, html);
  select.value = current;
  if (select.value !== current) select.value = '';
}

// ---------------------------------------------------------------- sound / notifications

function syncPrefControls() {
  document.getElementById('toggle-sound').setAttribute('aria-pressed', String(!!prefs.sound));
  document.getElementById('toggle-notify').setAttribute('aria-pressed', String(!!prefs.notify));
  views.settings.syncPrefs();
}

function testSound() {
  unlockAudio();
  setTimeout(() => {
    if (!beep()) toast('Звук недоступен в этом браузере', { type: 'error' });
  }, 40);
}

function setSound(enabled) {
  prefs.sound = !!enabled;
  savePrefs();
  if (prefs.sound) testSound();
  toast(prefs.sound ? 'Звук при новой вилке включён' : 'Звук выключен', { type: 'ok', timeout: 1800 });
  syncPrefControls();
}

async function setNotify(enabled) {
  const permission = enabled ? await requestNotifyPermission() : null;
  prefs.notify = permission === 'granted';
  savePrefs();
  syncPrefControls();
  if (prefs.notify) {
    showNotification('Уведомления включены', 'Сообщим о новой подтверждённой вилке, подходящей под фильтры.', 'arb-test');
    toast('Уведомления включены', { type: 'ok', timeout: 1800 });
  } else if (!enabled) {
    toast('Уведомления выключены', { type: 'ok', timeout: 1800 });
  } else {
    toast(
      permission === 'unsupported'
        ? 'Этот браузер не поддерживает уведомления'
        : 'Браузер запретил уведомления. Разрешите их в настройках сайта и включите снова.',
      { type: 'error', timeout: 6000 },
    );
  }
}

let soundHintShown = false;

function onNewArbs() {
  if (activeTab !== 'arbs') {
    const badge = document.getElementById('badge-arbs');
    badge.classList.remove('pulse');
    void badge.offsetWidth;
    badge.classList.add('pulse');
  }
  if (prefs.sound && !audioReady() && !soundHintShown) {
    soundHintShown = true;
    toast('Кликните в любом месте страницы, чтобы браузер разрешил звуковой сигнал', { timeout: 6000 });
  }
}

function focusArbs() {
  selectTab('arbs');
}

// ---------------------------------------------------------------- views

const isActive = (name) => () => activeTab === name;

const views = {};
views.arbs = createArbsView({ isActive: isActive('arbs'), onNewArbs, focusArbs, fillGameSelect, onVisibleChange: () => updateBadges() });
views.history = createHistoryView({ fillGameSelect });
views.stats = createStatsView();
views.pairs = createPairsView({ isActive: isActive('pairs'), fillGameSelect });
views.review = createReviewView({ isActive: isActive('review') });
views.settings = createSettingsView({ setSound, setNotify, testSound, resetFilters: () => views.arbs.resetFilters() });

// ---------------------------------------------------------------- tabs

function setBadge(id, value) {
  const el = document.getElementById(id);
  const text = String(value);
  el.hidden = !value;
  if (el.textContent !== text) el.textContent = text;
}

function updateBadges() {
  const st = store.state;
  const visible = views.arbs.visibleCount();
  setBadge('badge-arbs', visible);
  setBadge('badge-pairs', st?.counts?.pairs ?? 0);
  setBadge('badge-review', st?.counts?.review ?? 0);
  // A background tab must not look live when the data is outdated.
  let title = 'Esports Arb Scanner';
  if (isStale()) title = `Нет связи · ${title}`;
  else if (scannerStalled()) title = `Расчёт остановлен · ${title}`;
  else if (visible > 0) title = `(${visible}) Вилки · ${title}`;
  if (document.title !== title) document.title = title;
}

function selectTab(name, { focus = false } = {}) {
  if (!TABS.includes(name)) name = 'arbs';
  const changed = name !== activeTab;
  activeTab = name;
  prefs.tab = name;
  savePrefs();
  for (const tab of TABS) {
    const on = tab === name;
    const button = document.getElementById(`tab-${tab}`);
    button.setAttribute('aria-selected', String(on));
    button.tabIndex = on ? 0 : -1;
    document.getElementById(`panel-${tab}`).hidden = !on;
  }
  if (focus) document.getElementById(`tab-${name}`).focus();
  if (location.hash !== `#${name}`) history.replaceState(null, '', `#${name}`);
  if (changed) {
    hidePopover();
    views[name].onShow();
    runTicks();
  }
}

const tablist = document.querySelector('.tabs');
tablist.addEventListener('click', (e) => {
  const tab = e.target.closest('[data-tab]');
  if (tab) selectTab(tab.dataset.tab);
});
tablist.addEventListener('keydown', (e) => {
  const i = TABS.indexOf(activeTab);
  let next = null;
  if (e.key === 'ArrowRight') next = TABS[(i + 1) % TABS.length];
  else if (e.key === 'ArrowLeft') next = TABS[(i - 1 + TABS.length) % TABS.length];
  else if (e.key === 'Home') next = TABS[0];
  else if (e.key === 'End') next = TABS[TABS.length - 1];
  if (next) {
    e.preventDefault();
    selectTab(next, { focus: true });
  }
});
window.addEventListener('hashchange', () => selectTab(location.hash.slice(1)));

// ---------------------------------------------------------------- pair overrides (pairs, review, blocked)

const OVERRIDE_MESSAGES = {
  confirmed: 'Пара подтверждена',
  blocked: 'Пара заблокирована',
  clear_confirmed: 'Подтверждение снято',
  clear_blocked: 'Пара разблокирована',
  clear: 'Ручное решение снято',
};

async function sendOverride(pairKey, status) {
  await postJSON('/api/pairs/override', { pair_key: pairKey, status });
  await refreshState();
}

document.addEventListener('click', async (e) => {
  const button = e.target.closest('[data-override]');
  if (!button || button.disabled) return;
  const pairKey = button.dataset.pair;
  const status = button.dataset.override;
  const prev = button.dataset.prev || '';
  const label = button.dataset.label || '';
  const holder = button.closest('tr, .review-card, .blocked-row');
  holder?.setAttribute('data-pending', '');
  button.classList.add('loading');
  try {
    await sendOverride(pairKey, status);
    const message = OVERRIDE_MESSAGES[status === 'clear' ? `clear_${prev}` : status] || OVERRIDE_MESSAGES.clear;
    // Undo restores the previous manual decision (or clears it for auto / review pairs).
    const undoStatus = prev === 'confirmed' || prev === 'blocked' ? prev : 'clear';
    toast(`${message}: ${label}`, {
      type: 'ok',
      timeout: 6000,
      action: {
        label: 'Отменить',
        onClick: async () => {
          try {
            await sendOverride(pairKey, undoStatus);
            toast('Действие отменено', { type: 'ok', timeout: 2000 });
          } catch (err) {
            toast(`Не удалось отменить: ${err.message}`, { type: 'error' });
          }
        },
      },
    });
  } catch (err) {
    toast(`Не удалось сохранить решение: ${err.message}`, { type: 'error' });
  } finally {
    holder?.removeAttribute('data-pending');
    button.classList.remove('loading');
  }
});

// ---------------------------------------------------------------- top-bar toggles

document.getElementById('toggle-sound').addEventListener('click', () => setSound(!prefs.sound));
document.getElementById('toggle-notify').addEventListener('click', () => setNotify(!prefs.notify));

// Browsers only allow audio after a user gesture: unlock on the first interaction.
const unlock = () => {
  if (prefs.sound) unlockAudio();
};
document.addEventListener('pointerdown', unlock, true);
document.addEventListener('keydown', unlock, true);

// ---------------------------------------------------------------- stale data banner

/**
 * Banner + dimmed tables while the shown data is not live (no fresh data, or the scanner is stuck).
 * Ticking parts are aria-hidden so screen readers announce the banner once, not every second.
 */
function renderStale() {
  const stale = isStale();
  const stalled = scannerStalled();
  document.body.toggleAttribute('data-stale', stale || stalled);
  const banner = document.getElementById('stale-banner');
  banner.hidden = !(stale || stalled);
  if (banner.hidden) return;
  banner.dataset.kind = stalled ? 'stalled' : 'offline';
  let html;
  if (stalled) {
    html = `<b>Сканер не пересчитывает вилки.</b> Связь с сервером есть, но последний расчёт был <span aria-hidden="true" data-tick="ago" data-ts="${parseTs(store.state.last_eval_at)}"></span>. Цены и вилки ниже могут быть неактуальны, таймеры остановлены. Проверьте консоль сервера или лог в папке <code>logs/</code>.`;
  } else if (store.state) {
    html = `<b>Нет связи с сервером.</b> Данные ниже устарели, таймеры остановлены<span aria-hidden="true"> (<span data-tick="ago" data-prefix="последнее обновление " data-ts="${store.lastDataAt + store.clockOffset}"></span>)</span>. Переподключение — автоматически.`;
  } else {
    html = '<b>Нет связи с сервером сканера.</b> Переподключение — автоматически.';
  }
  setHTML(document.getElementById('stale-text'), html);
}

/** Connection indicator, stale banner, title; also re-checked every 500 ms because staleness is time-based. */
function renderLiveness() {
  renderConn();
  renderStale();
  updateBadges();
}

let livenessKey = '';
function tick() {
  const key = `${isStale()}|${scannerStalled()}`; // connection changes re-render through the 'conn' event
  if (key !== livenessKey) {
    livenessKey = key;
    renderLiveness();
  }
  runTicks();
}

// ---------------------------------------------------------------- live data

on('meta', () => {
  renderHeader();
  for (const view of Object.values(views)) view.onMeta?.();
});

on('state', (st) => {
  renderHeader();
  views.arbs.onState(st);
  if (activeTab !== 'arbs') views[activeTab].render();
  updateBadges();
  renderLiveness();
  runTicks();
  refreshPopover();
});

on('conn', () => {
  renderLiveness();
  runTicks();
  if (activeTab === 'settings') views.settings.render();
});

// ---------------------------------------------------------------- boot

hydrateIcons();
initPopover();
watchScrollEdges();
if (prefs.notify && notifyPermission() !== 'granted') {
  prefs.notify = false;
  savePrefs();
}
syncPrefControls();
renderHeader();
renderLiveness();
const initialTab = TABS.includes(location.hash.slice(1)) ? location.hash.slice(1) : prefs.tab;
selectTab(initialTab);
startConnection();
setInterval(tick, 500);
