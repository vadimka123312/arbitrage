// New-arb detection for sound / notifications / highlight (pure logic, no DOM; tested in tests/js).

/** One occurrence of an arb (an arb that vanishes and comes back is a new occurrence). */
export const instKey = (a) => `${a.arb_id}@${a.first_seen}`;

/**
 * Returns `detect(arbs) -> arbs to announce`. An occurrence is announced once, when ITS OWN data turns
 * alert-worthy (confirmed and passing `passes`) — at confirmation or later (profit grows past "Мин. профит",
 * the match goes live under "Только live", …). Arbs that only appear because the user changed a filter are
 * not new; the filters are applied to the previous snapshot too, so intermediate filter values while typing
 * cannot mute later alerts. The first call only records what is already on screen.
 */
export function createDetector(passes) {
  const alerted = new Set(); // occurrences already announced (or confirmed and visible on the first call)
  let previous = new Map(); // instKey -> arb from the previous call
  let initialized = false;
  return function detect(arbs) {
    const current = new Map();
    const fresh = [];
    for (const a of arbs || []) {
      const k = instKey(a);
      current.set(k, a);
      if (!a.confirmed || alerted.has(k) || !passes(a)) continue;
      if (!initialized) {
        alerted.add(k);
        continue;
      }
      const before = previous.get(k);
      if (before && before.confirmed && passes(before)) continue; // revealed by a filter change only
      alerted.add(k);
      fresh.push(a);
    }
    // Forget an occurrence only when it is gone: one that drops back below the confirmation threshold
    // (threshold raised) and confirms again is not announced twice.
    for (const k of alerted) if (!current.has(k)) alerted.delete(k);
    previous = current;
    initialized = true;
    return fresh;
  };
}
