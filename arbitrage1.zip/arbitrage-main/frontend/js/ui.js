// UI primitives: keyed DOM syncing, popovers, toasts and the 1-second ticker.

import { icons } from './icons.js';
import { confirmSeconds, dataNow, serverNow } from './store.js';
import { clamp, fmtAgo, fmtDuration, fmtStartRel } from './util.js';

// ---------------------------------------------------------------- keyed DOM sync

/** Set innerHTML only when it changed (keeps hover/focus state and avoids flicker). */
export function setHTML(el, html) {
  if (!el || el._html === html) return false;
  el.innerHTML = html;
  el._html = html;
  return true;
}

export function setText(el, text) {
  if (el && el.textContent !== text) el.textContent = text;
}

/**
 * Sync <tr> rows of `tbody` with `items`, diffing per cell.
 * `cells(item)` returns an array of HTML strings or {html, cls} objects.
 * Returns the newly created rows.
 */
export function syncRows(tbody, items, { key, cells, rowClass }) {
  return syncKeyed(tbody, items, {
    key,
    create: () => document.createElement('tr'),
    update: (tr, item) => {
      const cls = rowClass ? rowClass(item) || '' : '';
      if (tr._cls !== cls) {
        tr.className = cls;
        tr._cls = cls;
      }
      const defs = cells(item);
      while (tr.children.length < defs.length) tr.appendChild(document.createElement('td'));
      while (tr.children.length > defs.length) tr.lastElementChild.remove();
      defs.forEach((def, i) => {
        const td = tr.children[i];
        const tdCls = typeof def === 'string' ? '' : def.cls || '';
        setHTML(td, typeof def === 'string' ? def : def.html);
        if (td._cls !== tdCls) {
          td.className = tdCls;
          td._cls = tdCls;
        }
      });
    },
  });
}

/** Generic keyed sync of a container's children (cards, chips, list rows). */
export function syncKeyed(container, items, { key, create, update }) {
  const existing = new Map();
  for (const el of Array.from(container.children)) {
    if (el.dataset.key !== undefined) existing.set(el.dataset.key, el);
    else el.remove();
  }
  const created = [];
  const used = new Set();
  let prev = null;
  for (const item of items) {
    const k = String(key(item));
    if (used.has(k)) continue;
    used.add(k);
    let el = existing.get(k);
    if (!el) {
      el = create(item);
      el.dataset.key = k;
      created.push(el);
    }
    update(el, item);
    const expected = prev ? prev.nextElementSibling : container.firstElementChild;
    if (expected !== el) container.insertBefore(el, expected);
    prev = el;
  }
  for (const [k, el] of existing) if (!used.has(k)) el.remove();
  return created;
}

/** Briefly mark freshly inserted rows/cards with an entrance animation. */
export function markEntering(elements) {
  for (const el of elements) {
    el.setAttribute('data-enter', '');
    setTimeout(() => el.removeAttribute('data-enter'), 450);
  }
}

// ---------------------------------------------------------------- horizontal scroll hints

/**
 * Mark every `.table-wrap` with `more-left` / `more-right` while columns are hidden on that side
 * (narrow windows), so CSS can draw edge shadows instead of silently clipping columns such as ⚠.
 */
export function watchScrollEdges(root = document) {
  const update = (wrap) => {
    const hidden = wrap.scrollWidth - wrap.clientWidth;
    wrap.classList.toggle('more-left', hidden > 1 && wrap.scrollLeft > 1);
    wrap.classList.toggle('more-right', hidden > 1 && hidden - wrap.scrollLeft > 1);
  };
  // The observer also reports the initial size of every visible element.
  const observer = new ResizeObserver((entries) => {
    for (const entry of entries) update(entry.target.closest('.table-wrap'));
  });
  for (const wrap of root.querySelectorAll('.table-wrap')) {
    wrap.addEventListener('scroll', () => update(wrap), { passive: true });
    observer.observe(wrap); // window / panel size
    const table = wrap.querySelector('table');
    if (table) observer.observe(table); // rows added or removed
  }
  return observer; // a view that re-creates its tables disconnects it before watching the new ones
}

// ---------------------------------------------------------------- ticker

/** Update every live-ticking element: lifetimes, countdowns, relative times. */
export function runTicks(root = document) {
  const live = serverNow();
  // While data is outdated (no link, stuck scanner), lifetimes / countdowns stop at the moment of the last data.
  const now = dataNow();
  const confirm = confirmSeconds();
  for (const el of root.querySelectorAll('[data-tick]')) {
    const kind = el.dataset.tick;
    const ts = Number(el.dataset.ts);
    if (!Number.isFinite(ts) || el.dataset.ts === '') {
      setText(el, kind === 'progress' ? '' : '—');
      continue;
    }
    let text = null;
    switch (kind) {
      case 'age':
        text = fmtDuration((now - ts) / 1000);
        break;
      case 'ago':
        text = `${el.dataset.prefix || ''}${fmtAgo((live - ts) / 1000)}`;
        break;
      case 'start':
        text = fmtStartRel(ts, el.dataset.live === '1', live);
        break;
      case 'countdown': {
        const left = confirm - (now - ts) / 1000;
        text = left > 0.05 ? `через ${Math.ceil(left)} с` : 'ждём подтверждения сервера…';
        break;
      }
      case 'progress': {
        const pct = confirm > 0 ? clamp(((now - ts) / 1000 / confirm) * 100, 0, 100) : 100;
        const width = `${pct.toFixed(1)}%`;
        if (el.style.width !== width) el.style.width = width;
        break;
      }
      case 'retry': {
        const left = Math.ceil((ts - Date.now()) / 1000);
        text = left > 0 ? `повтор через ${left} с` : 'подключаемся…';
        break;
      }
      default:
        break;
    }
    if (text !== null) setText(el, text);
  }
}

// ---------------------------------------------------------------- popover

const pop = { el: null, trigger: null, key: null, pinned: false, hideTimer: null, html: null };

function popContent(trigger) {
  const tpl = trigger.querySelector('template.pop-src');
  return tpl ? tpl.innerHTML.trim() : '';
}

function positionPopover() {
  if (!pop.trigger || pop.el.hidden) return;
  const r = pop.trigger.getBoundingClientRect();
  if (r.width === 0 && r.height === 0) {
    hidePopover();
    return;
  }
  const pw = pop.el.offsetWidth;
  const ph = pop.el.offsetHeight;
  let top = r.bottom + 8;
  if (top + ph > window.innerHeight - 8 && r.top - ph - 8 > 8) top = r.top - ph - 8;
  const left = clamp(r.left + r.width / 2 - pw / 2, 8, Math.max(8, window.innerWidth - pw - 8));
  pop.el.style.top = `${Math.round(top)}px`;
  pop.el.style.left = `${Math.round(left)}px`;
}

function showPopover(trigger, pinned) {
  const html = popContent(trigger);
  if (!html) return;
  clearTimeout(pop.hideTimer);
  if (pop.trigger && pop.trigger !== trigger) pop.trigger.removeAttribute('aria-describedby');
  pop.trigger = trigger;
  pop.key = trigger.getAttribute('data-pop-key');
  pop.pinned = pinned;
  if (pop.html !== html) {
    pop.el.innerHTML = html;
    pop.html = html;
  }
  pop.el.classList.toggle('pinned', pinned);
  pop.el.hidden = false;
  trigger.setAttribute('aria-describedby', 'popover');
  runTicks(pop.el);
  positionPopover();
}

export function hidePopover() {
  clearTimeout(pop.hideTimer);
  if (pop.trigger) pop.trigger.removeAttribute('aria-describedby');
  pop.trigger = null;
  pop.key = null;
  pop.pinned = false;
  pop.html = null;
  if (pop.el) pop.el.hidden = true;
}

function scheduleHide() {
  clearTimeout(pop.hideTimer);
  pop.hideTimer = setTimeout(() => {
    if (!pop.pinned) hidePopover();
  }, 140);
}

/** After a re-render: re-attach the open popover to its (possibly replaced) trigger. */
export function refreshPopover() {
  if (!pop.el || pop.el.hidden || !pop.trigger) return;
  let trigger = pop.trigger;
  if (!trigger.isConnected) {
    trigger = pop.key ? document.querySelector(`[data-pop-key="${CSS.escape(pop.key)}"]`) : null;
    if (!trigger) {
      hidePopover();
      return;
    }
    pop.trigger = trigger;
    trigger.setAttribute('aria-describedby', 'popover');
  }
  const html = popContent(trigger);
  if (!html) {
    hidePopover();
    return;
  }
  if (html !== pop.html) {
    pop.el.innerHTML = html;
    pop.html = html;
    runTicks(pop.el);
  }
  positionPopover();
}

export function initPopover() {
  pop.el = document.getElementById('popover');
  document.addEventListener('mouseover', (e) => {
    const trigger = e.target.closest ? e.target.closest('[data-pop]') : null;
    if (trigger) {
      clearTimeout(pop.hideTimer);
      if (!pop.pinned && trigger !== pop.trigger) showPopover(trigger, false);
      return;
    }
    if (pop.el.contains(e.target)) clearTimeout(pop.hideTimer);
  });
  document.addEventListener('mouseout', (e) => {
    if (pop.pinned || !pop.trigger) return;
    const to = e.relatedTarget;
    if (to && (pop.trigger.contains(to) || pop.el.contains(to))) return;
    if (pop.trigger.contains(e.target) || pop.el.contains(e.target)) scheduleHide();
  });
  document.addEventListener('click', (e) => {
    const trigger = e.target.closest ? e.target.closest('[data-pop]') : null;
    if (trigger) {
      if (pop.pinned && pop.trigger === trigger) hidePopover();
      else showPopover(trigger, true);
      return;
    }
    if (pop.el.contains(e.target)) return;
    if (pop.trigger) hidePopover();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && pop.trigger) hidePopover();
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('span[data-pop], div[data-pop]')) {
      e.preventDefault();
      showPopover(e.target, true);
    }
  });
  document.addEventListener('focusin', (e) => {
    const trigger = e.target.closest ? e.target.closest('[data-pop]') : null;
    if (trigger && !pop.pinned && trigger !== pop.trigger) showPopover(trigger, false);
  });
  document.addEventListener('focusout', (e) => {
    if (!pop.pinned && pop.trigger && e.target === pop.trigger) scheduleHide();
  });
  window.addEventListener('scroll', positionPopover, true);
  window.addEventListener('resize', positionPopover);
}

// ---------------------------------------------------------------- toasts

/**
 * Show a toast. `type`: info | ok | error | arb. Optional `action` = {label, onClick}.
 * Returns a function that closes it.
 */
export function toast(message, { type = 'info', action = null, timeout = 4500 } = {}) {
  const box = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.setAttribute('role', type === 'error' ? 'alert' : 'status');
  el.innerHTML = `<div class="toast-msg"></div>${action ? '<button type="button" class="btn btn-xs toast-action"></button>' : ''}<button type="button" class="toast-close" aria-label="Закрыть">${icons.x}</button>`;
  el.querySelector('.toast-msg').textContent = message;
  let timer = null;
  const close = () => {
    if (el.classList.contains('leaving')) return;
    clearTimeout(timer);
    el.classList.add('leaving');
    setTimeout(() => el.remove(), 220);
  };
  if (action) {
    const btn = el.querySelector('.toast-action');
    btn.textContent = action.label;
    btn.addEventListener('click', () => {
      close();
      action.onClick();
    });
  }
  el.querySelector('.toast-close').addEventListener('click', close);
  timer = setTimeout(close, timeout);
  el.addEventListener('mouseenter', () => clearTimeout(timer));
  el.addEventListener('mouseleave', () => {
    clearTimeout(timer);
    timer = setTimeout(close, 2000);
  });
  box.appendChild(el);
  while (box.children.length > 4) box.firstElementChild.remove();
  return close;
}

// ---------------------------------------------------------------- empty states

export function emptyHtml({ icon = 'inbox', title, text = '', actionHtml = '' }) {
  return `<div class="empty-icon">${icons[icon] || ''}</div><div class="empty-title">${title}</div>${text ? `<div class="empty-text">${text}</div>` : ''}${actionHtml}`;
}

export function skeletonHtml(lines = 4) {
  const widths = [92, 78, 85, 64, 88, 70];
  let html = '<div class="skeleton">';
  for (let i = 0; i < lines; i += 1) html += `<div class="skeleton-line" style="width:${widths[i % widths.length]}%"></div>`;
  return `${html}</div>`;
}
