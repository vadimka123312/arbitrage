// "Статистика" tab: formatting and derived values without DOM access (tested with Node).

import { fmtDuration, fmtNum, fmtPct, fmtUsd, isNum, plural } from './util.js';

export const PERIODS = [
  { days: 1, label: 'Сегодня' },
  { days: 7, label: '7 дней' },
  { days: 30, label: '30 дней' },
  { days: 90, label: '90 дней' },
];
export const DEFAULT_DAYS = 7;

/** A period from the preferences, or the default when the saved value is not offered any more. */
export function periodDays(value) {
  const days = Number(value);
  return PERIODS.some((p) => p.days === days) ? days : DEFAULT_DAYS;
}

/** Hours with one decimal; a few minutes show as "<0,1" instead of a misleading "0,0". */
export function fmtHours(hours) {
  if (!isNum(hours)) return '—';
  if (hours > 0 && hours < 0.05) return '<0,1';
  return fmtNum(hours, 1, 1);
}

/** "12 мин", "34 ч 05 мин" from whole minutes. */
export function fmtMinutes(minutes) {
  if (!isNum(minutes)) return '—';
  if (minutes < 60) return `${minutes} мин`;
  return `${Math.floor(minutes / 60)} ч ${String(minutes % 60).padStart(2, '0')} мин`;
}

/** "16.10 пт" from "2026-10-16" and "пт". */
export function fmtDay(isoDate, weekday) {
  const [, month, day] = String(isoDate || '').split('-');
  if (!month || !day) return '—';
  return `${day}.${month}${weekday ? ` ${weekday}` : ''}`;
}

/** Share 0..1 as "58 %". */
export const fmtShare = (share) => (isNum(share) ? `${fmtNum(share * 100, 0, 0)}\u00a0%` : '—');

/** Width of an inline bar in % of the largest value; a non-zero value gets at least 2 % so it stays visible. */
export function barPct(value, max) {
  if (!isNum(value) || !isNum(max) || value <= 0 || max <= 0) return 0;
  return Math.max(2, Math.min(100, Math.round((value / max) * 100)));
}

/** "1 вилка", "2,5 вилки", "5 вилок" (a fraction takes the genitive singular). */
export function arbsWord(count) {
  return Number.isInteger(count) ? plural(count, ['вилка', 'вилки', 'вилок']) : 'вилки';
}

/** Local date and time in the report's time zone: "16.10.2026 16:34". */
export function fmtZoned(iso, timeZone) {
  const ms = Date.parse(iso || '');
  if (!Number.isFinite(ms)) return '—';
  try {
    const parts = new Intl.DateTimeFormat('ru-RU', {
      timeZone, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
    }).formatToParts(new Date(ms));
    const get = (type) => parts.find((p) => p.type === type)?.value || '';
    return `${get('day')}.${get('month')}.${get('year')} ${get('hour')}:${get('minute')}`;
  } catch {
    return new Date(ms).toISOString().slice(0, 16).replace('T', ' ');
  }
}

/** Why there is no rate per 24 h: one day can hardly have 24 h of fresh data, a longer period still can. */
function rateMissing(report) {
  const hours = report?.totals?.rate_min_data_hours ?? 24;
  if ((report?.days ?? 7) * 24 < hours * 2) return 'для оценки выберите 7 дней или больше';
  return `нужно хотя бы ${hours} ч со свежими данными`;
}

export const NO_DATA = 'данных нет';

/** Фазы отчёта по порядку и их подписи. */
export const PHASE_LABELS = { prematch: 'до старта', live: 'после старта', unknown: 'старт неизвестен' };

/** Деньги или «данных нет» (null, когда у группы нет ни одной вилки с данными при подтверждении). */
export const usdOrNoData = (value) => (isNum(value) ? fmtUsd(value) : NO_DATA);

/** Прибыль при ставке: «*» — часть вилок оценена по максимумам, «**» — только оценка. */
export function cappedText(block) {
  if (!block || !isNum(block.profit_usd)) return '—';
  const mark = block.estimated_arbs ? (block.exact_arbs ? '*' : '**') : '';
  return `${fmtUsd(block.profit_usd)}${mark}`;
}

/** Ячейка бумажной проверки: «3 из 5 (60 %)», «данных нет» или «без данных у 2» (ошибка, опоздание). */
export function paperCell(paper, delay) {
  const item = (paper || []).find((p) => p.delay_sec === delay);
  if (!item || !item.checked) return item && item.errors ? `без данных у ${item.errors}` : NO_DATA;
  return `${item.left} из ${item.checked} (${fmtShare(item.share_left)})`;
}

/** Флаги подозрительной ликвидности одной строки: «большой объём ×1, скачок размера ×2, нет снимков». */
export function flagsText(flags, arbs) {
  if (!flags) return '';
  const parts = [];
  for (const [key, label] of [['large_volume', 'большой объём'], ['size_jump', 'скачок размера'], ['stale_data', 'устаревшие данные']]) {
    if (flags[key]) parts.push(`${label} ×${flags[key]}`);
  }
  if (flags.no_data) parts.push(isNum(arbs) && flags.no_data >= arbs ? 'нет снимков' : `нет снимков ×${flags.no_data}`);
  return parts.join(', ');
}

/** The headline figures: [{ id, label, value, sub }] (plain text; the view escapes it). */
export function statsKpis(report) {
  const t = report?.totals || {};
  const h = t.honest || {};
  const cfg = report?.settings || {};
  const rate = t.per_24h;
  const rateShown = rate ? Math.round(rate.arbs * 10) / 10 : null; // the word must agree with the shown number
  const captured = t.captured_arbs ?? 0;
  const n = h.outliers ?? 0; // сколько вилок на самом деле исключено (меньше настройки, если вилок мало)
  const bank = h.bankroll;
  const firstPaper = (h.paper || [])[0];
  const paperOff = cfg.paper_enabled === false;
  return [
    {
      id: 'arbs',
      label: 'Вилок',
      value: fmtNum(t.arbs ?? 0, 0, 0),
      sub: `уникальных ${fmtNum(t.distinct_arbs ?? 0, 0, 0)} · матчей ${fmtNum(t.matches ?? 0, 0, 0)}`,
    },
    {
      id: 'confirm',
      label: 'Прибыль при подтверждении',
      value: captured ? usdOrNoData(h.confirm_profit_usd) : NO_DATA,
      sub: !t.arbs ? 'вилок нет' : captured ? `у ${fmtNum(captured, 0, 0)} из ${fmtNum(t.arbs, 0, 0)} вилок` : 'вилки записаны до этой версии',
      muted: !captured,
    },
    {
      id: 'trimmed',
      label: n ? `Без топ-${n}` : 'Сумма максимумов',
      value: fmtUsd((n ? h.profit_trimmed_usd : h.profit_usd) ?? 0),
      sub: n ? `сумма максимумов без них; всего ${fmtUsd(h.profit_usd ?? 0)}` : 'верхняя оценка',
    },
    {
      id: 'median',
      label: 'Прибыль на вилку, медиана',
      value: h.profit_spread ? fmtUsd(h.profit_spread.p50) : '—',
      sub: h.profit_spread ? `максимум за жизнь · p90 ${fmtUsd(h.profit_spread.p90)}` : 'вилок нет',
    },
    {
      id: 'bankroll',
      label: bank ? `Банкролл ${fmtUsd(bank.bankroll_usd, 0)}` : 'Банкролл',
      value: bank ? cappedText(bank) : '—',
      sub: bank ? `${bank.max_stake_usd ? `до ${fmtUsd(bank.max_stake_usd, 0)} на вилку` : 'без лимита на вилку'} · взято ${fmtNum(bank.taken, 0, 0)} из ${fmtNum(bank.arbs, 0, 0)}` : 'не задан (stats.bankroll_usd)',
    },
    {
      id: 'paper',
      label: firstPaper ? `Осталось через +${fmtNum(firstPaper.delay_sec, 0, 1)} с` : 'Бумажная проверка',
      value: firstPaper && firstPaper.checked ? fmtShare(firstPaper.share_left) : NO_DATA,
      sub: firstPaper && firstPaper.checked ? `${firstPaper.left} из ${firstPaper.checked} проверенных` : paperOff ? 'проверки выключены (paper.enabled)' : 'проверки пишет эта версия',
      muted: !(firstPaper && firstPaper.checked),
    },
    {
      id: 'lifetime',
      label: 'Время жизни, медиана',
      value: isNum(t.median_lifetime_sec) ? fmtDuration(t.median_lifetime_sec) : '—',
      sub: `≥ 30 с: ${fmtShare(t.share_30s)} · ≥ 60 с: ${fmtShare(t.share_60s)}`,
    },
    {
      id: 'rate',
      label: 'На 24 ч со свежими данными',
      value: rate ? `${fmtNum(rateShown, 0, 1)} ${arbsWord(rateShown)}` : '—',
      sub: rate ? `уникальных ${fmtNum(rate.distinct_arbs ?? 0, 0, 1)}` : rateMissing(report),
    },
  ];
}

/** Время работы сканера для строки над отчётом: «работа 46 ч 41 мин, со свежими данными 46 ч 31 мин». */
export function uptimeText(report) {
  const t = report?.totals || {};
  if (!isNum(t.run_minutes)) return 'время работы не записано';
  return `работа ${fmtMinutes(t.run_minutes)}, со свежими данными ${fmtMinutes(t.data_minutes)}`;
}

/** Why some hours are unknown or partial (the same rules as the console report; "" when every day is fully known). */
export function uptimeNote(report) {
  if (!report) return '';
  if (!report.uptime_tracked) {
    return 'Время работы сканера ещё не записано: эта версия пишет его каждую минуту с первого запуска. До этого часы неизвестны («—»).';
  }
  if (Date.parse(report.uptime_since) > Date.parse(report.period?.since)) {
    return `Время работы записывается с ${fmtZoned(report.uptime_since, report.timezone)}: до этого часы неизвестны («—») или неполные.`;
  }
  if ((report.by_day || []).some((d) => !isNum(d.run_hours))) {
    return 'Для дней с «—» время работы неизвестно: в эти дни есть вилки, но нет отметок времени работы.';
  }
  return '';
}
