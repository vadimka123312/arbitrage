// Live connection: WebSocket /ws with exponential-backoff reconnect (1 s → 15 s),
// and REST polling of /api/state every 2 s while the socket does not deliver data.
//
// Liveness: the server sends a STATE or a heartbeat at least every 2 s. A socket that stays silent for
// LINK_SILENCE_MS (half-open TCP after sleep or a network change, a stuck proxy) is dropped and replaced,
// and REST polling covers the gap. A socket counts as "open" only after its first message.

import { getJSON } from './api.js';
import { acceptHeartbeat, acceptMeta, acceptState, emit, isStale, store } from './store.js';

const MIN_DELAY = 1000;
const MAX_DELAY = 15000;
const POLL_MS = 2000;
const OPEN_TIMEOUT_MS = 4000; // start REST polling if the socket has not delivered data by then
const CONNECT_TIMEOUT_MS = 10000; // give up on a socket that still has not delivered data
const LINK_SILENCE_MS = 6000; // an open socket silent this long is dead (the server sends at least every 2 s)
const WATCHDOG_MS = 1000;

let ws = null;
let delay = MIN_DELAY;
let reconnectTimer = null;
let pollTimer = null;
let polling = false;
let pollInFlight = false;
let started = false;

function setConn(patch) {
  Object.assign(store.conn, patch);
  emit('conn', store.conn);
}

function connect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = null;
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  let sock;
  try {
    sock = new WebSocket(`${proto}//${location.host}/ws`);
  } catch {
    handleClose();
    return;
  }
  ws = sock;
  let gotData = false;
  setConn({ ws: 'connecting' });
  // If the socket hangs before its first message, keep data flowing through REST meanwhile …
  setTimeout(() => {
    if (ws === sock && !gotData) startPolling();
  }, OPEN_TIMEOUT_MS);
  // … and replace it if it still has not delivered anything.
  setTimeout(() => {
    if (ws === sock && !gotData) abandon(sock);
  }, CONNECT_TIMEOUT_MS);

  sock.addEventListener('message', (event) => {
    if (ws !== sock) return;
    let msg;
    try {
      msg = JSON.parse(event.data);
    } catch {
      return;
    }
    store.conn.lastMessageAt = Date.now();
    if (!gotData) {
      gotData = true;
      delay = MIN_DELAY;
      stopPolling();
      setConn({ ws: 'open', poll: 'idle', retryAt: 0 });
    }
    if (!msg) return;
    if (msg.type === 'meta') acceptMeta(msg.data);
    else if (msg.type === 'state') acceptState(msg.data);
    // A heartbeat that does not match the shown STATE means a STATE was missed: fetch it.
    else if (msg.type === 'heartbeat' && !acceptHeartbeat(msg.data)) refreshState();
  });
  sock.addEventListener('close', () => {
    if (ws === sock) handleClose();
  });
  // 'error' is always followed by 'close'; nothing to do here.
}

/** Drop a socket that never delivered data or went silent, and reconnect with backoff. */
function abandon(sock) {
  // handleClose() first: it clears `ws`, so the socket's own (possibly synchronous) close event is ignored.
  handleClose();
  sock.close();
}

function handleClose() {
  ws = null;
  startPolling();
  const wait = delay;
  delay = Math.min(delay * 2, MAX_DELAY);
  setConn({ ws: 'closed', retryAt: Date.now() + wait });
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, wait);
}

/** Replace an open socket that has been silent for too long (the server sends at least every 2 s). */
function watchdog() {
  if (ws && store.conn.ws === 'open' && Date.now() - store.conn.lastMessageAt > LINK_SILENCE_MS) abandon(ws);
}

async function pollOnce() {
  if (pollInFlight) return;
  pollInFlight = true;
  try {
    const meta = store.meta ? null : await getJSON('/api/meta');
    const next = await getJSON('/api/state');
    const wasDown = isStale(); // judged when the answer arrives, with the data shown until now
    if (meta) acceptMeta(meta);
    acceptState(next);
    if (polling) setConn({ poll: 'ok' });
    // The server answers again after an outage: try the socket now instead of waiting out the backoff
    // (up to 15 s). Only after an outage, so a proxy that blocks WebSockets cannot cause a reconnect storm.
    if (wasDown && !ws) reconnectNow();
  } catch {
    if (polling) setConn({ poll: 'fail' });
  } finally {
    pollInFlight = false;
  }
}

function startPolling() {
  if (polling) return;
  polling = true;
  pollOnce();
  pollTimer = setInterval(pollOnce, POLL_MS);
}

function stopPolling() {
  polling = false;
  clearInterval(pollTimer);
  pollTimer = null;
}

/** Skip the backoff wait and try the WebSocket right away (tab focus, network back). */
export function reconnectNow() {
  watchdog(); // a socket that went silent while the tab was hidden is replaced first
  if (ws) return;
  delay = MIN_DELAY;
  connect();
}

/** Fetch a fresh STATE right now (e.g. after an override) without waiting for the push. */
export async function refreshState() {
  try {
    acceptState(await getJSON('/api/state'));
  } catch {
    /* the live channel will catch up */
  }
}

export function startConnection() {
  if (started) return;
  started = true;
  window.addEventListener('online', reconnectNow);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') reconnectNow();
  });
  setInterval(watchdog, WATCHDOG_MS);
  connect();
}
