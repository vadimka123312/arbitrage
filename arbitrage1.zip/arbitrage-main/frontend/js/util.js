// Small helpers: DOM, escaping, number / time formatting (ru-RU).

export const $ = (sel, root = document) => root.querySelector(sel);

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/** Escape a value for safe use inside HTML text or a quoted attribute. */
export function esc(value) {
  if (value === null || value === undefined) return '';
  return String(value).replace(/[&<>"']/g, (ch) => ESC[ch]);
}

export const isNum = (v) => typeof v === 'number' && Number.isFinite(v);

/** Parse a user-entered number ("1,5" or "1.5"); returns null for empty / invalid input. */
export function parseNum(value) {
  if (value === null || value === undefined) return null;
  const text = String(value).trim().replace(',', '.');
  if (text === '') return null;
  const n = Number(text);
  return Number.isFinite(n) ? n : null;
}

/** Only allow http(s) links coming from the server. */
export function safeUrl(url) {
  if (typeof url !== 'string') return null;
  return /^https?:\/\//i.test(url.trim()) ? url.trim() : null;
}

/** Only allow plain CSS colors coming from the server (used inside style attributes). */
export function safeColor(color, fallback) {
  if (typeof color === 'string' && /^(#[0-9a-f]{3,8}|rgba?\([\d\s.,%]+\)|hsla?\([\d\s.,%deg]+\))$/i.test(color.trim())) {
    return color.trim();
  }
  return fallback;
}

/** Stable hue (0..359) for a string — used for game badges without hard-coded colors. */
export function hueOf(text) {
  let h = 2166136261;
  for (const ch of String(text || '')) {
    h ^= ch.codePointAt(0);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h % 360;
}

const FALLBACK_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#a855f7', '#ef4444', '#14b8a6', '#ec4899'];
export const fallbackColor = (key) => FALLBACK_COLORS[hueOf(key) % FALLBACK_COLORS.length];

/** "Polymarket (mock)" -> "Polymarket" (compact labels for buttons). */
export function shortName(name) {
  const text = String(name || '');
  return text.replace(/\s*\([^)]*\)\s*$/, '') || text;
}

// ---------------------------------------------------------------- numbers

const numberFormats = new Map();
function nf(min, max) {
  const key = `${min}:${max}`;
  let fmt = numberFormats.get(key);
  if (!fmt) {
    fmt = new Intl.NumberFormat('ru-RU', { minimumFractionDigits: min, maximumFractionDigits: max });
    numberFormats.set(key, fmt);
  }
  return fmt;
}

export const fmtNum = (v, min = 0, max = 2) => (isNum(v) ? nf(min, max).format(v) : '—');

/** Contract price 0..1 (e.g. "0,24" or "0,245"). */
export const fmtPrice = (v) => (isNum(v) ? nf(2, 3).format(v) : '—');

/** US dollars: "1 234,56 $". */
export function fmtUsd(v, digits = 2) {
  if (!isNum(v)) return '—';
  return `${nf(digits, digits).format(v)}\u00a0$`;
}

/** Percent with sign: "+1,70 %", "−4,74 %". */
export function fmtPct(v, digits = 2, withSign = true) {
  if (!isNum(v)) return '—';
  const rounded = Number(v.toFixed(digits));
  const body = nf(digits, digits).format(Math.abs(rounded));
  let sign = '';
  if (rounded > 0 && withSign) sign = '+';
  else if (rounded < 0) sign = '−';
  return `${sign}${body}\u00a0%`;
}

/** Profit tier for coloring: 1 (<1%), 2 (1–3%), 3 (3–5%), 4 (>=5%). */
export function profitTier(pct) {
  if (!isNum(pct)) return 1;
  if (pct >= 5) return 4;
  if (pct >= 3) return 3;
  if (pct >= 1) return 2;
  return 1;
}

// ---------------------------------------------------------------- time

/** Parse an ISO timestamp (tolerates microseconds) into epoch ms; NaN when missing. */
export function parseTs(iso) {
  if (!iso) return NaN;
  return Date.parse(String(iso).replace(/(\.\d{3})\d+/, '$1'));
}

const timeFmt = new Intl.DateTimeFormat('ru-RU', { hour: '2-digit', minute: '2-digit' });
const timeSecFmt = new Intl.DateTimeFormat('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
const dayFmt = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short' });

function dayDiff(a, b) {
  const da = new Date(a.getFullYear(), a.getMonth(), a.getDate());
  const db = new Date(b.getFullYear(), b.getMonth(), b.getDate());
  return Math.round((da - db) / 86400000);
}

/** Local wall-clock time with a day hint: "18:02", "завтра, 01:30", "16 окт., 18:02". */
export function fmtClock(ms, withSeconds = false) {
  if (!Number.isFinite(ms)) return '—';
  const d = new Date(ms);
  const t = (withSeconds ? timeSecFmt : timeFmt).format(d);
  const diff = dayDiff(d, new Date());
  if (diff === 0) return t;
  if (diff === 1) return `завтра, ${t}`;
  if (diff === -1) return `вчера, ${t}`;
  return `${dayFmt.format(d)}, ${t}`;
}

/** Compact span: "45 с", "12 мин", "2 ч 15 мин", "3 д 4 ч". */
export function fmtSpan(sec) {
  const a = Math.max(0, Math.floor(Math.abs(sec)));
  if (a < 60) return `${a} с`;
  if (a < 3600) return `${Math.floor(a / 60)} мин`;
  if (a < 86400) {
    const h = Math.floor(a / 3600);
    const m = Math.floor((a % 3600) / 60);
    return m ? `${h} ч ${m} мин` : `${h} ч`;
  }
  const d = Math.floor(a / 86400);
  const h = Math.floor((a % 86400) / 3600);
  return h ? `${d} д ${h} ч` : `${d} д`;
}

/** Ticking lifetime: "7 с", "1 мин 05 с", "2 ч 03 мин". */
export function fmtDuration(sec) {
  const a = Math.max(0, Math.floor(sec));
  if (a < 60) return `${a} с`;
  const m = Math.floor(a / 60);
  const s = a % 60;
  if (m < 60) return `${m} мин ${String(s).padStart(2, '0')} с`;
  const h = Math.floor(m / 60);
  return `${h} ч ${String(m % 60).padStart(2, '0')} мин`;
}

/** Relative start time: "через 2 ч", "идёт 40 мин", "начался 10 мин назад". */
export function fmtStartRel(startMs, isLive, nowMs) {
  if (!Number.isFinite(startMs)) return '';
  const delta = (startMs - nowMs) / 1000;
  if (isLive) return delta < 0 ? `идёт ${fmtSpan(-delta)}` : 'идёт';
  if (delta >= 0) return `через ${fmtSpan(delta)}`;
  return `начался ${fmtSpan(-delta)} назад`;
}

/** "только что", "3 с назад", "2 мин назад". */
export function fmtAgo(sec) {
  if (!isNum(sec)) return 'нет данных';
  if (sec < 1) return 'только что';
  return `${fmtSpan(sec)} назад`;
}

export function debounce(fn, ms) {
  let timer = null;
  const wrapped = (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      fn(...args);
    }, ms);
  };
  wrapped.cancel = () => clearTimeout(timer);
  wrapped.pending = () => timer !== null;
  return wrapped;
}

export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/** Russian plural: plural(5, ['вилка', 'вилки', 'вилок']). */
export function plural(n, forms) {
  const a = Math.abs(n) % 100;
  const b = a % 10;
  if (a > 10 && a < 20) return forms[2];
  if (b > 1 && b < 5) return forms[1];
  if (b === 1) return forms[0];
  return forms[2];
}
