// REST helpers. Errors carry the server's `detail` message (FastAPI style).

export class ApiError extends Error {
  constructor(message, status = 0) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

function detailText(data, status) {
  let detail = data && typeof data === 'object' ? data.detail : data;
  if (Array.isArray(detail)) {
    // FastAPI request-validation errors: [{loc, msg, type}, ...]
    detail = detail.map((d) => (d && d.msg ? `${(d.loc || []).slice(1).join('.')}: ${d.msg}` : JSON.stringify(d))).join('; ');
  }
  if (detail && typeof detail === 'object') detail = JSON.stringify(detail);
  return String(detail || `HTTP ${status}`);
}

async function request(method, url, body, timeoutMs = 10000) {
  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  const options = { method, headers: { Accept: 'application/json' }, cache: 'no-store' };
  if (controller) options.signal = controller.signal;
  if (body !== undefined) {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(body);
  }
  let response;
  try {
    response = await fetch(url, options);
  } catch (err) {
    throw new ApiError(err && err.name === 'AbortError' ? 'Сервер не ответил вовремя' : 'Сервер недоступен', 0);
  } finally {
    if (timer) clearTimeout(timer);
  }
  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
  }
  if (!response.ok) throw new ApiError(detailText(data, response.status), response.status);
  return data;
}

export const getJSON = (url) => request('GET', url);
export const postJSON = (url, body) => request('POST', url, body);
export const putJSON = (url, body) => request('PUT', url, body);

/** Build a query string, skipping empty values. */
export function query(params) {
  const qs = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '' || value === false) continue;
    qs.set(key, String(value));
  }
  const text = qs.toString();
  return text ? `?${text}` : '';
}
