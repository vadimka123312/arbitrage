// "Нужна проверка": doubtful pairs shown side by side with confirm / block actions,
// plus a collapsible list of blocked pairs with "Разблокировать".

import { icons } from '../icons.js';
import { currentSettings, platformInfo, prefs, savePrefs, store } from '../store.js';
import { emptyHtml, markEntering, setHTML, setText, skeletonHtml, syncKeyed } from '../ui.js';
import { $, esc, fmtClock, fmtNum, fmtPct, fmtPrice, parseTs, plural } from '../util.js';
import { NOT_ACTIONABLE_HINT, alignedRight, confidenceBadge, directionText, gameBadge, linkButton, quoteCells, warningsList } from './common.js';

const FORMAT_CHECK = { match: 'совпадает', ok: 'совпадает', mismatch: 'не совпадает', unknown: 'неизвестно' };

function pairLabel(p) {
  return `${p.left?.team_a || '?'} vs ${p.left?.team_b || '?'}`;
}

function headHtml(p) {
  const timeDiff = Number.isFinite(p.time_diff_minutes) ? `${fmtNum(p.time_diff_minutes, 0, 0)} мин` : 'неизвестно';
  return `${gameBadge(p.game)}<span class="rc-title">${esc(pairLabel(p))}</span>${confidenceBadge(p.confidence, p.status)}
    <span class="rc-meta"><span>Δ старта: <b>${esc(timeDiff)}</b></span><span>Команды: <b>${fmtNum(p.team_score, 0, 1)}%</b></span><span>Формат: <b>${esc(FORMAT_CHECK[p.format_check] || p.format_check || '—')}</b></span></span>`;
}

function sideHtml(p, which) {
  const m = (which === 'left' ? p.left : p.right) || {};
  const pf = platformInfo(m.platform, m.platform_name);
  const teams = which === 'left' ? { teamA: m.team_a, teamB: m.team_b } : alignedRight(p);
  const startMs = parseTs(m.start_time);
  const start = Number.isFinite(startMs)
    ? `${esc(fmtClock(startMs))} · <span data-tick="start" data-ts="${startMs}" data-live="${m.is_live ? 1 : 0}"></span>`
    : 'не указано';
  const order =
    which === 'right' && p.swapped
      ? `<dt>Порядок</dt><dd><span class="swap-mark">${icons.swap}</span> на платформе: «${esc(m.team_a)}» vs «${esc(m.team_b)}» — выровнено по левой стороне</dd>`
      : '';
  return `<div class="rc-side" style="--pf:${pf.color}">
    <div class="rc-side-head"><span class="rc-pf">${esc(pf.name)}</span>${linkButton(m.platform, m.platform_name, m.url)}</div>
    <div class="rc-event">${esc(m.event_title || '—')}</div>
    <div class="rc-teams">
      <div class="rc-team"><div class="rc-team-name">${esc(teams.teamA || '?')}</div><div class="rc-team-price">ask <b data-price="${which}-a">—</b></div></div>
      <span class="vs">vs</span>
      <div class="rc-team"><div class="rc-team-name">${esc(teams.teamB || '?')}</div><div class="rc-team-price">ask <b data-price="${which}-b">—</b></div></div>
    </div>
    <dl class="rc-kv">
      <dt>Старт</dt><dd>${start}${m.is_live ? ' <span class="live-badge">LIVE</span>' : ''}</dd>
      <dt>Формат</dt><dd>${m.best_of ? `BO${esc(m.best_of)}` : 'не указан'}</dd>
      <dt>Турнир</dt><dd>${esc(m.tournament || 'не указан')}</dd>
      <dt>Рынок</dt><dd><code>${esc(m.market_id || '—')}</code></dd>
      ${order}
    </dl>
  </div>`;
}

function sidesHtml(p) {
  return `${sideHtml(p, 'left')}<div class="rc-divider"><span>≟</span></div>${sideHtml(p, 'right')}`;
}

function fillPrices(el, p) {
  const c = quoteCells(p);
  const values = { 'left-a': c.leftA.ask, 'left-b': c.leftB.ask, 'right-a': c.rightA.ask, 'right-b': c.rightB.ask };
  for (const b of el.querySelectorAll('[data-price]')) setText(b, fmtPrice(values[b.dataset.price]));
}

function detailsHtml(p) {
  const reasons = (p.reasons || []).map((r) => `<li>${esc(r)}</li>`).join('') || '<li class="faint">нет данных</li>';
  const warnings = (p.warnings || []).length ? warningsList(p.warnings) : '<div class="faint">Различий в правилах не найдено</div>';
  return `<div class="rc-block"><div class="rc-block-title">Почему такая уверенность</div><ul class="reason-list">${reasons}</ul></div><div class="rc-block"><div class="rc-block-title">Правила платформ</div>${warnings}</div>`;
}

function quoteHtml(p) {
  const b = p.best;
  if (!b) return 'Цены недоступны';
  const stale = b.actionable === false ? ` <span class="not-actionable" title="${esc(NOT_ACTIONABLE_HINT)}">неактуально</span>` : '';
  return `Лучшее направление: ${esc(directionText(p, b.direction))} — сумма <b>${fmtPrice(b.sum_ask)}</b>, профит <b>${fmtPct(b.profit_pct)}</b>${stale}`;
}

function actionsHtml(p) {
  const key = esc(p.pair_key);
  const label = esc(pairLabel(p));
  return `<button type="button" class="btn btn-sm btn-danger" data-override="blocked" data-pair="${key}" data-prev="${esc(p.status)}" data-label="${label}">${icons.x}Это разные матчи</button><button type="button" class="btn btn-sm btn-success" data-override="confirmed" data-pair="${key}" data-prev="${esc(p.status)}" data-label="${label}">${icons.check}Подтвердить</button>`;
}

function createCard() {
  const el = document.createElement('article');
  el.className = 'card review-card';
  el.innerHTML = `<div class="rc-head" data-part="head"></div><div class="rc-sides" data-part="sides"></div><div class="rc-details" data-part="details"></div><div class="rc-foot"><div class="rc-quote" data-part="quote"></div><div class="rc-actions" data-part="actions"></div></div>`;
  return el;
}

function updateCard(el, p) {
  const part = (name) => el.querySelector(`[data-part="${name}"]`);
  setHTML(part('head'), headHtml(p));
  setHTML(part('sides'), sidesHtml(p));
  fillPrices(el, p);
  setHTML(part('details'), detailsHtml(p));
  setHTML(part('quote'), quoteHtml(p));
  setHTML(part('actions'), actionsHtml(p));
}

function blockedHtml(p) {
  const L = p.left || {};
  const R = p.right || {};
  const ar = alignedRight(p);
  const lpf = platformInfo(L.platform, L.platform_name);
  const rpf = platformInfo(R.platform, R.platform_name);
  return `<div class="blocked-side" style="--pf:${lpf.color}"><span class="leg-pf">${esc(lpf.short)}</span><div class="teams" title="${esc(L.event_title || '')}">${esc(L.team_a)} <span class="vs">vs</span> ${esc(L.team_b)}</div></div>
    <div class="blocked-side" style="--pf:${rpf.color}"><span class="leg-pf">${esc(rpf.short)}</span><div class="teams" title="${esc(R.event_title || '')}">${esc(ar.teamA)} <span class="vs">vs</span> ${esc(ar.teamB)}</div></div>
    <div>${gameBadge(p.game)}</div>
    <div>${confidenceBadge(p.confidence, p.status)}</div>
    <div><button type="button" class="btn btn-xs" data-override="clear" data-pair="${esc(p.pair_key)}" data-prev="blocked" data-label="${esc(pairLabel(p))}">${icons.unlock}Разблокировать</button></div>`;
}

export function createReviewView({ isActive }) {
  const els = {
    summary: $('#r-summary'),
    list: $('#r-list'),
    empty: $('#r-empty'),
    blocked: $('#blocked'),
    blockedList: $('#blocked-list'),
    blockedEmpty: $('#blocked-empty'),
    blockedCount: $('#blocked-count'),
  };
  let renderedOnce = false;

  function render() {
    const st = store.state;
    if (!st) {
      els.empty.hidden = false;
      setHTML(els.empty, skeletonHtml(4));
      return;
    }
    const review = [...(st.review || [])].sort((a, b) => b.confidence - a.confidence);
    const blocked = st.blocked || [];

    const createdCards = syncKeyed(els.list, review, { key: (p) => p.pair_key, create: createCard, update: updateCard });
    if (renderedOnce) markEntering(createdCards);

    els.empty.hidden = review.length > 0;
    if (!review.length) {
      const s = currentSettings();
      setHTML(
        els.empty,
        `<div class="empty">${emptyHtml({
          icon: 'shield',
          title: 'Нет пар, требующих проверки',
          text: `Сюда попадают сопоставления с уверенностью от ${fmtNum(Number(s['matching.review_threshold'] ?? 60), 0, 1)}% до ${fmtNum(Number(s['matching.auto_threshold'] ?? 85), 0, 1)}%.`,
        })}</div>`,
      );
    }

    const createdRows = syncKeyed(els.blockedList, blocked, {
      key: (p) => p.pair_key,
      create: () => {
        const el = document.createElement('div');
        el.className = 'blocked-row';
        return el;
      },
      update: (el, p) => setHTML(el, blockedHtml(p)),
    });
    if (renderedOnce) markEntering(createdRows);
    renderedOnce = true;
    setText(els.blockedCount, String(blocked.length));
    els.blockedEmpty.hidden = blocked.length > 0;

    setHTML(
      els.summary,
      `На проверке: <b>${review.length}</b> ${plural(review.length, ['пара', 'пары', 'пар'])}<span class="sep">·</span>заблокировано: <b>${blocked.length}</b><span class="sep">·</span>подтверждённая пара попадает в «Сопоставленные пары» с меткой «ручн.»`,
    );
  }

  els.blocked.open = !!prefs.blockedOpen;
  els.blocked.addEventListener('toggle', () => {
    prefs.blockedOpen = els.blocked.open;
    savePrefs();
  });

  return {
    render,
    onShow: render,
    onMeta() {
      if (isActive()) render();
    },
  };
}
