// Render helpers shared by several views (HTML strings; every server value is escaped).

import { icons } from '../icons.js';
import { currentSettings, gameInfo, platformInfo } from '../store.js';
import { esc, fmtClock, fmtNum, fmtPrice, hueOf, isNum, parseTs, safeUrl } from '../util.js';

/** Shown where the backend marks a quote as not actionable (`quotes.*.actionable === false`). */
export const NOT_ACTIONABLE_HINT =
  'Котировки устарели или торги на площадке приостановлены: сейчас эту сделку нельзя исполнить, пара не участвует в расчёте вилок.';

export function gameBadge(gameId) {
  const game = gameInfo(gameId);
  return `<span class="game-badge" style="--h:${hueOf(game.id)}" title="${esc(game.name)}">${esc(game.short)}</span>`;
}

export function teamsHtml(teamA, teamB) {
  return `<span class="teams">${esc(teamA || '?')}<span class="vs">vs</span>${esc(teamB || '?')}</span>`;
}

/** Start time: local clock + ticking relative time + LIVE badge. */
export function startCell(iso, isLive) {
  const ms = parseTs(iso);
  if (!Number.isFinite(ms)) {
    return isLive ? '<div class="start"><span class="start-time"><span class="live-badge">LIVE</span></span></div>' : '<span class="faint">—</span>';
  }
  return `<div class="start"><span class="start-time">${isLive ? '<span class="live-badge">LIVE</span>' : ''}${esc(fmtClock(ms))}</span><span class="start-rel" data-tick="start" data-ts="${ms}" data-live="${isLive ? 1 : 0}"></span></div>`;
}

const INSTRUMENT_SPLIT = / \+ (?=(?:YES|NO) «|\? ×)/;

/** One arb leg: platform (in its color), outcome to buy, ask price, instrument. */
export function legCell(leg) {
  if (!leg) return '<span class="faint">—</span>';
  const pf = platformInfo(leg.platform, leg.platform_name);
  const avg =
    isNum(leg.avg_price) && isNum(leg.ask) && Math.abs(leg.avg_price - leg.ask) > 0.0005
      ? `<div class="leg-avg">средняя ${fmtPrice(leg.avg_price)}</div>`
      : '';
  // A split Kalshi order ("YES «A» ×3 + NO «B» ×4") shows one order per line, so no part is cut off. Only a " + "
  // before the next order splits, not one inside a team name.
  const parts = leg.instrument ? String(leg.instrument).split(INSTRUMENT_SPLIT).map(esc).join('<br>+ ') : '';
  const instrument = parts ? `<div class="leg-instr" title="${esc(leg.instrument)}">${parts}</div>` : '';
  return `<div class="leg" style="--pf:${pf.color}"><div class="leg-top"><span class="leg-pf">${esc(pf.short)}</span><span class="price-pill" title="Лучшая цена покупки (ask)">${fmtPrice(leg.ask)}</span></div><div class="leg-out"><span class="buy">Купить</span> ${esc(leg.outcome || '?')}</div>${instrument}${avg}</div>`;
}

/** Link button labelled with the platform name, opening the market in a new tab. */
export function linkButton(platformId, platformName, url) {
  const pf = platformInfo(platformId, platformName);
  const href = safeUrl(url);
  if (!href) return `<span class="pf-link disabled" style="--pf:${pf.color}" title="Ссылка недоступна">${esc(pf.short)}</span>`;
  return `<a class="pf-link" style="--pf:${pf.color}" href="${esc(href)}" target="_blank" rel="noopener noreferrer" title="Открыть рынок на ${esc(pf.name)}">${esc(pf.short)} ↗</a>`;
}

const SEV_ORDER = { high: 0, medium: 1, info: 2 };
const SEV_LABEL = { high: 'важно', medium: 'внимание', info: 'инфо' };
const sevClass = (sev) => (sev in SEV_ORDER ? sev : 'info');

export function maxSeverity(list) {
  let best = 'info';
  for (const w of list || []) {
    const sev = sevClass(w && w.severity);
    if (SEV_ORDER[sev] < SEV_ORDER[best]) best = sev;
  }
  return best;
}

export function warningsList(list) {
  const sorted = [...(list || [])].sort((a, b) => SEV_ORDER[sevClass(a.severity)] - SEV_ORDER[sevClass(b.severity)]);
  return `<ul class="warn-list">${sorted
    .map((w) => {
      const sev = sevClass(w.severity);
      return `<li><span class="sev-dot ${sev}"></span><div><span class="sev-label ${sev}">${SEV_LABEL[sev]}</span>${esc(w.message || w.field || '')}</div></li>`;
    })
    .join('')}</ul>`;
}

/** ⚠ button with a popover listing rule warnings; colored by max severity. */
export function warningsButton(list, popKey, title = 'Различия правил платформ') {
  if (!list || !list.length) return '<span class="faint">—</span>';
  const sev = maxSeverity(list);
  const serious = list.filter((w) => w.severity === 'high' || w.severity === 'medium').length;
  const icon = serious ? icons.warning : icons.info;
  return `<button type="button" class="warn-btn sev-${sev}" data-pop data-pop-key="${esc(popKey)}" aria-label="Предупреждения: ${list.length}">${icon}${serious ? `<span>${serious}</span>` : ''}<template class="pop-src"><div class="pop-title">${esc(title)}</div>${warningsList(list)}</template></button>`;
}

/** Confidence badge colored against the matching thresholds; "ручн." for manual confirmation. */
export function confidenceBadge(confidence, status) {
  if (status === 'confirmed') return '<span class="conf-badge conf-manual" title="Пара подтверждена вручную">ручн.</span>';
  const settings = currentSettings();
  const auto = Number(settings['matching.auto_threshold'] ?? 85);
  const review = Number(settings['matching.review_threshold'] ?? 60);
  let cls = 'conf-lo';
  if (confidence >= auto) cls = 'conf-hi';
  else if (confidence >= review) cls = 'conf-mid';
  return `<span class="conf-badge ${cls}" title="Уверенность сопоставления (авто ≥ ${fmtNum(auto, 0, 1)}%)">${fmtNum(confidence, 0, 1)}%</span>`;
}

/**
 * Right-market quotes re-ordered to the LEFT market's team order.
 * When `swapped`, right.team_a is the same team as left.team_b.
 */
export function alignedRight(pair) {
  const r = pair.right || {};
  const s = !!pair.swapped;
  return {
    teamA: s ? r.team_b : r.team_a,
    teamB: s ? r.team_a : r.team_b,
    askA: s ? r.ask_b : r.ask_a,
    askB: s ? r.ask_a : r.ask_b,
    sizeA: s ? r.ask_b_size : r.ask_a_size,
    sizeB: s ? r.ask_a_size : r.ask_b_size,
    instrA: s ? r.instrument_b : r.instrument_a,
    instrB: s ? r.instrument_a : r.instrument_b,
  };
}

/**
 * The four quote cells (left A/B, right A/B in the left team order) with the prices the engine actually uses:
 * each cell is one leg of one direction, whose quote skips a split order part below the minimum. A direction
 * without a quote falls back to the raw top of the book.
 */
export function quoteCells(pair) {
  const L = pair.left || {};
  const ar = alignedRight(pair);
  const q = pair.quotes || {};
  const cell = (quote, side, ask, instrument, size) =>
    quote && isNum(quote[`${side}_price`])
      ? { ask: quote[`${side}_price`], instrument: quote[`${side}_instrument`], size: quote.contracts, executed: true }
      : { ask, instrument, size, executed: false };
  return {
    leftA: cell(q.A, 'left', L.ask_a, L.instrument_a, L.ask_a_size),
    leftB: cell(q.B, 'left', L.ask_b, L.instrument_b, L.ask_b_size),
    rightA: cell(q.B, 'right', ar.askA, ar.instrA, ar.sizeA),
    rightB: cell(q.A, 'right', ar.askB, ar.instrB, ar.sizeB),
  };
}

/** Human description of a direction: which team to buy on which platform. */
export function directionText(pair, direction) {
  const left = pair.left || {};
  const right = alignedRight(pair);
  const lpf = platformInfo(left.platform, left.platform_name).short;
  const rpf = platformInfo(pair.right?.platform, pair.right?.platform_name).short;
  if (direction === 'A') return `«${left.team_a}» на ${lpf} + «${right.teamB}» на ${rpf}`;
  return `«${left.team_b}» на ${lpf} + «${right.teamA}» на ${rpf}`;
}
