// "Настройки": runtime settings form (PUT /api/settings), UI preferences, mode info.

import { getJSON, putJSON } from '../api.js';
import { notifyPermission } from '../alerts.js';
import { refreshState } from '../connection.js';
import { icons } from '../icons.js';
import { platformInfo, platformTimingInfo, prefs, store } from '../store.js';
import { setHTML, toast } from '../ui.js';
import { $, esc, fmtClock, fmtNum, isNum, parseNum, parseTs } from '../util.js';
import { gameBadge } from './common.js';

/** Labels / hints for known runtime settings. Unknown keys still get a generic field. */
const FIELD_DEFS = {
  'engine.confirm_seconds': {
    group: 'engine', label: 'Порог подтверждения', unit: 'с', step: 1,
    hint: 'Сколько секунд вилка должна существовать, чтобы считаться подтверждённой (0–300).',
  },
  'engine.stale_seconds': {
    group: 'engine', label: 'Устаревание котировок', unit: 'с', step: 1,
    hint: 'Котировки старше этого возраста не участвуют в расчёте вилок (1–600).',
  },
  'engine.min_profit_pct': {
    group: 'engine', label: 'Мин. профит на сервере', unit: '%', step: 0.1,
    hint: 'Вилки с профитом ниже порога (после комиссий) не отслеживаются и не пишутся в историю (−100…100).',
  },
  'engine.min_volume_usd': {
    group: 'engine', label: 'Мин. объём на сервере', unit: '$', step: 10,
    hint: 'Минимальная стоимость сделки в долларах, чтобы вилка учитывалась (0–1 000 000).',
  },
  'engine.depth_mode': {
    group: 'engine', label: 'Расчёт объёма', type: 'select',
    options: [['best_level', 'Лучший уровень'], ['walk_book', 'Проход по стакану']],
    hint: 'Лучший уровень — объём только по лучшей цене; проход по стакану — объём и средняя цена по нескольким уровням.',
  },
  'matching.auto_threshold': {
    group: 'matching', label: 'Порог автосопоставления', unit: '%', step: 1,
    hint: 'Пары с уверенностью не ниже порога сопоставляются автоматически (0–100).',
  },
  'matching.review_threshold': {
    group: 'matching', label: 'Порог ручной проверки', unit: '%', step: 1,
    hint: 'Пары с уверенностью от этого порога до порога автосопоставления попадают во вкладку «Нужна проверка» (0–100).',
  },
  'matching.time_tolerance_hours': {
    group: 'matching', label: 'Допуск времени старта', unit: 'ч', step: 0.5,
    hint: 'Максимальная разница во времени начала матча на разных платформах (0–72).',
  },
};
const GROUPS = [['engine', 'Расчёт вилок'], ['matching', 'Сопоставление матчей'], ['other', 'Прочее']];
const ORDER = Object.keys(FIELD_DEFS);
const MODE_LABEL = { ws: 'WebSocket', rest: 'REST (опрос)', mock: 'синтетические данные' };

/** "engine.stale_seconds: must be between 1.0 and 600.0" -> {key, text in Russian}. */
function translateError(message) {
  const exceed = /^([a-z_]+\.[a-z_]+) must not exceed ([a-z_]+\.[a-z_]+)$/i.exec(message || '');
  if (exceed) return { key: exceed[1], text: `значение не может быть больше, чем «${FIELD_DEFS[exceed[2]]?.label || exceed[2]}»` };
  const m = /^([a-z_]+\.[a-z_]+):\s*(.*)$/i.exec(message || '');
  const key = m ? m[1] : null;
  let text = m ? m[2] : message || 'неизвестная ошибка';
  text = text
    .replace(/must be between (-?[\d.e+]+) and (-?[\d.e+]+)/i, (_, lo, hi) => `значение должно быть от ${fmtNum(Number(lo), 0, 2)} до ${fmtNum(Number(hi), 0, 2)}`)
    .replace(/expected a number/i, 'ожидается число')
    .replace(/invalid value (.*)/i, 'недопустимое значение $1')
    .replace(/not a runtime setting/i, 'этот параметр нельзя менять во время работы');
  return { key, text };
}

function sameValue(inputValue, serverValue) {
  if (isNum(serverValue)) {
    const n = parseNum(inputValue);
    return n !== null && Math.abs(n - serverValue) < 1e-9;
  }
  return String(inputValue) === String(serverValue ?? '');
}

export function createSettingsView({ setSound, setNotify, testSound, resetFilters }) {
  const els = {
    form: $('#settings-form'),
    fields: $('#settings-fields'),
    error: $('#settings-error'),
    save: $('#settings-save'),
    revert: $('#settings-revert'),
    info: $('#settings-info'),
    prefSound: $('#pref-sound'),
    prefNotify: $('#pref-notify'),
    notifyHint: $('#pref-notify-hint'),
    prefTest: $('#pref-test'),
    prefReset: $('#pref-reset'),
  };
  let serverValues = {};
  let serverSig = '';
  let builtSig = '';
  const dirty = new Set();

  const inputFor = (key) => els.fields.querySelector(`[data-key="${CSS.escape(key)}"]`);
  const rowFor = (key) => els.fields.querySelector(`[data-row="${CSS.escape(key)}"]`);

  function rowHtml(key, value) {
    const def = FIELD_DEFS[key] || { label: key, type: isNum(value) ? 'number' : 'text' };
    const id = `set-${key.replace(/[^a-z0-9]+/gi, '-')}`;
    let control;
    if (def.type === 'select') {
      control = `<select class="input" id="${id}" data-key="${esc(key)}">${def.options.map(([v, label]) => `<option value="${esc(v)}">${esc(label)}</option>`).join('')}</select>`;
    } else if (def.type === 'text') {
      control = `<input class="input" id="${id}" data-key="${esc(key)}" type="text" autocomplete="off">`;
    } else {
      control = `<input class="input" id="${id}" data-key="${esc(key)}" type="number" step="${def.step ?? 'any'}" inputmode="decimal">`;
    }
    return `<div class="setting-row" data-row="${esc(key)}">
      <div><label class="setting-label" for="${id}"><span class="dirty-mark" title="Изменено"></span>${esc(def.label)} <span class="setting-key">${esc(key)}</span></label>${def.hint ? `<div class="setting-hint">${esc(def.hint)}</div>` : ''}</div>
      <div class="setting-control">${control}<span class="setting-unit">${esc(def.unit || '')}</span></div>
      <div class="setting-error" hidden></div>
    </div>`;
  }

  function build(settings) {
    const keys = Object.keys(settings);
    const sig = keys.join('|');
    if (sig === builtSig) return;
    builtSig = sig;
    const groups = new Map(GROUPS.map(([id]) => [id, []]));
    for (const key of keys) groups.get(FIELD_DEFS[key]?.group || 'other').push(key);
    const rank = (k) => (ORDER.includes(k) ? ORDER.indexOf(k) : ORDER.length);
    let html = '';
    for (const [id, title] of GROUPS) {
      const list = groups.get(id).sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
      if (!list.length) continue;
      html += `<div class="settings-group"><div class="settings-group-title">${esc(title)}</div>${list.map((k) => rowHtml(k, settings[k])).join('')}</div>`;
    }
    els.fields.innerHTML = html || '<div class="empty empty-sm">Настройки недоступны</div>';
    dirty.clear();
  }

  function fill(force) {
    for (const input of els.fields.querySelectorAll('[data-key]')) {
      const key = input.dataset.key;
      if (!force && (dirty.has(key) || document.activeElement === input)) continue;
      const v = serverValues[key];
      const text = v === null || v === undefined ? '' : String(v);
      if (input.tagName === 'SELECT' && ![...input.options].some((o) => o.value === text)) input.add(new Option(text, text));
      if (input.value !== text) input.value = text;
    }
    syncDirtyMarks();
  }

  function syncDirtyMarks() {
    for (const input of els.fields.querySelectorAll('[data-key]')) {
      const key = input.dataset.key;
      if (dirty.has(key) && sameValue(input.value, serverValues[key])) dirty.delete(key);
      rowFor(key)?.classList.toggle('dirty', dirty.has(key));
    }
    els.revert.disabled = dirty.size === 0;
  }

  function setFieldError(key, text) {
    const row = rowFor(key);
    if (!row) return;
    const box = row.querySelector('.setting-error');
    box.textContent = text;
    box.hidden = !text;
    row.querySelector('[data-key]')?.classList.toggle('invalid', !!text);
  }

  function clearErrors() {
    els.error.hidden = true;
    els.error.innerHTML = '';
    for (const row of els.fields.querySelectorAll('[data-row]')) setFieldError(row.dataset.row, '');
  }

  function showError(message, raw) {
    els.error.innerHTML = `${icons.warning}<div><div>${esc(message)}</div>${raw ? `<div class="faint" style="font-size:11.5px;margin-top:3px">Ответ сервера: ${esc(raw)}</div>` : ''}</div>`;
    els.error.hidden = false;
  }

  /** Take settings from the server (STATE push or PUT/GET response). */
  function applyServer(settings, { resetDirty = false } = {}) {
    if (!settings || typeof settings !== 'object') return;
    serverValues = { ...settings };
    serverSig = JSON.stringify(serverValues);
    build(serverValues);
    if (resetDirty) dirty.clear();
    fill(resetDirty);
  }

  function syncFromState() {
    const settings = store.state?.settings || store.meta?.settings;
    if (!settings) return;
    if (JSON.stringify(settings) === serverSig && builtSig) return;
    applyServer(settings);
  }

  els.fields.addEventListener('input', (e) => {
    const input = e.target.closest('[data-key]');
    if (!input) return;
    const key = input.dataset.key;
    if (sameValue(input.value, serverValues[key])) dirty.delete(key);
    else dirty.add(key);
    setFieldError(key, '');
    syncDirtyMarks();
  });
  els.fields.addEventListener('change', (e) => {
    if (e.target.tagName === 'SELECT') e.target.dispatchEvent(new Event('input', { bubbles: true }));
  });

  els.form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors();
    const patch = {};
    let invalid = false;
    for (const key of dirty) {
      const input = inputFor(key);
      if (!input) continue;
      if (input.tagName === 'SELECT' || input.type === 'text') {
        patch[key] = input.value;
      } else {
        const n = parseNum(input.value);
        if (n === null) {
          setFieldError(key, 'Введите число');
          invalid = true;
        } else {
          patch[key] = n;
        }
      }
    }
    if (invalid) {
      showError('Исправьте выделенные поля.');
      return;
    }
    if (!Object.keys(patch).length) {
      toast('Изменений нет', { timeout: 2000 });
      return;
    }
    els.save.classList.add('loading');
    try {
      const result = await putJSON('/api/settings', patch);
      if (store.state && result && typeof result === 'object') store.state.settings = { ...store.state.settings, ...result };
      applyServer(result, { resetDirty: true });
      toast('Настройки сохранены и применены на сервере', { type: 'ok' });
      refreshState();
    } catch (err) {
      const { key, text } = translateError(err.message);
      const label = key && FIELD_DEFS[key] ? ` в поле «${FIELD_DEFS[key].label}»` : '';
      if (key && inputFor(key)) setFieldError(key, text);
      showError(`Сервер отклонил изменения${label}: ${text}.`, err.message);
      try {
        // The server may have applied part of the patch — re-read the actual values.
        applyServer(await getJSON('/api/settings'));
      } catch {
        /* keep the form as is */
      }
    } finally {
      els.save.classList.remove('loading');
    }
  });

  els.revert.addEventListener('click', () => {
    dirty.clear();
    clearErrors();
    fill(true);
  });

  // ------------------------------------------------------------ preferences

  els.prefSound.addEventListener('change', () => setSound(els.prefSound.checked));
  els.prefNotify.addEventListener('change', () => setNotify(els.prefNotify.checked));
  els.prefTest.addEventListener('click', testSound);
  els.prefReset.addEventListener('click', () => {
    resetFilters();
    toast('Фильтры сброшены', { type: 'ok', timeout: 2000 });
  });

  function syncPrefs() {
    els.prefSound.checked = !!prefs.sound;
    els.prefNotify.checked = !!prefs.notify;
    const perm = notifyPermission();
    const hints = {
      granted: 'Разрешение браузера выдано.',
      denied: 'Браузер запретил уведомления для этого сайта — разрешите их в настройках сайта.',
      default: 'При включении браузер попросит разрешение.',
      unsupported: 'Этот браузер не поддерживает уведомления.',
    };
    els.notifyHint.textContent = `Системное уведомление о новой вилке. ${hints[perm] || ''}`;
    els.notifyHint.classList.toggle('warn', perm === 'denied' || perm === 'unsupported');
  }

  // ------------------------------------------------------------ info block

  function platformBlock(p) {
    const pf = platformInfo(p.platform, p.name);
    const timing = platformTimingInfo(p.platform);
    const last = parseTs(p.last_update);
    const meta = [
      `${isNum(p.markets) ? fmtNum(p.markets, 0, 0) : '—'} рынков`,
      `режим: ${MODE_LABEL[p.mode] || p.mode || '—'}`,
      `${timing.latencyInline} ${isNum(p.latency_ms) ? `${fmtNum(p.latency_ms, 0, 0)} мс` : '—'}`,
      `${timing.updateInline} ${Number.isFinite(last) ? fmtClock(last, true) : '—'}`,
    ].join(' · ');
    return `<div class="info-platform" style="--pf:${pf.color}"><span class="chip-dot${p.healthy ? ' ok' : ''}"></span><span class="ip-name">${esc(p.name || pf.name)}</span>${p.mode ? `<span class="chip-mode">${esc(p.mode)}</span>` : '<span></span>'}<span class="ip-meta">${esc(meta)}</span>${p.error ? `<span class="ip-err">${esc(p.error)}</span>` : ''}</div>`;
  }

  function renderInfo() {
    const st = store.state;
    const meta = store.meta;
    const mock = st ? st.mock_mode : meta ? meta.mock_mode : null;
    const platforms = st?.platforms || [];
    const games = meta?.games || [];
    const conn = store.conn.ws === 'open' ? 'WebSocket (live)' : store.conn.poll === 'ok' ? 'REST-опрос (WebSocket переподключается)' : 'нет связи';
    let modeHtml;
    if (mock === null) {
      modeHtml = '<span>Ожидание данных…</span>';
    } else if (mock) {
      modeHtml = '<span class="mode-pill mock">MOCK</span><span>Синтетические данные (запуск с --mock): цены и вилки ненастоящие.</span>';
    } else {
      const names = platforms.map((p) => platformInfo(p.platform, p.name).short).join(', ') || '—';
      modeHtml = `<span class="mode-pill real">REAL</span><span>Реальные данные платформ: ${esc(names)}.</span>`;
    }
    const html = `<div class="info-mode">${modeHtml}</div>
      ${platforms.map(platformBlock).join('')}
      <dl class="info-kv">
        <dt>Сервер запущен</dt><dd>${esc(fmtClock(parseTs(st?.started_at), true))}</dd>
        <dt>Последний расчёт</dt><dd>${esc(fmtClock(parseTs(st?.last_eval_at), true))}</dd>
        <dt>Последнее сопоставление</dt><dd>${esc(fmtClock(parseTs(st?.last_match_at), true))}</dd>
        <dt>Связь интерфейса</dt><dd>${esc(conn)}</dd>
      </dl>
      ${games.length ? `<div><div class="settings-group-title">Игры</div><div class="info-games">${games.map((g) => gameBadge(g.id)).join('')}</div></div>` : ''}`;
    setHTML(els.info, html);
  }

  function render() {
    syncFromState();
    syncPrefs();
    renderInfo();
  }

  return {
    render,
    onShow: render,
    onMeta: render,
    syncPrefs,
  };
}
