// "Статистика": the report from /api/stats (days in the server's stats.timezone, Europe/Moscow by default).

import { getJSON, query } from '../api.js';
import { prefs, savePrefs } from '../store.js';
import {
  NO_DATA, PERIODS, PHASE_LABELS, barPct, cappedText, flagsText, fmtDay, fmtHours, fmtShare, paperCell, periodDays,
  statsKpis, uptimeNote, uptimeText,
} from '../stats-format.js';
import { emptyHtml, setHTML, skeletonHtml, toast, watchScrollEdges } from '../ui.js';
import { $, esc, fmtClock, fmtDuration, fmtNum, fmtPct, fmtUsd, isNum, parseTs } from '../util.js';
import { gameBadge, teamsHtml } from './common.js';

const TOP = 10;

const HINTS = {
  arbs: 'Подтверждённые появления: вилка продержалась порог подтверждения. Если вилка исчезла и появилась снова, это два появления (две строки «ARB confirmed» в логе). «Уникальных» — разные вилки среди них.',
  confirm: 'Прибыль после комиссий в момент подтверждения — то, что увидел бы человек по сигналу. Сканер пишет её с этой версии; у вилок, записанных раньше, — «данных нет».',
  trimmed: 'Сумма максимальной прибыли за жизнь каждой вилки без N самых прибыльных (выбросов, stats.exclude_top_n). Сама сумма максимумов — верхняя оценка: прибыль, процент и объём могли быть в разные моменты, а крупные объёмы проверить нельзя.',
  median: 'Медиана и 90-й процентиль максимальной прибыли одной вилки: типичная вилка, а не сумма с выбросами.',
  bankroll: 'Один общий капитал на все площадки. Вилки по времени подтверждения; ставка = min(лимит на вилку, свободные деньги, доступный объём). Деньги заняты до расчёта: старт матча (или подтверждение, если позже) + stats.settle_hours. Прибыль не реинвестируется. «*» — часть вилок оценена по максимумам (нет данных при подтверждении), «**» — только оценка.',
  paper: 'Через N секунд после подтверждения сканер перечитывает оба стакана отдельным запросом и проверяет, осталась ли вилка. Ошибка запроса — «данных нет», а не «вилка исчезла».',
  lifetime: 'Сколько вилка существовала, с момента появления, вместе с порогом подтверждения: после сигнала остаётся на этот порог меньше. Доли показывают, сколько вилок жили не меньше 30 и 60 секунд: хватает ли времени сделать две ставки.',
  rate: 'Вилки, найденные в минуты со свежими данными, делённые на число таких минут и пересчитанные на сутки. «Уникальных» — каждая вилка один раз за день. Нужны хотя бы 24 ч таких минут. Если сканер работает не круглые сутки, оценка может быть завышена: матчи идут неравномерно в течение дня.',
};

function hint(key, label) {
  const text = HINTS[key];
  if (!text) return '';
  return `<span class="hint-dot has-pop" role="button" tabindex="0" aria-label="Пояснение: ${esc(label)}" data-pop data-pop-key="stats-hint-${key}">?<template class="pop-src"><div>${esc(text)}</div></template></span>`;
}

const num = (v) => esc(fmtNum(v ?? 0, 0, 0));
const usdOr = (v) => (isNum(v) ? esc(fmtUsd(v)) : '<span class="faint">—</span>');
const noData = `<span class="faint">${NO_DATA}</span>`;
const nTop = (report) => report.totals?.honest?.outliers ?? 0; // сколько вилок на самом деле исключено
const trimmedHead = (report) => (nTop(report) ? `Без топ-${esc(nTop(report))} $` : 'Сумма макс. $');

/** «При подтверждении» группы: сумма, «данных нет» или сумма с пометкой, у скольких вилок она известна. */
function confirmCell(group) {
  if (!group?.arbs) return '<span class="faint">—</span>';
  if (!group.confirm_arbs) return noData;
  const part = group.confirm_arbs < group.arbs ? ` <span class="faint" title="Данные при подтверждении есть не у всех вилок">(${esc(fmtNum(group.confirm_arbs, 0, 0))} из ${esc(fmtNum(group.arbs, 0, 0))})</span>` : '';
  return `${usd(group.confirm_profit_usd)}${part}`;
}
const pct = (v) => (isNum(v) ? esc(fmtPct(v, 2, false)) : '<span class="faint">—</span>');
const usd = (v) => esc(fmtUsd(v ?? 0));
const lifetime = (sec) => (isNum(sec) ? esc(fmtDuration(sec)) : '<span class="faint">—</span>');
const hours = (h) => (isNum(h) ? esc(fmtHours(h)) : '<span class="faint" title="Время работы за этот день неизвестно">—</span>');
const flagsCell = (text) => (text ? `<span class="sp-flags">${esc(text)}</span>` : '');

/** A number with a bar to its left (share of the largest value in the column). */
function barCell(text, value, max, cls = '') {
  return `<div class="sp-barcell"><span class="sp-track" aria-hidden="true"><span class="sp-bar ${cls}" style="width:${barPct(value, max)}%"></span></span><span class="sp-barval">${text}</span></div>`;
}

/** A card with a title, an optional note (HTML) and a table. */
function tableCard(title, note, cls, head, rows) {
  return `<div class="card table-card"><div class="card-head"><h2>${title}</h2>${note ? `<p class="muted">${note}</p>` : ''}</div><div class="table-wrap"><table class="data-table ${cls}"><thead><tr>${head}</tr></thead><tbody>${rows.join('')}</tbody></table></div></div>`;
}

export function kpisHtml(report) {
  return `<div class="kpi-grid">${statsKpis(report)
    .map((k) => `<div class="card kpi kpi-${esc(k.id)}${k.muted ? ' kpi-muted' : ''}"><div class="kpi-label">${esc(k.label)}${hint(k.id, k.label)}</div><div class="kpi-value" title="${esc(k.value)}">${esc(k.value)}</div><div class="kpi-sub">${esc(k.sub)}</div></div>`)
    .join('')}</div>`;
}

export function daysHtml(report) {
  const days = report.by_day || [];
  const maxArbs = Math.max(0, ...days.map((d) => d.arbs || 0));
  const maxTrimmed = Math.max(0, ...days.map((d) => d.profit_trimmed_usd || 0));
  const rows = [...days].reverse().map((d) => `<tr>
      <td class="nowrap">${esc(fmtDay(d.date, d.weekday))}</td>
      <td class="num">${hours(d.run_hours)}</td>
      <td class="num">${hours(d.data_hours)}</td>
      <td class="num">${barCell(num(d.arbs), d.arbs, maxArbs)}</td>
      <td class="num">${num(d.distinct_arbs)}</td>
      <td class="num">${usdOr(d.median_profit_usd)}</td>
      <td class="num">${barCell(usd(d.profit_trimmed_usd), d.profit_trimmed_usd, maxTrimmed, 'gain')}</td>
      <td class="num nowrap">${confirmCell(d)}</td>
      <td class="num">${pct(d.best_profit_pct)}</td>
      <td class="num">${lifetime(d.median_lifetime_sec)}</td>
      <td class="num">${num(d.candidates)}</td>
    </tr>`);
  const head = `<th>Дата</th><th class="num">Работа, ч</th><th class="num">Данные, ч</th><th class="num">Вилок</th><th class="num">Уник.</th><th class="num">Медиана $</th><th class="num" title="Сумма максимумов без самых прибыльных вилок периода">${trimmedHead(report)}</th><th class="num">При подтв. $</th><th class="num">Макс. %</th><th class="num">Медиана жизни</th><th class="num" title="Исчезли раньше порога подтверждения">Кандидатов</th>`;
  return tableCard('По дням', 'Новые дни сверху. «Данные» — часы, когда все площадки отдавали свежие данные.', 'sp-days', head, rows);
}

/** По фазам: до старта и после старта матча (у старых строк фаза вычислена по времени старта из истории). */
export function phasesHtml(report) {
  const phases = report.phases || [];
  const cap = report.settings?.max_stake_per_arb_usd ?? 0;
  const delays = report.settings?.paper_delays_sec || [];
  const rows = phases.map((ph) => `<tr>
      <td class="nowrap">${esc(PHASE_LABELS[ph.phase] || ph.label || '—')}</td>
      <td class="num">${num(ph.arbs)}</td>
      <td class="num">${num(ph.distinct_arbs)}</td>
      <td class="num">${lifetime(ph.lifetime_spread?.p50)}</td>
      <td class="num">${esc(fmtShare(ph.share_30s))}</td>
      <td class="num">${usdOr(ph.volume_spread?.p50)}</td>
      <td class="num">${usdOr(ph.profit_spread?.p50)}</td>
      <td class="num">${usd(ph.profit_trimmed_usd)}</td>
      <td class="num nowrap">${confirmCell(ph)}</td>
      <td class="num">${esc(cappedText(ph.capped))}</td>
      <td class="num">${esc(cappedText(ph.bankroll))}</td>
      ${delays.map((d) => `<td class="num nowrap">${esc(paperCell(ph.paper, d))}</td>`).join('')}
    </tr>`);
  const head = `<th>Фаза</th><th class="num">Вилок</th><th class="num">Уник.</th><th class="num">Медиана жизни</th><th class="num">≥ 30 с</th><th class="num">Медиана объёма</th><th class="num">Медиана $</th><th class="num">${trimmedHead(report)}</th><th class="num">При подтв.</th><th class="num">${esc(cap ? `До ${fmtUsd(cap, 0)} на вилку` : 'Весь объём')}</th><th class="num" title="Доля фазы в общей симуляции с одним банкроллом: суммы фаз равны итогу">Банкролл (доля)</th>${delays.map((d) => `<th class="num">+${esc(fmtNum(d, 0, 1))} с</th>`).join('')}`;
  const derived = report.totals?.derived_phase_arbs || 0;
  const notes = ['До старта — вилка появилась раньше времени старта матча, после старта — позже.'];
  if (derived) notes.push(`Фаза ${fmtNum(derived, 0, 0)} вилок вычислена по времени старта из истории (строки до этой версии сканера).`);
  notes.push('«Банкролл (доля)» — прибыль вилок фазы в общей симуляции с одним банкроллом: суммы фаз равны итогу. «*» — часть вилок группы оценена по максимумам (нет данных при подтверждении), «**» — оценены все.');
  return tableCard('По фазам', esc(notes.join(' ')), 'sp-phases', head, rows);
}

/** Самые прибыльные появления: они исключены из «без топ-N». */
export function outliersHtml(report) {
  const items = report.outliers || [];
  if (!items.length) return '';
  const rows = items.map((o) => {
    const flags = o.flags === null || o.flags === undefined
      ? ['нет снимков']
      : o.flags.map((f) => ({ size_jump: 'скачок размера', stale_data: 'устаревшие данные' })[f]).filter(Boolean);
    if (o.large_volume) flags.unshift('большой объём');
    return `<tr>
      <td><div class="match"><div>${teamsHtml(o.team_a, o.team_b)}</div><div class="match-sub"><span class="tournament">${esc(o.tournament || '')}</span></div></div></td>
      <td class="nowrap">${esc(PHASE_LABELS[o.phase] || '—')}</td>
      <td class="num">${lifetime(o.lifetime_sec)}</td>
      <td class="num">${usd(o.volume_usd)}</td>
      <td class="num"><span class="money gain">${usd(o.profit_usd)}</span></td>
      <td class="num">${pct(o.profit_pct)}</td>
      <td>${flagsCell(flags.join(', '))}</td>
    </tr>`;
  });
  const head = '<th class="col-match">Матч</th><th>Фаза</th><th class="num">Жила</th><th class="num">Объём</th><th class="num">Прибыль</th><th class="num">%</th><th>Флаги</th>';
  return tableCard(`Крупнейшие вилки (исключены из «без топ-${esc(nTop(report))}»)`, 'Прибыль и объём — максимумы за жизнь вилки. Были ли эти объёмы настоящими, видно только по снимкам стаканов (с этой версии).', 'sp-outliers', head, rows);
}

export function tournamentsHtml(report) {
  const items = (report.by_tournament || []).slice(0, 15);
  if (!items.length) return '';
  const rows = items.map((x) => `<tr>
      <td>${esc(x.tournament || '—')}</td>
      <td class="num">${num(x.arbs)}</td>
      <td class="num nowrap">${num(x.prematch_arbs)} / ${num(x.live_arbs)}</td>
      <td class="num">${usdOr(x.median_volume_usd)}</td>
      <td class="num">${usdOr(x.max_volume_usd)}</td>
      <td class="num">${usd(x.profit_usd)}</td>
      <td class="num">${esc(fmtShare(x.share_of_profit))}</td>
      <td class="num">${usd(x.profit_trimmed_usd)}</td>
      <td class="num nowrap">${confirmCell(x)}</td>
      <td class="num">${num(x.large_volume_arbs)}</td>
    </tr>`);
  const head = `<th>Турнир</th><th class="num">Вилок</th><th class="num">До / после старта</th><th class="num">Медиана объёма</th><th class="num">Макс. объём</th><th class="num">Сумма макс. $</th><th class="num">Доля</th><th class="num">${trimmedHead(report)}</th><th class="num">При подтв. $</th><th class="num" title="Вилок с объёмом от capture.large_volume_usd">Большой объём</th>`;
  return tableCard('По турнирам', `Показано ${items.length} из ${num(report.tournaments_total ?? (report.by_tournament || []).length)}. «Доля» — доля суммы максимумов периода.`, 'sp-tournaments', head, rows);
}

export function paperHtml(report) {
  const total = report.totals?.honest?.paper || [];
  const cap = report.settings?.max_stake_per_arb_usd ?? 0;
  if (!total.some((p) => p.checked || p.errors)) {
    const why = report.settings?.paper_enabled === false
      ? 'проверки выключены (paper.enabled: false).'
      : `проверки (стаканы перечитаны отдельным запросом через +${(report.settings?.paper_delays_sec || []).map((d) => fmtNum(d, 0, 1)).join('/+')} с после подтверждения) пишет эта версия сканера.`;
    return `<div class="card"><div class="card-head"><h2>Бумажная проверка</h2><p class="muted">${esc(`${NO_DATA}: ${why}`)}</p></div></div>`;
  }
  const groups = [['все', total], ...(report.phases || []).map((ph) => [PHASE_LABELS[ph.phase] || ph.label, ph.paper || []])];
  const rows = [];
  for (const [label, items] of groups) {
    for (const p of items) {
      rows.push(`<tr>
        <td class="nowrap">+${esc(fmtNum(p.delay_sec, 0, 1))} с</td>
        <td class="nowrap">${esc(label)}</td>
        <td class="num">${num(p.checked)}</td>
        <td class="num">${num(p.left)}</td>
        <td class="num">${esc(fmtShare(p.share_left))}</td>
        <td class="num">${usd(p.profit_usd)}</td>
        <td class="num">${usd(p.capped_profit_usd)}</td>
        <td class="num">${num(p.books_mismatch)}</td>
        <td class="num">${num(p.errors)}</td>
        <td class="num">${num(p.no_data)}</td>
      </tr>`);
    }
  }
  const head = `<th>Через</th><th>Фаза</th><th class="num">Проверено</th><th class="num">Осталось</th><th class="num">Доля</th><th class="num">Прибыль $</th><th class="num">${esc(cap ? `До ${fmtUsd(cap, 0)} на вилку` : 'Весь объём')}</th><th class="num" title="Лучшие цена или размер у сканера не совпали с ответом запроса">Стакан сканера разошёлся</th><th class="num" title="Запрос не удался, опоздал или площадка не умеет запрос">Без данных</th><th class="num" title="Вилки без проверки на этой задержке">Без проверки</th>`;
  return tableCard('Бумажная проверка', 'Стаканы перечитаны отдельным REST-запросом; прибыль — по стаканам из запроса на оставшихся вилках.', 'sp-paper', head, rows);
}

export function lifetimeHtml(report) {
  const buckets = report.lifetime_buckets || [];
  const max = Math.max(0, ...buckets.map((b) => b.count || 0));
  const rows = buckets
    .map((b) => `<div class="lt-row"><span class="lt-label">${esc(b.label)}</span><span class="lt-track"><span class="sp-bar" style="width:${barPct(b.count, max)}%"></span></span><span class="lt-count">${num(b.count)}</span></div>`)
    .join('');
  return `<div class="card"><div class="card-head"><h2>Время жизни вилок</h2><p class="muted">Сколько подтверждённых вилок прожили столько времени.</p></div><div class="lt-list">${rows}</div></div>`;
}

export function gamesHtml(report) {
  const rows = (report.by_game || []).map((g) => `<tr>
      <td>${g.game ? gameBadge(g.game) : esc(g.name || '—')}</td>
      <td class="num">${num(g.arbs)}</td>
      <td class="num">${num(g.distinct_arbs)}</td>
      <td class="num">${usdOr(g.median_profit_usd)}</td>
      <td class="num"><span class="money gain">${usd(g.profit_trimmed_usd)}</span></td>
      <td class="num nowrap">${confirmCell(g)}</td>
      <td class="num">${pct(g.best_profit_pct)}</td>
      <td class="num">${lifetime(g.median_lifetime_sec)}</td>
    </tr>`);
  const head = `<th>Игра</th><th class="num">Вилок</th><th class="num">Уник.</th><th class="num">Медиана $</th><th class="num">${trimmedHead(report)}</th><th class="num">При подтв. $</th><th class="num">Макс. %</th><th class="num">Медиана жизни</th>`;
  return tableCard('По играм', '', 'sp-games', head, rows);
}

export function venuesHtml(report) {
  const rows = (report.by_platforms || []).map((v) => `<tr>
      <td>${esc(v.label || '—')}</td>
      <td class="num">${num(v.arbs)}</td>
      <td class="num">${num(v.distinct_arbs)}</td>
      <td class="num">${usdOr(v.median_profit_usd)}</td>
      <td class="num"><span class="money gain">${usd(v.profit_trimmed_usd)}</span></td>
      <td class="num nowrap">${confirmCell(v)}</td>
      <td class="num">${pct(v.best_profit_pct)}</td>
    </tr>`);
  const head = `<th>Площадки</th><th class="num">Вилок</th><th class="num">Уник.</th><th class="num">Медиана $</th><th class="num">${trimmedHead(report)}</th><th class="num">При подтв. $</th><th class="num">Макс. %</th>`;
  return tableCard('По парам площадок', '', 'sp-venues', head, rows);
}

export function topHtml(report) {
  const rows = (report.top_pairs || []).map((p) => `<tr>
      <td><div class="match"><div>${teamsHtml(p.team_a, p.team_b)}</div><div class="match-sub"><span class="tournament" title="${esc(p.event_title || '')}">${esc(p.tournament || p.event_title || '')}</span></div></div></td>
      <td>${p.game ? gameBadge(p.game) : esc(p.game_name || '—')}</td>
      <td class="nowrap">${esc(p.platforms_label || '—')}</td>
      <td class="num">${num(p.arbs)}</td>
      <td class="num">${lifetime(p.total_lifetime_sec)}</td>
      <td class="num">${usdOr(p.max_volume_usd)}</td>
      <td class="num"><span class="money gain">${usd(p.profit_usd)}</span></td>
      <td class="num">${usdOr(p.profit_trimmed_usd)}</td>
      <td class="num">${pct(p.best_profit_pct)}</td>
      <td>${flagsCell(flagsText(p.flags, p.arbs))}</td>
      <td class="nowrap">${esc(fmtClock(parseTs(p.last_arb_at)))}</td>
    </tr>`);
  const head = `<th class="col-match">Матч</th><th>Игра</th><th>Площадки</th><th class="num">Вилок</th><th class="num">Жили всего</th><th class="num">Макс. объём</th><th class="num">Сумма макс. $</th><th class="num">${trimmedHead(report)}</th><th class="num">Макс. %</th><th title="Флаги подозрительной ликвидности">Флаги</th><th>Последняя</th>`;
  return tableCard('Матчи с наибольшей суммой максимумов', `Показано ${rows.length} из ${num(report.pairs_total)}. «Нет снимков» — вилки записаны до этой версии: скачок размера и устаревшие данные неизвестны. Время — ваше местное.`, 'sp-top', head, rows);
}

export function createStatsView() {
  const els = {
    period: $('#s-period'),
    refresh: $('#s-refresh'),
    json: $('#s-json'),
    summary: $('#s-summary'),
    content: $('#s-content'),
  };

  let report = null;
  let loading = false;
  let error = null;
  let requestId = 0;
  let pendingDays = null; // the period of the request that is running (the same one is not asked again meanwhile)
  let edges = null; // scroll-edge shadows of the tables of the last render

  const days = () => periodDays(prefs.stats.days);

  function syncControls() {
    for (const b of els.period.querySelectorAll('button[data-days]')) {
      const on = Number(b.dataset.days) === days();
      b.setAttribute('aria-checked', String(on));
      b.tabIndex = on ? 0 : -1;
    }
    els.json.href = `/api/stats${query({ days: days() })}`;
    els.json.download = `stats-${days()}d.json`;
  }

  async function load() {
    if (loading && pendingDays === days()) return; // a held key or repeated clicks: one request per period
    const id = ++requestId;
    pendingDays = days();
    loading = true;
    error = null;
    render();
    try {
      const data = await getJSON(`/api/stats${query({ days: days(), top: TOP })}`);
      if (id !== requestId) return;
      report = data;
    } catch (err) {
      if (id !== requestId) return;
      error = err.message;
      // Only when the shown report stays (same period); otherwise the error card says it already.
      if (report && report.days === days()) toast(`Не удалось обновить статистику: ${err.message}`, { type: 'error' });
    } finally {
      if (id === requestId) {
        loading = false;
        pendingDays = null;
        render();
      }
    }
  }

  function render() {
    els.refresh.classList.toggle('loading', loading);
    // While another period loads, the old numbers stay dimmed (and are announced as busy) instead of looking current.
    els.content.setAttribute('aria-busy', String(loading && !!report && report.days !== days()));
    if (!report || (error && report.days !== days())) {
      // setHTML everywhere: it caches the last HTML, so a textContent write would make a later identical update a no-op.
      if (!error) {
        setHTML(els.content, `<div class="card empty">${skeletonHtml(5)}</div>`);
        setHTML(els.summary, 'Загрузка…');
      } else {
        setHTML(els.content, `<div class="card empty">${emptyHtml({ icon: 'warning', title: 'Не удалось загрузить статистику', text: esc(error), actionHtml: '<button type="button" class="btn btn-sm" data-action="stats-retry">Повторить</button>' })}</div>`);
        setHTML(els.summary, '');
      }
      return;
    }
    const period = PERIODS.find((p) => p.days === report.days);
    const from = fmtDay(report.period?.from);
    const to = fmtDay(report.period?.to);
    const note = uptimeNote(report);
    setHTML(
      els.summary,
      `${esc(period ? period.label : `${report.days} дн.`)}: ${esc(from === to ? from : `${from} – ${to}`)}<span class="sep">·</span>дни по часовому поясу <b>${esc(report.timezone)}</b><span class="sep">·</span>порог подтверждения ${esc(fmtNum(report.confirm_seconds, 0, 1))} с<span class="sep">·</span>${esc(uptimeText(report))}${loading ? '<span class="sep">·</span>обновление…' : ''}`,
    );
    const noArbs = !report.totals?.arbs;
    const empty = noArbs
      ? `<div class="card empty-card"><div class="empty">${emptyHtml({ icon: 'clock', title: 'Подтверждённых вилок за этот период нет', text: 'Вилка попадает в историю, когда исчезает с рынка. Для решения о новых площадках оставьте сканер работать 3–7 дней.' })}</div></div>`
      : '';
    const t = report.totals || {};
    const missing = t.arbs ? t.arbs - (t.captured_arbs || 0) : 0;
    const dataNote = missing
      ? `У ${fmtNum(missing, 0, 0)} из ${fmtNum(t.arbs, 0, 0)} вилок нет данных при подтверждении (записаны до этой версии сканера, сбор выключен или не удался): там, где они нужны, — «${NO_DATA}»; прибыль при ставке для них — оценка по максимумам («*» — часть вилок группы, «**» — все).`
      : '';
    const html = [
      kpisHtml(report),
      note ? `<div class="sp-note" role="note">${esc(note)}</div>` : '',
      dataNote ? `<div class="sp-note" role="note">${esc(dataNote)}</div>` : '',
      empty,
      noArbs ? '' : phasesHtml(report),
      noArbs ? '' : outliersHtml(report),
      daysHtml(report),
      noArbs ? '' : lifetimeHtml(report),
      noArbs ? '' : gamesHtml(report),
      noArbs ? '' : venuesHtml(report),
      noArbs ? '' : tournamentsHtml(report),
      noArbs ? '' : paperHtml(report),
      noArbs ? '' : topHtml(report),
    ].join('');
    // Only new tables need watching; re-watching unchanged ones would stack another scroll listener on each.
    if (setHTML(els.content, html)) {
      edges?.disconnect();
      edges = watchScrollEdges(els.content);
    }
  }

  els.period.addEventListener('click', (e) => {
    const button = e.target.closest('button[data-days]');
    if (!button) return;
    prefs.stats.days = Number(button.dataset.days);
    savePrefs();
    syncControls();
    load();
  });
  els.period.addEventListener('keydown', (e) => {
    if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return; // Alt+← is the browser's "back"
    if (e.repeat) return; // a held arrow key would request one period after another
    const buttons = [...els.period.querySelectorAll('button[data-days]')];
    const i = buttons.findIndex((b) => Number(b.dataset.days) === days());
    let next = null;
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') next = buttons[(i + 1) % buttons.length];
    else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') next = buttons[(i - 1 + buttons.length) % buttons.length];
    if (!next) return;
    e.preventDefault();
    next.click();
    next.focus();
  });
  els.refresh.addEventListener('click', () => load());
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-action="stats-retry"]')) load();
  });

  syncControls();

  return {
    render: () => {}, // the report comes from the history, not from the live state: no redraw every second
    onShow() {
      syncControls();
      load();
    },
    onMeta() {
      if (report) render(); // game names and colours arrive with META, possibly after the report
    },
  };
}
