// Top bar: brand + MOCK badge, platform status chips, counters, connection indicator.

import { icons } from '../icons.js';
import { isStale, platformInfo, platformTimingInfo, scannerStalled, store } from '../store.js';
import { setHTML, setText, syncKeyed } from '../ui.js';
import { esc, fmtClock, fmtNum, isNum, parseTs } from '../util.js';

const MODE_LABEL = { ws: 'WebSocket', rest: 'REST (опрос)', mock: 'синтетические данные' };

export function chipHtml(p) {
  const pf = platformInfo(p.platform, p.name);
  const timing = platformTimingInfo(p.platform);
  const lastMs = parseTs(p.last_update);
  const latency = isNum(p.latency_ms) ? `${fmtNum(p.latency_ms, 0, 0)} мс` : '— мс';
  const compactLatency = timing.latencyCompact ? `${timing.latencyCompact} ${latency}` : latency;
  const status = p.healthy ? 'работает' : p.connected ? 'нет свежих данных' : 'нет соединения';
  const tip = `<div class="pop-title">${esc(p.name || pf.name)}</div><dl class="pop-kv">
    <dt>Статус</dt><dd>${esc(status)}</dd>
    <dt>Режим</dt><dd>${esc(MODE_LABEL[p.mode] || p.mode || '—')}</dd>
    <dt>${esc(timing.latencyLabel)}</dt><dd>${esc(latency)}</dd>
    <dt>Рынков</dt><dd>${isNum(p.markets) ? fmtNum(p.markets, 0, 0) : '—'}</dd>
    <dt>${esc(timing.updateLabel)}</dt><dd>${Number.isFinite(lastMs) ? esc(fmtClock(lastMs, true)) : 'нет данных'}</dd>
  </dl>${timing.note ? `<div class="pop-note">${esc(timing.note)}</div>` : ''}${p.error ? `<div class="alert alert-error" style="margin-top:8px">${icons.warning}<div>${esc(p.error)}</div></div>` : ''}`;
  return `<span class="chip-dot"></span><span class="chip-body"><span class="chip-line"><span class="chip-name">${esc(pf.short)}</span>${p.mode ? `<span class="chip-mode">${esc(p.mode)}</span>` : ''}<span class="chip-meta">${esc(compactLatency)}</span></span><span class="chip-sub" data-tick="ago" data-prefix="${esc(timing.updatePrefix)}" data-ts="${Number.isFinite(lastMs) ? lastMs : ''}"></span></span>${p.error ? `<span class="chip-err-icon">${icons.warning}</span>` : ''}<template class="pop-src">${tip}</template>`;
}

function setStat(name, value) {
  const el = document.querySelector(`[data-stat="${name}"]`);
  if (!el) return;
  const text = isNum(value) ? fmtNum(value, 0, 0) : '—';
  if (el.textContent === text) return;
  const hadValue = el.textContent !== '—';
  el.textContent = text;
  if (hadValue) {
    el.classList.remove('bump');
    void el.offsetWidth; // restart the animation
    el.classList.add('bump');
  }
}

export function renderHeader() {
  const st = store.state;
  const meta = store.meta;
  const mock = st ? st.mock_mode : meta ? meta.mock_mode : false;
  document.getElementById('mock-badge').hidden = !mock;

  const list = st?.platforms?.length
    ? st.platforms
    : (meta?.platforms || []).map((p) => ({ platform: p.id, name: p.name, color: p.color, mode: null, connected: false, healthy: false }));

  const names = list.map((p) => platformInfo(p.platform, p.name).short);
  setText(document.getElementById('brand-sub'), names.length ? `${names.join(' × ')} · киберспорт` : 'Поиск вилок между платформами');

  syncKeyed(document.getElementById('platform-chips'), list, {
    key: (p) => p.platform,
    create: () => {
      const el = document.createElement('div');
      el.className = 'chip';
      el.tabIndex = 0;
      el.setAttribute('data-pop', '');
      return el;
    },
    update: (el, p) => {
      el.setAttribute('data-pop-key', `chip:${p.platform}`);
      el.style.setProperty('--pf', platformInfo(p.platform, p.name).color);
      el.classList.toggle('ok', !!p.healthy);
      el.classList.toggle('err', !!p.error);
      setHTML(el, chipHtml(p));
    },
  });

  const counts = st?.counts || {};
  setStat('markets', counts.matches); // a match listed on several platforms counts once
  setStat('pairs', counts.pairs);
  setStat('arbs', counts.active_arbs);

  const byPlatform = counts.markets_by_platform || {};
  const rows = Object.entries(byPlatform)
    .map(([id, n]) => `<dt>${esc(platformInfo(id).short)}</dt><dd>${fmtNum(n, 0, 0)}</dd>`)
    .join('');
  const tpl = document.querySelector('#stat-markets template.pop-src');
  const totals = isNum(counts.markets) ? `<dt>Рынков всего</dt><dd>${fmtNum(counts.markets, 0, 0)}</dd>` : '';
  const tipHtml = `<div class="pop-title">Отслеживаемые матчи</div><div>Уникальные матчи (рынки «победитель матча»). Матч, найденный на нескольких платформах, считается один раз.</div>${rows || totals ? `<dl class="pop-kv" style="margin-top:6px">${totals}${rows}</dl>` : ''}`;
  if (tpl && tpl.innerHTML !== tipHtml) tpl.innerHTML = tipHtml;
}

const TITLES = {
  live: 'Данные приходят по WebSocket в реальном времени',
  stalled: 'Связь с сервером есть, но сканер перестал пересчитывать вилки: данные на экране не обновляются',
  polling: 'WebSocket недоступен, данные приходят по REST каждые 2 с',
  offline: 'Нет свежих данных от сервера сканера: показанные данные устарели',
  connecting: 'Связь с сервером сканера',
};

/**
 * Connection indicator: are the numbers on screen live? Covers the dashboard's own link to the
 * backend (WebSocket, REST fallback, silent or dead link) and a scanner that stopped evaluating.
 */
export function renderConn() {
  const c = store.conn;
  const root = document.getElementById('conn');
  const label = document.getElementById('conn-label');
  const sub = document.getElementById('conn-sub');
  let state;
  let text;
  let subText = '';
  let tick = null;
  if (isStale()) {
    state = 'offline';
    text = 'Нет связи с сервером';
    if (c.ws === 'closed' && c.retryAt) tick = { kind: 'retry', ts: c.retryAt };
  } else if (scannerStalled()) {
    state = 'stalled';
    text = 'Расчёт остановлен';
    tick = { kind: 'ago', ts: parseTs(store.state.last_eval_at), prefix: 'обновлено ' };
  } else if (c.ws === 'open') {
    state = 'live';
    text = 'Live';
  } else if (c.poll === 'ok') {
    state = 'polling';
    text = 'Переподключение…';
    subText = 'данные по REST каждые 2 с';
  } else {
    state = 'connecting';
    text = store.state ? 'Переподключение…' : 'Подключение…';
  }
  if (root.dataset.state !== state) root.dataset.state = state;
  root.title = TITLES[state];
  setText(label, text);
  if (tick) {
    sub.dataset.tick = tick.kind;
    sub.dataset.ts = String(tick.ts);
    if (tick.prefix) sub.dataset.prefix = tick.prefix;
    else delete sub.dataset.prefix;
  } else {
    delete sub.dataset.tick;
    delete sub.dataset.ts;
    delete sub.dataset.prefix;
    setText(sub, subText);
  }
}
