// "История": paginated table from /api/history with filters and CSV export.

import { getJSON, query } from '../api.js';
import { icons } from '../icons.js';
import { platformInfo, prefs, savePrefs } from '../store.js';
import { emptyHtml, setHTML, skeletonHtml, toast } from '../ui.js';
import { $, debounce, esc, fmtClock, fmtNum, fmtPct, fmtPrice, fmtUsd, parseNum, parseTs, plural, profitTier, safeUrl } from '../util.js';
import { gameBadge, teamsHtml } from './common.js';

const PAGE = 100;

function legLine(platformId, outcome, ask, url) {
  const pf = platformInfo(platformId);
  const href = safeUrl(url);
  return `<div class="hleg" style="--pf:${pf.color}"><span class="leg-pf">${esc(pf.short)}</span><span>«${esc(outcome || '?')}»</span><span class="price-pill">${fmtPrice(ask)}</span>${href ? `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer" title="Открыть рынок на ${esc(pf.name)}">${icons.external}</a>` : ''}</div>`;
}

function warningsCount(item) {
  const list = Array.isArray(item.warnings) ? item.warnings : [];
  if (!list.length) return '<span class="faint">0</span>';
  const items = list.map((w) => `<li><span class="sev-dot medium"></span><div>${esc(w)}</div></li>`).join('');
  return `<button type="button" class="warn-btn sev-medium" data-pop data-pop-key="hwarn:${esc(item.id)}" aria-label="Предупреждения: ${list.length}">${icons.warning}<span>${list.length}</span><template class="pop-src"><div class="pop-title">Предупреждения (на момент вилки)</div><ul class="warn-list">${items}</ul></template></button>`;
}

function rowHtml(item) {
  const first = parseTs(item.first_seen);
  const last = parseTs(item.last_seen);
  const maxProfitTier = profitTier(item.max_profit_pct);
  return `<tr>
    <td class="time-cell" title="Последний раз: ${esc(fmtClock(last, true))}">${esc(fmtClock(first, true))}</td>
    <td><div class="match"><div>${teamsHtml(item.team_a, item.team_b)}</div><div class="match-sub"><span class="tournament" title="${esc(item.event_title || '')}">${esc(item.tournament || item.event_title || '')}</span></div></div></td>
    <td>${gameBadge(item.game)}</td>
    <td>${legLine(item.leg1_platform, item.leg1_outcome, item.leg1_ask, item.leg1_url)}${legLine(item.leg2_platform, item.leg2_outcome, item.leg2_ask, item.leg2_url)}</td>
    <td class="num">${fmtNum(item.lifetime_sec, 1, 1)}</td>
    <td class="num"><span class="profit tier-${maxProfitTier}" title="Последний профит: ${esc(fmtPct(item.last_profit_pct))}">${fmtPct(item.max_profit_pct)}</span></td>
    <td class="num">${fmtUsd(item.max_volume_usd)}</td>
    <td class="num"><span class="money gain">${fmtUsd(item.max_profit_usd)}</span></td>
    <td class="center">${item.confirmed ? `<span class="yes" title="Подтверждена">${icons.check}</span>` : '<span class="no" title="Не дожила до подтверждения">—</span>'}</td>
    <td class="center">${warningsCount(item)}</td>
  </tr>`;
}

export function createHistoryView({ fillGameSelect }) {
  const els = {
    game: $('#h-game'),
    minProfit: $('#h-min-profit'),
    confirmed: $('#h-confirmed'),
    refresh: $('#h-refresh'),
    csv: $('#h-csv'),
    summary: $('#h-summary'),
    body: $('#h-body'),
    empty: $('#h-empty'),
    footer: $('#h-footer'),
    more: $('#h-more'),
  };
  els.tableWrap = els.body.closest('.table-wrap');

  let items = [];
  let total = 0;
  let hasMore = false; // the last page was full, so older rows may follow
  let loading = false;
  let error = null;
  let loadedOnce = false;
  let requestId = 0;

  function filters() {
    const h = prefs.history;
    const minProfit = parseNum(h.minProfit);
    return {
      game: h.game || '',
      confirmed_only: h.confirmedOnly ? 'true' : '',
      min_profit_pct: minProfit === null ? '' : minProfit,
    };
  }

  function syncControls() {
    const h = prefs.history;
    fillGameSelect(els.game, h.game);
    els.minProfit.value = h.minProfit;
    els.confirmed.checked = !!h.confirmedOnly;
    els.csv.href = `/api/history.csv${query(filters())}`;
  }

  async function load(reset) {
    const id = ++requestId;
    loading = true;
    error = null;
    if (reset) {
      items = [];
      total = 0;
      hasMore = false;
    }
    render();
    // "Показать ещё" continues right after the last row shown (cursor), so rows written meanwhile cannot
    // shift the page; they appear after "Обновить".
    const last = reset ? null : items[items.length - 1];
    const cursor = last ? { before_first_seen: last.first_seen, before_id: last.id } : {};
    try {
      const data = await getJSON(`/api/history${query({ ...filters(), limit: PAGE, ...cursor })}`);
      if (id !== requestId) return;
      const page = Array.isArray(data?.items) ? data.items : [];
      if (reset) {
        items = page;
      } else {
        const seen = new Set(items.map((it) => it.id));
        items = items.concat(page.filter((it) => !seen.has(it.id)));
      }
      hasMore = page.length >= PAGE;
      total = Math.max(Number(data?.total) || 0, items.length);
      loadedOnce = true;
    } catch (err) {
      if (id !== requestId) return;
      error = err.message;
      if (!reset) toast(`Не удалось загрузить историю: ${err.message}`, { type: 'error' });
    } finally {
      if (id === requestId) {
        loading = false;
        render();
      }
    }
  }

  function render() {
    els.csv.href = `/api/history.csv${query(filters())}`;
    els.refresh.classList.toggle('loading', loading);
    if (!items.length) {
      els.tableWrap.hidden = true;
      els.footer.hidden = true;
      els.empty.hidden = false;
      if (loading || !loadedOnce) {
        setHTML(els.empty, skeletonHtml(4));
        els.summary.textContent = 'Загрузка…';
      } else if (error) {
        setHTML(els.empty, emptyHtml({ icon: 'warning', title: 'Не удалось загрузить историю', text: esc(error), actionHtml: '<button type="button" class="btn btn-sm" data-action="history-retry">Повторить</button>' }));
        els.summary.textContent = '';
      } else {
        setHTML(els.empty, emptyHtml({ icon: 'clock', title: 'История пуста', text: 'Здесь появятся вилки после того, как они исчезнут с рынка. Попробуйте ослабить фильтры.' }));
        els.summary.textContent = 'Записей: 0';
      }
      return;
    }
    els.empty.hidden = true;
    els.tableWrap.hidden = false;
    els.body.innerHTML = items.map(rowHtml).join('');
    // Rows written after the first page was loaded are newer than everything shown: they need a refresh.
    const newer = hasMore ? 0 : total - items.length;
    els.summary.innerHTML = `Показано <b>${items.length}</b> из ${total} ${plural(total, ['записи', 'записей', 'записей'])}<span class="sep">·</span>новые сверху${newer > 0 ? `<span class="sep">·</span>новых записей: <b>${newer}</b> — нажмите «Обновить»` : ''}`;
    els.footer.hidden = !hasMore;
    els.more.disabled = loading;
    els.more.classList.toggle('loading', loading);
    els.more.textContent = loading ? 'Загрузка…' : `Показать ещё (до ${PAGE})`;
  }

  const reloadDebounced = debounce(() => load(true), 350);

  els.game.addEventListener('change', () => {
    prefs.history.game = els.game.value;
    savePrefs();
    load(true);
  });
  els.minProfit.addEventListener('input', () => {
    prefs.history.minProfit = els.minProfit.value;
    savePrefs();
    els.csv.href = `/api/history.csv${query(filters())}`;
    reloadDebounced();
  });
  els.confirmed.addEventListener('change', () => {
    prefs.history.confirmedOnly = els.confirmed.checked;
    savePrefs();
    load(true);
  });
  els.refresh.addEventListener('click', () => load(true));
  els.more.addEventListener('click', () => load(false));
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-action="history-retry"]')) load(true);
  });

  syncControls();

  return {
    render: () => {},
    onShow() {
      syncControls();
      load(true);
    },
    onMeta() {
      syncControls();
    },
  };
}
