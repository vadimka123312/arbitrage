// "Активные вилки": filters, confirmation slider, live table of confirmed arbs, candidates,
// detection of NEW confirmed arbs (highlight, sound, browser notification).

import { putJSON } from '../api.js';
import { beep, showNotification } from '../alerts.js';
import { createDetector, instKey } from '../detector.js';
import { refreshState } from '../connection.js';
import { DEFAULT_FILTERS, confirmSeconds, gameInfo, platformInfo, prefs, savePrefs, store } from '../store.js';
import { emptyHtml, markEntering, setHTML, setText, skeletonHtml, syncRows, toast } from '../ui.js';
import { $, clamp, debounce, esc, fmtNum, fmtPct, fmtPrice, fmtUsd, isNum, parseNum, parseTs, plural, profitTier } from '../util.js';
import { confidenceBadge, gameBadge, legCell, linkButton, startCell, teamsHtml, warningsButton } from './common.js';


export function passesFilters(a, f = prefs.filters) {
  if (f.game && a.game !== f.game) return false;
  const minProfit = parseNum(f.minProfit);
  if (minProfit !== null && !(a.profit_pct >= minProfit)) return false;
  const minVolume = parseNum(f.minVolume);
  if (minVolume !== null && !(a.volume_usd >= minVolume)) return false;
  if (f.live === 'live' && !a.is_live) return false;
  if (f.live === 'upcoming' && a.is_live) return false;
  return true;
}

/**
 * Price per pair of contracts actually paid: average prices when several levels are swept (walk_book),
 * otherwise the two best asks (`sum_ask`). Fees are not included.
 */
function priceSum(a) {
  const p1 = isNum(a.leg1?.avg_price) ? a.leg1.avg_price : a.leg1?.ask;
  const p2 = isNum(a.leg2?.avg_price) ? a.leg2.avg_price : a.leg2?.ask;
  return isNum(p1) && isNum(p2) ? p1 + p2 : a.sum_ask;
}

function sumHtml(a) {
  const sum = priceSum(a);
  if (!isNum(a.sum_ask) || !isNum(sum) || Math.abs(sum - a.sum_ask) < 0.0005) return `<span class="money">${fmtPrice(a.sum_ask)}</span>`;
  return `<span class="money" title="Средние цены по нескольким уровням стакана (режим «Проход по стакану»)">${fmtPrice(sum)}</span><div class="leg-avg">лучшие ${fmtPrice(a.sum_ask)}</div>`;
}

const SORT_VALUE = {
  start: (a) => {
    const t = parseTs(a.start_time);
    return Number.isFinite(t) ? t : Number.MAX_SAFE_INTEGER;
  },
  sum: priceSum,
  profit: (a) => a.profit_pct,
  volume: (a) => a.volume_usd,
  profit_usd: (a) => a.profit_usd,
  age: (a) => -parseTs(a.first_seen),
};
const DEFAULT_DIR = { start: 'asc', sum: 'asc', profit: 'desc', volume: 'desc', profit_usd: 'desc', age: 'desc' };

function matchHtml(a) {
  return `<div class="match"><div>${teamsHtml(a.team_a, a.team_b)}</div><div class="match-sub">${gameBadge(a.game)}${confidenceBadge(a.confidence, a.pair_status)}<span class="tournament" title="${esc(a.event_title || '')}">${esc(a.tournament || a.event_title || '')}</span></div></div>`;
}

function profitHtml(a, key) {
  const pf1 = platformInfo(a.leg1?.platform, a.leg1?.platform_name).short;
  const pf2 = platformInfo(a.leg2?.platform, a.leg2?.platform_name).short;
  const tip = `<div class="pop-title">Прибыль после комиссий</div><dl class="pop-kv">
    <dt>Комиссии всего</dt><dd>${fmtUsd(a.fees_usd)}</dd>
    <dt>— ${esc(pf1)}</dt><dd>${fmtUsd(a.leg1?.fee_usd)}</dd>
    <dt>— ${esc(pf2)}</dt><dd>${fmtUsd(a.leg2?.fee_usd)}</dd>
    ${a.extra_costs_usd ? `<dt>Доп. расходы</dt><dd>${fmtUsd(a.extra_costs_usd)}</dd>` : ''}
    <dt>Цена контракта с комиссиями</dt><dd>${fmtNum(a.cost_per_contract, 4, 4)}\u00a0$</dd>
    <dt>Контрактов</dt><dd>${fmtNum(a.contracts, 0, 2)}</dd>
    <dt>Макс. профит за время жизни</dt><dd>${fmtPct(a.max_profit_pct)}</dd>
  </dl><div class="pop-note">Контракт выплачивает 1 $; профит = (1 − цена с комиссиями) / цена с комиссиями.</div>`;
  return `<span class="profit tier-${profitTier(a.profit_pct)} has-pop" tabindex="0" data-pop data-pop-key="profit:${esc(key)}">${fmtPct(a.profit_pct)}<template class="pop-src">${tip}</template></span>`;
}

function arbCells(a) {
  const key = instKey(a);
  return [
    matchHtml(a),
    startCell(a.start_time, a.is_live),
    legCell(a.leg1),
    legCell(a.leg2),
    { html: sumHtml(a), cls: 'num' },
    { html: profitHtml(a, key), cls: 'num' },
    { html: warningsButton(a.warnings, `warn:${key}`), cls: 'center' }, // next to profit: visible even at 900 px
    { html: `<span class="money">${fmtUsd(a.volume_usd)}</span>`, cls: 'num' },
    { html: `<span class="money gain">${fmtUsd(a.profit_usd)}</span>`, cls: 'num' },
    { html: `<span class="age" data-tick="age" data-ts="${parseTs(a.first_seen)}"></span>`, cls: 'num' },
    `<div class="links">${linkButton(a.leg1?.platform, a.leg1?.platform_name, a.leg1?.url)}${linkButton(a.leg2?.platform, a.leg2?.platform_name, a.leg2?.url)}</div>`,
  ];
}

function candCells(a) {
  const fs = parseTs(a.first_seen);
  return [
    `<div class="match"><div>${teamsHtml(a.team_a, a.team_b)}</div><div class="match-sub">${gameBadge(a.game)}<span class="tournament">${esc(a.tournament || '')}</span></div></div>`,
    legCell(a.leg1),
    legCell(a.leg2),
    { html: sumHtml(a), cls: 'num' },
    { html: `<span class="profit tier-${profitTier(a.profit_pct)}">${fmtPct(a.profit_pct)}</span>`, cls: 'num' },
    { html: fmtUsd(a.volume_usd), cls: 'num' },
    `<div class="countdown"><span class="countdown-text" data-tick="countdown" data-ts="${fs}"></span><div class="progress"><span data-tick="progress" data-ts="${fs}"></span></div></div>`,
  ];
}

function notifyArb(a, onClick) {
  const pf1 = platformInfo(a.leg1?.platform, a.leg1?.platform_name).short;
  const pf2 = platformInfo(a.leg2?.platform, a.leg2?.platform_name).short;
  const title = `Вилка ${fmtPct(a.profit_pct)} · ${gameInfo(a.game).short}`;
  const body = `${a.team_a} vs ${a.team_b}\n${pf1}: «${a.leg1?.outcome}» ${fmtPrice(a.leg1?.ask)} + ${pf2}: «${a.leg2?.outcome}» ${fmtPrice(a.leg2?.ask)}\nОбъём ${fmtUsd(a.volume_usd)}, прибыль ${fmtUsd(a.profit_usd)}`;
  showNotification(title, body, instKey(a), onClick);
}

export function createArbsView({ isActive, onNewArbs, focusArbs, fillGameSelect, onVisibleChange }) {
  const els = {
    body: $('#arbs-body'),
    empty: $('#arbs-empty'),
    summary: $('#arb-summary'),
    candidates: $('#candidates'),
    candBody: $('#cand-body'),
    candEmpty: $('#cand-empty'),
    candTitle: $('#cand-title'),
    candCount: $('#cand-count'),
    game: $('#f-game'),
    minProfit: $('#f-min-profit'),
    minVolume: $('#f-min-volume'),
    live: $('#f-live'),
    reset: $('#f-reset'),
    slider: $('#f-confirm'),
    sliderOut: $('#f-confirm-out'),
    thead: document.querySelector('.arbs-table thead'),
  };
  els.tableWrap = els.body.closest('.table-wrap');
  els.candWrap = els.candBody.closest('.table-wrap');

  const detectNew = createDetector((a) => passesFilters(a)); // see detector.js for the alert rules
  const flashUntil = new Map();
  let renderedOnce = false;
  let visibleCount = 0;

  // ------------------------------------------------------------ filters

  function syncFilterControls() {
    const f = prefs.filters;
    fillGameSelect(els.game, f.game);
    els.minProfit.value = f.minProfit;
    els.minVolume.value = f.minVolume;
    for (const b of els.live.querySelectorAll('button')) {
      const on = b.dataset.value === f.live;
      b.setAttribute('aria-checked', String(on));
      b.tabIndex = on ? 0 : -1;
    }
  }

  function filtersChanged() {
    savePrefs();
    render();
  }

  function resetFilters() {
    Object.assign(prefs.filters, DEFAULT_FILTERS);
    syncFilterControls();
    filtersChanged();
  }

  els.game.addEventListener('change', () => {
    prefs.filters.game = els.game.value;
    filtersChanged();
  });
  els.minProfit.addEventListener('input', () => {
    prefs.filters.minProfit = els.minProfit.value;
    filtersChanged();
  });
  els.minVolume.addEventListener('input', () => {
    prefs.filters.minVolume = els.minVolume.value;
    filtersChanged();
  });
  els.live.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-value]');
    if (!b) return;
    prefs.filters.live = b.dataset.value;
    syncFilterControls();
    filtersChanged();
  });
  els.live.addEventListener('keydown', (e) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    const buttons = [...els.live.querySelectorAll('button')];
    const i = buttons.findIndex((b) => b.dataset.value === prefs.filters.live);
    const next = buttons[(i + (e.key === 'ArrowRight' ? 1 : buttons.length - 1)) % buttons.length];
    prefs.filters.live = next.dataset.value;
    syncFilterControls();
    next.focus();
    filtersChanged();
  });
  els.reset.addEventListener('click', resetFilters);
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-action="reset-filters"]')) resetFilters();
  });

  // ------------------------------------------------------------ sorting

  function syncSortHeaders() {
    for (const th of els.thead.querySelectorAll('th[data-sort]')) {
      const active = th.dataset.sort === prefs.arbSort.key;
      if (active) th.dataset.dir = prefs.arbSort.dir;
      else delete th.dataset.dir;
      th.setAttribute('aria-sort', active ? (prefs.arbSort.dir === 'asc' ? 'ascending' : 'descending') : 'none');
      th.tabIndex = 0;
    }
  }

  function sortBy(key) {
    if (!SORT_VALUE[key]) return;
    if (prefs.arbSort.key === key) prefs.arbSort.dir = prefs.arbSort.dir === 'asc' ? 'desc' : 'asc';
    else {
      prefs.arbSort.key = key;
      prefs.arbSort.dir = DEFAULT_DIR[key] || 'desc';
    }
    savePrefs();
    syncSortHeaders();
    render();
  }

  els.thead.addEventListener('click', (e) => {
    const th = e.target.closest('th[data-sort]');
    if (th) sortBy(th.dataset.sort);
  });
  els.thead.addEventListener('keydown', (e) => {
    const th = e.target.closest('th[data-sort]');
    if (th && (e.key === 'Enter' || e.key === ' ')) {
      e.preventDefault();
      sortBy(th.dataset.sort);
    }
  });

  function sortArbs(list) {
    const valueOf = SORT_VALUE[prefs.arbSort.key] || SORT_VALUE.profit;
    const dir = prefs.arbSort.dir === 'asc' ? 1 : -1;
    list.sort((a, b) => {
      const va = valueOf(a);
      const vb = valueOf(b);
      if (va === vb) return (b.profit_pct - a.profit_pct) || (a.arb_id < b.arb_id ? -1 : 1);
      return va < vb ? -dir : dir;
    });
  }

  // ------------------------------------------------------------ confirmation slider

  let dragging = false;
  let sliderTarget = null;
  let sliderTargetUntil = 0;

  function updateFill() {
    const min = Number(els.slider.min) || 0;
    const max = Number(els.slider.max) || 60;
    const pct = ((Number(els.slider.value) - min) / (max - min)) * 100;
    els.slider.style.setProperty('--fill', `${clamp(pct, 0, 100)}%`);
  }

  function syncSlider() {
    if (dragging) return;
    const server = confirmSeconds();
    if (sliderTarget !== null) {
      if (Math.abs(server - sliderTarget) < 1e-9 || Date.now() > sliderTargetUntil) sliderTarget = null;
      else return;
    }
    const v = String(clamp(Math.round(server), 0, 60));
    if (els.slider.value !== v) els.slider.value = v;
    setText(els.sliderOut, `${fmtNum(server, 0, 1)} с`);
    updateFill();
  }

  const pushConfirm = debounce(async (value) => {
    sliderTarget = value;
    sliderTargetUntil = Date.now() + 6000;
    els.sliderOut.classList.add('busy');
    try {
      const result = await putJSON('/api/settings', { 'engine.confirm_seconds': value });
      if (store.state && result && typeof result === 'object') store.state.settings = { ...store.state.settings, ...result };
      toast(`Порог подтверждения ${value} с применён на сервере`, { type: 'ok', timeout: 2200 });
      refreshState();
    } catch (err) {
      sliderTarget = null;
      toast(`Не удалось изменить порог: ${err.message}`, { type: 'error' });
    } finally {
      els.sliderOut.classList.remove('busy');
      dragging = false;
      syncSlider();
      render();
    }
  }, 450);

  els.slider.addEventListener('input', () => {
    dragging = true;
    const v = Number(els.slider.value);
    setText(els.sliderOut, `${v} с`);
    updateFill();
    pushConfirm(v);
  });

  // ------------------------------------------------------------ new-arb detection

  function detect(st) {
    const now = Date.now();
    const fresh = detectNew(st.arbs);
    for (const a of fresh) flashUntil.set(instKey(a), now + 3000);
    const present = new Set((st.arbs || []).map(instKey));
    for (const [k, until] of flashUntil) if (until < now || !present.has(k)) flashUntil.delete(k);
    return fresh;
  }

  function announce(fresh) {
    if (!fresh.length) return;
    if (prefs.sound) beep();
    if (prefs.notify) {
      const best = [...fresh].sort((a, b) => b.profit_pct - a.profit_pct);
      if (best.length > 2) {
        showNotification(
          `Новые вилки: ${best.length}`,
          `Лучшая ${fmtPct(best[0].profit_pct)} — ${best[0].team_a} vs ${best[0].team_b}`,
          'arb-batch',
          focusArbs,
        );
      } else {
        for (const a of best) notifyArb(a, focusArbs);
      }
    }
    onNewArbs();
  }

  // ------------------------------------------------------------ rendering

  function renderSummary(confirmed, visible, candidates) {
    const hidden = confirmed.length - visible.length;
    const parts = [
      `Показано <b>${visible.length}</b> из ${confirmed.length} ${plural(confirmed.length, ['подтверждённой вилки', 'подтверждённых вилок', 'подтверждённых вилок'])}`,
    ];
    if (hidden > 0) parts.push(`скрыто фильтрами: <b>${hidden}</b>`);
    parts.push(`кандидатов: <b>${candidates}</b>`);
    parts.push(`подтверждение ≥ <b>${fmtNum(confirmSeconds(), 0, 1)} с</b>`);
    setHTML(els.summary, parts.join('<span class="sep">·</span>'));
  }

  function renderCandidates(st) {
    const cands = (st.arbs || [])
      .filter((a) => !a.confirmed && passesFilters(a))
      .sort((a, b) => parseTs(a.first_seen) - parseTs(b.first_seen));
    setText(els.candTitle, `Кандидаты (< ${fmtNum(confirmSeconds(), 0, 1)} с)`);
    setText(els.candCount, String(cands.length));
    markEntering(syncRows(els.candBody, cands, { key: instKey, cells: candCells }));
    els.candWrap.hidden = cands.length === 0;
    els.candEmpty.hidden = cands.length > 0;
    return cands.length;
  }

  function render() {
    syncSlider();
    const st = store.state;
    if (!st) {
      els.tableWrap.hidden = true;
      els.empty.hidden = false;
      setHTML(els.empty, skeletonHtml(5));
      setHTML(els.summary, 'Подключение к сканеру…');
      return;
    }
    const confirmed = (st.arbs || []).filter((a) => a.confirmed);
    const visible = confirmed.filter((a) => passesFilters(a));
    visibleCount = visible.length;
    sortArbs(visible);

    const created = syncRows(els.body, visible, {
      key: instKey,
      rowClass: (a) => `tier-${profitTier(a.profit_pct)}`,
      cells: arbCells,
    });
    const now = Date.now();
    for (const tr of created) {
      const until = flashUntil.get(tr.dataset.key);
      if (until && until > now) {
        tr.setAttribute('data-flash', '');
        setTimeout(() => tr.removeAttribute('data-flash'), 3000);
      } else if (renderedOnce) {
        markEntering([tr]);
      }
    }
    renderedOnce = true;

    els.tableWrap.hidden = visible.length === 0;
    if (visible.length) {
      els.empty.hidden = true;
    } else {
      els.empty.hidden = false;
      if (confirmed.length) {
        setHTML(
          els.empty,
          emptyHtml({
            icon: 'filter',
            title: 'Нет вилок, подходящих под фильтры',
            text: `${confirmed.length} ${plural(confirmed.length, ['вилка скрыта', 'вилки скрыты', 'вилок скрыто'])} фильтрами.`,
            actionHtml: '<button type="button" class="btn btn-sm" data-action="reset-filters">Сбросить фильтры</button>',
          }),
        );
      } else {
        const pairs = st.counts?.pairs ?? (st.pairs || []).length;
        setHTML(
          els.empty,
          emptyHtml({
            icon: 'activity',
            title: 'Сейчас активных вилок нет',
            text: `Сканер следит за ${pairs} ${plural(pairs, ['парой', 'парами', 'парами'])} матчей. Вилка появится здесь, когда просуществует не меньше ${fmtNum(confirmSeconds(), 0, 1)} с.`,
          }),
        );
      }
    }
    const candidates = renderCandidates(st);
    renderSummary(confirmed, visible, candidates);
    onVisibleChange?.();
  }

  // ------------------------------------------------------------ wiring

  els.candidates.open = !!prefs.candidatesOpen;
  els.candidates.addEventListener('toggle', () => {
    prefs.candidatesOpen = els.candidates.open;
    savePrefs();
  });

  syncFilterControls();
  syncSortHeaders();
  updateFill();

  return {
    render,
    onShow: render,
    onMeta() {
      syncFilterControls();
    },
    onState(st) {
      const fresh = detect(st);
      if (isActive()) render();
      else visibleCount = (st.arbs || []).filter((a) => a.confirmed && passesFilters(a)).length;
      announce(fresh);
    },
    visibleCount: () => visibleCount,
    resetFilters,
  };
}
