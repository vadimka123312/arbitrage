// "Сопоставленные пары": all matched pairs with prices aligned to the left market's team order.

import { icons } from '../icons.js';
import { platformInfo, prefs, savePrefs, store } from '../store.js';
import { emptyHtml, markEntering, setHTML, skeletonHtml, syncRows } from '../ui.js';
import { $, esc, fmtNum, fmtPct, fmtPrice, isNum, parseTs, profitTier } from '../util.js';
import { NOT_ACTIONABLE_HINT, alignedRight, confidenceBadge, directionText, gameBadge, linkButton, quoteCells, startCell, teamsHtml, warningsButton } from './common.js';

export function freshnessText(market) {
  if (market.platform === 'bcgame') {
    return market.fresh
      ? 'Состояние подтверждено недавней синхронизацией. Время изменения коэффициентов неизвестно.'
      : 'Синхронизация устарела — пара не участвует в расчёте вилок.';
  }
  return market.fresh
    ? 'Котировки свежие.'
    : 'Котировки устарели — пара не участвует в расчёте вилок.';
}

function matchHtml(p) {
  const L = p.left || {};
  const R = p.right || {};
  const ar = alignedRight(p);
  const rpf = platformInfo(R.platform, R.platform_name).short;
  const swap = p.swapped
    ? `<span class="swap-mark has-pop" tabindex="0" data-pop data-pop-key="swap:${esc(p.pair_key)}">${icons.swap}<template class="pop-src"><div class="pop-title">Обратный порядок команд</div>На ${esc(rpf)} матч записан как «${esc(R.team_a)}» vs «${esc(R.team_b)}». Цены в таблице выровнены по порядку команд слева.</template></span>`
    : '';
  return `<div class="match"><div title="${esc(rpf)}: ${esc(ar.teamA || '?')} / ${esc(ar.teamB || '?')}">${teamsHtml(L.team_a, L.team_b)}</div><div class="match-sub">${gameBadge(p.game)}${swap}<span class="tournament" title="${esc(L.event_title || '')}">${esc(L.tournament || R.tournament || '')}</span></div></div>`;
}

function quotesHtml(p) {
  const L = p.left || {};
  const R = p.right || {};
  const ar = alignedRight(p);
  const lpf = platformInfo(L.platform, L.platform_name);
  const rpf = platformInfo(R.platform, R.platform_name);
  const dir = p.best ? p.best.direction : null;
  const side = (m, pf, tag) => {
    const ts = parseTs(m.updated_at);
    const names = tag === 'L' ? `${m.team_a || '?'} / ${m.team_b || '?'}` : `${ar.teamA || '?'} / ${ar.teamB || '?'}`;
    const updateLabel = m.platform === 'bcgame' ? 'Последняя успешная синхронизация' : 'Обновлено';
    const tip = `<div class="pop-title">${esc(pf.name)}</div><div>${esc(freshnessText(m))}</div><dl class="pop-kv" style="margin-top:6px"><dt>${esc(updateLabel)}</dt><dd data-tick="ago" data-ts="${Number.isFinite(ts) ? ts : ''}"></dd><dt>Команды</dt><dd>${esc(names)}</dd><dt>Рынок</dt><dd>${esc(m.market_id || '—')}</dd></dl>${m.event_title ? `<div class="pop-note">${esc(m.event_title)}</div>` : ''}`;
    return `<span class="q-pf" style="--pf:${pf.color}" tabindex="0" data-pop data-pop-key="fresh:${tag}:${esc(p.pair_key)}"><span class="fresh-dot${m.fresh ? '' : ' stale'}"></span>${esc(pf.short)}<template class="pop-src">${tip}</template></span>`;
  };
  const val = (c, best) => {
    const size = isNum(c.size) ? `${c.executed ? 'в расчёте' : 'доступно'}: ${fmtNum(c.size, 0, 2)} контр.` : '';
    const title = [c.instrument ? `инструмент: ${c.instrument}` : '', size].filter(Boolean).join(' · ');
    return `<span class="q-val${best ? ' best' : ''}"${title ? ` title="${esc(title)}"` : ''}>${fmtPrice(c.ask)}</span>`;
  };
  const c = quoteCells(p);
  return `<div class="quotes">
    <span></span><span class="q-head" title="${esc(L.team_a)}">${esc(L.team_a || 'A')}</span><span class="q-head" title="${esc(L.team_b)}">${esc(L.team_b || 'B')}</span>
    ${side(L, lpf, 'L')}${val(c.leftA, dir === 'A')}${val(c.leftB, dir === 'B')}
    ${side(R, rpf, 'R')}${val(c.rightA, dir === 'B')}${val(c.rightB, dir === 'A')}
  </div>`;
}

function bestHtml(p) {
  const b = p.best;
  if (!b) return '<span class="faint" title="Нет цен на одной из сторон">—</span>';
  const q = p.quotes || {};
  const rows = ['A', 'B']
    .filter((d) => q[d])
    .map((d) => `<dt>${esc(directionText(p, d))}</dt><dd>${fmtPrice(q[d].sum_ask)} · ${fmtPct(q[d].profit_pct)}</dd>`)
    .join('');
  return `<span class="has-pop" tabindex="0" data-pop data-pop-key="best:${esc(p.pair_key)}"><span class="money">${fmtPrice(b.sum_ask)}</span><template class="pop-src"><div class="pop-title">Направления сделки</div><dl class="pop-kv">${rows}</dl><div class="pop-note">Подсвечены цены лучшего направления. Сумма — лучшие цены покупки обеих сторон без комиссий.</div></template></span>`;
}

function profitHtml(p) {
  const b = p.best;
  if (!b || !isNum(b.profit_pct)) return '<span class="faint">—</span>';
  if (b.actionable === false) {
    return `<span class="profit neg" title="${esc(NOT_ACTIONABLE_HINT)}">${fmtPct(b.profit_pct)}</span><div class="not-actionable" title="${esc(NOT_ACTIONABLE_HINT)}">неактуально</div>`;
  }
  const cls = b.profit_pct > 0 ? `profit tier-${profitTier(b.profit_pct)}` : 'profit neg';
  return `<span class="${cls}">${fmtPct(b.profit_pct)}</span>`;
}

function actionsHtml(p) {
  const label = esc(`${p.left?.team_a || '?'} vs ${p.left?.team_b || '?'}`);
  const key = esc(p.pair_key);
  const unconfirm =
    p.status === 'confirmed'
      ? `<button type="button" class="btn btn-xs" data-override="clear" data-pair="${key}" data-prev="confirmed" data-label="${label}">${icons.undo}Снять подтверждение</button>`
      : '';
  return `<div class="row-actions">${unconfirm}<button type="button" class="btn btn-xs btn-danger" data-override="blocked" data-pair="${key}" data-prev="${esc(p.status)}" data-label="${label}">${icons.ban}Заблокировать</button></div>`;
}

function pairCells(p) {
  return [
    matchHtml(p),
    startCell(p.start_time, p.is_live),
    quotesHtml(p),
    { html: bestHtml(p), cls: 'num' },
    { html: profitHtml(p), cls: 'num' },
    { html: warningsButton(p.warnings, `pwarn:${p.pair_key}`), cls: 'center' },
    { html: confidenceBadge(p.confidence, p.status), cls: 'center' },
    `<div class="links">${linkButton(p.left?.platform, p.left?.platform_name, p.left?.url)}${linkButton(p.right?.platform, p.right?.platform_name, p.right?.url)}</div>`,
    actionsHtml(p),
  ];
}

const actionable = (p) => (p.best && p.best.actionable !== false ? 1 : 0);
const SORTERS = {
  // Pairs whose quotes are outdated or paused ("неактуально") go last, whatever their old profit.
  profit: (a, b) => actionable(b) - actionable(a) || (b.best?.profit_pct ?? -Infinity) - (a.best?.profit_pct ?? -Infinity),
  start: (a, b) => (parseTs(a.start_time) || Infinity) - (parseTs(b.start_time) || Infinity),
  confidence: (a, b) => (b.status === 'confirmed') - (a.status === 'confirmed') || b.confidence - a.confidence,
};

function haystack(p) {
  const L = p.left || {};
  const R = p.right || {};
  return [L.team_a, L.team_b, R.team_a, R.team_b, L.event_title, R.event_title, L.tournament, R.tournament]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();
}

export function createPairsView({ isActive, fillGameSelect }) {
  const els = {
    search: $('#p-search'),
    game: $('#p-game'),
    sort: $('#p-sort'),
    summary: $('#p-summary'),
    body: $('#p-body'),
    empty: $('#p-empty'),
  };
  els.tableWrap = els.body.closest('.table-wrap');
  let renderedOnce = false;

  function syncControls() {
    const p = prefs.pairs;
    els.search.value = p.search;
    fillGameSelect(els.game, p.game);
    els.sort.value = SORTERS[p.sort] ? p.sort : 'profit';
  }

  function render() {
    const st = store.state;
    if (!st) {
      els.tableWrap.hidden = true;
      els.empty.hidden = false;
      setHTML(els.empty, skeletonHtml(5));
      return;
    }
    const all = st.pairs || [];
    const term = prefs.pairs.search.trim().toLowerCase();
    const list = all.filter((p) => (!prefs.pairs.game || p.game === prefs.pairs.game) && (!term || haystack(p).includes(term)));
    list.sort(SORTERS[prefs.pairs.sort] || SORTERS.profit);

    const created = syncRows(els.body, list, { key: (p) => p.pair_key, cells: pairCells });
    if (renderedOnce) markEntering(created);
    renderedOnce = true;
    els.tableWrap.hidden = list.length === 0;
    els.empty.hidden = list.length > 0;
    if (!list.length) {
      setHTML(
        els.empty,
        all.length
          ? emptyHtml({ icon: 'search', title: 'Ничего не найдено', text: 'Нет пар, подходящих под поиск и фильтр игры.', actionHtml: '<button type="button" class="btn btn-sm" data-action="pairs-reset">Сбросить поиск</button>' })
          : emptyHtml({ icon: 'plug', title: 'Пары ещё не найдены', text: 'Сопоставление выполняется автоматически, как только с платформ приходят рынки.' }),
      );
    }
    const live = all.filter((p) => p.is_live).length;
    const manual = all.filter((p) => p.status === 'confirmed').length;
    const stale = all.filter((p) => p.best?.actionable === false || (p.left && p.right && (!p.left.fresh || !p.right.fresh))).length;
    const parts = [`Пар: <b>${all.length}</b>`];
    if (list.length !== all.length) parts.push(`показано: <b>${list.length}</b>`);
    parts.push(`live: <b>${live}</b>`, `подтверждено вручную: <b>${manual}</b>`);
    if (stale) parts.push(`<span title="${esc(NOT_ACTIONABLE_HINT)}">неактуальные цены: <b>${stale}</b></span>`);
    setHTML(els.summary, parts.join('<span class="sep">·</span>'));
  }

  els.search.addEventListener('input', () => {
    prefs.pairs.search = els.search.value;
    savePrefs();
    render();
  });
  els.game.addEventListener('change', () => {
    prefs.pairs.game = els.game.value;
    savePrefs();
    render();
  });
  els.sort.addEventListener('change', () => {
    prefs.pairs.sort = els.sort.value;
    savePrefs();
    render();
  });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('[data-action="pairs-reset"]')) return;
    prefs.pairs.search = '';
    prefs.pairs.game = '';
    savePrefs();
    syncControls();
    render();
  });

  syncControls();

  return {
    render,
    onShow: render,
    onMeta() {
      syncControls();
      if (isActive()) render();
    },
  };
}
