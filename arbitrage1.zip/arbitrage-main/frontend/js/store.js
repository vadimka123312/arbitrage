// Shared app state: META, latest STATE, UI preferences (localStorage), server clock, events.

import { DEFAULT_DAYS } from './stats-format.js';
import { fallbackColor, parseTs, safeColor, shortName } from './util.js';

const PREFS_KEY = 'esports-arb-scanner.prefs.v1';

export const DEFAULT_FILTERS = { game: '', minProfit: '', minVolume: '', live: 'all' };

const DEFAULT_PREFS = {
  tab: 'arbs',
  filters: { ...DEFAULT_FILTERS },
  arbSort: { key: 'profit', dir: 'desc' },
  candidatesOpen: true,
  blockedOpen: false,
  sound: false,
  notify: false,
  history: { game: '', minProfit: '', confirmedOnly: false },
  stats: { days: DEFAULT_DAYS },
  pairs: { search: '', game: '', sort: 'profit' },
};

function loadPrefs() {
  let saved = {};
  try {
    saved = JSON.parse(localStorage.getItem(PREFS_KEY) || '{}') || {};
  } catch {
    saved = {};
  }
  const prefs = {};
  for (const [key, def] of Object.entries(DEFAULT_PREFS)) {
    const value = saved[key];
    if (def && typeof def === 'object') {
      prefs[key] = { ...def, ...(value && typeof value === 'object' ? value : {}) };
    } else {
      prefs[key] = value === undefined ? def : value;
    }
  }
  return prefs;
}

export const prefs = loadPrefs();

export function savePrefs() {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  } catch {
    /* storage may be disabled — preferences then live for this page only */
  }
}

export const store = {
  meta: null,
  state: null,
  clockOffset: 0, // server time minus local time, ms
  lastDataAt: 0, // local time when the shown STATE was last confirmed current (STATE or matching heartbeat)
  evalLagMs: null, // server_time − last_eval_at of the latest STATE / heartbeat (server clock only)
  evalLagSince: 0, // local time since when evalLagMs has stayed above EVAL_STALE_MS (0 = not lagging)
  // ws: connecting | open (messages arrive) | closed; poll: idle | ok | fail (REST fallback)
  conn: { ws: 'connecting', poll: 'idle', retryAt: 0, lastMessageAt: 0 },
};

/** Data not confirmed by the server for this long is outdated: banner, dimmed tables, frozen timers. */
const DATA_STALE_MS = 6000;
/** The scanner evaluates every 0.5 s; no evaluation for this long means it is stuck. */
const EVAL_STALE_MS = 5000;
/**
 * The lag must persist this long before the scanner counts as stuck: a server resuming after a freeze answers
 * once with its pre-freeze evaluation time before its first new evaluation (within 0.5 s).
 */
const STALL_CONFIRM_MS = 1500;

/**
 * True when what is shown is outdated: both channels fail right now (socket closed, REST failing),
 * or the server has not confirmed the data for DATA_STALE_MS (frozen server, silent socket).
 */
export function isStale() {
  if (store.conn.ws !== 'open' && store.conn.poll === 'fail') return true;
  return store.lastDataAt > 0 && Date.now() - store.lastDataAt > DATA_STALE_MS;
}

/**
 * True when the server answers but its scanner stopped evaluating. Uses only the server's own clock
 * (server_time − last_eval_at of the latest message), so silence, a slow link or a local clock jump
 * never look like a stuck scanner; silence is covered by isStale().
 */
export const scannerStalled = () =>
  !isStale() && store.evalLagSince > 0 && Date.now() - store.evalLagSince >= STALL_CONFIRM_MS;

function noteEvalLag(serverTime, lastEvalAt) {
  const lag = parseTs(serverTime) - parseTs(lastEvalAt);
  store.evalLagMs = Number.isFinite(lag) ? Math.max(0, lag) : null;
  if (store.evalLagMs === null || store.evalLagMs <= EVAL_STALE_MS) store.evalLagSince = 0;
  else if (!store.evalLagSince) store.evalLagSince = Date.now();
}

/** Server-clock moment the shown data is valid for: timers stop there while data is outdated. */
export function dataNow() {
  if (isStale() && store.lastDataAt) return store.lastDataAt + store.clockOffset;
  if (scannerStalled()) return parseTs(store.state.last_eval_at);
  return serverNow();
}

// ---------------------------------------------------------------- events

const listeners = new Map();

export function on(event, fn) {
  if (!listeners.has(event)) listeners.set(event, new Set());
  listeners.get(event).add(fn);
  return () => listeners.get(event).delete(fn);
}

export function emit(event, payload) {
  for (const fn of listeners.get(event) || []) {
    try {
      fn(payload);
    } catch (err) {
      console.error(`[${event}] handler failed`, err);
    }
  }
}

// ---------------------------------------------------------------- server clock

const offsetSamples = [];

/**
 * Track the server/local clock offset from `server_time`. A sample can only
 * under-estimate the true offset (network delay, cached snapshots), so the max
 * of a recent window is the best estimate.
 */
export function noteServerTime(iso) {
  const t = parseTs(iso);
  if (!Number.isFinite(t)) return;
  offsetSamples.push(t - Date.now());
  if (offsetSamples.length > 20) offsetSamples.shift();
  store.clockOffset = Math.max(...offsetSamples);
}

export const serverNow = () => Date.now() + store.clockOffset;

// ---------------------------------------------------------------- state intake

/** Accept a STATE payload; returns false when it is older than what we have. */
export function acceptState(next) {
  if (!next || typeof next !== 'object') return false;
  store.lastDataAt = Date.now();
  noteServerTime(next.server_time);
  noteEvalLag(next.server_time, next.last_eval_at); // also for a cached snapshot (same version, fresh server_time)
  const current = store.state;
  if (current && current.started_at === next.started_at && next.version <= current.version) return false;
  store.state = next;
  emit('state', next);
  return true;
}

/**
 * Accept a heartbeat (the server had nothing new to send). It confirms that the shown STATE is still
 * the server's current one; returns false when it is not (a STATE was missed and must be fetched).
 */
export function acceptHeartbeat(beat) {
  if (!beat || typeof beat !== 'object') return true;
  noteServerTime(beat.server_time);
  noteEvalLag(beat.server_time, beat.last_eval_at);
  const current = store.state;
  if (!current || current.started_at !== beat.started_at || current.version !== beat.version) return false;
  store.lastDataAt = Date.now();
  return true;
}

export function acceptMeta(meta) {
  if (!meta || typeof meta !== 'object') return;
  store.meta = meta;
  emit('meta', meta);
}

// ---------------------------------------------------------------- lookups

/** Platform display info from STATE / META (no hard-coded platform list). */
export function platformInfo(id, fallbackName) {
  const fromState = store.state?.platforms?.find((p) => p.platform === id);
  const fromMeta = store.meta?.platforms?.find((p) => p.id === id);
  const name = fromState?.name || fromMeta?.name || fallbackName || id || '?';
  const color = safeColor(fromState?.color || fromMeta?.color, fallbackColor(id));
  return { id, name, short: shortName(name), color };
}

/** Labels describe what platform status timestamps actually measure. */
export function platformTimingInfo(id) {
  if (id === 'bcgame') {
    return {
      latencyLabel: 'Последний HTTP-ответ', latencyInline: 'HTTP-ответ', latencyCompact: 'HTTP',
      updateLabel: 'Последняя успешная синхронизация', updateInline: 'синхронизировано', updatePrefix: 'синхр. ',
      note: 'Время HTTP включает long-poll и загрузку одного ответа. Это не возраст коэффициентов: BETBY не сообщает его отдельно.',
    };
  }
  return {
    latencyLabel: 'Задержка', latencyInline: 'задержка', latencyCompact: '',
    updateLabel: 'Обновлено', updateInline: 'обновлено', updatePrefix: 'обновлено ', note: '',
  };
}

export function gameInfo(id) {
  const game = store.meta?.games?.find((g) => g.id === id);
  return { id, name: game?.name || id || '?', short: game?.short || game?.name || id || '?' };
}

export function currentSettings() {
  return store.state?.settings || store.meta?.settings || {};
}

export function confirmSeconds() {
  const v = Number(currentSettings()['engine.confirm_seconds']);
  return Number.isFinite(v) ? v : 5;
}
