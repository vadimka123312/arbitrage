// Sound (WebAudio, no files) and browser notifications for new confirmed arbs.

let audioCtx = null;

/** Create / resume the AudioContext. Call from a user gesture (autoplay policy). */
export function unlockAudio() {
  if (!audioCtx) {
    const AudioCtor = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtor) return null;
    try {
      audioCtx = new AudioCtor();
    } catch {
      return null;
    }
  }
  if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
  return audioCtx;
}

export const audioReady = () => !!audioCtx && audioCtx.state === 'running';

let lastBeepAt = 0;

/** Short two-tone chime. Returns false when audio is not unlocked yet. */
export function beep() {
  if (!audioCtx) return false;
  const nowMs = Date.now();
  if (nowMs - lastBeepAt < 800) return true; // de-duplicate bursts
  lastBeepAt = nowMs;
  if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
  const start = audioCtx.currentTime + 0.02;
  const tone = (freq, at, duration, volume) => {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, at);
    gain.gain.setValueAtTime(0.0001, at);
    gain.gain.exponentialRampToValueAtTime(volume, at + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(at);
    osc.stop(at + duration + 0.03);
  };
  tone(880, start, 0.16, 0.18);
  tone(1318.5, start + 0.12, 0.24, 0.16);
  return true;
}

export const notifySupported = () => typeof window !== 'undefined' && 'Notification' in window;

export function notifyPermission() {
  return notifySupported() ? Notification.permission : 'unsupported';
}

export async function requestNotifyPermission() {
  if (!notifySupported()) return 'unsupported';
  if (Notification.permission !== 'default') return Notification.permission;
  try {
    return await Notification.requestPermission();
  } catch {
    return Notification.permission;
  }
}

/** Fire a system notification (no-op without permission). */
export function showNotification(title, body, tag, onClick) {
  if (!notifySupported() || Notification.permission !== 'granted') return;
  try {
    const n = new Notification(title, { body, tag, renotify: false });
    n.onclick = () => {
      window.focus();
      if (onClick) onClick();
      n.close();
    };
    setTimeout(() => n.close(), 20000);
  } catch {
    /* some platforms (e.g. Android Chrome) only allow notifications from a service worker */
  }
}
