"""Start the Esports Arb Scanner: ``python run.py`` (real data) or ``python run.py --mock``."""

from backend.run import main

if __name__ == "__main__":
    main()
