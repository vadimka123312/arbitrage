"""Report from the SQLite history: ``python report.py`` (last 7 days), ``python report.py --days 30 --json``."""

import sys

from backend.report import main

if __name__ == "__main__":
    sys.exit(main())
